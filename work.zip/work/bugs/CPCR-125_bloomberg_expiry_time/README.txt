# The fix for the timer is to change the following, its tested and works!!

<mapField destField="convTimeLimit" sourceField="TotalTradeTime"/>

# For an outright we have the following

a) At  13:59:21 we get the following from Bloomberg

    'SecondsTillExpiry': 59L
    'TotalTradeTime': '00090'

   The autoquoter has the following

    <field name="convTimeLimit" value="59" />
    <field name="convTimeRemaining" value="38" />

b) At 13:59:41 we get the following    

    'SecondsTillExpiry': 69L
    'TotalTradeTime': '00090'

    We go negative in the autoquoter

    <field name="convTimeLimit" value="59" />
    <field name="convTimeRemaining" value="-5" />

c) At 14:00:25  we get the following from Bloomberg

    'SecondsTillExpiry': 25L
    'TotalTradeTime': '00090'


d) The expiry message from bloomberg comes at 14:00:52

    'SecondsTillExpiry': 0L
    'TotalTradeTime': '00090'

# This looks like the actual field to be used

 'TotalTradeTime': 180L

# The negotiation for a switch had the following time limit settings

a) At 11:58:07 the initial message that comes from Bloomberg has

   'SecondsTillExpiry': 119L
   'TotalTradeTime': 180L

   Our bet gateway has the following initialisation

   <field name="convTimeLimit" value="119" /> 
   <field name="convTimeRemaining" value="118" />

b) Then at 11:58:53 we get the following message from Bloomberg

    'SecondsTillExpiry': 132L
    'TotalTradeTime': 180L

    Our bet gateway has the following

    <field name="convTimeLimit" value="119" /> 
    <field name="convTimeRemaining" value="72" />

c) Then at 11:59:38 we get the following from Bloomberg

    'SecondsTillExpiry': 88L
    'TotalTradeTime': 180L

    When out bet gateway shows


    <field name="convTimeLimit" value="119" />
    <field name="convTimeRemaining" value="28" />

d) At 12:00:16 we have 

    'SecondsTillExpiry': 49L,
    'TotalTradeTime': 180L

e) Finally at 12:00:22 we get

    'SecondsTillExpiry': 0L
    'TotalTradeTime': 180L

# After you counter the SecondsTillExpiry turns to the following by the convTimeLimit remains

 'SecondsTillExpiry': 92L

# The mapping from SecondsTillExpiry from BBG and convTimeLimit in CP is in bloomberg-betgateway2-bonds-messagemap.xml

<mapField destField="convTimeLimit" sourceField="SecondsTillExpiry"/>

# Here is the data we recieve from Bloomberg in the bloomberg-betgateway2-bonds

'SecondsTillExpiry': 149L

# The following are the initial attributes that come with the RFQ

convTimeLimit='59'
convStartTime='2010-04-26 04:05:00.000'

# Below is were the initial AqInitialMessage with the convTimeLimit comes in

ConversationRequestDispatcher.put(AqGetSetableMessage) line: 234	
AQProcessor.onMessage(AqMessage) line: 47	
GatewayAdapter$2.dispatch(Object, Object) line: 122	
ListenerList.notifyListeners(Object, ListenerList$Dispatcher) line: 128	
GatewayAdapter.processIncomingMessage(AqMessage) line: 425	
GatewayAdapter.access$700(GatewayAdapter, AqMessage) line: 47	
GatewayAdapter$5.onMessage(AqMessage) line: 371	
AqMessageListener$1.dispatch(Object, Object) line: 22	
ListenerList.notifyListeners(Object, ListenerList$Dispatcher) line: 128	
ListenerList.notifyListeners(Object) line: 112	
AqMessageProducer$1.consume(Object) line: 157	
ProducerConsumer.runConsumerLoop() line: 292	
ProducerConsumer.access$100(ProducerConsumer) line: 24	
ProducerConsumer$1.run() line: 214	
Thread.run() line: 619	

# This is the conversation time limit for an outright

      <field name="convTimeLimit" value="149" />
      <field name="convTimeRemaining" value="144" />

# The wire time seems to be defined by the following for switches

      <field name="convTimeLimit" value="59" />
      <field name="convTimeRemaining" value="38" />
