# This is how we append the intervention reason to the conversation

com.rbsfm.fi.bet.autoquoter.business.conversation.DefaultConversation.addInterventionReason(java.lang.String) line: 382	
com.rbsfm.fi.bet.autoquoter.business.conversation.DefaultConversation.addInterventionReason(java.lang.String, com.rbsfm.fi.pricing.ecn.util.Severity) line: 394	
com.rbsfm.fi.bet.autoquoter.business.step.AQDetermineCustomerStatus.performStep(com.rbsfm.fi.bet.autoquoter.business.conversation.IConversation) line: 75	
com.rbsfm.fi.bet.autoquoter.business.action.MultiInquiryOrderAction(com.rbsfm.fi.bet.autoquoter.business.action.AbstractBusinessAction).executeStepsThenBusinessLogic(com.rbsfm.fi.bet.autoquoter.business.conversation.IConversation) line: 105	
com.rbsfm.fi.bet.autoquoter.business.action.StartBusinessAction(com.rbsfm.fi.bet.autoquoter.business.action.AbstractBusinessAction).carryOutNextBusinessLogic(com.rbsfm.fi.bet.autoquoter.business.conversation.IConversation, com.rbsfm.fi.bet.autoquoter.business.action.IBusinessAction) line: 76	
com.rbsfm.fi.bet.autoquoter.business.action.StartBusinessAction.executeBusinessLogic(com.rbsfm.fi.bet.autoquoter.business.conversation.IConversation) line: 100	
com.rbsfm.fi.bet.autoquoter.business.conversation.ConversationRequestHandler.doAction(com.rbsfm.fi.bet.autoquoter.business.conversation.IInternalConversation) line: 418	
com.rbsfm.fi.bet.autoquoter.business.conversation.ConversationRequestHandler.processIncoming(com.rbsfm.fi.pricing.ecn.autoquote.external.message.AqGetSetableMessage) line: 190	
com.rbsfm.fi.bet.autoquoter.business.conversation.ConversationRequestHandler.handleConversationMessage(com.rbsfm.fi.pricing.ecn.autoquote.external.message.AqGetSetableMessage) line: 157	
com.rbsfm.fi.bet.autoquoter.business.conversation.ConversationRequestDispatcher$1.dispatch() line: 240	
com.rbsfm.fi.bet.autoquoter.business.conversation.ConversationRequestDispatcher$ConversationRequests.run() line: 83	
com.rbsfm.fi.pricing.util.ThreadPool$DefaultThreadPool$WorkerThread.internalRun() line: 217	
com.rbsfm.fi.pricing.util.ThreadPool$DefaultThreadPool$WorkerThread$1.run() line: 191	
java.lang.Thread.run() line: 619	

