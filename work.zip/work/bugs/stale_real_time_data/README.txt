# The following calculators represent the 9m points

18544442 -> "CEEMEA.FRA_HUF.9m_quot" ->  Bad point for [3342293] 9m in .\..\curves\local\LIBOR\HUF\FRA.HUF IS_INACTIVE{1}!!
18544442 -> "CEEMEA.FRA_HUF.9m_quot" -> Bad point for [3342293] 9m in .\..\curves\local\LIBOR\HUF\FRA.HUF IS_INACTIVE{1}!!

# Entry in the FRA.HUF file is 

{id="9m",type="it_fixed_loan",start_date="settle",start_date_jd=40144,end_date="9m",end_date_jd=40417,input_rule="ir_input",status="is_peripheral",observable=1,discount_curve="FRA.HUF",payment_period="6m",accrual_basis="act360",priority=8}

{id="9m",type="it_interest_rate_swap",start_date="settle",start_date_jd=40144,end_date="9m",end_date_jd=40417,input_rule="ir_coupon_linear",status="is_inactive",observable=0,fixed_side={discount_curve="FRA.HUF",payment_period="6m",accrual_basis="act360"} float_side={discount_curve="FRA.HUF",payment_period="6m",accrual_basis="act360",projection_curve="FRA.HUF",reset_period="6m",reset_convention="swap"}


{id="9m",type="it_fixed_loan",input_values=<{type="iv_rate",value=0}>} {id="12m",type="it_fixed_loan",input_values=<{type="iv_rate",value=0.056}>} {id="30m",type="it_fixed_loan",input_values=<{type="iv_rate",value=0}>

# The 9m point for FRA_HUF is CurvePoint.getType() 

SYNTHETIC

# The following point is an IR_COUPON_LINEAR rule

CEEMEA.FRA_HUF.9m_quot

# The result is that we set the curve point status to INACTIVE

curvePoint.setStatus(CurvePointStatus.INACTIVE);

# We then check the calculator status before publishing the data with

boolean isStatusOk = getStatus().isOK();

# When the node is invalid because of

          if(!isQuoteValid(inputValues[RATE].getValue(), curvePoint.getInstrumentCategory().getId())) {
            propagateStatus(StatusType.STALE, "Quote invalid");
          }


# The NodeManager says that the quote is invalid

18v21_quot 30 Stale real-time data Quote invalid com.rbsfm.fi.pricing.dependency.curve.CurvePointQuoteCalculator 
