# Building the bloomberg bet gateway

1) To acquire the tag associated with the UAT and PROD deployments use the following
   command with cpadmin.

    cpadmin>tag uat-bloomberg-betgateway2-bonds
    uat-bloomberg-betgateway2-bonds betgateway2-1_0_4

   or for PROD

    cpadmin>tag prod-bloomberg-betgateway2-bonds
    prod-bloomberg-betgateway2-bonds betgateway2-1_0_4

2) Once the tag has been acquired the build machine can be invoked from the following
   address.

   http://lonms02482:44444/netbuild/netbuild?action=build

   Here you need to provide the tag, which is "betgateway2-1_0_4" and the
   regular expression "bloomberg-.*"

3) The build server can be logged on to using remote desktop. To logon using
   remote desktop you will need a CyberArk account, which is temporarily.

    ca_dm_ecomtech_118
    c5U8puy

4) Currently CVS is pointing to the new server as the old server no longer
   exists.

   <target name="cvs.init" depends="init">
     <property name="my.cvs.user" value="tofti" />
     <property name="tag.options" value="" />
     <property name="cvs.password" value="" />
     <property name="cvs.server" value="lonrs05497" />
     <property name="cvs.passfile" value="${basedir}/.cvspass" />
     <echo>cvs.user= ${cvs.user}</echo>
     <property name="cvs.root" value=":pserver:${my.cvs.user}@${cvs.server}:/opt/data/cp/scm/cvs" />
     <echo>cvs.root=${cvs.root}</echo>
     <cvspass cvsroot="${cvs.root}" password="${cvs.password}" passfile="${cvs.passfile}" />
   </target>

5) To make changes that will be picked up by the build you will need to check out the
   build tag locally. Once this is done files can be modified and tagged so that they
   will be picked up. The build artifacts will appear in an address like the following.

   http://lonms02482:44444/builds/netbuild1247754763924-uat-betgateway2-1_0_4/egpricing/

   You can download the build artifcat from there. For example.

   egpricing.betgateway2-1_0_4.uat.zip 

   This can then be deployed manually to the build machine.

6) To install the process run the following command.

   bloomberg-betgateway2-stamford_bonds.exe -install

7) When installed as a service exeucte the service manager by selecting. Start > Run and 
   entering the following executable.

   services.msc

8) Looking at the <environment>_server_build.xml files it looks as the the contingency and local
   environments do not have an entry for the bloomberg-betgateway2-stamford_bonds.xml.  

   local_server_build.xml
   cont_server_build.xml

   Also some of the server details seem to be missing from the following.

   prod_server_details.xml

9) The current london UAT bloomberg-betgateway2-bonds gateway uses the following Bloomberg
   host and port.

   host: 160.43.166.170
   port: 20481

   This is accessed through a firewall and should be accessible from the betgateway2 host.
   If the Stamford instance is going to use a different address to the London instance then
   the following should be used to request a firewall change.

   http://sharepointit/it/Security/default.aspx

   For example.

   http://sharepointit/it/Security/Lists/Request%20Submission/DispForm.aspx?ID=4452&Source=http%3A%2F%2Fsharepointit%2Fit%2FSecurity%2Fdefault.aspx

10) In order to patch the bonds_stanford release the patch.jar needs to be copied from the
    following production machine.

    \\lonms05305\readonly\rbsfm\egpricing\aqrouter-2_0_4_release\lib

    Also, a copy of the configuration needs to be taken.
   


   
   


   
