1) CEEMEA.grid.config

			<books>
            <book id="CEEMEA-HUF" name="HUF"/>
            <book id="CEEMEA-PLN" name="PLN"/>
            <book id="CEEMEA-CZK" name="CZK"/>
            <book id="CEEMEA-ZAR" name="ZAR"/>
            <book id="CEEMEA-RUB" name="RUB"/>
            <book id="CEEMEA-TRY" name="TRY"/>
            <book id="CEEMEA-ILS" name="ILS"/>
			</books>

2) bond.xml

    <field name="BrokerCode" displayName="BCode" longName="Broker Code" dataType="System.String" editType="edit" align="left" width="60" contextField="ticker"/>        

3) bond.xml

		<field name="YSprd2Bond_benId" displayName="Bench" dataType="System.String" editType="selection" selectionType="treeBondIds" width="60" backColour="#FFFFC0" align="left" />

4) bond.xml

		<field name="YSprd2Bond_benSprd" displayName="Spd" dataType="System.Double" editType="edit" slave="True" multiplier="10000" format="+0.00;-0.00" width="55" backColour="#FFFFC0" fontFormat="Bold"/>

5) future.xml

  <group id="Analytics">  
        <!-- Duration Analytic -->    
        <field name="duration.1000.S" displayName="duration.1000.S" longName="Duration (sell)" dataType="System.Double" width="60" editType="none" />    
        <field name="duration.1000.B" displayName="duration.1000.B" longName="Duration (buy)" dataType="System.Double" width="60" editType="none" />
            
        <!-- Return Analytic -->
        <field name="return.60" displayName="return.60" longName="60 second log return" dataType="System.Double" width="60" editType="none" />
        	  	
        <!-- Mu Analytic - weighted moving average -->
        <field name="mu.60" displayName="mu.60" longName="Weighted moving average 60 second return" dataType="System.Double" width="60" editType="none" />
        <field name="sigma.60" displayName="sigma.60" longName="Std(60 second return)" dataType="System.Double" width="60" editType="none" />
        	  	   
        <!-- VWAP Analytic - VWAP average 60 second return -->  	
        <field name="vwap.today" displayName="vwap.today" longName="Volume weighted price 1s window" dataType="System.Double" width="60" editType="none" />
        <field name="vwap.60" displayName="vwap.60" longName="Volume weighted price 60s window" dataType="System.Double" width="60" editType="none" />
        <field name="vwap.120" displayName="vwap.120" longName="Volume weighted price 120s window" dataType="System.Double" width="60" editType="none" />
        <field name="vwap.300" displayName="vwap.300" longName="Volume weighted price 300s window" dataType="System.Double" width="60" editType="none" />
        <field name="vwap.1200" displayName="vwap.1200" longName="Volume weighted price 1200s window" dataType="System.Double" width="60" editType="none" />
        
        <!-- Volume Analytics -->
        <field name="volume.today" displayName="volume.today" longName="Volume today" dataType="System.Double" width="60" editType="none" />
        <field name="volume.60" displayName="volume.60" longName="Volume 60s window" dataType="System.Double" width="60" editType="none" />
        <field name="volume.120" displayName="volume.120" longName="Volume 120s window" dataType="System.Double" width="60" editType="none" />
        <field name="volume.300" displayName="volume.300" longName="Volume 300s window" dataType="System.Double" width="60" editType="none" />
        <field name="volume.1200" displayName="volume.1200" longName="Volume 1200s window" dataType="System.Double" width="60" editType="none" />
        
        <!-- Volume Statistic Analytics -->
        <field name="volume.60.max.60m" displayName="volume.60.max.60m" longName="Max(volume.60) in past hour" dataType="System.Double" width="60" editType="none" />
        <field name="volume.60.min.60m" displayName="volume.60.min.60m" longName="Min(volume.60) in past hour" dataType="System.Double" width="60" editType="none" />
        <field name="volume.60.samples.60m" displayName="volume.60.samples.60m" longName="Size(volume.60) in past hour" dataType="System.Double" width="60" editType="none" />
        <field name="volume.60.std.60m" displayName="volume.60.std.60m" longName="Std(volume.60) in past hour" dataType="System.Double" width="60" editType="none" />
        <field name="volume.60.var.60m" displayName="volume.60.var.60m" longName="Var(volume.60) in past hour" dataType="System.Double" width="60" editType="none" />
        <field name="volume.60.avg.60m" displayName="volume.60.avg.60m" longName="Avg(volume.60) in past hour" dataType="System.Double" width="60" editType="none" />
        <field name="volume.60.perc.60m" displayName="volume.60.perc.60m" longName="volume.60/volume.60.avg.60m" dataType="System.Double" width="60" editType="none" />
        
        <!-- Data monitor analytics -->
        <field name="tps.60" displayName="tps.today" longName="Tick per second" dataType="System.Double" width="60" editType="none" />
        <field name="trades.60" displayName="trades.60" longName="Trades per minute" dataType="System.Double" width="60" editType="none" /> 	
  </group>

#### Additional Configs ####

1) CEEMEA.grid.config

		<style Master="true" WhatIf="true">
			<name>CurvePricing</name>
			<public>true</public>
			<fixed_screen_export>False</fixed_screen_export>
			<fixed_width>-1</fixed_width>
			<fixed_height>-1</fixed_height>
			<in_grid_splitter>
				<in_name>ownIndicator</in_name>
				<in_name>crvId</in_name>
				<in_name>disName</in_name>
				<in_name>midSwapRate</in_name>
				<in_name>mastId</in_name>
			</in_grid_splitter>
			<in_grid>
		<in_name fixed_width="8">sodRate</in_name>
	<in_name fixed_width="8">consolidatedSpread</in_name>            
                <in_name fixed_width="8">dailySpread</in_name>
	 <in_name fixed_width="8">sodSpread</in_name>	
	<in_name fixed_width="8">consolidatedRate</in_name>				
				<in_name fixed_width="8">lastRunTime</in_name>
				<in_name fixed_width="8">curvePointBenchmark</in_name>
				<in_name fixed_width="8">swapBench</in_name>
				<in_name fixed_width="8">matSprd</in_name>
				<in_name fixed_width="8">interpFrom</in_name>
				<in_name fixed_width="8">interpTo</in_name>
				<in_name fixed_width="8">interpSprd</in_name>	
				<in_name fixed_width="8">own</in_name>					
				<in_name fixed_width="8">setId</in_name>
				<in_name fixed_width="8">ccy</in_name>
				<in_name fixed_width="8">nodeId</in_name>			
				<in_name fixed_width="8">adjust</in_name>				
			</in_grid>
		</style>

		<style Master="true" WhatIf="true">
			<name>3MCurvePricing</name>
			<public>true</public>
			<fixed_screen_export>False</fixed_screen_export>
			<fixed_width>-1</fixed_width>
			<fixed_height>-1</fixed_height>
			<in_grid_splitter>
				<in_name>ownIndicator</in_name>
				<in_name>crvId</in_name>
				<in_name>disName</in_name>
				<in_name>midSwapRate</in_name>
				<in_name>mastId</in_name>
			</in_grid_splitter>
			<in_grid>			
				<in_name fixed_width="8">consolidatedRate</in_name>	            
   				<in_name fixed_width="8">dailySpread</in_name>
				<in_name fixed_width="8">sodRate</in_name>
				<in_name fixed_width="8">lastRunTime</in_name>
				<in_name fixed_width="8">curvePointBenchmark</in_name>
				<in_name fixed_width="8">swapBench</in_name>
				<in_name fixed_width="8">matSprd</in_name>
				<in_name fixed_width="8">interpFrom</in_name>
				<in_name fixed_width="8">interpTo</in_name>
				<in_name fixed_width="8">interpSprd</in_name>	
				<in_name fixed_width="8">own</in_name>					
				<in_name fixed_width="8">setId</in_name>
				<in_name fixed_width="8">ccy</in_name>
				<in_name fixed_width="8">nodeId</in_name>			
				<in_name fixed_width="8">adjust</in_name>				
			</in_grid>
		</style>

2) CEEMEA.grid.config


    <Layout>
		<name>Quoting MTS</name>
		<sort>QuotefeedMaturity</sort>
		<style>Quoting MTS</style>
		<edit>False</edit>
		<visible>false</visible>
		<Filters operation="AND">
            <Filter>
			  <RowFilterRowType>Bond</RowFilterRowType>
			  <RowFilterField>MTmktId</RowFilterField>
			  <RowFilterValue></RowFilterValue>
			  <RowFilterMin></RowFilterMin>
			  <RowFilterMax></RowFilterMax>
			  <RowFilterFieldType>String</RowFilterFieldType>
              <RowFilterType>notequal</RowFilterType>
            </Filter>   
            <Filter>
			  <RowFilterRowType>Bond</RowFilterRowType>
			  <RowFilterField>MTobligation1ObligationTime</RowFilterField>
			  <RowFilterValue>0</RowFilterValue>
			  <RowFilterMin></RowFilterMin>
			  <RowFilterMax></RowFilterMax>
			  <RowFilterFieldType>String</RowFilterFieldType>
              <RowFilterType>notequal</RowFilterType>
            </Filter>             
        </Filters>
    </Layout> 

3) CEEMEA.grid.config

                <in_name fixed_width="8">bestMid</in_name>

4) bond.xml

    <field name="rtBestMid" displayName="rtBstMid" longName="RealTime Best Mid" dataType="System.Double" width="60" format="0.000" multiplier="100" editType="none"/>

5) bond.xml

    <field name="cdsBasisRatio" displayName="CDS Basis Ratio" dataType="System.Double" editType="none" width="70" format = "+0.0;-0.0;#" longName="MidZSpread / Int CDS EffMat"/>

6) Fra.xml, MoneyMarket.xml, Swap.xml

        <!-- GDS curve rates -->
        <field name="consolidatedRate"    displayName="Implied Rate"        dataType="System.Double" format="0.000"  multiplier="100" editType="none"/>
        <field name="consolidatedSpread"  displayName="Total Sprd"  dataType="System.Double" format="0.000"  multiplier="10000" editType="none"/>
        <field name="lastRunTime"         displayName="Update Time" dataType="System.String" editType="none"/>
        <field name="dailySpread"         displayName="Change On Day"        dataType="System.Double" format="0.000"  multiplier="10000"  backColour="#FFFF00" editType="edit"/> 
        <field name="sodRate"             displayName="3M Rate"     dataType="System.Double" format="0.000"  multiplier="100" editType="none"/>  
        <field name="sodSpread"           displayName="SOD Sprd"    dataType="System.Double" format="0.000"  multiplier="10000" editType="none"/>  
        <field name="curvePointBenchmark" displayName="Benchmark"   dataType="System.String" editType="selection" selectionType="curvePointNodeIdList"/>
        <field name="curvePointInputRule" displayName="Rule"        dataType="System.String" editType="none"/>

7) 
