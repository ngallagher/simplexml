import sys
from java.util.regex import Matcher
from java.util.regex import Pattern
#===== Mapping for outgoing messages =======================
def loop_CopyBrokerFields(sourceMessage, destMessage):
	for fieldName in sourceMessage.keys():
		
			if fieldName.startswith("BET_"): destMessage[fieldName[4:]] = sourceMessage[fieldName]
		
def map_Ack(sourceMessage, destMessage):
	loop_CopyBrokerFields(sourceMessage, destMessage)
	destMessage["MsgSeqNo"] = int(sourceMessage["frameSeqNo"])
	if str(sourceMessage["isAck"]) == "true":
		destMessage["Status"] = int(1)
	else:
		destMessage["Status"] = int(2)
		try:
			destMessage["Text"] = str(sourceMessage["nackText"])
		except KeyError:
			pass
def map_GeneratedAck(sourceMessage, destMessage):
	loop_CopyBrokerFields(sourceMessage, destMessage)
	destMessage["MsgSeqNo"] = int(sourceMessage["frameSeqNo"])
	destMessage["Status"] = int(1)
def map_OutrightPriceType(sourceMessage, destMessage):
	if sourceMessage.has_key("instrumentQuoteType"):
		destMessage["PriceType"] = map_value("QuoteType",str(sourceMessage["instrumentQuoteType"]))
	elif sourceMessage.has_key("priceDetailType"):
		if sourceMessage.has_key("ticker"):
			if str(sourceMessage["ticker"]) == "BOTS":
				destMessage["PriceType"] = "P"
			elif in_map("PriceDetailType",str(sourceMessage["priceDetailType"])):
				destMessage["PriceType"] = map_value("PriceDetailType",str(sourceMessage["priceDetailType"]))
			else:
				destMessage["PriceType"] = "P"
		else:
			destMessage["PriceType"] = "P"
	else:
		destMessage["PriceType"] = "P"
def map_SwitchPriceType(sourceMessage, destMessage):
	if sourceMessage.has_key("instrumentQuoteType"):
		destMessage["PriceType1"] = map_value("QuoteType",str(sourceMessage["instrumentQuoteType"]))
	elif sourceMessage.has_key("priceDetailType"):
		if sourceMessage.has_key("ticker"):
			if str(sourceMessage["ticker"]) == "BOTS":
				destMessage["PriceType1"] = "P"
			elif in_map("PriceDetailType",str(sourceMessage["priceDetailType"])):
				destMessage["PriceType1"] = map_value("PriceDetailType",str(sourceMessage["priceDetailType"]))
			else:
				destMessage["PriceType1"] = "P"
		else:
			destMessage["PriceType1"] = "P"
	else:
		destMessage["PriceType1"] = "P"
	if sourceMessage.has_key("switchinstrumentQuoteType"):
		destMessage["PriceType2"] = map_value("QuoteType",str(sourceMessage["switchinstrumentQuoteType"]))
	if sourceMessage.has_key("priceDetailType"):
		if sourceMessage.has_key("switchticker"):
			if str(sourceMessage["switchticker"]) == "BOTS":
				destMessage["PriceType2"] = "P"
			elif in_map("PriceDetailType",str(sourceMessage["switchpriceDetailType"])):
				destMessage["PriceType2"] = map_value("PriceDetailType",str(sourceMessage["switchpriceDetailType"]))
			else:
				destMessage["PriceType2"] = "P"
		else:
			destMessage["PriceType2"] = "P"
	else:
		destMessage["PriceType2"] = "P"
def map_CrossPriceType(sourceMessage, destMessage):
	if sourceMessage.has_key("priceDetailType"):
		if sourceMessage.has_key("ticker"):
			if str(sourceMessage["ticker"]) == "BOTS":
				destMessage["PriceType1"] = "P"
			elif in_map("PriceDetailType",str(sourceMessage["priceDetailType"])):
				destMessage["PriceType2"] = map_value("PriceDetailType",str(sourceMessage["priceDetailType"]))
			else:
				destMessage["PriceType2"] = "P"
		else:
			destMessage["PriceType2"] = "P"
	else:
		destMessage["PriceType2"] = "P"
	if sourceMessage.has_key("priceDetailType"):
		if sourceMessage.has_key("switchticker"):
			if str(sourceMessage["switchticker"]) == "BOTS":
				destMessage["PriceType1"] = "P"
			elif in_map("PriceDetailType",str(sourceMessage["switchpriceDetailType"])):
				destMessage["PriceType1"] = map_value("PriceDetailType",str(sourceMessage["switchpriceDetailType"]))
			else:
				destMessage["PriceType1"] = "P"
		else:
			destMessage["PriceType1"] = "P"
	else:
		destMessage["PriceType1"] = "P"
def map_PriceType(sourceMessage, destMessage):
	if str(sourceMessage["tradeType"]) == "OUTRIGHT":
		map_OutrightPriceType(sourceMessage, destMessage)
	elif str(sourceMessage["tradeType"]) == "SWITCH":
		map_SwitchPriceType(sourceMessage, destMessage)
	elif str(sourceMessage["tradeType"]) == "CROSS":
		if str(sourceMessage["switchinstrumentRef"]) == sourceMessage["BET_SecurityId1"]:
			map_CrossPriceType(sourceMessage, destMessage)
		else:
			map_SwitchPriceType(sourceMessage, destMessage)
	else:
		log("error","failed to map trade details as unknown tradeType["+str(sourceMessage["tradeType"])+"]")
def map_QuoteDetails2(sourceMessage, destMessage):
	loop_CopyBrokerFields(sourceMessage, destMessage)
	map_PriceType(sourceMessage, destMessage)
	if str(sourceMessage["tradeType"]) == "OUTRIGHT":
		destMessage["Price"] = float(sourceMessage["indicativePrice"])
		destMessage["Yield"] = float(sourceMessage["indicativeYield"])
		try:
			destMessage["BookingTraderNo"] = str(sourceMessage["tradersBookId"])
		except KeyError:
			pass
		try:
			destMessage["BookingTraderName"] = str(sourceMessage["tradersBookName"])
		except KeyError:
			pass
	elif str(sourceMessage["tradeType"]) == "SWITCH":
		destMessage["Price1"] = float(sourceMessage["indicativePrice"])
		destMessage["Yield1"] = float(sourceMessage["indicativeYield"])
		destMessage["Price2"] = float(sourceMessage["switchindicativePrice"])
		destMessage["Yield2"] = float(sourceMessage["switchindicativeYield"])
		try:
			destMessage["BookingTraderNo1"] = str(sourceMessage["tradersBookId"])
		except KeyError:
			pass
		try:
			destMessage["BookingTraderNo2"] = str(sourceMessage["tradersBookId"])
		except KeyError:
			pass
		try:
			destMessage["BookingTraderName1"] = str(sourceMessage["tradersBookName"])
		except KeyError:
			pass
		try:
			destMessage["BookingTraderName2"] = str(sourceMessage["tradersBookName"])
		except KeyError:
			pass
	elif str(sourceMessage["tradeType"]) == "CROSS":
		if str(sourceMessage["switchinstrumentRef"]) == sourceMessage["BET_SecurityId1"]:
			destMessage["Price2"] = float(sourceMessage["indicativePrice"])
			destMessage["Yield2"] = float(sourceMessage["indicativeYield"])
			destMessage["Price1"] = float(sourceMessage["switchindicativePrice"])
			destMessage["Yield1"] = float(sourceMessage["switchindicativeYield"])
			try:
				destMessage["BookingTraderNo1"] = str(sourceMessage["tradersBookId"])
			except KeyError:
				pass
			try:
				destMessage["BookingTraderNo2"] = str(sourceMessage["tradersBookId"])
			except KeyError:
				pass
			try:
				destMessage["BookingTraderName1"] = str(sourceMessage["tradersBookName"])
			except KeyError:
				pass
			try:
				destMessage["BookingTraderName2"] = str(sourceMessage["tradersBookName"])
			except KeyError:
				pass
		else:
			destMessage["Price1"] = float(sourceMessage["indicativePrice"])
			destMessage["Yield1"] = float(sourceMessage["indicativeYield"])
			destMessage["Price2"] = float(sourceMessage["switchindicativePrice"])
			destMessage["Yield2"] = float(sourceMessage["switchindicativeYield"])
			try:
				destMessage["BookingTraderNo1"] = str(sourceMessage["tradersBookId"])
			except KeyError:
				pass
			try:
				destMessage["BookingTraderNo2"] = str(sourceMessage["tradersBookId"])
			except KeyError:
				pass
			try:
				destMessage["BookingTraderName1"] = str(sourceMessage["tradersBookName"])
			except KeyError:
				pass
			try:
				destMessage["BookingTraderName2"] = str(sourceMessage["tradersBookName"])
			except KeyError:
				pass
	else:
		log("error","failed to map trade details as unknown tradeType["+str(sourceMessage["tradeType"])+"]")
def convert_OrderAckNack(sourceMessage, destQueue):
	if in_set("TwoSecTrades",str(sourceMessage["tradeType"])):
		destMessage = {}
		destMessage["TransTypeName"] = "TwoSecOrderAck"
		destQueue.append(destMessage)
		map_Ack(sourceMessage, destMessage)
	elif str(sourceMessage["tradeType"]) == "OUTRIGHT":
		destMessage = {}
		destMessage["TransTypeName"] = "OrderAck"
		destQueue.append(destMessage)
		map_Ack(sourceMessage, destMessage)
	else:
		log("error","OrderAckNack: Unhandled tradeType["+str(sourceMessage["tradeType"])+"]")
def convert_ReconciliationAckNack(sourceMessage, destQueue):
	if in_set("TwoSecTrades",str(sourceMessage["tradeType"])):
		destMessage = {}
		destMessage["TransTypeName"] = "TwoSecReconciliationAck"
		destQueue.append(destMessage)
		map_Ack(sourceMessage, destMessage)
	elif str(sourceMessage["tradeType"]) == "OUTRIGHT":
		destMessage = {}
		destMessage["TransTypeName"] = "ReconciliationAck"
		destQueue.append(destMessage)
		map_Ack(sourceMessage, destMessage)
	else:
		log("error","ReconciliationAckNack: Unhandled tradeType["+str(sourceMessage["tradeType"])+"]")
def convert_InquiryAckNack(sourceMessage, destQueue):
	if in_set("TwoSecTrades",str(sourceMessage["tradeType"])):
		destMessage = {}
		destMessage["TransTypeName"] = "TwoSecPriceRequestAck"
		destQueue.append(destMessage)
		map_Ack(sourceMessage, destMessage)
	elif str(sourceMessage["tradeType"]) == "OUTRIGHT":
		destMessage = {}
		destMessage["TransTypeName"] = "MultiPriceInquiryAck"
		destQueue.append(destMessage)
		map_Ack(sourceMessage, destMessage)
	else:
		log("error","InquiryAckNack: Unhandled tradeType["+str(sourceMessage["tradeType"])+"]")
def convert_WiretimeExpireAckNack(sourceMessage, destQueue):
	if in_set("TwoSecTrades",str(sourceMessage["tradeType"])):
		destMessage = {}
		destMessage["TransTypeName"] = "TwoSecWiretimeExpireAck"
		destQueue.append(destMessage)
		map_Ack(sourceMessage, destMessage)
	elif str(sourceMessage["tradeType"]) == "OUTRIGHT":
		destMessage = {}
		destMessage["TransTypeName"] = "WiretimeExpireAck"
		destQueue.append(destMessage)
		map_Ack(sourceMessage, destMessage)
	else:
		log("error","WiretimeExpireAckNack: Unhandled tradeType["+str(sourceMessage["tradeType"])+"]")
def convert_CustAccExpAckNack(sourceMessage, destQueue):
	if in_set("TwoSecTrades",str(sourceMessage["tradeType"])):
		destMessage = {}
		destMessage["TransTypeName"] = "TwoSecCustomerHitLiftAck"
		destQueue.append(destMessage)
		map_Ack(sourceMessage, destMessage)
	elif str(sourceMessage["tradeType"]) == "OUTRIGHT":
		destMessage = {}
		destMessage["TransTypeName"] = "CustomerHitLiftAck"
		destQueue.append(destMessage)
		map_Ack(sourceMessage, destMessage)
	else:
		log("error","CustAccExpAckNack: Unhandled tradeType["+str(sourceMessage["tradeType"])+"]")
def convert_CustAcceptAckNack(sourceMessage, destQueue):
	if in_set("TwoSecTrades",str(sourceMessage["tradeType"])):
		destMessage = {}
		destMessage["TransTypeName"] = "TwoSecCustomerAcceptAck"
		destQueue.append(destMessage)
		map_Ack(sourceMessage, destMessage)
	elif str(sourceMessage["tradeType"]) == "OUTRIGHT":
		destMessage = {}
		destMessage["TransTypeName"] = "CustomerAcceptAck"
		destQueue.append(destMessage)
		map_Ack(sourceMessage, destMessage)
	else:
		log("error","Unhandled CustAcceptAckNack - unknown tradeType")
def convert_ConvTermAckNack(sourceMessage, destQueue):
	if in_set("TwoSecTrades",str(sourceMessage["tradeType"])):
		if last_received_source_type_equals("TwoSecExpiration"):
			destMessage = {}
			destMessage["TransTypeName"] = "TwoSecExpirationAck"
			destQueue.append(destMessage)
			map_Ack(sourceMessage, destMessage)
		elif last_received_source_type_equals("TwoSecCustomerHitLift"):
			destMessage = {}
			destMessage["TransTypeName"] = "TwoSecCustomerHitLiftAck"
			destQueue.append(destMessage)
			map_Ack(sourceMessage, destMessage)
		else:
			log("error","Unhandled ConvTermAckNack - last received source type "+str(get_last_received_source_type())+"")
	elif str(sourceMessage["tradeType"]) == "OUTRIGHT":
		if last_received_source_type_equals("PassTradedAwayCovered"):
			destMessage = {}
			destMessage["TransTypeName"] = "PassTradedAwayCoveredAck"
			destQueue.append(destMessage)
			map_Ack(sourceMessage, destMessage)
		elif last_received_source_type_equals("Expiration"):
			destMessage = {}
			destMessage["TransTypeName"] = "ExpirationAck"
			destQueue.append(destMessage)
			map_Ack(sourceMessage, destMessage)
		else:
			log("error","Unhandled ConvTermAckNack - last received source type "+str(get_last_received_source_type())+"")
	else:
		log("error","ConvTermAckNack: Unhandled tradeType["+str(sourceMessage["tradeType"])+"]")
def convert_OrderAcceptMessage(sourceMessage, destQueue):
	if in_set("TwoSecTrades",str(sourceMessage["tradeType"])):
		destMessage = {}
		destMessage["TransTypeName"] = "TwoSecExecution"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(1)
		destMessage["OriginalTradeDateTime"] = long(sourceMessage["BET_TradeDatetime"])
	elif str(sourceMessage["tradeType"]) == "OUTRIGHT":
		destMessage = {}
		destMessage["TransTypeName"] = "Execution"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(1)
		destMessage["OriginalTradeDateTime"] = long(sourceMessage["BET_TradeDatetime"])
		destMessage["TraderNumber"] = int(sourceMessage["tradersBookId"])
	else:
		log("error","OrderAcceptMessage: Unhandled tradeType["+str(sourceMessage["tradeType"])+"]")
def convert_OrderRejectMessage(sourceMessage, destQueue):
	if in_set("TwoSecTrades",str(sourceMessage["tradeType"])):
		destMessage = {}
		destMessage["TransTypeName"] = "TwoSecExecution"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		destMessage["OriginalTradeDateTime"] = long(sourceMessage["BET_TradeDatetime"])
		destMessage["SalesBookNo"] = int(0)
		destMessage = {}
		destMessage["TransTypeName"] = "DealerMessage"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		destMessage["Text1"] = str(sourceMessage["rejectionReason"])
	elif str(sourceMessage["tradeType"]) == "OUTRIGHT":
		destMessage = {}
		destMessage["TransTypeName"] = "Execution"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		destMessage["OriginalTradeDateTime"] = long(sourceMessage["BET_TradeDatetime"])
		destMessage["SalesBookNo"] = int(0)
		destMessage = {}
		destMessage["TransTypeName"] = "DealerMessage"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		destMessage["Text1"] = str(sourceMessage["rejectionReason"])
	else:
		log("error","OrderRejectMessage: Unhandled tradeType["+str(sourceMessage["tradeType"])+"]")
def convert_OrderCounterMessage(sourceMessage, destQueue):
	if in_set("TwoSecTrades",str(sourceMessage["tradeType"])):
		destMessage = {}
		destMessage["TransTypeName"] = "TwoSecPriceFill"
		destQueue.append(destMessage)
		map_QuoteDetails2(sourceMessage, destMessage)
		destMessage["Status"] = int(6)
		destMessage["Timer"] = int(sourceMessage["validTime"])
	elif str(sourceMessage["tradeType"]) == "OUTRIGHT":
		destMessage = {}
		destMessage["TransTypeName"] = "PriceRequestFill"
		destQueue.append(destMessage)
		map_QuoteDetails2(sourceMessage, destMessage)
		destMessage["Status"] = int(6)
		destMessage["Timer"] = int(sourceMessage["validTime"])
	else:
		log("error","OrderCounterMessage: Unhandled tradeType["+str(sourceMessage["tradeType"])+"]")
def convert_InquiryResponseMessage(sourceMessage, destQueue):
	if last_received_source_type_equals("MultiPriceInquiry"):
		destMessage = {}
		destMessage["TransTypeName"] = "PriceRequestFill"
		destQueue.append(destMessage)
		map_QuoteDetails2(sourceMessage, destMessage)
		destMessage["Timer"] = int(sourceMessage["validTime"])
		destMessage["Status"] = int(1)
	elif last_received_source_type_equals("CustomerHitLift"):
		destMessage = {}
		destMessage["TransTypeName"] = "PriceRequestFill"
		destQueue.append(destMessage)
		map_QuoteDetails2(sourceMessage, destMessage)
		destMessage["Timer"] = int(sourceMessage["validTime"])
		destMessage["Status"] = int(6)
	elif last_received_source_type_equals("WiretimeExpire"):
		destMessage = {}
		destMessage["TransTypeName"] = "PriceRequestFill"
		destQueue.append(destMessage)
		map_QuoteDetails2(sourceMessage, destMessage)
		destMessage["Timer"] = int(sourceMessage["validTime"])
		destMessage["Status"] = int(1)
	elif last_received_source_type_equals("TwoSecPriceRequest"):
		destMessage = {}
		destMessage["TransTypeName"] = "TwoSecPriceFill"
		destQueue.append(destMessage)
		map_QuoteDetails2(sourceMessage, destMessage)
		destMessage["Timer"] = int(sourceMessage["validTime"])
		destMessage["Status"] = int(1)
	elif last_received_source_type_equals("TwoSecCustomerHitLift"):
		destMessage = {}
		destMessage["TransTypeName"] = "TwoSecPriceFill"
		destQueue.append(destMessage)
		map_QuoteDetails2(sourceMessage, destMessage)
		destMessage["Timer"] = int(sourceMessage["validTime"])
		destMessage["Status"] = int(6)
	elif last_received_source_type_equals("TwoSecWiretimeExpire"):
		destMessage = {}
		destMessage["TransTypeName"] = "TwoSecPriceFill"
		destQueue.append(destMessage)
		map_QuoteDetails2(sourceMessage, destMessage)
		destMessage["Timer"] = int(sourceMessage["validTime"])
		destMessage["Status"] = int(1)
	elif last_received_source_type_equals("PriceRequestFillAck"):
		destMessage = {}
		destMessage["TransTypeName"] = "PriceRequestFill"
		destQueue.append(destMessage)
		map_QuoteDetails2(sourceMessage, destMessage)
		destMessage["Timer"] = int(sourceMessage["validTime"])
		destMessage["Status"] = int(6)
	else:
		log("error","Unhandled InquiryResponse - last received source type "+str(get_last_received_source_type())+"")
def convert_InquiryTermMessage(sourceMessage, destQueue):
	if in_set("TwoSecTrades",str(sourceMessage["tradeType"])):
		destMessage = {}
		destMessage["TransTypeName"] = "TwoSecPriceFill"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		destMessage = {}
		destMessage["TransTypeName"] = "DealerMessage"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		destMessage["Text1"] = str(sourceMessage["rejectionReason"])
	elif str(sourceMessage["tradeType"]) == "OUTRIGHT":
		destMessage = {}
		destMessage["TransTypeName"] = "PriceRequestFill"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		destMessage = {}
		destMessage["TransTypeName"] = "DealerMessage"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		destMessage["Text1"] = str(sourceMessage["rejectionReason"])
	else:
		log("error","InquiryTermMessage: Unhandled tradeType["+str(sourceMessage["tradeType"])+"]")
def convert_InquiryAcceptMessage(sourceMessage, destQueue):
	if in_set("TwoSecTrades",str(sourceMessage["tradeType"])):
		destMessage = {}
		destMessage["TransTypeName"] = "TwoSecInquiryExecution"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(1)
	elif str(sourceMessage["tradeType"]) == "OUTRIGHT":
		destMessage = {}
		destMessage["TransTypeName"] = "InquiryExecution"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(1)
	else:
		log("error","InquiryAcceptMessage: Unhandled tradeType["+str(sourceMessage["tradeType"])+"]")
def convert_InquiryRejectMessage(sourceMessage, destQueue):
	if in_set("TwoSecTrades",str(sourceMessage["tradeType"])):
		destMessage = {}
		destMessage["TransTypeName"] = "TwoSecInquiryExecution"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		destMessage = {}
		destMessage["TransTypeName"] = "DealerMessage"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		try:
			destMessage["Text1"] = str(sourceMessage["rejectionReason"])
		except KeyError:
			pass
	elif str(sourceMessage["tradeType"]) == "OUTRIGHT":
		destMessage = {}
		destMessage["TransTypeName"] = "InquiryExecution"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		destMessage = {}
		destMessage["TransTypeName"] = "DealerMessage"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		try:
			destMessage["Text1"] = str(sourceMessage["rejectionReason"])
		except KeyError:
			pass
	else:
		log("error","InquiryRejectMessage: Unhandled tradeType["+str(sourceMessage["tradeType"])+"]")
def convert_UnroutableMessage(sourceMessage, destQueue):
	if str(sourceMessage["incomingType"]) == "Heartbeat":
		destMessage = {}
		destMessage["TransTypeName"] = "HeartbeatAck"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["MsgSeqNo"] = int(sourceMessage["frameSeqNo"])
def convert_OrderMessage(sourceMessage, destQueue):
	if str(sourceMessage["IncomingType"]) == "Order":
		log("unknown_instrument","REJECTING Order for unsubscribed ticker "+str(sourceMessage["instrumentRef"])+"")
		destMessage = {}
		destMessage["TransTypeName"] = "OrderAck"
		destQueue.append(destMessage)
		map_GeneratedAck(sourceMessage, destMessage)
		destMessage = {}
		destMessage["TransTypeName"] = "Execution"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		destMessage["OriginalTradeDateTime"] = long(sourceMessage["BET_TradeDatetime"])
		destMessage = {}
		destMessage["TransTypeName"] = "DealerMessage"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		destMessage["Text1"] = "Unable to autoexecute this instrument - please call"
	elif str(sourceMessage["IncomingType"]) == "TwoSecOrder":
		log("unknown_instrument","REJECTING Order for unsubscribed ticker "+str(sourceMessage["instrumentRef"])+" - "+str(sourceMessage["switchinstrumentRef"])+"")
		destMessage = {}
		destMessage["TransTypeName"] = "TwoSecOrderAck"
		destQueue.append(destMessage)
		map_GeneratedAck(sourceMessage, destMessage)
		destMessage = {}
		destMessage["TransTypeName"] = "TwoSecExecution"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		destMessage["OriginalTradeDateTime"] = long(sourceMessage["BET_TradeDatetime"])
		destMessage = {}
		destMessage["TransTypeName"] = "DealerMessage"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		destMessage["Text1"] = "Unable to autoexecute this instrument - please call"
	else:
		log("error","Unhandled tradeType["+str(sourceMessage["tradeType"])+"]")
def convert_InquiryMessage(sourceMessage, destQueue):
	if str(sourceMessage["IncomingType"]) == "MultiPriceInquiry":
		log("unknown_instrument","REJECTING Inquiry for unsubscribed ticker "+str(sourceMessage["instrumentRef"])+"")
		destMessage = {}
		destMessage["TransTypeName"] = "MultiPriceInquiryAck"
		destQueue.append(destMessage)
		map_GeneratedAck(sourceMessage, destMessage)
		destMessage = {}
		destMessage["TransTypeName"] = "PriceRequestFill"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		destMessage = {}
		destMessage["TransTypeName"] = "DealerMessage"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		destMessage["Text1"] = "Unable to autoquote this instrument - please call"
	elif str(sourceMessage["IncomingType"]) == "TwoSecPriceRequest":
		log("unknown_instrument","REJECTING Inquiry for unsubscribed ticker "+str(sourceMessage["instrumentRef"])+" - "+str(sourceMessage["switchinstrumentRef"])+"")
		destMessage = {}
		destMessage["TransTypeName"] = "TwoSecPriceRequestAck"
		destQueue.append(destMessage)
		map_GeneratedAck(sourceMessage, destMessage)
		destMessage = {}
		destMessage["TransTypeName"] = "TwoSecPriceFill"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		destMessage = {}
		destMessage["TransTypeName"] = "DealerMessage"
		destQueue.append(destMessage)
		loop_CopyBrokerFields(sourceMessage, destMessage)
		destMessage["Status"] = int(2)
		destMessage["Text1"] = "Unable to autoquote this instrument - please call"
	else:
		log("error","Unhandled tradeType["+str(sourceMessage["tradeType"])+"]")
def convert_ReconciliationMessage(sourceMessage, destQueue):
	if str(sourceMessage["BET_Status"]) == "2":
		if str(sourceMessage["IncomingType"]) == "TwoSecReconciliation":
			destMessage = {}
			destMessage["TransTypeName"] = "TwoSecReconciliationAck"
			destQueue.append(destMessage)
			loop_CopyBrokerFields(sourceMessage, destMessage)
			destMessage["MsgSeqNo"] = int(sourceMessage["frameSeqNo"])
			destMessage["Status"] = int(1)
		elif str(sourceMessage["IncomingType"]) == "Reconciliation":
			destMessage = {}
			destMessage["TransTypeName"] = "ReconciliationAck"
			destQueue.append(destMessage)
			loop_CopyBrokerFields(sourceMessage, destMessage)
			destMessage["MsgSeqNo"] = int(sourceMessage["frameSeqNo"])
			destMessage["Status"] = int(1)
		else:
			log("error","Unhandled messageType["+str(sourceMessage["IncomingType"])+"]")
	else:
		log("error","ReconciliationMessage has unexpected Status["+str(sourceMessage["BET_Status"])+"] - expected 2=Reject")
#===== Convenience functions ============================
def last_sent_source_type_equals(source_type):
	global conversation_id
	return conversation.outgoing.sourceMessages.lastMessage(conversation_id)["MESSAGETYPE"] == source_type
def get_last_sent_source_type():
	global conversation_id
	return conversation.outgoing.sourceMessages.lastMessage(conversation_id)["MESSAGETYPE"]
def last_received_source_type_equals(source_type):
	global conversation_id
	return conversation.incoming.sourceMessages.lastMessage(conversation_id)["TransTypeName"] == source_type
def get_last_received_source_type():
	global conversation_id
	return conversation.incoming.sourceMessages.lastMessage(conversation_id)["TransTypeName"]
def get_outgoing_message(msgType):
	global conversation_id
	return conversation.outgoing.sourceMessages.getMessage(conversation_id, msgType)
def has_outgoing_message(msgType):
	global conversation_id
	return conversation.outgoing.sourceMessages.hasPreviousMessage(conversation_id, msgType)
def get_incoming_message(msgType):
	global conversation_id
	return conversation.incoming.sourceMessages.getMessage(conversation_id, msgType)
def has_incoming_message(msgType):
	global conversation_id
	return conversation.incoming.sourceMessages.hasPreviousMessage(conversation_id, msgType)
def has_key(test_obj, nested_fields):
	if test_obj.has_key(nested_fields[0]):
		if len(nested_fields) == 1: return 1
		else: return has_key(test_obj[nested_fields[0]], nested_fields[1:])
	else: return 0
#===== Conversion function ============================
def convert(sourceMessage, destQueue):
	global convert_funcs
	global conversation_id
	message_type = str(sourceMessage["MESSAGETYPE"])
	#set conversation history current conversation id
	if has_key(sourceMessage,["brkConvId"]):
		conversation_id = str(sourceMessage["brkConvId"])
		conversation.outgoing.sourceMessages.setConversationId(conversation_id)
		#add source message
		conversation.outgoing.sourceMessages.addMessage(sourceMessage, message_type)
	#do conversion
	convert_funcs[message_type](sourceMessage, destQueue)
	if conversation_id is not None:
		conversation.outgoing.destMessages.setConversationId(conversation_id)
		conversation.outgoing.destMessages.addMessages(destQueue, "TransTypeName")
#===== Script entry point ===============================
convert_funcs = {}
conversation_id = None
convert_funcs["CustAcceptAckNack"] = convert_CustAcceptAckNack
convert_funcs["OrderAcceptMessage"] = convert_OrderAcceptMessage
convert_funcs["InquiryAckNack"] = convert_InquiryAckNack
convert_funcs["ReconciliationAckNack"] = convert_ReconciliationAckNack
convert_funcs["InquiryAcceptMessage"] = convert_InquiryAcceptMessage
convert_funcs["UnroutableMessage"] = convert_UnroutableMessage
convert_funcs["OrderAckNack"] = convert_OrderAckNack
convert_funcs["InquiryRejectMessage"] = convert_InquiryRejectMessage
convert_funcs["OrderCounterMessage"] = convert_OrderCounterMessage
convert_funcs["InquiryMessage"] = convert_InquiryMessage
convert_funcs["InquiryResponseMessage"] = convert_InquiryResponseMessage
convert_funcs["InquiryTermMessage"] = convert_InquiryTermMessage
convert_funcs["ReconciliationMessage"] = convert_ReconciliationMessage
convert_funcs["CustAccExpAckNack"] = convert_CustAccExpAckNack
convert_funcs["OrderMessage"] = convert_OrderMessage
convert_funcs["OrderRejectMessage"] = convert_OrderRejectMessage
convert_funcs["WiretimeExpireAckNack"] = convert_WiretimeExpireAckNack
convert_funcs["ConvTermAckNack"] = convert_ConvTermAckNack
convert(sourceMessage, destQueue)
