using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Reflection.Emit;
using System.Threading;

namespace Rbsfm.Capmarkets.EuroPricingClient.PropertyGrid.Converters
{
    public class DynamicListConverterFactory
    {
        public static Type CreateInstance(String selectionList)
        {
            AssemblyName assemblyName = new AssemblyName();
            assemblyName.Name = "Rbsfm.FI.TempAssembly";
            AssemblyBuilder assemblyBuilder = Thread.GetDomain().DefineDynamicAssembly(assemblyName, AssemblyBuilderAccess.Run);
            ModuleBuilder moduleBuilder =  assemblyBuilder.DefineDynamicModule("DynamicLists");
            TypeBuilder typeBuilder = moduleBuilder.DefineType(assemblyName.Name + "." + selectionList + "_DynamicListConverter", TypeAttributes.Public | TypeAttributes.Class, typeof(DynamicListConverter));
            MethodBuilder methodBuilder = typeBuilder.DefineMethod("GetListName",    
                            MethodAttributes.Public | 
                            MethodAttributes.ReuseSlot |
                            MethodAttributes.Virtual | 
                            MethodAttributes.HideBySig,
                            typeof(String),
                            Type.EmptyTypes);

            ILGenerator msil = methodBuilder.GetILGenerator();

            msil.Emit(OpCodes.Ldstr, selectionList);
            msil.Emit(OpCodes.Ret);

            return typeBuilder.CreateType();
        }
    }
}

