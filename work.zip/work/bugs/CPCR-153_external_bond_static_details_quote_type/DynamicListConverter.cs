using System;
using System.Collections;
using System.Text;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using Rbsfm.Capmarkets.EuroPricingClient.Grid.SelectionList;
using Rbsfm.FI.Data;

namespace Rbsfm.Capmarkets.EuroPricingClient.PropertyGrid.Converters
{
    public abstract class DynamicListConverter : StringConverter
    {
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }

        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return new StandardValuesCollection(GetSectorList(context));
        }

        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return false;
        }

        private List<string> GetSectorList(ITypeDescriptorContext context)
        {
            List<string> returnValue = new List<string>();
            IList list = SelectionListManager.Instance.GetSelectionList(GetListName());

            if (list != null && ListHasValidData(list))
            {
                foreach (string item in list)
                {
                    returnValue.Add(item.Replace('?', ':'));
                }
            }

            return returnValue;
        }

        private static bool ListHasValidData(IList list)
        {
            bool valid = false;

            if (list != null)
            {
                if (!(list.Count == 1 && list[0].Equals("")))
                {
                    valid = true;
                }
            }

            return valid;
        }

        public virtual String GetName()
        {
            return "DynamicList" + GetListName();
        }

        public abstract String GetListName();
    }
}

