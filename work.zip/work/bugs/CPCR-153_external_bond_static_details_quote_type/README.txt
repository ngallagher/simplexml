# Here is the schema for configuring a popup numeric edit field

render
type
title
selltitle
twidth
tfontsize
tbackcolor
tforecolor
tbold
titalic
vfontsize
vbackcolor
vforecolor
vbold
vitalic
target
lookupField
align
buysellbackcolor
buysell
rounding
tickerDisplay
verticaledit
buttonsleft
editbuttons
formatter
contexthandler
increment
roundDp
displayFormat
zerovalid
hidden
defaultroundbutton
rawformat
backcalcrequired
fieldAction
freetextrequired
paddingside
padding
validationregexp
multiplier
roundingLabels
roundingValues
roundingHalfPoints
roundingRegex
roundingButtonSetsValue
roundingButtonBroker
clickHandler

# A change is required to the _base_selection_list.config

Price
Yield
Unknown

# The PriceDetailType has been replaced with QuoteType in most places

QuoteType.isPrice
QuoteType.isYield
QuoteType.isUnknown

# Looks like for switches we are not sending the correct prices

Price1 -> Updated
Price2 -> Ignored

# This is where the messages written can be intercepted

com.rbsfm.fi.pricing.ecn.gateway.message.AqMuxMessageReaderWriter->writeAqMessage()
com.rbsfm.fi.pricing.ecn.gateway.message.AqMuxMessageReaderWriter->readMessage()

# This performs mappings when it is given AQ message, the following should be added

		<valueMap name="QuoteType">
		  <value sourceValue="PRICE" destValue="P"/>
		  <value sourceValue="YIELD" destValue="Y"/>
		</valueMap>

        ...

		<fieldMap name="OutrightPriceType">
            <!-- this section is completely vile and should be changed/handled in the autoquoter -->			
            <if sourceFieldExists="quoteType">
                <mapField destField="PriceType" sourceField="quoteType" valueMap="QuoteType"/>
            </if>
			<elseif sourceFieldExists="priceDetailType">
			  <if sourceFieldExists="ticker">
				  <if sourceField="ticker" value="BOTS">
					  <mapField destField="PriceType" value="P"/>
				  </if>
					<elseif sourceField="priceDetailType" inMap="PriceDetailType">
						<mapField destField="PriceType" sourceField="priceDetailType" valueMap="PriceDetailType"/>
					</elseif>
					<else>
					  <mapField destField="PriceType" value="P"/>
					</else>
				</if>
				<else>
					<mapField destField="PriceType" value="P"/>
				</else>
			</elseif>
			<else>
				<mapField destField="PriceType" value="P"/>
			</else>
		</fieldMap>


# Conversion is performed via

d:\uat\rbsfm\cp\betgateway2-6_0_0\config\in-bloomberg-betgateway2-rbsmbonds-messagemap.py

# This is used to counter the inquiry

OrderCounterMessage

# The message to response to an order is

InquiryResponseMessage

# The problem for this is in the following class

com.rbsfm.fi.bet.gateway.message.converter.BetMessageAdapter#parseMessage

# When converting a Y price type in the ProxyMessageConverter the price type is

'PriceType': 'P' <<<------ should be 'PriceType': 'Y'

# A switch has the following

BET_PriceType2='P', BET_PriceType1='P'

# The following is the BLOOMBERG type so it can not be wrong

BetProtocol.PRICE_TYPE --> BET_PriceType == [P|Y]

# Setting of static is done in this stack trace

ConversationLeg.setStaticDetails(ExternalStaticDetails) line: 66	
BaseBondConversationFactory(AbstractConversationFactory).setSecurityDetail(ConversationLeg, String) line: 1113	
BaseBondConversationFactory(AbstractBondConversationFactory).setLegPriceDetails(BaseInquiryDetailsMessage, BaseInquiryDetailsMessage, ConversationLeg, IConversation) line: 542	
BaseBondConversationFactory(AbstractBondConversationFactory).createLegs(BaseInquiryDetailsMessage, IInternalConversation) line: 136	
BaseBondConversationFactory(AbstractConversationFactory).populateConversation(BaseInquiryDetailsMessage, IInternalConversation) line: 267	
BaseBondConversationFactory(AbstractConversationFactory).acceptMessage(AqGetSetableMessage, IInternalConversation) line: 405	
DefaultConversation.acceptMessage(AqGetSetableMessage) line: 671	

# Here is where we set the price type

ConversationLeg.setStaticDetails

# The BetMessageConverter is where we marshall the BET_PriceType

mBetToAQFields.put(BetProtocol.PRICE_TYPE,new FieldConverter() {

# This is an OrderCounterMessage type

numberOfLegs[1,OK]
BET_CustomerExtended[ROYAL BANK OF SCOTLAND PLC, THE,OK]
parentBrokerRef[BET,OK]
BET_AlternateUsertype[S,OK]
buySell[S,OK]
BET_BidByTime[000000,OK]
BET_UserNo[4236152,OK]
BET_AccountExtended[,OK]
conversationId[BBG-RBSM-EURO-100519-40,OK]
JAVA_CLASS[com.rbsfm.fi.pricing.ecn.autoquote.external.message.OrderCounterMessage,OK]
BET_PendingReason[0000,OK]
BET_BookingTraderName[,OK]
BET_Customer[ROYAL BANK OF SCOTLAND PLC, THE,OK]
ticker[POLGB,OK]
BET_BookingTraderNo[0,OK]
BET_Broker[RBSM,OK]
BET_RepoRate[0000000000,OK]
convTimeLimit[59,OK]
accrued[0.0,OK]
BET_Unused[000,OK]
BET_Originator[1,OK]
BET_SalespersonUUID3[00000000,OK]
BET_SecondsTillExpiry[59,OK]
BET_SalespersonUUID2[00000000,OK]
BET_ListIndex[00,OK]
BET_Version[402,OK]
priceDetailType[BILLY,OK]
BET_Status[1,OK]
BET_UserLogon[RRBSTRAD,OK]
BET_SecurityId[PL0000105078,OK]
BET_PreAgreedPrice[,OK]
BET_RepoPrice[00000000000,OK]
BET_BenchmarkId[,OK]
counterPartyFirmName[ROYAL BANK OF SCOTLAND PLC, THE,OK]
BET_Price[101.01,OK]
BET_ListID[,OK]
BET_Workstation[3,OK]
tradeType[OUTRIGHT,OK]
BET_DealerFirm[00000000,OK]
BET_AlternatecustomerNumber[00061230,OK]
BET_SettlementLocation[,OK]
BET_UserNameExtended[RRBSTRADING2 RRBSTRADING2,OK]
currency[PLN,OK]
BET_CommissionCode[,OK]
convStartTime[2010-05-19 11:36:58.000,OK]
brokerRef[BET,OK]
settlementDate[2010-05-21,OK]
BET_CommissionRate[0.0,OK]
subBrokerRef[RBSM,OK]
BET_Timer[0003,OK]
BET_CompositePrice[09969999695,OK]
clientName[ROYAL BANK OF SCOTLAND PLC, THE,OK]
BET_ListTotal[00,OK]
brokerBookId[,OK]
memoText1[                                                                                ,OK]
memoText2[                                                                                ,OK]
rbosTrader[gallane,OK]
maturityDate[2010-07-25,OK]
BET_Yield[-5.61483,OK]
BET_DirtyPricedFlag[N,OK]
BET_BBTCompositePriceExtended[0099699996948,OK]
BET_DealerUUID[00000000,OK]
noOfDealers[0,OK]
MESSAGETYPE[OrderMessage,OK]
BET_TicketNo[0,OK]
counterpartyTrader[RRBSTRAD,OK]
BET_Side[2,OK]
account[TEST1,OK]
BET_UnitTraded[,OK]
BET_Product[8,OK]
broker[RBSM,OK]
BET_Unused2[0000000000000N00000000000,OK]
BET_Unused3[N0000000000   000000000000000000000000000000000000000000,OK]
BET_Text3[                                                                                ,OK]
BET_Unused1[,OK]
BET_Text2[                                                                                ,OK]
BET_AlternatecustomerName[ROYAL BANK OF SCOTLAND PLC, THE,OK]
BET_Text1[                                                                                ,OK]
BET_AlternateUUID[04566892,OK]
BET_TransactionCost[0.0,OK]
BET_SerialNo[788708,OK]
BET_Competition[0,OK]
BET_Account[TEST1,OK]
BET_AlternateLogon[TXANTHOPOUL1,OK]
IncomingType[Order,OK]
instrumentRef[PL0000105078,OK]
BET_UserName[RRBSTRADING2,OK]
BET_IrregularSettlementFlag[N,OK]
indicativeYieldSpread[0.0,OK]
BET_BenchmarkIdType[00,OK]
BET_DollarPriceExtended[101.01,OK]
BET_AlternateUserName[THOMAS XANTHOPOULOS,OK]
BET_DiscountRate[0.0,OK]
BET_PriceType[P,OK]
BET_SalesBookNo[0,OK]
tradersBookName[SOV-MURP,OK]
qty[100000.0,OK]
BET_OrderSeqNo[40,OK]
indicativePrice[99.627,OK]
BET_UserUUID[05165808,OK]
BET_TradeDatetime[20100519113658,OK]
validTime[15,OK]
counterpartyId[ROYAL BANK OF SCOTLAND PLC, THE,OK]
indicativeYield[2.1,OK]
BET_SecurityType[08,OK]
BET_PartialsAccepted[N,OK]
tradersBookId[442,OK]
BET_Tier[01,OK]
frameSeqNo[124,OK]
BET_Platform[3,OK]
BET_Coupon[0.0,OK]
BET_InventoryFlag[Y,OK]
salesToTrader[false,OK]
BET_AccruedInterest[0.0,OK]
BET_SalesPersonUUID[4566892,OK]
BET_Proceeds[101010.0,OK]
BET_Ticker[POLGB,OK]
coupon[0.0,OK]
BET_CurrencyCode[PLN,OK]
BET_UserLogonExtended[RRBSTRADING2,OK]
BET_Series[,OK]
BET_SubFlag[10,OK]
brkConvId[40,OK]
BET_QuantityExtended[,OK]
BET_BodyLength[0585,OK]
BET_PinId[,OK]
BET_SettlementDate[2010-05-21,OK]
BET_MaturityDate[2010-07-25,OK]
BET_CoveredPriceExtended[0000000000000,OK]
BET_FirmOrder[N,OK]
BET_OrderQty[100000.0,OK]
BET_TotalTradeTime[00090,OK]

# Here is where we write the best MESSAGE

AqMuxMessageReaderWriter(AbstractChannelReaderWriter).writeBytes(ByteChannel, byte[], int) line: 187	
AqMuxMessageReaderWriter(AbstractChannelReaderWriter).writeBytes(byte[]) line: 126	
AqMuxMessageReaderWriter.writeMessage(Message) line: 126	
AqMuxMessageReaderWriter.writeAqMessage(AqMessage) line: 92	
AqMessageConsumer.writeMessage(AqMessage) line: 152	
AqMessageConsumer.access$000(AqMessageConsumer, AqMessage) line: 29	
AqMessageConsumer$1.consume(Object) line: 122	
ProducerConsumer.runConsumerLoop() line: 292	
ProducerConsumer.access$100(ProducerConsumer) line: 24	
ProducerConsumer$1.run() line: 214	
Thread.run() line: 619	

# Attribute on yield stream is 

Leg1.yieldStreamSpread

# Here is where we respond to an RFQ <<---- not true really

AQStreamPriceChange.performStep(IConversation) line: 46	
TraderPriceChangeAction(AbstractBusinessAction).executeStepsThenBusinessLogic(IConversation) line: 105	
StartBusinessAction(AbstractBusinessAction).carryOutNextBusinessLogic(IConversation, IBusinessAction) line: 76	
StartBusinessAction.executeBusinessLogic(IConversation) line: 100	
ConversationRequestHandler.doAction(IInternalConversation) line: 418	
ConversationRequestHandler$PriceRequestHandler.internalHandle(IInternalConversation, AttributeMap) line: 556	
ConversationRequestHandler$PriceRequestHandler(ConversationRequestHandler$AQUserRequestHandlerBase).handle(AttributeMap) line: 530	
ConversationRequestHandler.handleRequest(String, AttributeMap) line: 242	
ConversationRequestDispatcher$2.dispatch() line: 278	

# Here is how we change

appEraseCEEMEABond 'PL0000104857'
go
appEraseCEEMEABond 'PL0000105391'
go

# Changes made to the client

CPClient/config/clients/_base_selections.config
CPClient/config/clients/CEEMEA.config
CPClient/config/clients/CEEMEA.grid.config
CPClient/config/fieldmaps/bond.xml
CPClient/src/Grid/SelectionList/SelectionListManager.cs
CPClient/src/messages/Attributes.cs
CPClient/config/clients/_ceemea_instrument_maintenance_dialog.config
CPClient/src/BondMaintenance/PropertyGrid/Converters/ObligationTypeConverter.cs
CPClient/src/BondMaintenance/PropertyGrid/Converters/QuoteTypeConverter.cs

# Add new enricher

  <component name="QuoteTypeEnricher" class_name="com.rbsfm.fi.instmaint.enrich.QuoteTypeEnricher">
    <requestBondsConsumer>RequestBondsConsumer</requestBondsConsumer>
  </component>

# SQL to erase

appEraseCEEMEABond 'PL0000101937'
go
appEraseCEEMEABond 'PL0000104287'
go

# Test these polish instruments

PL0000101937
PL0000104287

# Add the following for the new RequestBondsConsumer

  <source>SocketServerSource</source>
  <isNewImplementation>false</isNewImplementation>

# Actual launcher for Visual Studion for CEEMEA should bne

env="UAT" debug="true" monitor="false" token="FIPricing-CEEMEA-All-Read" title="CEEMEA" client="CEEMEA" server="ceemea-clientmux-offshore" servers="ceemea-pricing-offshore" usesoap="false" fi_server_details="http://lon3617xns.fm.rbsgrp.net:8080/uat-all_server_details.xml" autologin="true"

# Launcher for Visual Studio is

env="UAT" debug="true" monitor="false" token="FIPricing-EuroGov-All-Read" title="EuroGov Master" client="EUROGOV" server="rates-clientmux-eurogov" servers="eurogov-pricing-master" usesoap="false" fi_server_details="http://lon3617xns.fm.rbsgrp.net:8080/uat-all_server_details.xml" autologin="true"

# Launcher for CP client CEEMEA is

env=UAT
debug=true
monitor=true
shellfile=CPClient
token=FIPricing-CEEMEA-All-Read
title=CEEMEA
client=CEEMEA
server=ceemea-clientmux-offshore
servers=ceemea-pricing-offshore
autologin=true

# Change the selection list for the quote type

<selectionList name="quoteTypeList">
	<item displayName="Price" returnValue="PRICE" filter=""/>
	<item displayName="Yield" returnValue="YIELD" filter=""/>
	<item displayName="Spread" returnValue="SPREAD" filter=""/>
	<item displayName="Discount" returnValue="DISCOUNT" filter=""/>
</selectionList>

# Example bond static

ZAG000016247
ZAG000019878

# To make the quoteType editable the pricing.xml needs

    <rule name="quoteType" action="set" id="SetStaticAttributeMessage5"/>  

# The client required the following two in bond.xml

    <field name="quoteType"  displayName="quoteType" align="left" dataType="System.String" editType="edit" selectionType="quoteTypeList"/>
    <field name="validationState"  displayName="validationState" dataType="System.Int32" editType="edit" />

# Addition of XML configuration in expricepub.xml is required
 
<component name="BondStaticTransformer" class_name="com.rbsfm.fi.pricing.mux.ConfigurableMessageTransformer">
    ...
    <att name="${AttributeNames.QUOTE_TYPE_ATT}"/>
    <att name="${AttributeNames.VALIDATION_STATE_ATT}"/>     

# The following classes need to be modified

com.rbsfm.fi.bet.autoquoter.business.conversation.CategoriseDeal
com.rbsfm.external.fi.pricing.detail.ExternalBondStaticDetails
com.rbsfm.fi.pricing.external.detail.ExternalDetailsAdapter
com.rbsfm.fi.pricing.external.detail.mux.ExternalBondStaticMessage
com.rbsfm.commonx.fi.pricing.detail.rv.ExternalBondStaticDetailsRvAdapter
com.rbsfm.external.fi.pricing.detail.xml.ExternalBondStaticDetailsXmlAdapter
com.rbsfm.fi.pricing.dependency.bond.BondStaticCalculator
com.rbsfm.fi.pricing.external.attribute.AttributeNames
com.rbsfm.fi.bet.autoquoter.business.conversation.QuoteTypeCategoriseDeal
