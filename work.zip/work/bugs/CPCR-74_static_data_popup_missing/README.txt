# The following details are exported from the server side for a FRA

The FRA and Swap nodes share many fields, however the Swap static calculator appends L1- to some of these, indicating the first leg. Below are the attributes emitted by both calculators. Hera are the static attributes emitted by the FRA static calculator.

id=6MFRA_CZK_105v108
 type=FRA
 IsModifiable=true
 isPricingSource=false
 discountCurve=
 startDate=2018-11-24
 endDt=2019-02-25
 effectiveStartDate=2018-11-26
 startDateSymbol=105m
 endDateSymbol=108m
 notional=1000000.0
 rateOrSpread=0.0
 fixFloat=FIXED
 paymentPeriod=3m
 spotDays=0
 paymentHolidayList=PRAGUE
 paymentBasis=A/A
 originDate=TODAY
 shiftConvention=MOD FOLLOWING
 paymentType=INARREARS
 doShiftAccrual=false
 resetLead=0
 resetHolidayList=PRAGUE
 resetConvention=NORMALBE
 firstReg=1900-01-01
 lastReg=1900-01-01
 rateCurve=
 CompFreq=
 fixingIndex=
 fixingRateOvr=0.0
 fixingIndexOvr=false
 fraDayIndex=0
 fraForwardIndex=0
 ccy=CZK
 fix=0.0
 crvId=6MFRA_CZK

The static attributes emitted by the Swap static calculator. 

 id=6MFRA_CZK_20y
 type=SWAP
 IsModifiable=true
 isPricingSource=false
 matDt=2030-02-26
 supExtPrc=false
 SwapId=6MFRA_CZK_20y
 SwapTicker=6MFRA_CZK_20y
 SwapName=6MFRA_CZK 20y
 rateCurve=
 SwapConventionCode=
 discountCurve=
 projectionCurve=
 legsAnchored=false
 fix=0.0
 fixingIndex=WIBOR
 IsWhatIfSwap=false
 ccy=CZK
 EOM_Roll=false
 L1-startDate=2010-02-24
 L1-endDt=2030-02-26
 L1-effectiveStartDate=2010-02-26
 L1-startDateSymbol=0d
 L1-endDateSymbol=20y
 L1-notional=1000000.0
 L1-rateOrSpread=0.0
 L1-fixFloat=FIXED
 L1-paymentPeriod=1y
 L1-spotDays=2
 L1-paymentHolidayList=PRAGUE
 L1-paymentBasis=30/360
 L1-originDate=TODAY
 L1-shiftConvention=MOD FOLLOWING
 L1-paymentType=INARREARS
 L1-doShiftAccrual=true
 L1-resetLead=0
 L1-resetHolidayList=PRAGUE
 L1-resetConvention=N/A
 L1-firstReg=1900-01-01
 L1-lastReg=1900-01-01
 L1-rateCurve=
 L1-CompFreq=1d
 L1-fixingIndex=null
 L1-fixingRateOvr=0.0
 L1-fixingIndexOvr=false
 L2-startDate=2010-02-24
 L2-endDt=2030-02-26
 L2-effectiveStartDate=2010-02-26
 L2-startDateSymbol=0d
 L2-endDateSymbol=20y
 L2-notional=-1000000.0
 L2-rateOrSpread=0.0
 L2-fixFloat=FLOAT
 L2-paymentPeriod=6m
 L2-spotDays=2
 L2-paymentHolidayList=PRAGUE
 L2-paymentBasis=A/A
 L2-originDate=TODAY
 L2-shiftConvention=MOD FOLLOWING
 L2-paymentType=INARREARS
 L2-doShiftAccrual=true
 L2-resetLead=-2
 L2-resetHolidayList=PRAGUE
 L2-resetConvention=NORMALBE
 L2-firstReg=1900-01-01
 L2-lastReg=1900-01-01
 L2-rateCurve=
 L2-CompFreq=1d
 L2-fixingIndex=WIBOR
 L2-fixingRateOvr=0.0
 L2-fixingIndexOvr=false

# Next

System.NullReferenceException: Object reference not set to an instance of an object.
   at Rbsfm.Capmarkets.EuroPricingClient.FraStaticDialog.GetValue(IFieldDataSet data, String fieldName, String defaultValue) in C:\work\development\client_all\cpclient\CPClient\src\forms\FraStaticDialog.cs:line 422
   at Rbsfm.Capmarkets.EuroPricingClient.FraStaticDialog.GetValue(IFieldDataSet data, String fieldName) in C:\work\development\client_all\cpclient\CPClient\src\forms\FraStaticDialog.cs:line 412
   at Rbsfm.Capmarkets.EuroPricingClient.FraStaticDialog.GetValue(String fieldName) in C:\work\development\client_all\cpclient\CPClient\src\forms\FraStaticDialog.cs:line 407
   at Rbsfm.Capmarkets.EuroPricingClient.FraStaticDialog..ctor(String rowName, IDataProvider dataProvider, IFieldDataSetMutator mutator) in C:\work\development\client_all\cpclient\CPClient\src\forms\FraStaticDialog.cs:line 251
   at Rbsfm.Capmarkets.EuroPricingClient.MainForm.MainContextMenu_OnStaticData(Object sender, ContextMenuItemGridClickEventArgs e) in C:\work\development\client_all\cpclient\CPClient\src\forms\MainForm.cs:line 4470
   at Rbsfm.Capmarkets.EuroPricingClient.MainContextMenu.StaticData_Click(Object sender, EventArgs e) in C:\work\development\client_all\cpclient\CPClient\src\forms\Menu\MainContextMenu.cs:line 2526
   at System.Windows.Forms.MenuItem.OnClick(EventArgs e)
   at System.Windows.Forms.MenuItem.MenuItemData.Execute()
   at System.Windows.Forms.Command.Invoke()
   at System.Windows.Forms.Command.DispatchID(Int32 id)
   at System.Windows.Forms.Control.WmCommand(Message& m)
   at System.Windows.Forms.Control.WndProc(Message& m)
   at System.Windows.Forms.ScrollableControl.WndProc(Message& m)
   at System.Windows.Forms.ContainerControl.WndProc(Message& m)
   at System.Windows.Forms.UserControl.WndProc(Message& m)
   at System.Windows.Forms.Control.ControlNativeWindow.OnMessage(Message& m)

# Next exception 

System.NullReferenceException: Object reference not set to an instance of an object.
   at Rbsfm.Capmarkets.EuroPricingClient.FraStaticDialog.UpdateRateLabel(IFieldDataSet data) in C:\work\development\client_all\cpclient\CPClient\src\forms\FraStaticDialog.cs:line 3173
   at Rbsfm.Capmarkets.EuroPricingClient.FraStaticDialog..ctor(String rowName, IDataProvider dataProvider, IFieldDataSetMutator mutator) in C:\work\development\client_all\cpclient\CPClient\src\forms\FraStaticDialog.cs:line 247
   at Rbsfm.Capmarkets.EuroPricingClient.MainForm.MainContextMenu_OnStaticData(Object sender, ContextMenuItemGridClickEventArgs e) in C:\work\development\client_all\cpclient\CPClient\src\forms\MainForm.cs:line 4470
   at Rbsfm.Capmarkets.EuroPricingClient.MainContextMenu.StaticData_Click(Object sender, EventArgs e) in C:\work\development\client_all\cpclient\CPClient\src\forms\Menu\MainContextMenu.cs:line 2526
   at System.Windows.Forms.MenuItem.OnClick(EventArgs e)
   at System.Windows.Forms.MenuItem.MenuItemData.Execute()
   at System.Windows.Forms.Command.Invoke()
   at System.Windows.Forms.Command.DispatchID(Int32 id)
   at System.Windows.Forms.Control.WmCommand(Message& m)
   at System.Windows.Forms.Control.WndProc(Message& m)
   at System.Windows.Forms.ScrollableControl.WndProc(Message& m)
   at System.Windows.Forms.ContainerControl.WndProc(Message& m)
   at System.Windows.Forms.UserControl.WndProc(Message& m)
   at System.Windows.Forms.Control.ControlNativeWindow.OnMessage(Message& m)
   at System.Windows.Forms.Control.ControlNativeWindow.WndProc(Message& m)
   at System.Windows.Forms.NativeWindow.Callback(IntPtr hWnd, Int32 msg, IntPtr wparam, IntPtr lparam)

# Exception from the swap static dialog

System.NullReferenceException: Object reference not set to an instance of an object.
   at Rbsfm.Capmarkets.EuroPricingClient.FraStaticDialog.PopulateHolidayLists() in C:\work\development\client_all\cpclient\CPClient\src\forms\FraStaticDialog.cs:line 479
   at Rbsfm.Capmarkets.EuroPricingClient.FraStaticDialog..ctor(IDataProvider dataProvider, String rowName) in C:\work\development\client_all\cpclient\CPClient\src\forms\FraStaticDialog.cs:line 239
   at Rbsfm.Capmarkets.EuroPricingClient.FraStaticDialog..ctor(String rowName, IDataProvider dataProvider, IFieldDataSetMutator mutator) in C:\work\development\client_all\cpclient\CPClient\src\forms\FraStaticDialog.cs:line 244
   at Rbsfm.Capmarkets.EuroPricingClient.MainForm.MainContextMenu_OnStaticData(Object sender, ContextMenuItemGridClickEventArgs e) in C:\work\development\client_all\cpclient\CPClient\src\forms\MainForm.cs:line 4470
   at Rbsfm.Capmarkets.EuroPricingClient.MainContextMenu.StaticData_Click(Object sender, EventArgs e) in C:\work\development\client_all\cpclient\CPClient\src\forms\Menu\MainContextMenu.cs:line 2526
   at System.Windows.Forms.MenuItem.OnClick(EventArgs e)
   at System.Windows.Forms.MenuItem.MenuItemData.Execute()
   at System.Windows.Forms.Command.Invoke()
   at System.Windows.Forms.Command.DispatchID(Int32 id)
   at System.Windows.Forms.Control.WmCommand(Message& m)
   at System.Windows.Forms.Control.WndProc(Message& m)
   at System.Windows.Forms.ScrollableControl.WndProc(Message& m)
   at System.Windows.Forms.ContainerControl.WndProc(Message& m)
   at System.Windows.Forms.UserControl.WndProc(Message& m)
   at System.Windows.Forms.Control.ControlNativeWindow.OnMessage(Message& m)
   at System.Windows.Forms.Control.ControlNativeWindow.WndProc(Message& m)
   at System.Windows.Forms.NativeWindow.Callback(IntPtr hWnd, Int32 msg, IntPtr wparam, IntPtr lparam)


# Static data popup is missing for FRA points

Right click on a money market to get the popup
