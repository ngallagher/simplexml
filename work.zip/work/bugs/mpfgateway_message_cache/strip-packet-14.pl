$ip_address = "160.43.166.170";
$debug = 0;

while(<>){
    if($left_boundary_isin =~ /.+/ && $isin_found =~ /[A-Z0-9]+/ && /MPF-PACKET-14.*$ip_address.*\|\s*GDCO\s*/) {
        if($debug) {
            print "..$left_boundary_isin  LDNRBS $isin_found\n";
        } else {
            print "$isin_found\n";
        }
        $left_boundary_isin = "";
    }
    elsif($left_boundary_isin =~ /.+/ && /MPF-PACKET-14.*$ip_address.*\|\s*([A-Z0-9]+)\s*$/) {
        $isin_found = $1;
    }
    elsif(/MPF-PACKET-14.*$ip_address.*\|.*\.\.(.*)\s\sLDNRBS/) {
        $left_boundary_isin = $1;
    }
}
