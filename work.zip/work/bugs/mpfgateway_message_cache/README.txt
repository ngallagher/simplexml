# Here is where the ECN price feed restart sends out prices

MuxPublisher.updateQuote(EcnFeedPriceDetails, boolean) line: 214	
MuxPublisher.performQuoteUpdated(EcnFeedPriceDetails) line: 210	
MuxPublisher(AbstractEcnPublisher).throttledQuoteUpdated(EcnFeedPriceDetails) line: 775	
AbstractEcnPublisher$ThrottleConsumer.run() line: 71	

# On a bounce of the ECN price feed gateway a different process takes place

When the ECN price feed is bounced the MuxPublisher cache is empty. So the 
method sentAllBrokerPrices sends nothing. However all the prices are pushed
back in to the MuxPublisher so that it can populate its mCache. This has a
side affect. In that it results in all of the prices it is given to be sent
out, regardless of whether those prices are enabled or not.


# On establishing a connection the following is published

The MuxPublisher will send out all EcnPriceFeedDetails in its mCache except those 
EcnPriceFeedDetails that are not enabled. So this will result in only a subset of
those bonds being sent out. The following if statement in sendAllBrokerPrices is
responsible.

if (!mUseQuoteStatus || (details.isEnabled() || mSendEmptyPrices)) {
   processUpdate(details);
}

# Before bounce the message cache count is

mCache {
    EcnFeedPriceDetails = ConcurrentHashMap [430] 
    EcnClosingPriceDetails = ConcurrentHashMap [355] 
    Heartbeat = ConcurrentHashMap@2627842 [1] 
}

mUpdateTimes {
    EcnClosingPriceDetails = HashMap [786]
}

