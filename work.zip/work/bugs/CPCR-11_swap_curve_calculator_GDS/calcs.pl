while(<>){
    chop;
    s/\s*$//;
    s/^\s*//;
    if(/([a-zA-Z0-9]+)_([a-zA-Z0-9]+)_(.*)/){
        print "exec CalculatorStore \@NodeRef = '$1_$2_$3',\@CalculatorId = 'SwapCurveCalc',\@JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.job.SwapCurveCalculator',\@Version = 0,\@ServerName = 'script',\@UpdaterRef = 'script'\n";
        print "exec CalculatorAttributeStore \@NodeRef = '$1_$2_$3',\@CalculatorId = 'SwapCurveCalc',\@AttributeName = 'lastRunTime',\@ValueType = 'STRING',\@ValueInt = 0,\@ValueFloat = 0.0,\@ValueDatetime = '1-1-1900',\@ValueString = '01 Jan 1900 00:00',\@Version = 0,\@ServerName = 'script',\@UpdaterRef = 'script'\n";
        print "exec CalculatorAttributeStore \@NodeRef = '$1_$2_$3',\@CalculatorId = 'SwapCurveCalc',\@AttributeName = 'sodRate',\@ValueType = 'FLOAT',\@ValueInt = 0,\@ValueFloat = 0.0,\@ValueDatetime = '1-1-1900',\@ValueString = '',\@Version = 0,\@ServerName = 'script',\@UpdaterRef = 'script'\n";
        print "exec CalculatorAttributeStore \@NodeRef = '$1_$2_$3',\@CalculatorId = 'SwapCurveCalc',\@AttributeName = 'sodSpread',\@ValueType = 'FLOAT',\@ValueInt = 0,\@ValueFloat = 0.0,\@ValueDatetime = '1-1-1900',\@ValueString = '',\@Version = 0,\@ServerName = 'script',\@UpdaterRef = 'script'\n";
        print "exec CalculatorAttributeStore \@NodeRef = '$1_$2_$3',\@CalculatorId = 'SwapCurveCalc',\@AttributeName = 'dailySpread',\@ValueType = 'FLOAT',\@ValueInt = 0,\@ValueFloat = 0.0,\@ValueDatetime = '1-1-1900',\@ValueString = '',\@Version = 0,\@ServerName = 'script',\@UpdaterRef = 'script'\n";
        print "exec CalculatorAttributeStore \@NodeRef = '$1_$2_$3',\@CalculatorId = 'SwapCurveCalc',\@AttributeName = 'curvePointNodes',\@ValueType = 'STRING',\@ValueInt = 0,\@ValueFloat = 0.0,\@ValueDatetime = '1-1-1900',\@ValueString = '',\@Version = 0,\@ServerName = 'script',\@UpdaterRef = 'script'\n";
        print "exec CalculatorAttributeStore \@NodeRef = '$1_$2_$3',\@CalculatorId = 'SwapCurveCalc',\@AttributeName = 'curvePointBenchmark',\@ValueType = 'STRING',\@ValueInt = 0,\@ValueFloat = 0.0,\@ValueDatetime = '1-1-1900',\@ValueString = 'FRA_$2_$3',\@Version = 0,\@ServerName = 'script',\@UpdaterRef = 'script'\n";
        print "go\n";
    }
}
