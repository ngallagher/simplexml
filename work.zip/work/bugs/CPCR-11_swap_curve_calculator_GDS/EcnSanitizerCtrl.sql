exec EcnSanitizerCtrlStore "AQ Orders","fmDSInstr","XMA",1,"gallane","gallane"
exec EcnSanitizerCtrlStore "AQ Orders","fmCPInstr","XMA",1,"gallane","gallane"
exec EcnSanitizerCtrlStore "AQ Orders","fmMaxMvmnt","0.00050",1,"gallane","gallane"
exec EcnSanitizerCtrlStore "AQ Orders","fmTimePeriod","10000",1,"gallane","gallane"
exec EcnSanitizerCtrlStore "AQ Orders","futFdTol","0.0003",1,"gallane","gallane"

