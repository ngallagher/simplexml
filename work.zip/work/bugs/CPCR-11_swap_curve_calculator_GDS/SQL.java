  
    
    private String generateSQL() {
        StringWriter text = new StringWriter();
        PrintWriter out = new PrintWriter(text);
        
        for(String curve : curveList) {
            generateSQL(out, curve);
            generateSQL(out, curve);
            generateSQL(out, curve);
        }        
        out.println("go");
        out.close();
        return text.toString();
    }
    
    private void generateSQL(PrintWriter out, String curveName) {
        Curve curve = getExternalCurve(curveName);
        List<CurvePoint> curvePoints = curve.getCurvePoints();
        
        if(curvePoints != null && !curvePoints.isEmpty()) {
            for(CurvePoint point : curvePoints) {     
                String nodeId = curveManager.getNodeRef(point);
                GdsSwapCurveCalculator calculator = getCalculator(nodeId);
                
                if(calculator != null) {
                    generateCalculatorSQL(out, nodeId, GdsSwapCurveCalculator.class);
                    generateAttributeSQL(out, nodeId, GdsSwapCurveCalculator.CURVE_RATE);
                    generateAttributeSQL(out, nodeId, GdsSwapCurveCalculator.CURVE_SPREAD);
                    generateAttributeSQL(out, nodeId, GdsSwapCurveCalculator.TRADER_SPREAD);
                    generateAttributeSQL(out, nodeId, GdsSwapCurveCalculator.BENCHMARK_CURVE);
                }
            }
        }
    }
    
    private void generateCalculatorSQL(PrintWriter out, String nodeId, Class<?> calcType) {
        out.printf("exec CalculatorStore ");
        out.printf("@NodeRef = '%s',", nodeId);
        out.printf("@CalculatorId = 'GdsSwapCurveCalc',");
        out.printf("@JavaClass = '%s',", calcType.getName());
        out.printf("@Version = 0,");
        out.printf("@ServerName = 'script',");
        out.printf("@UpdaterRef = 'script'"); 
        out.println();
    }
    
    private void generateAttributeSQL(PrintWriter out, String nodeId, String name) {
        out.printf("exec CalculatorAttributeStore ");
        out.printf("@NodeRef = '%s',", nodeId);
        out.printf("@CalculatorId = 'GdsSwapCurveCalc',");
        out.printf("@AttributeName = '%s',", name); 
        out.printf("@ValueType = 'FLOAT',");
        out.printf("@ValueInt = 0,");
        out.printf("@ValueFloat = 0.0,");
        out.printf("@ValueDatetime = '1-1-1900',");
        out.printf("@ValueString = '',");
        out.printf("@Version = 1,");
        out.printf("@ServerName = 'script',");
        out.printf("@UpdaterRef = 'script'");  
        out.println();
    }
    
    public Admin getAdmin() {
        return new Admin();
    }
    
    public static interface AdminMBean {
        
        public static final String JMX_DESCRIPTION = "Load Gds Curve closes";
        public static final Object[][] JMX_METHODS = { { "runJobNow", "run the job now" }, { "generateCalculatorSQL", "generate the calculator SQL"} };
        
        public String runJobNow();
        public String generateCalculatorSQL();
    }
    
    public class Admin implements AdminMBean {
        
        public String generateCalculatorSQL() {
            StringWriter sw = new StringWriter();
            sw.write("<pre>");
            sw.write(generateSQL());
            sw.write("Job complete");
            sw.write("</pre>");
            return sw.toString();  
        }
        
        public String runJobNow() {
            StringWriter sw = new StringWriter();
            sw.write("<pre>");
            run();
            sw.write(getDescription());
            sw.write("Job complete");
            sw.write("</pre>");
            return sw.toString();
        }
    }

