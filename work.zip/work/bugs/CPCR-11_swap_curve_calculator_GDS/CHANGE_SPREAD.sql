exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '102v105_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_102v105',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '105v108_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_105v108',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '108v111_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_108v111',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '111v114_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_111v114',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '114v117_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_114v117',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '117v120_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_117v120',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '120v123_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_120v123',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '123v126_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_123v126',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '126v129_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_126v129',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '129v132_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_129v132',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '12v15_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_12v15',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '132v135_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_132v135',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '135v138_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_135v138',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '138v141_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_138v141',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '141v144_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_141v144',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '144v147_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_144v147',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '147v150_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_147v150',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '150v153_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_150v153',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '153v156_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_153v156',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '156v159_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_156v159',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '159v162_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_159v162',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '15v18_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_15v18',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '162v165_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_162v165',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '165v168_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_165v168',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '168v171_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_168v171',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '171v174_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_171v174',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '174v177_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_174v177',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '177v180_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_177v180',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '18v21_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_18v21',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '20y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_20y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '21v24_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_21v24',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '24v27_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_24v27',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '25y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_25y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '27v30_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_27v30',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '30v33_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_30v33',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '30y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_30y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '33v36_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_33v36',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '36v39_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_36v39',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '39v42_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_39v42',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '3m_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_3m',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '3v6_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_3v6',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '42v45_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_42v45',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '45v48_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_45v48',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '48v51_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_48v51',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '51v54_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_51v54',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '54v57_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_54v57',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '57v60_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_57v60',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '60v63_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_60v63',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '63v66_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_63v66',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '66v69_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_66v69',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '69v72_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_69v72',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '6v9_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_6v9',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '72v75_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_72v75',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '75v78_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_75v78',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '78v81_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_78v81',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '81v84_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_81v84',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '84v87_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_84v87',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '87v90_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_87v90',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '90v93_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_90v93',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '93v96_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_93v96',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '96v99_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_96v99',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '99v102_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_99v102',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = '9v12_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_9v12',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = 'O/N_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_O/N',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_CZK',@CalculatorId = 'T/N_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_CZK_T/N',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '102v105_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_102v105',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '105v108_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_105v108',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '108v111_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_108v111',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '111v114_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_111v114',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '114v117_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_114v117',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '117v120_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_117v120',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '120v123_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_120v123',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '123v126_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_123v126',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '126v129_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_126v129',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '129v132_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_129v132',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '12v15_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_12v15',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '132v135_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_132v135',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '135v138_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_135v138',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '138v141_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_138v141',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '141v144_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_141v144',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '144v147_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_144v147',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '147v150_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_147v150',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '150v153_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_150v153',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '153v156_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_153v156',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '156v159_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_156v159',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '159v162_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_159v162',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '15v18_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_15v18',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '162v165_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_162v165',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '165v168_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_165v168',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '168v171_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_168v171',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '171v174_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_171v174',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '174v177_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_174v177',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '177v180_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_177v180',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '18v21_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_18v21',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '20y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_20y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '21v24_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_21v24',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '24v27_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_24v27',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '25y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_25y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '27v30_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_27v30',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '30v33_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_30v33',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '30y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_30y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '33v36_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_33v36',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '36v39_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_36v39',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '39v42_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_39v42',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '3m_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_3m',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '3v6_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_3v6',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '42v45_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_42v45',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '45v48_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_45v48',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '48v51_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_48v51',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '51v54_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_51v54',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '54v57_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_54v57',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '57v60_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_57v60',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '60v63_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_60v63',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '63v66_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_63v66',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '66v69_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_66v69',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '69v72_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_69v72',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '6v9_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_6v9',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '72v75_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_72v75',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '75v78_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_75v78',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '78v81_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_78v81',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '81v84_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_81v84',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '84v87_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_84v87',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '87v90_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_87v90',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '90v93_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_90v93',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '93v96_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_93v96',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '96v99_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_96v99',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '99v102_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_99v102',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = '9v12_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_9v12',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = 'O/N_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_O/N',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_HUF',@CalculatorId = 'T/N_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_HUF_T/N',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '102v105_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_102v105',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '105v108_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_105v108',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '108v111_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_108v111',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '111v114_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_111v114',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '114v117_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_114v117',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '117v120_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_117v120',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '120v123_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_120v123',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '123v126_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_123v126',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '126v129_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_126v129',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '129v132_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_129v132',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '12v15_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_12v15',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '132v135_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_132v135',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '135v138_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_135v138',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '138v141_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_138v141',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '141v144_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_141v144',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '144v147_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_144v147',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '147v150_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_147v150',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '150v153_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_150v153',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '153v156_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_153v156',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '156v159_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_156v159',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '159v162_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_159v162',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '15v18_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_15v18',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '15y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_15y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '162v165_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_162v165',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '165v168_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_165v168',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '168v171_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_168v171',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '171v174_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_171v174',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '174v177_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_174v177',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '177v180_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_177v180',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '18v21_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_18v21',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '20y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_20y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '21v24_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_21v24',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '24v27_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_24v27',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '27v30_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_27v30',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '30v33_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_30v33',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '33v36_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_33v36',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '36v39_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_36v39',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '39v42_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_39v42',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '3m_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_3m',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '3v6_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_3v6',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '42v45_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_42v45',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '45v48_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_45v48',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '48v51_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_48v51',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '51v54_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_51v54',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '54v57_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_54v57',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '57v60_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_57v60',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '60v63_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_60v63',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '63v66_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_63v66',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '66v69_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_66v69',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '69v72_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_69v72',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '6v9_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_6v9',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '72v75_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_72v75',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '75v78_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_75v78',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '78v81_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_78v81',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '81v84_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_81v84',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '84v87_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_84v87',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '87v90_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_87v90',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '90v93_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_90v93',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '93v96_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_93v96',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '96v99_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_96v99',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '99v102_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_99v102',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN',@CalculatorId = '9v12_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = '6MFRA_PLN_9v12',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '102v105_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_102v105',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '105v108_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_105v108',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '108v111_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_108v111',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '111v114_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_111v114',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '114v117_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_114v117',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '117v120_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_117v120',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '120v123_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_120v123',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '123v126_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_123v126',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '126v129_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_126v129',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '129v132_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_129v132',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '12v15_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_12v15',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '132v135_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_132v135',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '135v138_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_135v138',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '138v141_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_138v141',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '141v144_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_141v144',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '144v147_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_144v147',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '147v150_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_147v150',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '150v153_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_150v153',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '153v156_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_153v156',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '156v159_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_156v159',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '159v162_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_159v162',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '15v18_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_15v18',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '162v165_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_162v165',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '165v168_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_165v168',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '168v171_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_168v171',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '171v174_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_171v174',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '174v177_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_174v177',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '177v180_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_177v180',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '18v21_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_18v21',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '20y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_20y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '21v24_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_21v24',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '24v27_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_24v27',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '25y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_25y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '27v30_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_27v30',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '30v33_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_30v33',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '30y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_30y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '33v36_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_33v36',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '36v39_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_36v39',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '39v42_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_39v42',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '3m_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_3m',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '3v6_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_3v6',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '42v45_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_42v45',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '45v48_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_45v48',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '48v51_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_48v51',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '51v54_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_51v54',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '54v57_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_54v57',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '57v60_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_57v60',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '60v63_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_60v63',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '63v66_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_63v66',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '66v69_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_66v69',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '69v72_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_69v72',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '6v9_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_6v9',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '72v75_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_72v75',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '75v78_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_75v78',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '78v81_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_78v81',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '81v84_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_81v84',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '84v87_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_84v87',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '87v90_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_87v90',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '90v93_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_90v93',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '93v96_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_93v96',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '96v99_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_96v99',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '99v102_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_99v102',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = '9v12_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_9v12',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = 'O/N_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_O/N',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_HUF',@CalculatorId = 'T/N_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_HUF_T/N',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '102v105_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_102v105',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '105v108_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_105v108',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '108v111_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_108v111',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '111v114_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_111v114',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '114v117_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_114v117',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '117v120_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_117v120',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '120v123_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_120v123',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '123v126_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_123v126',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '126v129_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_126v129',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '129v132_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_129v132',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '12v15_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_12v15',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '132v135_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_132v135',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '135v138_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_135v138',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '138v141_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_138v141',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '141v144_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_141v144',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '144v147_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_144v147',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '147v150_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_147v150',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '150v153_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_150v153',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '153v156_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_153v156',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '156v159_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_156v159',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '159v162_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_159v162',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '15v18_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_15v18',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '15y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_15y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '162v165_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_162v165',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '165v168_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_165v168',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '168v171_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_168v171',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '171v174_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_171v174',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '174v177_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_174v177',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '177v180_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_177v180',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '18v21_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_18v21',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '20y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_20y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '21v24_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_21v24',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '24v27_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_24v27',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '25y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_25y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '27v30_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_27v30',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '30v33_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_30v33',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '30y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_30y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '33v36_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_33v36',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '36v39_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_36v39',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '39v42_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_39v42',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '3m_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_3m',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '3v6_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_3v6',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '42v45_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_42v45',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '45v48_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_45v48',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '48v51_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_48v51',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '51v54_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_51v54',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '54v57_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_54v57',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '57v60_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_57v60',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '60v63_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_60v63',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '63v66_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_63v66',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '66v69_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_66v69',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '69v72_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_69v72',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '6v9_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_6v9',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '72v75_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_72v75',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '75v78_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_75v78',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '78v81_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_78v81',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '81v84_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_81v84',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '84v87_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_84v87',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '87v90_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_87v90',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '90v93_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_90v93',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '93v96_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_93v96',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '96v99_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_96v99',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '99v102_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_99v102',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ILS',@CalculatorId = '9v12_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ILS_9v12',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '102v105_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_102v105',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '105v108_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_105v108',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '108v111_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_108v111',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '111v114_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_111v114',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '114v117_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_114v117',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '117v120_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_117v120',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '120v123_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_120v123',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '123v126_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_123v126',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '126v129_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_126v129',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '129v132_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_129v132',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '12v15_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_12v15',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '132v135_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_132v135',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '135v138_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_135v138',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '138v141_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_138v141',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '141v144_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_141v144',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '144v147_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_144v147',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '147v150_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_147v150',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '150v153_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_150v153',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '153v156_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_153v156',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '156v159_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_156v159',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '159v162_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_159v162',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '15v18_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_15v18',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '15y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_15y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '162v165_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_162v165',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '165v168_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_165v168',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '168v171_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_168v171',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '171v174_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_171v174',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '174v177_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_174v177',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '177v180_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_177v180',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '18v21_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_18v21',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '20y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_20y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '21v24_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_21v24',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '24v27_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_24v27',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '27v30_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_27v30',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '30v33_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_30v33',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '33v36_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_33v36',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '36v39_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_36v39',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '39v42_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_39v42',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '3m_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_3m',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '3v6_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_3v6',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '42v45_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_42v45',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '45v48_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_45v48',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '48v51_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_48v51',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '51v54_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_51v54',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '54v57_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_54v57',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '57v60_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_57v60',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '60v63_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_60v63',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '63v66_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_63v66',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '66v69_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_66v69',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '69v72_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_69v72',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '6v9_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_6v9',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '72v75_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_72v75',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '75v78_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_75v78',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '78v81_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_78v81',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '81v84_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_81v84',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '84v87_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_84v87',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '87v90_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_87v90',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '90v93_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_90v93',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '93v96_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_93v96',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '96v99_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_96v99',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '99v102_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_99v102',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = '9v12_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_9v12',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = 'O/N_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_O/N',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN',@CalculatorId = 'T/N_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_PLN_T/N',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '102v105_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_102v105',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '105v108_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_105v108',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '108v111_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_108v111',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '111v114_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_111v114',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '114v117_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_114v117',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '117v120_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_117v120',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '12v15_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_12v15',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '15v18_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_15v18',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '18v21_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_18v21',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '1m_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_1m',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '1wk_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_1wk',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '21v24_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_21v24',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '24v27_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_24v27',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '27v30_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_27v30',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '2m_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_2m',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '2wk_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_2wk',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '30v33_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_30v33',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '33v36_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_33v36',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '36v39_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_36v39',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '39v42_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_39v42',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '3m_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_3m',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '3v6_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_3v6',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '42v45_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_42v45',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '45v48_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_45v48',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '48v51_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_48v51',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '51v54_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_51v54',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '54v57_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_54v57',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '57v60_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_57v60',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '60v63_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_60v63',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '63v66_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_63v66',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '66v69_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_66v69',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '69v72_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_69v72',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '6v9_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_6v9',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '72v75_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_72v75',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '75v78_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_75v78',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '78v81_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_78v81',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '81v84_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_81v84',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '84v87_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_84v87',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '87v90_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_87v90',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '90v93_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_90v93',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '93v96_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_93v96',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '96v99_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_96v99',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '99v102_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_99v102',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = '9v12_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_9v12',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = 'O/N_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_O/N',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_RUB',@CalculatorId = 'T/N_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_RUB_T/N',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '102v105_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_102v105',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '105v108_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_105v108',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '108v111_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_108v111',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '111v114_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_111v114',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '114v117_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_114v117',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '117v120_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_117v120',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '120v123_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_120v123',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '123v126_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_123v126',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '126v129_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_126v129',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '129v132_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_129v132',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '12v15_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_12v15',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '132v135_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_132v135',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '135v138_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_135v138',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '138v141_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_138v141',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '141v144_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_141v144',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '144v147_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_144v147',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '147v150_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_147v150',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '150v153_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_150v153',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '153v156_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_153v156',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '156v159_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_156v159',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '159v162_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_159v162',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '15v18_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_15v18',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '15y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_15y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '162v165_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_162v165',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '165v168_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_165v168',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '168v171_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_168v171',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '171v174_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_171v174',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '174v177_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_174v177',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '177v180_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_177v180',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '180v183_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_180v183',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '183v186_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_183v186',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '186v189_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_186v189',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '189v192_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_189v192',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '18v21_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_18v21',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '20y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_20y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '21v24_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_21v24',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '24v27_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_24v27',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '27v30_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_27v30',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '30v33_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_30v33',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '33v36_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_33v36',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '36v39_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_36v39',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '39v42_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_39v42',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '3m_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_3m',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '3v6_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_3v6',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '42v45_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_42v45',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '45v48_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_45v48',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '48v51_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_48v51',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '51v54_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_51v54',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '54v57_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_54v57',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '57v60_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_57v60',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '60v63_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_60v63',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '63v66_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_63v66',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '66v69_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_66v69',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '69v72_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_69v72',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '6v9_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_6v9',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '72v75_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_72v75',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '75v78_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_75v78',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '78v81_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_78v81',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '81v84_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_81v84',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '84v87_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_84v87',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '87v90_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_87v90',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '90v93_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_90v93',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '93v96_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_93v96',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '96v99_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_96v99',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '99v102_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_99v102',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_TRY',@CalculatorId = '9v12_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_TRY_9v12',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '102v105_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_102v105',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '105v108_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_105v108',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '108v111_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_108v111',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '111v114_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_111v114',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '114v117_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_114v117',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '117v120_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_117v120',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '120v123_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_120v123',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '123v126_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_123v126',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '126v129_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_126v129',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '129v132_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_129v132',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '12v15_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_12v15',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '132v135_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_132v135',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '135v138_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_135v138',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '138v141_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_138v141',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '141v144_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_141v144',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '144v147_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_144v147',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '147v150_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_147v150',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '150v153_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_150v153',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '153v156_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_153v156',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '156v159_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_156v159',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '159v162_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_159v162',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '15v18_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_15v18',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '162v165_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_162v165',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '165v168_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_165v168',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '168v171_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_168v171',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '171v174_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_171v174',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '174v177_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_174v177',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '177v180_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_177v180',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '180v183_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_180v183',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '18v21_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_18v21',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '20y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_20y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '21v24_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_21v24',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '24v27_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_24v27',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '25y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_25y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '27v30_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_27v30',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '30v33_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_30v33',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '30y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_30y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '33v36_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_33v36',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '35y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_35y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '36v39_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_36v39',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '39v42_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_39v42',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '3m_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_3m',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '3v6_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_3v6',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '40y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_40y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '42v45_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_42v45',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '45v48_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_45v48',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '48v51_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_48v51',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '50y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_50y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '51v54_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_51v54',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '54v57_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_54v57',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '57v60_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_57v60',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '60v63_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_60v63',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '60y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_60y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '63v66_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_63v66',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '66v69_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_66v69',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '69v72_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_69v72',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '6v9_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_6v9',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '70y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_70y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '72v75_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_72v75',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '75v78_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_75v78',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '78v81_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_78v81',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '81v84_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_81v84',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '84v87_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_84v87',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '87v90_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_87v90',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '90v93_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_90v93',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '93v96_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_93v96',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '96v99_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_96v99',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '99v102_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_99v102',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'CFRA_ZAR',@CalculatorId = '9v12_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'CFRA_ZAR_9v12',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '102v105_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_102v105',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '105v108_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_105v108',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '108v111_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_108v111',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '111v114_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_111v114',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '114v117_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_114v117',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '117v120_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_117v120',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '120v123_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_120v123',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '123v126_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_123v126',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '126v129_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_126v129',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '129v132_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_129v132',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '12v15_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_12v15',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '132v135_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_132v135',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '135v138_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_135v138',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '138v141_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_138v141',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '141v144_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_141v144',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '144v147_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_144v147',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '147v150_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_147v150',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '150v153_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_150v153',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '153v156_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_153v156',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '156v159_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_156v159',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '159v162_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_159v162',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '15v18_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_15v18',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '162v165_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_162v165',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '165v168_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_165v168',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '168v171_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_168v171',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '171v174_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_171v174',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '174v177_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_174v177',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '177v180_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_177v180',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '18v21_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_18v21',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '20y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_20y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '21v24_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_21v24',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '24v27_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_24v27',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '25y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_25y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '27v30_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_27v30',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '30v33_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_30v33',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '30y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_30y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '33v36_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_33v36',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '36v39_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_36v39',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '39v42_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_39v42',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '3m_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_3m',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '3v6_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_3v6',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '42v45_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_42v45',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '45v48_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_45v48',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '48v51_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_48v51',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '51v54_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_51v54',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '54v57_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_54v57',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '57v60_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_57v60',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '60v63_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_60v63',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '63v66_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_63v66',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '66v69_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_66v69',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '69v72_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_69v72',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '6v9_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_6v9',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '72v75_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_72v75',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '75v78_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_75v78',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '78v81_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_78v81',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '81v84_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_81v84',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '84v87_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_84v87',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '87v90_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_87v90',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '90v93_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_90v93',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '93v96_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_93v96',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '96v99_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_96v99',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '99v102_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_99v102',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = '9v12_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_9v12',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = 'O/N_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_O/N',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_HUF',@CalculatorId = 'T/N_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_HUF_T/N',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '102v105_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_102v105',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '105v108_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_105v108',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '108v111_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_108v111',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '111v114_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_111v114',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '114v117_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_114v117',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '117v120_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_117v120',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '120v123_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_120v123',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '123v126_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_123v126',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '126v129_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_126v129',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '129v132_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_129v132',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '12v15_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_12v15',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '132v135_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_132v135',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '135v138_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_135v138',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '138v141_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_138v141',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '141v144_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_141v144',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '144v147_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_144v147',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '147v150_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_147v150',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '150v153_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_150v153',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '153v156_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_153v156',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '156v159_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_156v159',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '159v162_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_159v162',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '15v18_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_15v18',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '162v165_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_162v165',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '165v168_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_165v168',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '168v171_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_168v171',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '171v174_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_171v174',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '174v177_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_174v177',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '177v180_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_177v180',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '18v21_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_18v21',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '20y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_20y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '21v24_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_21v24',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '24v27_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_24v27',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '25y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_25y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '27v30_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_27v30',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '30v33_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_30v33',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '30y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_30y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '33v36_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_33v36',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '36v39_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_36v39',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '39v42_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_39v42',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '3m_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_3m',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '3v6_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_3v6',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '42v45_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_42v45',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '45v48_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_45v48',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '48v51_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_48v51',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '51v54_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_51v54',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '54v57_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_54v57',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '57v60_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_57v60',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '60v63_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_60v63',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '63v66_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_63v66',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '66v69_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_66v69',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '69v72_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_69v72',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '6v9_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_6v9',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '72v75_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_72v75',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '75v78_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_75v78',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '78v81_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_78v81',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '81v84_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_81v84',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '84v87_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_84v87',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '87v90_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_87v90',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '90v93_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_90v93',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '93v96_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_93v96',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '96v99_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_96v99',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '99v102_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_99v102',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ILS',@CalculatorId = '9v12_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ILS_9v12',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '102v105_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_102v105',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '105v108_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_105v108',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '108v111_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_108v111',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '111v114_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_111v114',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '114v117_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_114v117',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '117v120_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_117v120',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '120v123_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_120v123',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '123v126_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_123v126',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '126v129_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_126v129',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '129v132_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_129v132',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '12v15_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_12v15',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '132v135_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_132v135',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '135v138_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_135v138',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '138v141_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_138v141',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '141v144_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_141v144',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '144v147_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_144v147',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '147v150_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_147v150',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '150v153_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_150v153',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '153v156_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_153v156',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '156v159_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_156v159',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '159v162_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_159v162',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '15v18_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_15v18',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '162v165_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_162v165',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '165v168_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_165v168',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '168v171_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_168v171',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '171v174_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_171v174',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '174v177_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_174v177',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '177v180_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_177v180',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '18v21_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_18v21',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '20y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_20y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '21v24_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_21v24',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '24v27_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_24v27',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '25y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_25y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '27v30_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_27v30',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '30v33_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_30v33',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '30y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_30y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '33v36_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_33v36',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '36v39_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_36v39',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '39v42_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_39v42',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '3m_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_3m',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '3v6_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_3v6',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '42v45_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_42v45',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '45v48_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_45v48',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '48v51_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_48v51',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '51v54_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_51v54',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '54v57_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_54v57',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '57v60_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_57v60',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '60v63_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_60v63',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '63v66_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_63v66',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '66v69_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_66v69',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '69v72_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_69v72',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '6v9_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_6v9',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '72v75_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_72v75',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '75v78_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_75v78',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '78v81_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_78v81',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '81v84_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_81v84',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '84v87_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_84v87',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '87v90_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_87v90',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '90v93_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_90v93',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '93v96_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_93v96',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '96v99_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_96v99',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '99v102_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_99v102',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN',@CalculatorId = '9v12_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_PLN_9v12',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '102v105_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_102v105',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '105v108_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_105v108',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '108v111_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_108v111',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '111v114_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_111v114',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '114v117_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_114v117',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '117v120_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_117v120',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '12v15_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_12v15',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '15v18_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_15v18',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '18v21_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_18v21',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '21v24_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_21v24',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '24v27_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_24v27',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '27v30_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_27v30',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '30v33_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_30v33',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '33v36_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_33v36',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '36v39_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_36v39',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '39v42_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_39v42',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '3m_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_3m',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '3v6_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_3v6',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '42v45_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_42v45',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '45v48_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_45v48',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '48v51_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_48v51',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '51v54_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_51v54',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '54v57_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_54v57',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '57v60_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_57v60',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '60v63_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_60v63',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '63v66_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_63v66',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '66v69_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_66v69',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '69v72_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_69v72',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '6v9_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_6v9',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '72v75_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_72v75',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '75v78_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_75v78',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '78v81_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_78v81',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '81v84_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_81v84',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '84v87_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_84v87',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '87v90_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_87v90',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '90v93_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_90v93',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '93v96_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_93v96',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '96v99_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_96v99',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '99v102_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_99v102',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_RUB',@CalculatorId = '9v12_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_RUB_9v12',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '102v105_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_102v105',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '105v108_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_105v108',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '108v111_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_108v111',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '111v114_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_111v114',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '114v117_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_114v117',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '117v120_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_117v120',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '120v123_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_120v123',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '123v126_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_123v126',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '126v129_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_126v129',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '129v132_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_129v132',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '12v15_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_12v15',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '132v135_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_132v135',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '135v138_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_135v138',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '138v141_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_138v141',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '141v144_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_141v144',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '144v147_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_144v147',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '147v150_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_147v150',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '150v153_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_150v153',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '153v156_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_153v156',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '156v159_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_156v159',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '159v162_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_159v162',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '15v18_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_15v18',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '162v165_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_162v165',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '165v168_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_165v168',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '168v171_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_168v171',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '171v174_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_171v174',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '174v177_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_174v177',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '177v180_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_177v180',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '180v183_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_180v183',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '18v21_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_18v21',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '20y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_20y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '21v24_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_21v24',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '24v27_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_24v27',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '25y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_25y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '27v30_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_27v30',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '30v33_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_30v33',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '30y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_30y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '33v36_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_33v36',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '35y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_35y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '36v39_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_36v39',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '39v42_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_39v42',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '3m_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_3m',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '3v6_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_3v6',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '40y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_40y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '42v45_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_42v45',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '45v48_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_45v48',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '48v51_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_48v51',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '50y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_50y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '51v54_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_51v54',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '54v57_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_54v57',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '57v60_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_57v60',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '60v63_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_60v63',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '60y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_60y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '63v66_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_63v66',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '66v69_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_66v69',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '69v72_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_69v72',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '6v9_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_6v9',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '70y_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_70y',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '72v75_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_72v75',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '75v78_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_75v78',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '78v81_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_78v81',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '81v84_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_81v84',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '84v87_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_84v87',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '87v90_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_87v90',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '90v93_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_90v93',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '93v96_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_93v96',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '96v99_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_96v99',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '99v102_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_99v102',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec CalculatorAttributeStore @NodeRef = 'FRA_ZAR',@CalculatorId = '9v12_quot',@AttributeName = 'CurvePointSpreadNodeId',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'FRA_ZAR_9v12',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
