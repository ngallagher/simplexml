exec CalculatorStore @NodeRef = '6MFRA_PLN', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_102v105', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_102v105', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_105v108', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_105v108', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_108v111', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_108v111', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_111v114', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_111v114', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_114v117', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_114v117', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_117v120', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_117v120', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_120v123', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_120v123', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_123v126', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_123v126', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_126v129', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_126v129', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_129v132', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_129v132', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_12v15', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_12v15', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_132v135', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_132v135', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_135v138', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_135v138', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_138v141', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_138v141', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_141v144', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_141v144', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_144v147', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_144v147', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_147v150', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_147v150', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_150v153', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_150v153', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_153v156', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_153v156', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_156v159', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_156v159', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_159v162', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_159v162', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_15v18', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_15v18', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_15y', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_15y', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_162v165', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_162v165', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_165v168', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_165v168', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_168v171', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_168v171', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_171v174', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_171v174', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_174v177', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_174v177', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_177v180', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_177v180', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_18v21', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_18v21', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_20y', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_20y', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_21v24', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_21v24', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_24v27', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_24v27', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_27v30', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_27v30', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_30v33', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_30v33', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_33v36', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_33v36', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_36v39', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_36v39', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_39v42', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_39v42', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_3m', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_3m', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_3v6', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_3v6', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_42v45', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_42v45', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_45v48', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_45v48', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_48v51', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_48v51', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_51v54', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_51v54', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_54v57', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_54v57', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_57v60', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_57v60', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_60v63', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_60v63', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_63v66', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_63v66', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_66v69', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_66v69', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_69v72', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_69v72', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_6v9', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_6v9', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_72v75', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_72v75', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_75v78', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_75v78', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_78v81', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_78v81', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_81v84', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_81v84', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_84v87', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_84v87', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_87v90', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_87v90', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_90v93', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_90v93', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_93v96', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_93v96', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_96v99', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_96v99', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_99v102', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_99v102', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '6MFRA_PLN_9v12', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '6MFRA_PLN_9v12', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'BUDAPEST', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'BUDAPEST', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_102v105', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_102v105', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_105v108', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_105v108', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_108v111', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_108v111', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_111v114', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_111v114', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_114v117', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_114v117', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_117v120', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_117v120', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_120v123', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_120v123', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_123v126', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_123v126', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_126v129', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_126v129', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_129v132', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_129v132', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_12v15', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_12v15', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_132v135', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_132v135', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_135v138', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_135v138', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_138v141', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_138v141', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_141v144', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_141v144', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_144v147', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_144v147', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_147v150', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_147v150', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_150v153', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_150v153', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_153v156', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_153v156', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_156v159', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_156v159', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_159v162', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_159v162', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_15v18', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_15v18', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_15y', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_15y', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_162v165', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_162v165', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_165v168', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_165v168', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_168v171', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_168v171', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_171v174', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_171v174', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_174v177', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_174v177', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_177v180', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_177v180', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_18v21', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_18v21', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_20y', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_20y', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_21v24', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_21v24', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_24v27', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_24v27', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_27v30', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_27v30', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_30v33', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_30v33', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_33v36', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_33v36', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_36v39', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_36v39', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_39v42', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_39v42', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_3m', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_3m', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_3v6', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_3v6', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_42v45', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_42v45', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_45v48', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_45v48', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_48v51', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_48v51', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_51v54', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_51v54', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_54v57', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_54v57', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_57v60', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_57v60', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_60v63', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_60v63', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_63v66', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_63v66', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_66v69', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_66v69', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_69v72', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_69v72', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_6v9', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_6v9', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_72v75', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_72v75', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_75v78', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_75v78', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_78v81', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_78v81', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_81v84', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_81v84', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_84v87', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_84v87', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_87v90', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_87v90', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_90v93', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_90v93', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_93v96', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_93v96', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_96v99', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_96v99', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_99v102', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_99v102', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_9v12', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_9v12', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_O/N', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_O/N', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CFRA_PLN_T/N', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CFRA_PLN_T/N', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'CZJUSD', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'CZJUSD', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'DEFAULT', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'DEFAULT', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'EURCZK', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'EURCZK', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'EURHUF', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'EURHUF', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'EURISL', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'EURISL', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'EURPLN', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'EURPLN', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'EURRUB', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'EURRUB', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'EURTRY', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'EURTRY', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'EURZAR', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'EURZAR', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_102v105', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_102v105', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_105v108', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_105v108', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_108v111', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_108v111', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_111v114', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_111v114', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_114v117', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_114v117', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_117v120', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_117v120', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_120v123', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_120v123', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_123v126', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_123v126', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_126v129', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_126v129', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_129v132', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_129v132', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_12v15', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_12v15', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_132v135', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_132v135', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_135v138', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_135v138', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_138v141', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_138v141', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_141v144', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_141v144', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_144v147', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_144v147', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_147v150', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_147v150', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_150v153', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_150v153', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_153v156', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_153v156', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_156v159', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_156v159', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_159v162', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_159v162', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_15v18', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_15v18', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_162v165', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_162v165', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_165v168', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_165v168', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_168v171', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_168v171', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_171v174', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_171v174', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_174v177', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_174v177', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_177v180', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_177v180', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_18v21', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_18v21', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_20y', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_20y', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_21v24', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_21v24', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_24v27', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_24v27', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_25y', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_25y', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_27v30', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_27v30', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_30v33', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_30v33', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_30y', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_30y', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_33v36', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_33v36', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_36v39', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_36v39', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_39v42', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_39v42', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_3m', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_3m', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_3v6', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_3v6', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_42v45', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_42v45', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_45v48', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_45v48', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_48v51', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_48v51', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_51v54', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_51v54', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_54v57', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_54v57', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_57v60', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_57v60', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_60v63', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_60v63', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_63v66', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_63v66', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_66v69', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_66v69', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_69v72', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_69v72', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_6v9', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_6v9', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_72v75', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_72v75', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_75v78', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_75v78', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_78v81', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_78v81', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_81v84', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_81v84', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_84v87', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_84v87', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_87v90', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_87v90', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_90v93', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_90v93', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_93v96', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_93v96', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_96v99', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_96v99', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_99v102', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_99v102', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'FRA_PLN_9v12', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'FRA_PLN_9v12', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Fwd GC HUF', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Fwd GC HUF', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Fwd GC PLN', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Fwd GC PLN', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Fwd GC RUB', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Fwd GC RUB', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Fwd GC TRY', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Fwd GC TRY', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Fwd GC ZAR', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Fwd GC ZAR', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'GBPCZK', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'GBPCZK', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'GBPHUF', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'GBPHUF', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'GBPISL', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'GBPISL', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'GBPPLN', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'GBPPLN', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'GBPRUB', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'GBPRUB', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'GBPTRY', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'GBPTRY', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'GBPZAR', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'GBPZAR', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'HUFUSD', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'HUFUSD', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'ISLUSD', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'ISLUSD', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'ISTANBUL', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'ISTANBUL', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'JOBURG', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'JOBURG', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'LIBOR-HDUSD', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'LIBOR-HDUSD', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'LIBOR-HD_USD', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'LIBOR-HD_USD', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'LIBOR-HD_USD(3MFWD)', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'LIBOR-HD_USD(3MFWD)', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'LMLIBORPLN', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'LMLIBORPLN', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'LMLIBOR_PLN(3MFwd)', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'LMLIBOR_PLN(3MFwd)', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'LMLIBOR_USD(3MUSDFwd)', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'LMLIBOR_USD(3MUSDFwd)', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000101937', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000101937', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000102646', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000102646', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000102836', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000102836', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000103305', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000103305', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000103602', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000103602', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000103735', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000103735', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000104287', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000104287', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000104543', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000104543', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000104659', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000104659', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000104717', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000104717', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000104857', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000104857', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000105037', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000105037', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000105078', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000105078', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000105391', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000105391', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000105433', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000105433', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000105441', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000105441', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000105524', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000105524', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000105730', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000105730', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000105912', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000105912', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000500013', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000500013', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Master-PL0000500021', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Master-PL0000500021', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000101937', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000101937', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000102646', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000102646', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000102836', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000102836', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000103305', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000103305', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000103602', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000103602', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000103735', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000103735', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000104287', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000104287', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000104543', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000104543', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000104659', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000104659', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000104717', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000104717', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000104857', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000104857', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000105037', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000105037', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000105078', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000105078', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000105391', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000105391', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000105433', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000105433', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000105441', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000105441', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000105524', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000105524', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000105730', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000105730', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000105912', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000105912', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000500013', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000500013', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PL0000500021', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PL0000500021', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PLN', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PLN', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PLNUSD', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PLNUSD', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'PRAGUE', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'PRAGUE', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'RUB', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'RUB', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'RUBUSD', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'RUBUSD', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_01', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_01', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_02', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_02', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_03', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_03', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_04', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_04', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_05', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_05', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_06', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_06', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_07', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_07', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_08', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_08', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_09', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_09', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_10', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_10', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_11', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_11', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_12', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_12', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_13', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_13', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_14', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_14', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_15', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_15', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_16', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_16', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_17', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_17', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_18', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_18', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_19', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_19', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'Run_20', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'Run_20', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'SettleDateOverride', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'SettleDateOverride', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'TRYUSD', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'TRYUSD', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = 'ZARUSD', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = 'ZARUSD', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

exec CalculatorStore @NodeRef = '', @CalculatorId = 'GdsSwapCurveCalc', @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator', @Version = 0, @ServerName = 'gallane', @UpdaterRef = 'gallane'
exec CalculatorAttributeStore @NodeRef = '', @CalculatorId = 'GdsSwapCurveCalc', @AttributeName = 'threeMonthRate', @ValueType = 'FLOAT', @ValueInt = 0, @ValueFloat = 0.0, @ValueDatetime = '1-1-1900', @ValueString = '', @Version = 1, @ServerName = 'script', @UpdaterRef = 'script'

go
