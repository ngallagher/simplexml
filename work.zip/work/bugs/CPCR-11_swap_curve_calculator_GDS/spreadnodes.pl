while(<>){
    chop;
    s/\s*$//;
    s/^\s*//;
    #if(/([a-zA-Z0-0]+)_([a-zA-Z0-0]+)\s+(.*)_quot/){
    if(/([a-zA-Z0-9]*FRA)_([a-zA-Z0-9]+)_(.*)/){    
        print "exec CalculatorAttributeStore \@NodeRef = '$1_$2',\@CalculatorId = '$3_quot',\@AttributeName = 'CurvePointSpreadNodeId',\@ValueType = 'STRING',\@ValueInt = 0,\@ValueFloat = 0.0,\@ValueDatetime = '1-1-1900',\@ValueString = '$1_$2_$3',\@Version = 0,\@ServerName = 'script',\@UpdaterRef = 'script'\n";

        #print "update CalculatorAttribute set ValueString = '$1_$2_$3' where CalculatorId = '$3_quot' and NodeRef = '$1_$2' and AttributeName = 'CurvePointSpreadNodeId'\n";
        print "go\n";
    }
}
