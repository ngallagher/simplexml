#!/bin/sh
isql -Ufip_dbo -Puat12345 -SCORP -Dfi_CEEMEA_uat 2>&1 <<-END
select distinct NodeRef from GenericNode where JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.SwapNode' or JavaClass = 'com.rbsfm.fi.pricing.dependency.fra.FraNode' or JavaClass = 'com.rbsfm.fi.pricing.dependency.moneymarket.MoneyMarketNode' order by NodeRef
go
END
