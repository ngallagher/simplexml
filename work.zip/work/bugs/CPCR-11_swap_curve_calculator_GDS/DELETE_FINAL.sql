delete from Calculator where CalculatorId = 'SwapCurveCalc'
delete from CalculatorAudit where CalculatorId = 'SwapCurveCalc'
delete from CalculatorAttribute where CalculatorId = 'SwapCurveCalc'
delete from CalculatorAttributeAudit where CalculatorId = 'SwapCurveCalc'
go
