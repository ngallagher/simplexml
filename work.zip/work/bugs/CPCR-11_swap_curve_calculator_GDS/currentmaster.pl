while(<>){
    chop;
    s/\s*$//;
    s/^\s*//;
    #if(/([a-zA-Z0-0]+)_([a-zA-Z0-0]+)\s+(.*)_quot/){
    if(/([a-zA-Z0-9]*FRA)_([a-zA-Z0-9]+)_(.*)/){    
        print "exec GenericNodeAttributeStore \@NodeRef = '$1_$2_$3',\@AttributeName = 'CurrentMaster',\@ValueType = 'STRING',\@ValueInt = 0,\@ValueFloat = 0.0,\@ValueDatetime = '1-1-1900',\@ValueString = 'SwapCurveCalc',\@Version = 0,\@ServerName = 'script',\@UpdaterRef = 'script'\n";
        print "go\n"
    }
}
