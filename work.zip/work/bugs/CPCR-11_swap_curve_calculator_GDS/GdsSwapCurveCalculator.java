package com.rbsfm.fi.pricing.dependency.swap;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.rbsfm.common.config.Config;
import com.rbsfm.common.config.Configurable;
import com.rbsfm.common.system.App;
import com.rbsfm.common.system.Log;
import com.rbsfm.fi.pricing.curve.Curve;
import com.rbsfm.fi.pricing.curve.CurveRate;
import com.rbsfm.fi.pricing.dependency.Calculator;
import com.rbsfm.fi.pricing.dependency.DependencyTree;
import com.rbsfm.fi.pricing.dependency.generic.GenericAttribute;
import com.rbsfm.fi.pricing.dependency.generic.GenericCalculator;
import com.rbsfm.fi.pricing.external.attribute.Attribute;
import com.rbsfm.fi.pricing.external.message.SetAttributeMessage;
import com.rbsfm.fi.pricing.external.message.TreeMessage;

/*
  exec CalculatorStore 
     @NodeRef = 'XS0106768608', 
     @CalculatorId = 'GdsSwapCurveCalc', 
     @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator',
     @Version = 0,                        
     @ServerName = 'gallane', 
     @UpdaterRef = 'gallane'
  
  exec CalculatorAttributeStore 
      @NodeRef = 'US20441XAA00', 
      @CalculatorId = 'GdsSwapCurveCalc', 
      @AttributeName = 'threeMonthRate',
      @ValueType = 'FLOAT',
      @ValueInt = 0,
      @ValueFloat = 0.0,
      @ValueDatetime = '1-1-1900', 
      @ValueString = '',
      @Version = 1,
      @ServerName = 'script',
      @UpdaterRef = 'script'
         
  go                      
 */
public class GdsSwapCurveCalculator extends Calculator implements GenericCalculator, Configurable {
    
    public static final String DEFAULT_CALC_ID = "GdsSwapCurveCalc";
    
    private static final String THREE_MONTH_RATE = "threeMthRate";
    private static final String SIX_MONTH_RATE = "sixMthRate";
    private static final String THREE_MONTH_SPREAD = "threeMthSprd";

    private GdsCurveClient client;
    private String threeMonthCurveName;
    private String sixMonthCurveName;
    private Curve threeMonthCurve;
    private Curve sixMonthCurve;
    private double threeMonthRate;
    private double sixMonthRate;
    private double threeMonthSpread;
    
    public GdsSwapCurveCalculator(DependencyTree tree, String ownerId, String id) {
        super(tree, ownerId, id, false);
    }
    
    /*
      <delegate name="GdsSwapCurveCalculatorHome" 
          class_name="com.rbsfm.fi.pricing.dependency.generic.DbGenericCalculatorHome" 
          autocommit="${autoCommit}" 
          populateForTreeType="all" 
          readOnly="${readOnly}" 
          calculatorClass="com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator">
          
          <threeMonthCurve>FRA.PLN</threeMonthCurve>
          <sixMonthCurve>6MFRA.PLN</sixMonthCurve>
       </delegate>     
     */
    @Override
    public void configure(Config config) {
        client = (GdsCurveClient) App.getComponentManager().getComponent("GdsCurveClient");
        threeMonthCurveName = config.getStringValue("threeMonthCurve");
        sixMonthCurveName = config.getStringValue("sixMonthCurve");
    }

    @Override
    protected boolean calculateDerivedImpl() {
        Curve sixMonthCurve = getSixMonthCurve();
        Curve threeMonthCurve = getThreeMonthCurve();
        List<?> threeMonthRates = threeMonthCurve.getCurveRates();
        List<?> sixMonthRates = sixMonthCurve.getCurveRates();        
        
        for(int i = 0; i < threeMonthRates.size(); i++) {
            CurveRate curveRate = (CurveRate) threeMonthRates.get(i);
            String curveRateId = curveRate.getId();
            double rateOverride = curveRate.getRateOverride();
            
            Log.INFO.report("Three month id ["+curveRateId+"] override ["+rateOverride+"]");            
        }
        for(int i = 0; i < sixMonthRates.size(); i++) {
            CurveRate curveRate = (CurveRate) sixMonthRates.get(i);
            String curveRateId = curveRate.getId();
            double rateOverride = curveRate.getRateOverride();
            
            Log.INFO.report("Six month id ["+curveRateId+"] override ["+rateOverride+"]");            
        }  
        return false;
    }

    @Override
    protected boolean calculateMasterImpl() {
        return false;
    }   
    
    private Curve getSixMonthCurve() {
        if(sixMonthCurveName != null && sixMonthCurve == null) {
            sixMonthCurve = client.getGdsCurve(sixMonthCurveName); 
        }
        return sixMonthCurve;
    }
    
    private Curve getThreeMonthCurve() {
        if(threeMonthCurveName != null && threeMonthCurve == null) {
            threeMonthCurve = client.getGdsCurve(threeMonthCurveName); 
        }
        return threeMonthCurve;
    }
    
    @Override
    public void processMessage(TreeMessage message) {
        if(message instanceof SetAttributeMessage) {
           processMessage((SetAttributeMessage) message);
        }
    }
    
    private void processMessage(SetAttributeMessage message) {
        String attributeName = message.getAttributeName();
       
        if(attributeName.equals(THREE_MONTH_SPREAD)) {
            threeMonthSpread = message.getDoubleValue();
            write(); 
            inputsChanged(); 
        } 
    }   
    
    @Override
    public GenericAttribute[] getGenericAttributes() {
        return new GenericAttribute[]{
                new GenericAttribute(THREE_MONTH_SPREAD, threeMonthSpread),
        };
    }
    
    @Override
    public void setGenericAttributes(Map<String, GenericAttribute> atts) {
        threeMonthSpread = GenericAttribute.getDoubleValue(atts, THREE_MONTH_SPREAD, this);    
    }
    
    /*
      <field name="threeMthRate" displayName="threeMthRate" longName="threeMthRate" dataType="System.Double" editType="edit" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#FF0000" fontFormat="Bold"/>
      <field name="sixMthRate" displayName="sixMthRate" longName="sixMthRate" dataType="System.Double" editType="edit" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#FF0000" fontFormat="Bold"/>
      <field name="threeMthSprd" displayName="threeMthSprd" longName="threeMthSprd" dataType="System.Double" editType="none" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#000000" contextField='ticker'/>
     */
    @Override
    public void addAttributes(Collection<Attribute> atts) {
        super.addAttributes(atts);

        atts.add(createAttribute(THREE_MONTH_RATE, threeMonthRate, getStatusId()));
        atts.add(createAttribute(SIX_MONTH_RATE, sixMonthRate, getStatusId()));
        atts.add(createAttribute(THREE_MONTH_SPREAD, threeMonthSpread, getStatusId()));
    }
}

