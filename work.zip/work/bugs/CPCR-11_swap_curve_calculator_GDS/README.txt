# The pricing server will only allow RPC messages which are in the following HARDCODED list of types, this includes CloseMessage and RequestBonds

com.rbsfm.fi.pricing.mux.rpc.ClientRPCSource.MESSAGE_SET --->> (Should contain "RatesSetMessage")

This can be seen at the following stack trace.

com.rbsfm.fi.pricing.mux.rpc.ClientRPCSource.isTrue(com.rbsfm.fi.pricing.mux.Message) line: 252 (out of synch)	
com.rbsfm.fi.pricing.mux.rpc.RPCDelegate.processRPCMessage(com.rbsfm.fi.pricing.mux.Message) line: 56	
com.rbsfm.fi.pricing.mux.rpc.RPCDelegate(com.rbsfm.fi.pricing.mux.rpc.AbstractRPCDelegate).handleRPCMessage(com.rbsfm.fi.pricing.mux.rpc.AbstractRPCDelegate, com.rbsfm.fi.pricing.mux.Message) line: 151	

# To see what a binary message looks like use the following

BinaryMessageImpl.getAttributes()

This can be called from the major interception point for all processes located at.

com.rbsfm.fi.pricing.mux.socket.SocketQueueMonitor.onMessage(com.rbsfm.fi.pricing.mux.Message, java.nio.channels.SocketChannel) line: 111	
com.rbsfm.fi.pricing.mux.socket.SocketQueueMonitor(com.rbsfm.fi.pricing.mux.socket.AbstractSocketMessageReader).readAndDispatch(java.nio.channels.SocketChannel) line: 202	
com.rbsfm.fi.pricing.mux.socket.SocketQueueMonitor$ThreadRunner.run() line: 184	


# Here is where the clientmux intercepts the message being delivered to the pricing server

com.rbsfm.fi.pricing.mux.router2.DynamicSinkCollection.deliverMessage(com.rbsfm.fi.pricing.mux.Message) line: 401	<<----- handle message from CP client
com.rbsfm.fi.pricing.mux.router2.DynamicRPCSource.processRPCMessage(com.rbsfm.fi.pricing.mux.Message) line: 37	
com.rbsfm.fi.pricing.mux.rpc.RPCDelegate.processRPCMessage(com.rbsfm.fi.pricing.mux.Message) line: 58	
com.rbsfm.fi.pricing.mux.rpc.RPCDelegate(com.rbsfm.fi.pricing.mux.rpc.AbstractRPCDelegate).handleRPCMessage(com.rbsfm.fi.pricing.mux.rpc.AbstractRPCDelegate, com.rbsfm.fi.pricing.mux.Message) line: 151	
com.rbsfm.fi.pricing.mux.rpc.RPCDelegate(com.rbsfm.fi.pricing.mux.rpc.AbstractRPCDelegate).handleRPCMessage(com.rbsfm.fi.pricing.mux.Message) line: 147	
com.rbsfm.fi.pricing.mux.rpc.RPCDelegate(com.rbsfm.fi.pricing.mux.rpc.AbstractRPCDelegate).processMessage(com.rbsfm.fi.pricing.mux.Message) line: 82	
com.rbsfm.fi.pricing.mux.rpc.RPCDelegate(com.rbsfm.fi.pricing.mux.rpc.AbstractRPCDelegate).removeAnyOutstandingRPCSubscriptions() line: 250	
com.rbsfm.fi.pricing.mux.rpc.RPCDelegate(com.rbsfm.fi.pricing.mux.rpc.AbstractRPCDelegate).close() line: 242	
com.rbsfm.fi.pricing.mux.socket.SocketQueueMonitor$ThreadRunner.run() line: 201	
java.lang.Thread.run() line: not available	


# The following is sent with the rates set message

<message><RatesSetMessage><treeToken /><nodeId>6MFRA_PLN</nodeId></RatesSetMessage></message>

# Some nodes have a problem being the master calculator

2010-01-21 17:33:41.121 +0000 WARNING [CEEMEACalcCycle] cpratesdev: Exception in calculateMaster for 6MFRA_HUF.30y_quot -class{class java.lang.ClassCastException} -mssg{com.rbsfm.fi.pricing.dependency.swap.ManualSwapRateCalculator cannot be cast to com.rbsfm.fi.pricing.dependency.curve.CurvePointQuoteSpread}: com.rbsfm.fi.pricing.dependency.swap.ManualSwapRateCalculator cannot be cast to com.rbsfm.fi.pricing.dependency.curve.CurvePointQuoteSpread: Stack Trace: java.lang.ClassCastException: com.rbsfm.fi.pricing.dependency.swap.ManualSwapRateCalculator cannot be cast to com.rbsfm.fi.pricing.dependency.curve.CurvePointQuoteSpread
	at com.rbsfm.fi.pricing.dependency.swap.SwapNode.getCurrentQuoteSpread(SwapNode.java:333)
	at com.rbsfm.fi.pricing.dependency.curve.CurvePointQuoteCalculator.calculateMasterImpl(CurvePointQuoteCalculator.java:693)
	at com.rbsfm.fi.pricing.dependency.Calculator.calculateMaster(Calculator.java:588)
	at com.rbsfm.fi.pricing.dependency.NodeWithCalculators.calculateMaster(NodeWithCalculators.java:781)
	at com.rbsfm.fi.pricing.dependency.curve.AbstractInternalCurveNode.prime(AbstractInternalCurveNode.java:644)
	at com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode.curveCalculate(InternalCurveNode.java:179)
	at com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode.calculate(InternalCurveNode.java:146)
	at com.rbsfm.fi.pricing.dependency.DefaultNodeCalculationManager.calculateNode(DefaultNodeCalculationManager.java:48)
	at com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.calculateNode(TreeCalculationManagerImpl.java:171)
	at com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.access$0(TreeCalculationManagerImpl.java:170)
	at com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl$SingleThreadedCalculation.calculateNodes(TreeCalculationManagerImpl.java:498)
	at com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.calculateNodes(TreeCalculationManagerImpl.java:177)
	at com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree.calculateNodes(AbstractDependencyTree.java:691)
	at com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl.doCalcCycle(SimpleTreeControl.java:444)
	at com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl.runCalcCycle(SimpleTreeControl.java:322)
	at com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl.access$5(SimpleTreeControl.java:307)
	at com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl$1.run(SimpleTreeControl.java:263)
	at java.lang.Thread.run(Unknown Source)

# The following quote is used for testing

FRA_PLN_141v144

# The pointers to the nodes for the CurvePointQuoteCalculator are

CurvePointNodeId ---> CurvePointNode
CurvePointSpreadNodeId --> CurvePointQuoteSpreadNode

# In order to spread from the same node the FraNode, MoneyMarketNode, and SwapNode need to implement

CurvePointQuoteSpreadNode

This ensures that a single calculator can be used to provide the rate and the spread to CAF.
Providing both the spread and the rate to CAF allows us to have the internal representation
of the curve match the GDS representation, so less hacking.

# Money market nodes show the same issue

2010-01-19 12:18:59.251 +0000 ERROR [Node attribute extractor/publisher] unknown: failed to get details from node [class com.rbsfm.fi.pricing.dependency.swap.SwapNode:CFRA_PLN_15y]: com.rbsfm.fi.pricing.dependency.swap.job.SwapCurveCalculator cannot be cast to com.rbsfm.fi.pricing.dependency.moneymarket.MoneyMarketPrice: Stack Trace: java.lang.ClassCastException: com.rbsfm.fi.pricing.dependency.swap.job.SwapCurveCalculator cannot be cast to com.rbsfm.fi.pricing.dependency.moneymarket.MoneyMarketPrice
	at com.rbsfm.fi.pricing.dependency.swap.SwapNode.getSFROverride(SwapNode.java:434)
	at com.rbsfm.fi.pricing.dependency.swap.SwapNode.addAttributes(SwapNode.java:442)
	at com.rbsfm.fi.pricing.dependency.NodeWithCalculators.toNewDetails(NodeWithCalculators.java:995)
	at com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.getNodeDetails(TreeCalculationManagerImpl.java:186)
	at com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.access$2(TreeCalculationManagerImpl.java:181)
	at com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl$SingleThreadedCalculation.nodeOutputDetails(TreeCalculationManagerImpl.java:543)
	at com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.getNodeDetails(TreeCalculationManagerImpl.java:205)
	at com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree.getNodeDetails(AbstractDependencyTree.java:715)
	at com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl$ResultsExtractorThread.run(SimpleTreeControl.java:790)

# Problem with the FRA and Swap nodes looks like so

2010-01-19 12:18:59.407 +0000 ERROR [CEEMEACalcCycle] cpratesdev: Exception in calculateMaster for CFRA_PLN.15y_quot -class{class java.lang.ClassCastException} -mssg{com.rbsfm.fi.pricing.dependency.swap.job.SwapCurveCalculator cannot be cast to com.rbsfm.fi.pricing.dependency.swap.SwapPrice}: com.rbsfm.fi.pricing.dependency.swap.job.SwapCurveCalculator cannot be cast to com.rbsfm.fi.pricing.dependency.swap.SwapPrice: Stack Trace: java.lang.ClassCastException: com.rbsfm.fi.pricing.dependency.swap.job.SwapCurveCalculator cannot be cast to com.rbsfm.fi.pricing.dependency.swap.SwapPrice
	at com.rbsfm.fi.pricing.dependency.swap.SwapPriceCalculator.getExternalQuote(SwapPriceCalculator.java:120)
	at com.rbsfm.fi.pricing.dependency.swap.SwapNode.getExternalQuote(SwapNode.java:391)
	at com.rbsfm.fi.pricing.dependency.curve.CurvePointQuoteCalculator.calculateMasterImpl(CurvePointQuoteCalculator.java:641)
	at com.rbsfm.fi.pricing.dependency.Calculator.calculateMaster(Calculator.java:588)
	at com.rbsfm.fi.pricing.dependency.NodeWithCalculators.calculateMaster(NodeWithCalculators.java:781)
	at com.rbsfm.fi.pricing.dependency.curve.AbstractInternalCurveNode.prime(AbstractInternalCurveNode.java:644)
	at com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode.curveCalculate(InternalCurveNode.java:179)
	at com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode.calculate(InternalCurveNode.java:146)
	at com.rbsfm.fi.pricing.dependency.DefaultNodeCalculationManager.calculateNode(DefaultNodeCalculationManager.java:48)
	at com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.calculateNode(TreeCalculationManagerImpl.java:171)
	at com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.access$0(TreeCalculationManagerImpl.java:170)
	at com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl$SingleThreadedCalculation.calculateNodes(TreeCalculationManagerImpl.java:498)
	at com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.calculateNodes(TreeCalculationManagerImpl.java:177)
	at com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree.calculateNodes(AbstractDependencyTree.java:691)
	at com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl.doCalcCycle(SimpleTreeControl.java:444)
	at com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl.runCalcCycle(SimpleTreeControl.java:322)
	at com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl.access$5(SimpleTreeControl.java:307)
	at com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl$1.run(SimpleTreeControl.java:263)
	at java.lang.Thread.run(Unknown Source)

# How the curve point input rules affect the discount factor

1) Change to "Spread" with "IR_INPUT" has NO EFFECT
2) Change to "Rate" with "IR_INPUT" will CHANGE THE DISCOUNT FACTOR
3) Change to "Spread" with "IR_INPUT_PLUS_SPREAD" will CHANGE THE DISCOUNT FACTOR
4) Change to "Rate" with "IR_INPUT_PLUS_SPREAD" will CHANGE THE DISCOUNT FACTOR

!!!! IMPORTANT !!!!

With the above it seems that when the rate is the sum of the spread and the rate,
and the actual spread value is 0.0 then the curve point input rule is irrelevant.
So we can effectively always just provide the consolidated rate and leave the 
spread as 0.0 to get consistent "Discount Factor" values from CAF!!!!!

# Assumption about the curve point input

The curve point input rule is irrelevant if the spread is 0.0. Here only the consolidate rate
is important for calculating the discount factors used.

# The GDS server is located at

uat-swap-gdsgateway-master

# The key requirements are

1) Ensure that we pass the fvar back to GDS in the same format that we got it ie with the spread values populated. 
   get help from Jago with this.

   a) Ensuring the FVAR is in the correct format should be simple
   b) Setting the CAF spread and rate is independent of the FVAR

2) Ensure we pass the correct values to CAF to calculate the curve discount factors

   a) We need to ensure here that the CurvePointInputRule is correct
   b) It must be INPUT_PLUS_SPREAD_TKN if we send the rate + spread + traderSpread

 
# If we ignore the spread node we need to ensure the following

The com.rbsfm.fi.pricing.curve.CurvePointInputRule is set to INPUT_PLUS_SPREAD_TKN, this is actually
set on the curve point itself rather than the InputValues. See the following for options.

http://caf.fm.rbsgrp.net/caf/funcref/newCDM.html#eInputRuleType

# Questions on the spread node

How does the CurvePointQuoteCalculator fit in with another master under a swap node? Does the
other calculator become the master and the CurvePointQuoteCalculator just takes the getCurrentQuote
from the CurvePointNode.getCurrentQuote() and drive that through to CAF. If so then our calculator
needs to implement CurvePointQuote.getQuote() and be set to master. This is used by the following

FraNode
MoneyMarketNode
SwapNode

This will allow the CurvePointQuoteCalculator to extract the rate from the node in order to 
populate the rate for CAF. The raises the following questions.

1) What about the spread, is there a way to ensure the spread is never set?
2) If we only set the RATE how do we tell CAF about this?
3) Would it be simpler to just create a CurvePointQuoteSpreadNode just to hold the spread?
4) Will the trader be able to set the spread in the Curve layout using the spread column?

We can not possible share a calculator instance between two nodes, so a spread node is not
an ideal solution, however it is possible through a pointer. So we need to ensure the 
following criteria is set.

a) When the CurvePointQuoteCalculator populates CAF it contains something that says IV_SPREAD=ignore 
b) The InputValue[] array should have a 0.0 or null value for the spread
c) There must be some existing logic to determine if a single rate can set the value in CAF

The following question arises

1) What will the FVAR send from the pricing server look like, where does it get the spread?????

# Rate for the FraNode and MoneyMarketNode is taken from 

  public double getCurrentQuote() {
    double retVal;
    Calculator master = getCurrentMaster(); // <<<<<------ IF YOU ARE THE MASTER THEN YOU DECIDE WHAT GOES TO CAF EVENTUALLY
    if (master instanceof CurvePointQuote) {
      retVal = ((CurvePointQuote) master).getQuote();
    } else {
      throw new IllegalStateException("FraNode <" + getId() + "> current master <"
          + ((master != null) ? master.getId() : "null") + "> is not a CurvePointQuote");

    }
    return retVal;
  }


# The CurvePointQuoteCalculator.setSpread can be set by a user action

1) The processMessage() method can set the spread from a user action
2) The spread can be taken from a spread node

# The status must be Ok in order for the BOOTSTRAP to occur

java.lang.IllegalStateException: SwapNode <PRIBOR_CZK_30y> current master <null> is not a CurvePointQuote <<------ Prevents setting of values to CAF

The following code governs whether the data is used to populate CAF. This will
bootstap the entire curve where each curve point will take its value from the
CurvePointQuoteCalculator.getValues() and set it to CAF.

if(getStatus().isOK()){
    bootstrap(CurveCalculator.RateType.REAL);
    postBootstrap();
}



# Below the CREATION STACK TRACE from the InputValue array is as follows

[CurveRateImpl[ 3m null IT_FIXED_LOAN{0} 0.0419 [com.rbsfm.fi.pricing.curve.impl.InputValueImpl@1796d0[value=0.0,type=IV_BID_OFFER_SPREAD{2},gdsFlag=org.omg.CORBA.BooleanHolder@37ff37,gdsBondPrice=0.0,gdsBondYield=0.0,gdsInheritanceFlag=org.omg.CORBA.BooleanHolder@b6379b,gdsCurve=null,gdsInstrument=null,gdsType=null,stackTrace=java.lang.Exception
	at com.rbsfm.fi.pricing.curve.impl.InputValueImpl.<init>(InputValueImpl.java:54)  <<<<<-------------------------------- HERE IS WHERE THE RAW DATA IS POPULATED FOR CAF
	at com.rbsfm.fi.pricing.dependency.curve.CurvePointQuoteCalculator.<init>(CurvePointQuoteCalculator.java:79)
	at sun.reflect.GeneratedConstructorAccessor16.newInstance(Unknown Source)
	at sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)
	at java.lang.reflect.Constructor.newInstance(Unknown Source)


# SETTING THE VALUES IN CAF FROM THE VALUES IN THE CurvePointQuoteCalculator

"!!!!!!!! THIS IS WHERE THE ACTUAL VALUES ARE FED IN TO CAF ON BOOTSTRAP !!!!!!!!"
com.rbsfm.fi.pricing.newanalytics.general.ALCurve.CurveSetRates(java.lang.Object, java.lang.Object, java.util.Map) line: 120	
com.rbsfm.fi.pricing.curve.CafCurveCalculatorImpl.calculate(com.rbsfm.fi.pricing.curve.Curve, com.rbsfm.fi.pricing.curve.CurveCalculator$RateType, boolean, boolean) line: 183	
com.rbsfm.fi.pricing.curve.impl.RegularCurveImpl(com.rbsfm.fi.pricing.curve.impl.CurveBaseImpl).calculate(com.rbsfm.fi.pricing.curve.CurveCalculator$RateType, boolean) line: 593	
com.rbsfm.fi.pricing.curve.impl.RegularCurveImpl(com.rbsfm.fi.pricing.curve.impl.CurveBaseImpl).calculate(com.rbsfm.fi.pricing.curve.CurveCalculator$RateType) line: 589	
com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode(com.rbsfm.fi.pricing.dependency.curve.AbstractInternalCurveNode).bootstrap(com.rbsfm.fi.pricing.curve.CurveCalculator$RateType) line: 712	
com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode.curveCalculate() line: 194	
com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode.calculate() line: 146	

# Here is where the curve points are set to feed from the curve point quote calculator

"InternalCurveNode.resolveNode()": This will get each CurvePointQuoteCalculator that is 
hanging from the node and initialise the CurvePoint it represents to feed its values
from the internal InputValue array it maintains. See full stack trace below.

# When a spread is set on the curve then its put in to the curve point quote calculator

The CurvePointQuoteCalculator will set the spread within the InputValue[] array it
maintains, this is then referenced as a pointer to the actual array within the calculator
by the CurveRateImpl. This object can have its rates feed in to CAF from there when there
is a calculate performed. 

# Here are the nodes the curve point quote calculator is hanging off

7> select distinct NodeRef from Calculator where CalculatorId like '%_quot'
8> go
 NodeRef
 ----------------------------------------------------------------------------
 6MFRA_PLN
 6MFRA.CZK
 CPRIBOR_CZK
 PRIBOR_CZK
 6MFRA_HUF
 FRA_HUF
 CFRA_HUF
 FRA_ILS
 CFRA_ILS
 FRA_RUB
 CFRA_RUB
 CFRA_TRY
 FRA_ZAR
 CFRA_ZAR
 CFRA_PLN
 FRA_PLN

# Here is where we set the curve point input provider

"InternalCurveNode.resolveNode()":
com.rbsfm.fi.pricing.dependency.curve.CurvePointQuoteCalculator.resetCurvePoint(java.lang.String) line: 960	
com.rbsfm.fi.pricing.dependency.curve.CurvePointQuoteCalculator.getCurvePoint() line: 927	
com.rbsfm.fi.pricing.dependency.curve.CurvePointQuoteCalculator$1.toOrder(java.lang.Object) line: 111	
com.rbsfm.fi.pricing.dependency.curve.CurvePointQuoteCalculator$1.compare(java.lang.Object, java.lang.Object) line: 104	
java.util.Arrays.mergeSort(java.lang.Object[], java.lang.Object[], int, int, int, java.util.Comparator) line: not available	
java.util.Arrays.mergeSort(java.lang.Object[], java.lang.Object[], int, int, int, java.util.Comparator) line: not available	
java.util.Arrays.mergeSort(java.lang.Object[], java.lang.Object[], int, int, int, java.util.Comparator) line: not available	
java.util.Arrays.mergeSort(java.lang.Object[], java.lang.Object[], int, int, int, java.util.Comparator) line: not available	
java.util.Arrays.mergeSort(java.lang.Object[], java.lang.Object[], int, int, int, java.util.Comparator) line: not available	
java.util.Arrays.sort(T[], java.util.Comparator<? super T>) line: not available	
java.util.Collections.sort(java.util.List<T>, java.util.Comparator<? super T>) line: not available	
com.rbsfm.fi.pricing.dependency.curve.AbstractInternalCurveNode.getOrderedQuoteCalculatorList(java.util.Collection) line: 936	
com.rbsfm.fi.pricing.dependency.curve.AbstractInternalCurveNode.getOrderedQuoteCalculators(java.util.Collection) line: 917	
com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode(com.rbsfm.fi.pricing.dependency.curve.AbstractInternalCurveNode).getOrderedQuoteCalculators() line: 908	
com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode(com.rbsfm.fi.pricing.dependency.curve.AbstractInternalCurveNode).setCurvePointNodeGlobalInfo() line: 304	
com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode(com.rbsfm.fi.pricing.dependency.curve.AbstractInternalCurveNode).resolveNode() line: 297	
com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode.resolveNode() line: 243	
com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.linkTree() line: 371	
com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.validate() line: 238	
com.rbsfm.fi.pricing.dependency.tree.DependencyTreeImpl(com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree).validate() line: 749	
com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl.internalStart() line: 241	
com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl(com.rbsfm.common.system.AbstractControl).actualStart() line: 205	
com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl(com.rbsfm.common.system.AbstractControl).start() line: 97	
com.rbsfm.common.system.ControlManager.startControls(java.util.List<com.rbsfm.common.system.ControlManager.ControlInfo>) line: 325	
com.rbsfm.common.system.ControlManager.start() line: 231	
com.rbsfm.common.system.ControlServer.main0(java.lang.String[]) line: 62	
com.rbsfm.common.system.ControlServer$1.run() line: 34	

# The methos set curve point sets the input provider

private void resetCurvePoint(String curvePointId) --> mCurvePoint.setInputProvider(this)

Once set the curve point will source changes from the curve point quote calculator.

# When the curve manager creates the CurvePointQuoteCalculator it sets the following

@Spread = 0.12
@Rate = 0.23

# In order the use a spread node for the curve point quote calculator the following is needed

1) A new node which is specifically for containing the spread value
2) Calculators for the spread node which will provide the spread value
3) The master calculator must implement the Spread interface exposing getMidSpread()

# On boot strap of the InternalCurveNode the following is true

1) The curve will be taken from the CurveHome and thus the FVAR
2) The curve will provide the IV_RATE and IV_SPREAD for each CurvePoint
3) The settings are independent of spread nodes

# The get curve rates method is what is used to pust data into CAF via the ALProxy

Curve.getCurveRates() : List

# The curve is acquired from the curve home and so is taken from the FVAR values

      MutableCurve mutableCurve = (MutableCurve) getCurveHome().findByPrimaryKey(mCurveId);

# For the below stack trace the typical inputs will be as follows which contains IV_SPREAD

ID=3m
[
    {TYPE=IV_BID_OFFER_SPREAD, VALUE=0.0}, 
    {TYPE=IV_CONVEXITY_ADJUSTMENT, VALUE=0.0}, 
    {TYPE=IV_FORWARD_SPREAD, VALUE=0.0}, 
    {TYPE=IV_RATE, VALUE=0.0419}, <<------ Rate as taken from the curve 
    {TYPE=IV_RECOVERY, VALUE=0.0}, 
    {TYPE=IV_SPREAD, VALUE=0.0013} <<------ Spread as taken from the curve
]

# This is used to set the rates for the curve

com.rbsfm.fi.pricing.newanalytics.general.ALCurve.CurveSetRates(java.lang.Object, java.lang.Object, java.util.Map) line: 125	
com.rbsfm.fi.pricing.curve.CafCurveCalculatorImpl.calculate(com.rbsfm.fi.pricing.curve.Curve, com.rbsfm.fi.pricing.curve.CurveCalculator$RateType, boolean, boolean) line: 183	
com.rbsfm.fi.pricing.curve.impl.RegularCurveImpl(com.rbsfm.fi.pricing.curve.impl.CurveBaseImpl).calculate(com.rbsfm.fi.pricing.curve.CurveCalculator$RateType, boolean) line: 593	
com.rbsfm.fi.pricing.curve.impl.RegularCurveImpl(com.rbsfm.fi.pricing.curve.impl.CurveBaseImpl).calculate(com.rbsfm.fi.pricing.curve.CurveCalculator$RateType) line: 589	
com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode(com.rbsfm.fi.pricing.dependency.curve.AbstractInternalCurveNode).bootstrap(com.rbsfm.fi.pricing.curve.CurveCalculator$RateType) line: 712	
com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode.curveCalculate() line: 194	
com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode.calculate() line: 146	
com.rbsfm.fi.pricing.dependency.DefaultNodeCalculationManager.calculateNode(com.rbsfm.fi.pricing.dependency.DependencyTree, com.rbsfm.fi.pricing.dependency.InternalNode, java.lang.String) line: 48	
com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.calculateNode(com.rbsfm.fi.pricing.dependency.InternalNode) line: 171	
com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.access$0(com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl, com.rbsfm.fi.pricing.dependency.InternalNode) line: 170	
com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl$SingleThreadedCalculation.calculateNodes(java.util.List) line: 498	
com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.calculateNodes() line: 177	
com.rbsfm.fi.pricing.dependency.tree.DependencyTreeImpl(com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree).calculateNodes() line: 691	
com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl.doCalcCycle() line: 444	
com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl.internalStart() line: 255	
com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl(com.rbsfm.common.system.AbstractControl).actualStart() line: 205	
com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl(com.rbsfm.common.system.AbstractControl).start() line: 97	
com.rbsfm.common.system.ControlManager.startControls(java.util.List<com.rbsfm.common.system.ControlManager.ControlInfo>) line: 325	
com.rbsfm.common.system.ControlManager.start() line: 231	

# Input values for the FVAR are

FRA.HUF {
    type=IV_RATE value=0.0825
    type=IV_SPREAD value=0.0
}

# There is where we load the curve to the FVAR 

com.rbsfm.fi.pricing.curve.impl.CurveRateImpl.getInputValues() line: 86	
com.rbsfm.fi.pricing.curve.fvar.CurveFVarWriter.toCurveRates(com.rbsfm.fi.pricing.curve.Curve) line: 403	
com.rbsfm.fi.pricing.curve.fvar.CurveFVarWriter.to(com.rbsfm.fi.pricing.curve.Curve, boolean, boolean, boolean) line: 81	
com.rbsfm.fi.pricing.curve.fvar.CurveFVarWriter.to(com.rbsfm.fi.pricing.curve.Curve, boolean) line: 67	
com.rbsfm.fi.pricing.dependency.curve.CurveExporter.resetDefinition(com.rbsfm.fi.pricing.curve.Curve, boolean) line: 49	
com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode(com.rbsfm.fi.pricing.dependency.curve.AbstractInternalCurveNode).initialiseCurve(com.rbsfm.common.date.Date) line: 663	
com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode.curveCalculate() line: 184	
com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode.calculate() line: 146	
com.rbsfm.fi.pricing.dependency.DefaultNodeCalculationManager.calculateNode(com.rbsfm.fi.pricing.dependency.DependencyTree, com.rbsfm.fi.pricing.dependency.InternalNode, java.lang.String) line: 48	
com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.calculateNode(com.rbsfm.fi.pricing.dependency.InternalNode) line: 171	
com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.access$0(com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl, com.rbsfm.fi.pricing.dependency.InternalNode) line: 170	
com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl$SingleThreadedCalculation.calculateNodes(java.util.List) line: 498	
com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.calculateNodes() line: 177	
com.rbsfm.fi.pricing.dependency.tree.DependencyTreeImpl(com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree).calculateNodes() line: 691	
com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl.doCalcCycle() line: 444	
com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl.internalStart() line: 255	
com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl(com.rbsfm.common.system.AbstractControl).actualStart() line: 205	
com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl(com.rbsfm.common.system.AbstractControl).start() line: 97	
com.rbsfm.common.system.ControlManager.startControls(java.util.List<com.rbsfm.common.system.ControlManager.ControlInfo>) line: 325	
com.rbsfm.common.system.ControlManager.start() line: 231	
com.rbsfm.common.system.ControlServer.main0(java.lang.String[]) line: 62	
com.rbsfm.common.system.ControlServer$1.run() line: 34	

# This is where the curve point values are taken to set the rates

com.rbsfm.fi.pricing.dependency.curve.CurvePointQuoteCalculator.getValues() line: 93	
com.rbsfm.fi.pricing.curve.impl.FixedLoanInstrumentImpl(com.rbsfm.fi.pricing.curve.impl.CurvePointImpl).setRates() line: 299	
com.rbsfm.fi.pricing.curve.impl.RegularCurveImpl(com.rbsfm.fi.pricing.curve.impl.CurveBaseImpl).setRates() line: 702	
com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode(com.rbsfm.fi.pricing.dependency.curve.AbstractInternalCurveNode).setRates() line: 679	
com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode.curveCalculate() line: 191	
com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode.calculate() line: 146	
com.rbsfm.fi.pricing.dependency.DefaultNodeCalculationManager.calculateNode(com.rbsfm.fi.pricing.dependency.DependencyTree, com.rbsfm.fi.pricing.dependency.InternalNode, java.lang.String) line: 48	
com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.calculateNode(com.rbsfm.fi.pricing.dependency.InternalNode) line: 171	
com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.access$0(com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl, com.rbsfm.fi.pricing.dependency.InternalNode) line: 170	
com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl$SingleThreadedCalculation.calculateNodes(java.util.List) line: 498	
com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.calculateNodes() line: 177	
com.rbsfm.fi.pricing.dependency.tree.DependencyTreeImpl(com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree).calculateNodes() line: 691	
com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl.doCalcCycle() line: 444	
com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl.internalStart() line: 255	
com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl(com.rbsfm.common.system.AbstractControl).actualStart() line: 205	
com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl(com.rbsfm.common.system.AbstractControl).start() line: 97	
com.rbsfm.common.system.ControlManager.startControls(java.util.List<com.rbsfm.common.system.ControlManager.ControlInfo>) line: 325	
com.rbsfm.common.system.ControlManager.start() line: 231	
com.rbsfm.common.system.ControlServer.main0(java.lang.String[]) line: 62	
com.rbsfm.common.system.ControlServer$1.run() line: 34	

# The field for selecting the benchmark curve should be the following

    <field name="benchmarkCurve" displayName="benchmarkCurve" dataType="System.String" format="0.000000" editType="selection" selectionType="treeCurves"/>   

Here the selectionType must be a value that is sent from a calculator. For each row an 
individual calculator will populate the options for the selectionType. For example
take the treeCurves selectionType above, this could be sent as "FRA_PLN, 6MFRA_PLN, CFRA_PLN",
which will be parsed in to "FRA_PLN", "6MFRA_PLN" and "CFRA_PLN" as values that can
be selected. For example here is some code to do the trick.

 atts.add(createAttribute(AttributeNames.TREE_CURVES_ATT, SelectionListHelper.getAllCurves(), getStatusId()))

# See the below with how to populate a selection list

com.rbsfm.fi.pricing.dependency.util.SelectionListHelper

# The following entry is required in the  GridMessageMapperManager.xml

<rule name="traderSpread" action="set" id="SetAttributeMessage5"/> 
<rule name="benchmarkCurve" action="set" id="SetAttributeMessage5"/> 

# This is used to create the swap style in CEEMEA.grid.config

        <style Master="true" WhatIf="true">
			<name>Swap</name>
			<public>true</public>
			<in_grid_splitter>
				<in_name fixed_width="8">nodeId</in_name>
  				<in_name fixed_width="8">disName</in_name>
			</in_grid_splitter>
			<in_grid>
               	<in_name fixed_width="8">bid</in_name>
              	<in_name fixed_width="8">ask</in_name>
              	<in_name fixed_width="8">prc</in_name>
              	<in_name fixed_width="8">adjustedRate</in_name>
             	<in_name fixed_width="8">curveRate</in_name>
              	<in_name fixed_width="8">curveSpread</in_name>
              	<in_name fixed_width="8">traderSpread</in_name>
              	<in_name fixed_width="8">benchmarkCurve</in_name>
              	<in_name fixed_width="8">runCurveJob</in_name>
			</in_grid>
		</style>
	
# Change to the attributes published from the calculator in Swap.xml

    <field name="adjustedRate" displayName="adjustedRate" dataType="System.Double" format="0.000000" editType="none"/> 
    <field name="curveRate" displayName="curveRate" dataType="System.Double" format="0.000000" editType="none"/>  
    <field name="curveSpread" displayName="curveSpread" dataType="System.Double" format="0.000000" editType="none"/>  
    <field name="traderSpread" displayName="traderSpread" dataType="System.Double" format="0.000000" editType="edit"/> 
    <field name="benchmarkCurve" displayName="benchmarkCurve" dataType="System.String" editType="selection" selectionType="treeCurves"/> 
    <field name="runCurveJob" displayName="runCurveJob" dataType="System.String" editType="selection" selectionType="onoff"/> 

# Curve manager JMX method to create the XML is

curveCreationFromFvar

# Cron is implemented badly

If there is an exception thrown from any job that has been scheduled with Cron,
then the Cron thread stops. This means that any one job can shutdown any other
job if it allows an exception to propagate.

# Create the SQL from the following FVAR

(Local) C:\Temp\curves\local\LIBOR\PLN\FRA.PLN
(UAT) D:\uat\rbsfm\cp\curves\local\LIBOR\PLN\FRA.PLN

# A given calculator can be given a message type like so

<mapper node_type="com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator" row_type="${MessageTypes.CURVE_POINT}" />

This needs the followign in the calculator class also.

    public boolean com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator.getOutputOwnDetails() {
        return true;
    }


# On start up here is where the curve is calculated

com.rbsfm.fi.pricing.dependency.curve.CurvePointQuoteCalculator.addAttributes(java.util.Collection) line: 841	
com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode(com.rbsfm.fi.pricing.dependency.NodeWithCalculators).toNewDetails() line: 1008	
com.rbsfm.fi.pricing.dependency.curve.InternalCurveNode(com.rbsfm.fi.pricing.dependency.curve.AbstractInternalCurveNode).toNewDetails() line: 844	
com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.getNodeDetails(com.rbsfm.fi.pricing.dependency.InternalNode) line: 186	
com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.access$200(com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl, com.rbsfm.fi.pricing.dependency.InternalNode) line: 39	
com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl$SingleThreadedCalculation.nodeOutputDetails(java.util.List) line: 543	
com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.getNodeDetails(java.util.List<com.rbsfm.fi.pricing.dependency.InternalNode>) line: 205	
com.rbsfm.fi.pricing.dependency.tree.DependencyTreeImpl(com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree).getNodeDetails(java.util.List<com.rbsfm.fi.pricing.dependency.InternalNode>) line: 715	
com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl$ResultsExtractorThread.run() line: 790	

# Looks like the CurvePointQuoteCalculator for each swap node is needed

So given the curve name CFRA_PLN, 6MFRA_PLN, or FRA_PLN a CurvePointQuoteCalculator can be 
used (or something similar) to post a value for each curve point. Each calculator contains
a unique calculator id based on itscurve point name.

# All curve points on a given node will match only one specific FraNode

Because the FraNode names are taken from the curve, then if the curves are
iterated over this means that each node will have only one specific value.
So the six month FraNodes will have a sixMonth rate but they will have no
three month rate. 


# Below is the Swap messages published for the curve points

HEADER: id[6MFRA_PLN_99v102] type[Swap] sourceName[ceemea-pricing-offshore] sourceType[PS][*]
  startDateSymbol[99m]{0}
  ccy[PLN]{0}
  secApp[FIPricing-CEEMEA-All-Update]{0}
  resetLead[0]{0}
  last[0.054]{0}
  endDateSymbol[102m]{0}
  doShiftAccrual[false]{0}
  fraDayIndex[0]{0}
  treeTok[CEEMEA.master]{0}
  originDate[TODAY]{0}
  shiftConvention[MOD FOLLOWING]{0}
  rtOvr[0.0]{0}
  nodeId[6MFRA_PLN_99v102]{0}
  fraForwardIndex[0]{0}
  fixFloat[FIXED]{0}
  LocalGlobalOwner[null]{0}
  firstReg[1900-01-01]{0}
  threeMthSprd[0.0]{0}
  basisRate[0.0]{0}
  PublicationLocation[GREENWICH]{0}
  rateOrSpread[0.0]{0}
  endDt[2018-06-18]{0}
  crvId[]{0}
  paymentBasis[A/A]{0}
  mastId[manualPrice]{0}
  prcMthds[manualPrice:manualPrice:midSwapRate]{0}
  own[CurveManager]{0}
  ask[0.054]{0}
  paymentPeriod[3m]{0}
  fixingIndex[]{0}
  startDate[2018-03-17]{0}
  isPricingSource[false]{0}
  threeMthRate[0.0]{0}
  PriceController[null]{0}
  effectiveStartDate[2018-03-19]{0}
  CompFreq[]{0}
  masterBeforeCronFlip[]{0}
  IsModifiable[true]{0}
  fix[0.0]{0}
  resetConvention[NORMALBE]{0}
  dirty[false]{0}
  clkPrd[1]{0}
  bid[0.054]{0}
  setId[FRA-6MFRA_PLN]{0}
  extInstType[FRA]{0}
  resetHolidayList[PLN]{0}
  disName[99v102]{0}
  discountCurve[]{0}
  sixMthRate[0.0548]{0}
  alias[]{0}
  paymentType[INARREARS]{0}
  rateCurve[]{0}
  paymentHolidayList[PLN]{0}
  fixingIndexOvr[false]{0}
  notional[1000000.0]{0}
  midAdjTim[1900-01-01 00:00:00.000]{0}
  prc[0.054]{0}
  LocalPreviousOwner[null]{0}
  fixingRateOvr[0.0]{0}
  lastReg[1900-01-01]{0}
  spotDays[0]{0}

# The messages from the GdsSwapCurveCalculator are mapped to Swap because of

 <mapper node_type="com.rbsfm.fi.pricing.dependency.fra.FraNode" row_type="${MessageTypes.SWAP}"/>

The above XML is in pricing under the "AttributeMapperManager" which associates a node type
to a message type. In order to see the messages being emitted for the GdsSwapCurveCalculator 
the MESSAGE level in the "LogAdmin" component should be set to true.

 <log name="MESSAGE" active="false"/>

This ensures that all messages sent out to the "GridResultsPublisher" component will be 
logged out.


# Message not intercepted

com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessageWithoutRecalc(com.rbsfm.fi.pricing.external.message.TreeMessage, boolean) line: 133	
com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage, boolean) line: 89	
com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 79	
com.rbsfm.fi.pricing.dependency.tree.DependencyTreeImpl(com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree).processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 644	
com.rbsfm.fi.pricing.dependency.remote.ClientImpl.processMessage(java.lang.String, java.lang.String) line: 238	
com.rbsfm.fi.pricing.mux.delegate.message.LocalClientMessageHandlerDelegate.processMessage(java.lang.String, java.lang.String, com.rbsfm.fi.pricing.external.message.GridMessage) line: 43	
com.rbsfm.fi.pricing.mux.remote.LocalClient.processMessage(java.lang.String, java.lang.String) line: 72	

# Normal message from the client intercepted

com.rbsfm.fi.pricing.dependency.bond.PriceYieldCalculator.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 156	
com.rbsfm.fi.pricing.dependency.bond.InternalBondNode(com.rbsfm.fi.pricing.dependency.NodeWithCalculators).forward2Calculator(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 1261	
com.rbsfm.fi.pricing.dependency.bond.InternalBondNode.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 305	
com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessageWithoutRecalc(com.rbsfm.fi.pricing.external.message.TreeMessage, boolean) line: 130	
com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage, boolean) line: 89	
com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 79	
com.rbsfm.fi.pricing.dependency.tree.DependencyTreeImpl(com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree).processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 644	
com.rbsfm.fi.pricing.dependency.remote.ClientImpl.processMessage(java.lang.String, java.lang.String) line: 238	
com.rbsfm.fi.pricing.mux.delegate.message.LocalClientMessageHandlerDelegate.processMessage(java.lang.String, java.lang.String, com.rbsfm.fi.pricing.external.message.GridMessage) line: 43	
com.rbsfm.fi.pricing.mux.remote.LocalClient.processMessage(java.lang.String, java.lang.String) line: 72	


# The HostNameResolver must be enabled

 <component name="LondonRSHostSelector" lazy="true" class_name="com.rbsfm.fi.pricing.mux.failover.HostSelector">
	<jmxDomain>CoreGDS</jmxDomain>
	<servername>${RatesServicesServerLondon}</servername>
	<hostnameResolver>HostnameResolver</hostnameResolver>
	<enabled>true</enabled>  <---------------------------------- THIS SHOULD BE ENABLED
 </component>

# The following issue is preventing downloading the curves

2009-12-11 10:14:10.909 -0500 ERROR [app-main] cpratesdev: Exception in loadOfficalCurve from Rates Services. Check GDS Rates Services.: ratesservices-uat-london6: Stack Trace: com.rbsfm.fi.pricing.mux.failover.HostSelector$NoAvailableHostException: ratesservices-uat-london6
	at com.rbsfm.fi.pricing.mux.failover.HostSelector.getCurrentHost(HostSelector.java:485)
	at com.rbsfm.fi.pricing.mux.delegate.AbstractSoapDelegate.getCurrentHost(AbstractSoapDelegate.java:144)
	at com.rbsfm.fi.pricing.mux.delegate.AbstractSoapDelegate.getSoapUrl(AbstractSoapDelegate.java:152)
	at com.rbsfm.fi.pricing.external.coregds.MarketDataManagerServiceDelegate.getMarketDataManagerServer(MarketDataManagerServiceDelegate.java:36)
	at com.rbsfm.fi.pricing.dependency.swap.GdsCurveClient.getMarketDataManager(GdsCurveClient.java:102)
	at com.rbsfm.fi.pricing.dependency.swap.GdsCurveClient.getGdsCurveFVAR(GdsCurveClient.java:66)
	at com.rbsfm.fi.pricing.dependency.swap.GdsCurveClient.getGdsCurve(GdsCurveClient.java:45)
	at com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator.configure(GdsSwapCurveCalculator.java:41)
	at com.rbsfm.fi.pricing.dependency.util.TreeUtil.newCalculatorInstance(TreeUtil.java:124)
	at com.rbsfm.fi.pricing.dependency.tree.TreeUpdateManagerImpl.createRealCalculator(TreeUpdateManagerImpl.java:348)

# To ensure the calculator is loaded by the server 

  <delegate name="GdsSwapCurveCalculatorHome" 
      class_name="com.rbsfm.fi.pricing.dependency.generic.DbGenericCalculatorHome" 
      autocommit="${autoCommit}" 
      populateForTreeType="all" 
      readOnly="${readOnly}" 
      calculatorClass="com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator"/>  

# To add this calculator to a bond

  exec CalculatorStore 
     @NodeRef = 'XS0106768608', 
     @CalculatorId = 'GdsSwapCurveCalc', 
     @JavaClass = 'com.rbsfm.fi.pricing.dependency.swap.GdsSwapCurveCalculator',
     @Version = 0,                        
     @ServerName = 'gallane', 
     @UpdaterRef = 'gallane'

# This new calculator will need to implement com.rbsfm.common.config.Configurable

Implementing the Configurable interface allows the calculator home to pass in a configuration
object. This can be used to extract details such as the types of type of curves to use and
where the curve information can be extracted from. A good example to look at here is the
StaticCurveCalculatorHome object.

# The associated web service can be found below, the getSoapURL method is used to get the location

<component name="MarketDataManagerServiceDelegate" lazy="${gdsServicesDisabled}" class_name="com.rbsfm.fi.pricing.external.coregds.MarketDataManagerServiceDelegate">
  <jmxDomain>CoreGDS</jmxDomain>
  <hostselector>CoreGdsServerHostSelector</hostselector>
  <soapurl>http://rates-services-uat.fm.rbsgrp.net:7221/jboss-net/services/MarketDataManager?wsdl</soapurl>
</component>

# The GDS locations are tokens available from a web service

GDSHKG
GDSMNH
GDSTKY
GDSLDN

# The variables CoreGdsLocation are expanded from class statics

<component name="ClassConstants" class_name="com.rbsfm.common.properties.ClassConstantsProperties">
  <class name="AttributeNames" package="com.rbsfm.fi.pricing.external.attribute" />
  <class name="AttributeUtil" package="com.rbsfm.fi.pricing.external.attribute" />
  <class name="MessageTypes" package="com.rbsfm.fi.pricing.external.message" />
  <class name="MuxAttributeNames" package="com.rbsfm.fi.pricing.mux" />
  <class name="CoreGdsLocation" package="com.rbsfm.fi.pricing.coregdsutil" /> <<--------------- CORE GDS LOCATION CONSTANTS
  <class name="EcnAttributeNames" package="com.rbsfm.fi.pricing.ecn.external.attribute" />
</component>

# Curves are loaded from the following component

<component name="CoreGdsCurrencyServiceLocation" class_name="com.rbsfm.fi.pricing.gds.servicelocation.CoreGdsCurrencyServiceLocation" lazy="${gdsServicesDisabled}">
  <jmxDomain>CoreGDS</jmxDomain>
  <currencyLocationDict>
    <dictEntry currency="EUR" />
    <dictEntry currency="GBP" />
    <dictEntry currency="JPY" staticServiceLocation="${CoreGdsLocation.TKY}" />
    <dictEntry currency="USD" tradingServiceLocation="${CoreGdsLocation.MNH}" marketDataServiceLocation="${CoreGdsLocation.MNH}" staticServiceLocation="${CoreGdsLocation.MNH}" />
    <dictEntry currency="SEK" tradingServiceLocation="${CoreGdsLocation.LDN}" marketDataServiceLocation="${CoreGdsLocation.LDN}" staticServiceLocation="${CoreGdsLocation.LDN}" />
  </currencyLocationDict>
  <defaultServiceLocation>"${server.currency.location}"</defaultServiceLocation> 
  <currency>${server.currency}</currency>
</component>

# This is used to acquire the associated curves

GDSCurveCloseRates
