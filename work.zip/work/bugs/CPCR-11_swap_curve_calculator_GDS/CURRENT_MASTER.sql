exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_102v105',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_105v108',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_108v111',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_111v114',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_114v117',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_117v120',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_120v123',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_123v126',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_126v129',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_129v132',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_12v15',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_132v135',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_135v138',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_138v141',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_141v144',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_144v147',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_147v150',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_150v153',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_153v156',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_156v159',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_159v162',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_15v18',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_162v165',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_165v168',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_168v171',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_171v174',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_174v177',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_177v180',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_18v21',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_20y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_21v24',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_24v27',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_25y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_27v30',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_30v33',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_30y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_33v36',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_36v39',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_39v42',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_3m',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_3v6',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_42v45',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_45v48',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_48v51',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_51v54',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_54v57',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_57v60',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_60v63',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_63v66',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_66v69',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_69v72',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_6v9',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_72v75',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_75v78',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_78v81',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_81v84',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_84v87',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_87v90',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_90v93',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_93v96',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_96v99',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_99v102',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_9v12',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_O/N',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_CZK_T/N',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_102v105',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_105v108',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_108v111',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_111v114',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_114v117',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_117v120',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_120v123',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_123v126',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_126v129',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_129v132',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_12v15',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_132v135',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_135v138',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_138v141',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_141v144',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_144v147',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_147v150',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_150v153',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_153v156',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_156v159',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_159v162',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_15v18',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_162v165',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_165v168',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_168v171',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_171v174',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_174v177',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_177v180',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_18v21',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_20y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_21v24',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_24v27',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_25y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_27v30',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_30v33',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_30y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_33v36',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_36v39',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_39v42',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_3m',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_3v6',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_42v45',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_45v48',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_48v51',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_51v54',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_54v57',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_57v60',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_60v63',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_63v66',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_66v69',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_69v72',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_6v9',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_72v75',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_75v78',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_78v81',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_81v84',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_84v87',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_87v90',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_90v93',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_93v96',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_96v99',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_99v102',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_9v12',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_O/N',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_HUF_T/N',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_102v105',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_105v108',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_108v111',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_111v114',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_114v117',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_117v120',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_120v123',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_123v126',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_126v129',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_129v132',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_12v15',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_132v135',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_135v138',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_138v141',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_141v144',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_144v147',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_147v150',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_150v153',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_153v156',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_156v159',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_159v162',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_15v18',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_15y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_162v165',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_165v168',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_168v171',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_171v174',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_174v177',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_177v180',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_18v21',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_20y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_21v24',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_24v27',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_27v30',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_30v33',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_33v36',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_36v39',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_39v42',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_3m',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_3v6',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_42v45',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_45v48',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_48v51',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_51v54',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_54v57',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_57v60',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_60v63',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_63v66',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_66v69',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_69v72',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_6v9',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_72v75',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_75v78',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_78v81',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_81v84',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_84v87',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_87v90',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_90v93',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_93v96',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_96v99',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_99v102',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = '6MFRA_PLN_9v12',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_102v105',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_105v108',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_108v111',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_111v114',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_114v117',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_117v120',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_120v123',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_123v126',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_126v129',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_129v132',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_12v15',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_132v135',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_135v138',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_138v141',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_141v144',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_144v147',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_147v150',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_150v153',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_153v156',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_156v159',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_159v162',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_15v18',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_162v165',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_165v168',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_168v171',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_171v174',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_174v177',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_177v180',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_18v21',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_20y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_21v24',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_24v27',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_25y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_27v30',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_30v33',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_30y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_33v36',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_36v39',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_39v42',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_3m',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_3v6',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_42v45',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_45v48',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_48v51',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_51v54',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_54v57',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_57v60',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_60v63',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_63v66',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_66v69',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_69v72',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_6v9',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_72v75',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_75v78',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_78v81',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_81v84',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_84v87',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_87v90',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_90v93',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_93v96',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_96v99',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_99v102',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_9v12',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_O/N',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_HUF_T/N',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_102v105',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_105v108',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_108v111',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_111v114',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_114v117',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_117v120',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_120v123',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_123v126',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_126v129',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_129v132',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_12v15',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_132v135',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_135v138',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_138v141',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_141v144',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_144v147',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_147v150',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_150v153',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_153v156',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_156v159',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_159v162',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_15v18',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_15y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_162v165',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_165v168',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_168v171',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_171v174',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_174v177',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_177v180',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_18v21',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_20y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_21v24',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_24v27',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_25y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_27v30',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_30v33',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_30y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_33v36',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_36v39',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_39v42',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_3m',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_3v6',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_42v45',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_45v48',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_48v51',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_51v54',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_54v57',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_57v60',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_60v63',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_63v66',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_66v69',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_69v72',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_6v9',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_72v75',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_75v78',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_78v81',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_81v84',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_84v87',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_87v90',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_90v93',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_93v96',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_96v99',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_99v102',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ILS_9v12',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_102v105',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_105v108',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_108v111',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_111v114',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_114v117',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_117v120',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_120v123',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_123v126',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_126v129',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_129v132',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_12v15',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_132v135',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_135v138',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_138v141',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_141v144',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_144v147',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_147v150',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_150v153',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_153v156',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_156v159',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_159v162',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_15v18',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_15y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_162v165',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_165v168',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_168v171',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_171v174',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_174v177',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_177v180',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_18v21',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_20y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_21v24',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_24v27',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_27v30',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_30v33',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_33v36',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_36v39',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_39v42',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_3m',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_3v6',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_42v45',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_45v48',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_48v51',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_51v54',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_54v57',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_57v60',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_60v63',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_63v66',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_66v69',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_69v72',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_6v9',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_72v75',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_75v78',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_78v81',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_81v84',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_84v87',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_87v90',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_90v93',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_93v96',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_96v99',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_99v102',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_9v12',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_O/N',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_PLN_T/N',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_102v105',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_105v108',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_108v111',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_111v114',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_114v117',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_117v120',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_12v15',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_15v18',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_18v21',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_1m',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_1wk',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_21v24',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_24v27',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_27v30',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_2m',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_2wk',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_30v33',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_33v36',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_36v39',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_39v42',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_3m',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_3v6',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_42v45',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_45v48',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_48v51',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_51v54',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_54v57',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_57v60',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_60v63',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_63v66',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_66v69',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_69v72',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_6v9',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_72v75',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_75v78',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_78v81',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_81v84',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_84v87',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_87v90',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_90v93',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_93v96',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_96v99',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_99v102',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_9v12',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_O/N',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_RUB_T/N',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_102v105',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_105v108',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_108v111',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_111v114',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_114v117',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_117v120',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_120v123',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_123v126',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_126v129',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_129v132',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_12v15',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_132v135',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_135v138',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_138v141',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_141v144',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_144v147',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_147v150',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_150v153',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_153v156',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_156v159',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_159v162',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_15v18',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_15y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_162v165',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_165v168',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_168v171',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_171v174',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_174v177',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_177v180',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_180v183',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_183v186',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_186v189',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_189v192',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_18v21',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_20y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_21v24',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_24v27',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_27v30',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_30v33',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_33v36',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_36v39',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_39v42',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_3m',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_3v6',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_42v45',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_45v48',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_48v51',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_51v54',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_54v57',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_57v60',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_60v63',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_63v66',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_66v69',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_69v72',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_6v9',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_72v75',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_75v78',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_78v81',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_81v84',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_84v87',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_87v90',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_90v93',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_93v96',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_96v99',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_99v102',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_TRY_9v12',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_102v105',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_105v108',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_108v111',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_111v114',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_114v117',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_117v120',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_120v123',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_123v126',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_126v129',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_129v132',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_12v15',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_132v135',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_135v138',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_138v141',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_141v144',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_144v147',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_147v150',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_150v153',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_153v156',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_156v159',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_159v162',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_15v18',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_162v165',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_165v168',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_168v171',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_171v174',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_174v177',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_177v180',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_180v183',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_18v21',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_20y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_21v24',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_24v27',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_25y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_27v30',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_30v33',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_30y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_33v36',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_35y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_36v39',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_39v42',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_3m',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_3v6',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_40y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_42v45',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_45v48',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_48v51',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_50y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_51v54',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_54v57',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_57v60',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_60v63',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_60y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_63v66',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_66v69',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_69v72',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_6v9',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_70y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_72v75',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_75v78',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_78v81',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_81v84',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_84v87',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_87v90',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_90v93',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_93v96',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_96v99',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_99v102',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'CFRA_ZAR_9v12',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_102v105',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_105v108',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_108v111',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_111v114',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_114v117',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_117v120',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_120v123',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_123v126',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_126v129',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_129v132',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_12v15',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_132v135',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_135v138',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_138v141',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_141v144',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_144v147',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_147v150',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_150v153',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_153v156',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_156v159',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_159v162',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_15v18',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_162v165',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_165v168',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_168v171',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_171v174',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_174v177',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_177v180',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_18v21',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_20y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_21v24',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_24v27',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_25y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_27v30',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_30v33',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_30y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_33v36',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_36v39',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_39v42',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_3m',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_3v6',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_42v45',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_45v48',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_48v51',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_51v54',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_54v57',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_57v60',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_60v63',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_63v66',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_66v69',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_69v72',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_6v9',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_72v75',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_75v78',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_78v81',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_81v84',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_84v87',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_87v90',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_90v93',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_93v96',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_96v99',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_99v102',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_9v12',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_O/N',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_HUF_T/N',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_102v105',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_105v108',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_108v111',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_111v114',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_114v117',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_117v120',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_120v123',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_123v126',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_126v129',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_129v132',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_12v15',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_132v135',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_135v138',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_138v141',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_141v144',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_144v147',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_147v150',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_150v153',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_153v156',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_156v159',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_159v162',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_15v18',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_162v165',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_165v168',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_168v171',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_171v174',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_174v177',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_177v180',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_18v21',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_20y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_21v24',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_24v27',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_25y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_27v30',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_30v33',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_30y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_33v36',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_36v39',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_39v42',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_3m',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_3v6',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_42v45',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_45v48',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_48v51',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_51v54',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_54v57',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_57v60',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_60v63',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_63v66',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_66v69',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_69v72',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_6v9',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_72v75',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_75v78',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_78v81',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_81v84',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_84v87',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_87v90',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_90v93',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_93v96',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_96v99',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_99v102',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ILS_9v12',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_102v105',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_105v108',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_108v111',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_111v114',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_114v117',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_117v120',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_120v123',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_123v126',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_126v129',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_129v132',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_12v15',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_132v135',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_135v138',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_138v141',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_141v144',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_144v147',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_147v150',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_150v153',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_153v156',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_156v159',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_159v162',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_15v18',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_162v165',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_165v168',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_168v171',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_171v174',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_174v177',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_177v180',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_18v21',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_20y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_21v24',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_24v27',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_25y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_27v30',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_30v33',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_30y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_33v36',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_36v39',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_39v42',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_3m',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_3v6',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_42v45',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_45v48',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_48v51',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_51v54',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_54v57',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_57v60',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_60v63',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_63v66',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_66v69',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_69v72',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_6v9',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_72v75',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_75v78',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_78v81',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_81v84',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_84v87',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_87v90',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_90v93',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_93v96',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_96v99',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_99v102',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_PLN_9v12',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_102v105',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_105v108',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_108v111',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_111v114',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_114v117',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_117v120',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_12v15',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_15v18',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_18v21',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_21v24',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_24v27',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_27v30',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_30v33',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_33v36',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_36v39',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_39v42',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_3m',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_3v6',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_42v45',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_45v48',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_48v51',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_51v54',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_54v57',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_57v60',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_60v63',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_63v66',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_66v69',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_69v72',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_6v9',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_72v75',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_75v78',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_78v81',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_81v84',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_84v87',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_87v90',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_90v93',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_93v96',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_96v99',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_99v102',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_RUB_9v12',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_102v105',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_105v108',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_108v111',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_111v114',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_114v117',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_117v120',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_120v123',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_123v126',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_126v129',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_129v132',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_12v15',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_132v135',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_135v138',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_138v141',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_141v144',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_144v147',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_147v150',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_150v153',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_153v156',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_156v159',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_159v162',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_15v18',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_162v165',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_165v168',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_168v171',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_171v174',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_174v177',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_177v180',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_180v183',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_18v21',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_20y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_21v24',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_24v27',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_25y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_27v30',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_30v33',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_30y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_33v36',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_35y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_36v39',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_39v42',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_3m',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_3v6',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_40y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_42v45',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_45v48',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_48v51',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_50y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_51v54',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_54v57',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_57v60',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_60v63',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_60y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_63v66',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_66v69',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_69v72',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_6v9',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_70y',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_72v75',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_75v78',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_78v81',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_81v84',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_84v87',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_87v90',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_90v93',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_93v96',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_96v99',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_99v102',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
exec GenericNodeAttributeStore @NodeRef = 'FRA_ZAR_9v12',@AttributeName = 'CurrentMaster',@ValueType = 'STRING',@ValueInt = 0,@ValueFloat = 0.0,@ValueDatetime = '1-1-1900',@ValueString = 'RatesSetCurveCalc',@Version = 0,@ServerName = 'script',@UpdaterRef = 'script'
go
