#!/bin/sh
isql -Ufip_dbo -Puat12345 -SCORP -Dfi_CEEMEA_uat 2>&1 <<-END
select distinct NodeRef from GenericNode where JavaClass like '%InternalCurveNode' order by NodeRef asc
go
END
