# Change availability check port to connect to UAT

<hostattribute name="availability_check_port" value="+49"/>

# Here is where data is taken off the socket

AbstractSocketMessageReader.readAndDispatch(final SocketChannel channel) throws IOException;

# Here is how we start listening for best prices for the DS

MuxDataSource.addRealtimeDataListener(RealtimeDataListener, String) line: 70	
DeferredTreeDataIntegrator(SimpleRealtimeDataIntegrator).addRealtimeDataListener(String, String, RealtimeDataListener) line: 142	
DeferredTreeDataIntegrator.addRealtimeDataListener(String, String, RealtimeDataListener) line: 141	
BidAskBestPriceMuxRealtimeCalculator(AbstractRealtimeCalculator).startListening() line: 251	
BidAskBestPriceMuxRealtimeCalculator(MuxRealtimeCalculator).startListening() line: 171	
BidAskBestPriceMuxRealtimeCalculator(AbstractRealtimeCalculator).start() line: 242	
InternalBondNode(NodeWithCalculators).startNode() line: 877	
InternalBondNode(InternalNode).start() line: 1253	
TreeCalculationManagerImpl.startNodes() line: 417	
TreeCalculationManagerImpl.start() line: 128	
DependencyTreeImpl(AbstractDependencyTree).start() line: 739	
SimpleTreeControl.internalStart() line: 242	
SimpleTreeControl(AbstractControl).actualStart() line: 205	
SimpleTreeControl(AbstractControl).start() line: 97	
ControlManager.startControls(List<ControlInfo>) line: 325	
ControlManager.start() line: 231	

# Hack to use reuters in UAT

    <server servername="reutersp2p_london" virtual="true" servertype="INF">
		<hosts>
			<hostdetails name="primary">
				<hostattribute name="hostname" value="bcup2p101.fm.rbsgrp.net" />
				<hostattribute name="backup_hostname" value="shup2p101.fm.rbsgrp.net.net" />
				<hostattribute name="port" value="8100" />
			</hostdetails>
		</hosts>
	</server>

# Reuters config for LOCAL

*eventMechanism : notify
*connectionRetryInterval : 60
*traceSelector : INFO
*username : App_CP_CEM_PS_OFF
*position : localhost
*connectMaxRetryDelay : 1
*serverList : bcdp2p101.fm.rbsgrp.net shdp2p101.fm.rbsgrp.net
*application : 306
*serverType : sapi
*portNumber : 8100

# Reuters config for UAT

*eventMechanism : notify
*connectionRetryInterval : 60
*traceSelector : INFO
*username : App_CP_CEM_PS_OFF
*position : localhost
*connectMaxRetryDelay : 1
*serverList : bcup2p101.fm.rbsgrp.net shup2p101.fm.rbsgrp.net
*application : 306
*serverType : sapi
*portNumber : 8100

# When all is done the calculator emits the following details

rtBestBidOvrd <---- rtBestBid (or if specified a user override)
rtBestAskOvrd <---- rtBestAsk (or if specified a user override)

rtBestBid <----- bestBid
rtBestAsk <----- bestAsk
rtBestBidMkt <----- bestBidMkt
rtBestAskMkt <----- bestAskMkt
rtBestPrcTyp <----- bestPrcTyp
rtUpdateTm <----- DateTime.now()

# The data is acted upon when the following method returns true

1) This is invoked to determine if the change is valid

   a) public boolean MuxRealtimeCalculator.populateFromDataEvent(RealtimeDataEvent event)

2) If it is valid then the attributes of the calculator are updated
3) The calculator is set to dirty after the attributes are populated
4) The following two methods are invoked

   a) void BidAskBestPriceRealtimeCalculator.attributesChanged() called from calculateMasterImpl()
   b) boolean BidAskBestPriceRealtimeCalculator.internalCalculateMasterImpl() called from calculateMasterImpl()

# To avoid updates when data has not changed the previous value is kept

This ensures only delta updates are provided

# For the BestPriceMuxRealtimeCalculator we need to add the following

bestMid

# Attributes are filtered on the following details using the MuxRealtimeCalculator.DefaultAttributeFilter()

bestBidLive
bestAskLive
bestAsk
bestBidMkt
bestAskMkt
bestBid
bestPrcTyp

# The following attributes are used in a best price update

lstTrdDir
lstTrdPrc=0.0
lstTrdTm=00:00:00.000
bestMid=8.24
lstTrdSz=0
bestAskSz=0
totTrdSz
bestAsk=8.225
bestBidMkt=RCT
bestAskMkt=RCT
lstTrdMkt
bestBid=8.255
bestBidSz=0
bestPrcTypPrice
version=2.0

# The following events occur in order to get best price data

1) Pricing server starts and creates the "EcnBestPriceServerHostSelector"
2) The "BestPriceSink" establishes a connection to the ceemea-exchangedata-offshore using "EcnBestPriceServerHostSelector"
3) The "BestPriceSource" is used to subscribe realtime update listeners for updates
4) Best price calculators are instantiated and register to listen for updates with the "BestPriceSource"
5) The ceemea-exchangedata-offshore sends updates to the "BestPriceSink" which updates "BestPriceSource" which updates listeners
6) When an update is issued to a listener it is propagated to the "BidAskBestPriceMuxRealtimeCalculator"

# The pricing server initiates a connection to the exchangedata server using the server_details.xml entry

  <hostattribute name="EcnBestPriceServer" value="ceemea-exchangedata-offshore"/>

# The values are provided by the following sink

  <component enabled="@{best_price_enabled}" name="BestPriceSink" class_name="com.rbsfm.fi.pricing.mux.socket.SocketClientSink">
       <hostselector>EcnBestPriceServerHostSelector</hostselector>
       <msg_buffer_size_bytes>${msg_buffer_size_bytes}</msg_buffer_size_bytes>
       <use_direct_buffer>${use_direct_buffer}</use_direct_buffer>
       <port>%mbp_socket_port%</port>
   </component>

# The BestPriceDS data source is defined by 

com.rbsfm.fi.pricing.mux.datasource.MuxDataSource

# Each instrument subscribes to a specified data source with a unique key, for example

CEEMEA.CZ0001000731.bestPriceCZ0001000731

# Here is where the registration occurs for the best price data

com.rbsfm.fi.pricing.dependency.simple.DeferredTreeDataIntegrator.addRealtimeDataListener(java.lang.String, java.lang.String, com.rbsfm.commonx.realtime.RealtimeDataListener) line: 134	
com.rbsfm.fi.pricing.dependency.bond.BidAskBestPriceMuxRealtimeCalculator(com.rbsfm.fi.pricing.dependency.util.AbstractRealtimeCalculator).startListening() line: 251	
com.rbsfm.fi.pricing.dependency.bond.BidAskBestPriceMuxRealtimeCalculator(com.rbsfm.fi.pricing.dependency.util.MuxRealtimeCalculator).startListening() line: 171	
com.rbsfm.fi.pricing.dependency.bond.BidAskBestPriceMuxRealtimeCalculator(com.rbsfm.fi.pricing.dependency.util.AbstractRealtimeCalculator).start() line: 242	
com.rbsfm.fi.pricing.dependency.bond.InternalBondNode(com.rbsfm.fi.pricing.dependency.NodeWithCalculators).startNode() line: 877	


# The data source providing the best price data is 

BestPriceDS

# Instrument example to use

PL0000104287
