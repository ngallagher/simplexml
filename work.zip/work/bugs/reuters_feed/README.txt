# The following DACS ids need to be created

App_CP_CEM_EA_OFF
App_CP_CEM_EI_OFF
App_CP_CEM_PS_OFF

# CR raised for new DACS ids

http://change.fm.rbsgrp.net/Change/Forms/ChangeRequest/Details.aspx?ID=0&_pm=0&_mi=1&CRID=112074
