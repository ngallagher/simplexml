# Are prices required from any other exchanges? Currently we use

Reuters (we get indicative prices from Reuters)

# The following setup is being used in production at the moment

SEC_ACT_1=ASK  # Fields may be different if they are yield pricing
PRIM_ACT_1=BID  # Fields may be different if they are yield pricing

FEED=IDN-RDF

# TRY Instruments 

TR280813TV0=IS
TR260912TV0=IS
TRT260912T15 (CP ISIN)

# The questions relate to Reuters pages for CEEMEA
# The Reuters pages that have already been prepared are
#
# ZAR (4GBC and TTSA1)
# TRY
# RUB (for RICS only)

# For all Russian RUB pages the composite is shown, should we show this? What are the other
# options? Should best price be shown, some other price perhaps?
1) For the Russian RUB pages the composite price is being shown, is this correct? 
   There are several prices for each instrument, perhaps composite price is not correct.

# Ignore for now
2) Is the TRUSTBND page required or not? (NOT IMPORTANT)

# Here the question is basically should some intervention be taken to swap prices to get a balance
# so that there is no gap between the bid and offer.
3) For the 4GBC page (shown aboove as ZAR) the bid is sometimes greater than the offer, should these 
   values been swapped so that the offer is greater than the bid. The examples are shown below, taken
   from a dump of the Reuters page.

field: ROW80_1 = 10:48 19FEB10           ICAP                           UK69580              4GBC
field: ROW80_2 = JHB 276 9025                            LDN 44 207 532 4800                     
field: ROW80_3 = STOCK        BID   OFF     VOL     1    SWITCH       BID   OFF     VOL     1    
field: ROW80_4 = .                                       R157/R201        / -3.0     :5          
field: ROW80_5 = R157         8.32/  8.31   5:5     32 H R157/R206   -3.0 / -4.0    5:5         H

# Basically here what is being asked is which value to use to determine what the bid price is? For 
# example is it the SEC_ACT_1, or the SEC_ACT_2 attributes?
3) For the TRY RIC structure there are a number of key value pairs, which key refers to the bid and 
   which refers the the ask? Best source of reference is to take a look at the Excel spread sheet. Here
   is a sample below (taken from email)

# ARE THESE SAMPLES COMPREHENSIVE
-----------------------------
TR130110TV0=IS

PROD_PERM = 3224
RDNDISPLAY = 10
DSPLY_NAME = 130110          
RDN_EXCHID = IST
TRDPRC_1 = +99.981
  
# What is the actual question being asked here? Does this mean that for the ISIN ZAG000015512 is an exception 
# to all other cases??
# What do the fields PRIM_ACT_1 and SEC_ACT_1 refer to? Also RT_YIELD_1 and SEC_YIELD_1, what do these mean?
5) The ZATSY page record capture for the first record (ISIN = ZAG000015512). For this record we need to
   get the PRIMACT_1 and SEC_ACT_1, and for others we get the RT_YIELD_! and SEC_YIELD_1.

# ARE THESE SAMPLES COMPREHENSIVE
-----------------------------
ZAT011=

PROD_PERM = 3967
RDNDISPLAY = 152
DSPLY_NAME = TRANSNET        
   
