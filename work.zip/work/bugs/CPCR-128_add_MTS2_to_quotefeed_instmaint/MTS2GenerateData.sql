-- Clear
select 'delete from EcnQuoteNew where BrokerRef="MTS2"'
select 'delete from EcnQuoteNewAudit where BrokerRef="MTS2"'


select 'exec EcnQuoteNewStore @BrokerRef="'
+ 'MTS2' + '"'
+ ', @InstrumentRef="'
+ RTRIM(LTRIM(eqnv.InstrumentRef) ) + '"'
+ ', @BucketRef="'
+ RTRIM(LTRIM(eqnv.BucketRef) ) + '"'
+ ', @BuySell="'
+ eqnv.BuySell + '"'
+ ', @ChainId="'
+ RTRIM(LTRIM(eqnv.ChainId) ) + '"'
+ ', @Size=' 
+ CONVERT( VARCHAR(30), eqnv.Size )
+ ', @BlockSize='
+ CONVERT( VARCHAR(30), eqnv.BlockSize )
+ ', @Version=0'
+ ', @ServerName='
+ '"MTS2GenerateEcnQuoteNew.sql"'
+ ', @UpdaterRef='
+ '"script"'
from EcnQuoteNewView eqnv
where eqnv.BrokerRef="MTS"
order by eqnv.BrokerRef, eqnv.InstrumentRef
go

-- Clear
select 'delete from EcnQuoteTimer where BrokerRef="MTS2"'
select 'delete from EcnQuoteTimerAudit where BrokerRef="MTS2"'

--QuoteTimer
select 'exec EcnQuoteTimerStore @BrokerRef="'
+ 'MTS2' + '"'
+ ', @InstrumentRef="'
+ RTRIM(LTRIM(eqtv.InstrumentRef) ) + '"'
+ ', @TimerName="quoteTimer"'
+ ', @CounterDirection="Asc"'
+ ', @MaxSpread=null' 
+ ', @MinSize=null'
+ ', @ObligationTime=null'
+ ', @StartTime=null'
+ ', @EndTime=null'
+ ', @LastRunning=null'
+ ', @QuoteTime=0'
+ ', @Version=0'
+ ', @ServerName='
+ '"MTS2GenerateEcnQuoteTimer.sql"'
+ ', @UpdaterRef='
+ '"script"'
from EcnQuoteTimerView eqtv
where eqtv.BrokerRef="MTS"
and eqtv.TimerName="quoteTimer"
order by eqtv.BrokerRef, eqtv.InstrumentRef
go

--Obligation1 without StartTime and EndTime
select 'exec EcnQuoteTimerStore @BrokerRef="'
+ 'MTS2' + '"'
+ ', @InstrumentRef="'
+ RTRIM(LTRIM(eqtv.InstrumentRef) ) + '"'
+ ', @TimerName="obligation1"'
+ ', @CounterDirection="Asc"'
+ ', @MaxSpread=' 
+ str( eqtv.MaxSpread, 6,4 ) 
+ ', @MinSize='
+ CONVERT( VARCHAR(30), eqtv.MinSize )
+ ', @ObligationTime=0'
+ ', @StartTime=null'
+ ', @EndTime=null'
+ ', @LastRunning=null'
+ ', @QuoteTime=0'
+ ', @Version=0'
+ ', @ServerName='
+ '"MTS2GenerateEcnQuoteTimer.sql"'
+ ', @UpdaterRef='
+ '"script"'
from EcnQuoteTimerView eqtv
where eqtv.BrokerRef="MTS"
and eqtv.TimerName="obligation1"
and eqtv.StartTime=null
and eqtv.EndTime=null
order by eqtv.BrokerRef, eqtv.InstrumentRef
go


--Obligation1 with StartTime and EndTime
select 'exec EcnQuoteTimerStore @BrokerRef="'
+ 'MTS2' + '"'
+ ', @InstrumentRef="'
+ RTRIM(LTRIM(eqtv.InstrumentRef) ) + '"'
+ ', @TimerName="obligation1"'
+ ', @CounterDirection="Asc"'
+ ', @MaxSpread=' 
+ str( eqtv.MaxSpread, 6,4 ) 
+ ', @MinSize='
+ CONVERT( VARCHAR(30), eqtv.MinSize )
+ ', @ObligationTime=0'
+ ', @StartTime="'
+ CONVERT( VARCHAR(30), eqtv.StartTime, 108 ) + '"'
+ ', @EndTime="'
+ CONVERT( VARCHAR(30), eqtv.EndTime, 108 ) + '"'
+ ', @LastRunning=null'
+ ', @QuoteTime=0'
+ ', @Version=0'
+ ', @ServerName='
+ '"MTS2GenerateEcnQuoteTimer.sql"'
+ ', @UpdaterRef='
+ '"script"'
from EcnQuoteTimerView eqtv
where eqtv.BrokerRef="MTS"
and eqtv.TimerName="obligation1"
and eqtv.StartTime<>null
and eqtv.EndTime<>null
order by eqtv.BrokerRef, eqtv.InstrumentRef
go


--Obligation2
select 'exec EcnQuoteTimerStore @BrokerRef="'
+ 'MTS2' + '"'
+ ', @InstrumentRef="'
+ RTRIM(LTRIM(eqtv.InstrumentRef) ) + '"'
+ ', @TimerName="obligation2"'
+ ', @CounterDirection="Asc"'
+ ', @MaxSpread=' 
+ str( eqtv.MaxSpread, 6,4 ) 
+ ', @MinSize='
+ CONVERT( VARCHAR(30), eqtv.MinSize )
+ ', @ObligationTime=0'
+ ', @StartTime="'
+ CONVERT( VARCHAR(30), eqtv.StartTime, 108 ) + '"'
+ ', @EndTime="'
+ CONVERT( VARCHAR(30), eqtv.EndTime, 108 ) + '"'
+ ', @LastRunning=null'
+ ', @QuoteTime=0'
+ ', @Version=0'
+ ', @ServerName='
+ '"MTS2GenerateEcnQuoteTimer.sql"'
+ ', @UpdaterRef='
+ '"script"'
from EcnQuoteTimerView eqtv
where eqtv.BrokerRef="MTS"
and TimerName="obligation2"
order by eqtv.BrokerRef, eqtv.InstrumentRef
go

-- Clear
select 'delete from EcnSpreadNew where BrokerRef="MTS2"'
select 'delete from EcnSpreadNewAudit where BrokerRef="MTS2"'


select 'exec EcnSpreadNewStore @BrokerRef="'
+ 'MTS2' + '"'
+ ', @InstrumentRef="'
+ RTRIM(LTRIM(esnv.InstrumentRef) ) + '"'
+ ', @BucketRef="'
+ RTRIM(LTRIM(esnv.BucketRef) ) + '"'
+ ', @Spread='
+ str(esnv.Spread, 6,4 ) 
+ ', @Skew='
+ str(esnv.Skew, 7,5 ) 
+ ', @Round='
+ str(esnv.Round, 7,5 )
+ ', @SpreadType="'
+ esnv.SpreadType + '"'
+ ', @Version=0'
+ ', @ServerName='
+ '"MTS2GenerateEcnSpreadNew.sql"'
+ ', @UpdaterRef='
+ '"script"'
from EcnSpreadNewView esnv
where esnv.BrokerRef="MTS"
order by esnv.BrokerRef, esnv.InstrumentRef
go

-- Clear
select 'delete from EcnTrack where BrokerRef="MTS2"'
select 'delete from EcnTrackAudit where BrokerRef="MTS2"'

go

-- The following is commented out because Jim Hough does not want to track on MTS
-- The best way to acheive this is to leave EcnTrack Completely blank
--select 'exec EcnTrackStore @BrokerRef="'
--+ 'MTS2' + '"'
--+ ', @InstrumentRef="'
--+ RTRIM(LTRIM( etv.InstrumentRef) ) + '"'
--+ ', @TrackingStatus="'
--+ RTRIM(LTRIM( etv.TrackingStatus) ) + '"'
--+ ', @BidSpread=' 
--+ str( etv.BidSpread, 6,4 ) 
--+ ', @AskSpread=' 
--+ str( etv.AskSpread, 6,4 ) 
--+ ', @TrackDepth='
--+ CONVERT( VARCHAR(30), etv.TrackDepth )
--+ ', @DynamicScale='
--+ CONVERT( VARCHAR(30), etv.DynamicScale )
--+ ', @MaxMultiplier='
--+ CONVERT( VARCHAR(30), etv.MaxMultiplier )
--+ ', @MinDepth='
--+ CONVERT( VARCHAR(30), etv.MinDepth )
--+ ', @Version=0'
--+ ', @ServerName='
--+ '"MTS2GenerateEcnTrack.sql"'
--+ ', @UpdaterRef='
--+ '"script"'
--from EcnTrackView etv
--where etv.BrokerRef="MTS"
--order by etv.BrokerRef, etv.InstrumentRef
--go