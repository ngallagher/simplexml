# The current template for polish bonds is

  <component class_name="com.rbsfm.fi.instmaint.enrich.ObligationTypeEnricher" name="ObligationTypeEnricher">
    <requestBondsConsumer>RequestBondsConsumer</requestBondsConsumer>
    <obligationType name="${AttributeNames.SD_FIXING_OBLIGATION}"> 
      <clone currency="PLN" instrument="PL0000105730"/>
    </obligationType>
    <obligationType name="${AttributeNames.SD_BENCHMARK_OBLIGATION}"> 
      <clone currency="PLN" instrument="PL0000104287"/>
    </obligationType>    
    <obligationType name="${AttributeNames.SD_NO_OBLIGATION}"> 
      <clone currency="PLN" instrument="PL0000103222"/>
    </obligationType>   
  </component>  

# Remove the following bonds

appEraseCEEMEABond 'PL0000104857'
go
appEraseCEEMEABond 'PL0000106126'
go
appEraseCEEMEABond 'PL0000104717'
go

# Here is what you would run for DEV

isql -Ufip_dbo -Pfip_dbo_pwd -SDEV  -Dfi_CEEMEA_dev  -w 400 -i MTS2GenerateData.sql -o ceemeaDEVMTS2Data.sql

# Here is what to run to get the SQL for UAT

isql -SCORP -Ufip_dbo -Puat12345 -Dfi_CEEMEA_uat -w 400 -i MTS2GenerateData.sql -o ceemeaUATMTS2Data.sql
