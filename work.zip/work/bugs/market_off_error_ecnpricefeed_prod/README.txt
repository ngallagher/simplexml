# The trader status can not be used for sorting

	public static final Comparator COMPARATOR = new Comparator() {
		public int compare(Object o1, Object o2) {
			return ((TraderStatus)o1).compareTo(o2);
		}
	};

# Bad implementation of InstrumentECNStatus caused by

CVS r1.1.2.77 to r1.1.2.78

# If the following message is sent it turns only the broker status off, not the instrument status

<?xml version="1.0" encoding="utf-16"?>
<messages>
  <message>
    <header dataSetId="gallane@MA" dataSetType="BrokerStatus" sourceType="PS" sourceName="" />
    <fields>
      <field name="brkEnable" value="False" />
      <field name="brkId" value="gallane@MA" />
      <field name="brkName" value="MA" />
      <field name="dataSetId" value="gallane@MA" />
      <field name="dataSetType" value="BrokerStatus" />
      <field name="MA" value="ON" />
      <field name="NbManual" value="0" />
      <field name="ServerName" value="corp-ecnpricefeed-master16" />
      <field name="ServerType" value="EI" />
    </fields>
  </message>
  <message>
    <header dataSetId="gallane@MA" dataSetType="BrokerStatus" sourceType="EQ" sourceName="" />
    <fields>
      <field name="brkAlive" value="True" />
      <field name="tdrId" value="gallane" />
    </fields>
  </message>
</messages>

# The following causes instrument market status (MktStat) to go off

If not all markets are turned off then this causes the instrument to become grey

InstrumentECNStatus$RefreshInstrumentStatusCommand.execute() line: 597	
InstrumentECNStatus.internalConsume(Object) line: 564	
AbstractConsumerControl$1.consume(Object) line: 55	
ProducerConsumer.runConsumerLoop() line: 292	
ProducerConsumer.access$100(ProducerConsumer) line: 24	
ProducerConsumer$1.run() line: 214	
Thread.run() line: 619	

# Looks like the connection pool was the cause

Trader did a market off after the error

# Looks like the price was still there at 10:17

Price pulled at 10:24:17.130, price goes at 10:24:18
                10:24.16.710 (synchronized with Bloomberg)

# CP machine time

CP is approx 1.42 secs ahead of Bloomberg

# Turn off markets causes a refresh

InstrumentECNStatus$RefreshTraderStatusCommand.execute() line: 665	
InstrumentECNStatus.internalConsume(Object) line: 564	
AbstractConsumerControl$1.consume(Object) line: 55	
ProducerConsumer.runConsumerLoop() line: 292	
ProducerConsumer.access$100(ProducerConsumer) line: 24	
ProducerConsumer$1.run() line: 214	
Thread.run() line: 619	

# Taking ownership causes a status refresh

Turn on a single bond

# Instrument pulled via onApplicableEcnStatusUpdated

2009-12-03 10:24:17.130 INFO [InstrumentECNStatus:ConsumerThread] crpricing_server: Control[MpfIndicativePricePublisher]: onApplicableEcnStatusUpdated(BB=>BB): XS0205828477
2009-12-03 10:24:17.130 INFO [InstrumentECNStatus:ConsumerThread] crpricing_server: Control[MpfIndicativePricePublisher]: onTraderStatusUpdated(): marshjp

# Look for XS0205828477

This was pulled at 10:24

# Excessive modifications noticed at 10:15 due to addition

DbRowModificationPoller polled 4 row modifications, for example: 346078350.03-Dec-09 10:15:13.173 AM.CalculatorAttribute.UPDATE.XS0110562534.manualPrice.BidPriceOrYield..33
DbRowModificationPoller polled 29 row modifications, for example: 346078354.03-Dec-09 10:15:14.893 AM.CalculatorAttribute.INSERT.XS0470427476.BondStaticCalc.BondId..1
DbRowModificationPoller polled 116 row modifications, for example: 346078383.03-Dec-09 10:15:15.123 AM.SubTreeNodes.INSERT.STAGING.XS0470427476...1
DbRowModificationPoller polled 18 row modifications, for example: 346078499.03-Dec-09 10:15:17.006 AM.CalculatorAttribute.UPDATE.DUMMY1.ZSpreadCalc.bidZSprd..1795
DbRowModificationPoller polled 112 row modifications, for example: 346078517.03-Dec-09 10:15:17.150 AM.CalculatorAttribute.UPDATE.GB00B39R3707.ZSpreadCalcRBS.bidZSprd..1809
DbRowModificationPoller polled 46 row modifications, for example: 346078629.03-Dec-09 10:15:18.150 AM.CalculatorAttribute.UPDATE.XS0268648952.ZSpreadCalcRBS.bidZSprd..5

# Bond was added as XS0470427476

This seemed to cause the start of the database exhaustion
