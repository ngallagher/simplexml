# FRA data is missing from the Curve style such as 

ZeroRate
DF
Spread
