/** This is required for the DependencyTree **/

alter table Node add
ClockPeriod int default 1 not null
go

/** Include the node view table */

if exists (select 1 from sysobjects where name='NodeView' and type='V')
begin
  drop view NodeView
end
go
 
create view NodeView
as

select
       NodeSetRef                     = NodeSetRef,
       NodeId                         = NodeId,
       NodeType                       = NodeType,
       DisplayName                    = DisplayName,
       ExternalCode                   = ExternalCode,
       Owner                          = Owner,
       ClockPeriod                     = ClockPeriod,
       Version                        = Version,
       RecordStatus                   = RecordStatus,
       ServerName                     = ServerName,
       CreatorRef                     = CreatorRef,
       CreationDatetime               = CreationDatetime,
       UpdaterRef                     = UpdaterRef,
       UpdateDatetime                 = UpdateDatetime
from Node
where RecordStatus = 'C'
go

/** Audit table for NodeView **/

if exists (select 1 from sysobjects where name='NodeAudit' and type='U')
begin
  drop table NodeAudit
end
go
create table NodeAudit (
    NodeSetRef                     char(25) not null,
    NodeId                         varchar(255) not null,
    NodeType                       char(20) not null,
    DisplayName                    varchar(255) not null,
    ExternalCode                   char(32) not null,
    Owner                          varchar(32) not null,
    ClockPeriod                     int default 1 not null,
    Version                        int not null,
    RecordStatus                   char(1) not null,
    ServerName                     varchar(30) not null,
    CreatorRef                     varchar(32) not null,
    CreationDatetime               datetime not null,
    UpdaterRef                     varchar(32) not null,
    UpdateDatetime                 datetime not null)

lock datarows
go
sp_primarykey NodeAudit, NodeId
go

/** The NodeAuditView table **/

if exists (select 1 from sysobjects where name='NodeAuditView' and type='V')
begin
  drop view NodeAuditView
end
go
 
create view NodeAuditView
as
select
       NodeSetRef                     = NodeSetRef,
       NodeId                         = NodeId,
       NodeType                       = NodeType,
       DisplayName                    = DisplayName,
       ExternalCode                   = ExternalCode,
       Owner                          = Owner,
       ClockPeriod                     = ClockPeriod,
       Version                        = Version,
       RecordStatus                   = RecordStatus,
       ServerName                     = ServerName,
       CreatorRef                     = CreatorRef,
       CreationDatetime               = CreationDatetime,
       UpdaterRef                     = UpdaterRef,
       UpdateDatetime                 = UpdateDatetime
from NodeAudit
where RecordStatus = 'C'
go

/** Required for stored proc change **/

alter table EcnInstrumentStatus add
Firm varchar(4) default '' 
go

/** Fix the view */

if exists (select 1 from sysobjects where name='EcnInstrumentStatusView' and type='V')
begin
  drop view EcnInstrumentStatusView
end
go

create view EcnInstrumentStatusView
as

select
       BrokerRef                      = BrokerRef,
       InstrumentRef                  = InstrumentRef,
       OwnerRef                       = OwnerRef,
       BidEachDay                     = BidEachDay,
       AskEachDay                     = AskEachDay,
       BidToday                       = BidToday,
       AskToday                       = AskToday,
       Tolerance                      = Tolerance,
       ResendCount                    = ResendCount,
       WireTime                       = WireTime,
       MarketStatus                   = MarketStatus,
       AutoAcceptingStatus            = AutoAcceptingStatus,
       CheckTradeLimitStatus          = CheckTradeLimitStatus,
       BookId                         = BookId,
       Version                        = Version,
       RecordStatus                   = RecordStatus,
       ServerName                     = ServerName,
       CreatorRef                     = CreatorRef,
       Firm                           = Firm,
       CreationDatetime               = CreationDatetime,
       UpdaterRef                     = UpdaterRef,
       UpdateDatetime                 = UpdateDatetime
from EcnInstrumentStatus
where RecordStatus = 'C'
go

/** The whole view needs to be dropped and created for GenericNodeView to pick up ClockPeriod **/

if exists (select 1 from sysobjects where name='GenericNodeView' and type='V')
begin
  drop view GenericNodeView
end
go
 
create view GenericNodeView
as

select
       NodeSetRef                     = n.NodeSetRef,
       DisplayName                    = n.DisplayName,
       ExternalCode                   = n.ExternalCode,
       Owner                          = n.Owner,
       NodeRef                        = t.NodeRef,
       JavaClass                      = t.JavaClass,
       ClockPeriod                    = n.ClockPeriod,       
       Version                        = t.Version,
       RecordStatus                   = t.RecordStatus,
       ServerName                     = t.ServerName,
       CreatorRef                     = t.CreatorRef,
       CreationDatetime               = t.CreationDatetime,
       UpdaterRef                     = t.UpdaterRef,
       UpdateDatetime                 = t.UpdateDatetime
from Node n, GenericNode t
where n.NodeId = t.NodeRef
  and t.RecordStatus = 'C'
go

/** This is required by the InstrumentEnlivener **/

if exists (select * from sysobjects where name="PerSectorDefault"
                                       and type="U")
begin
  drop table PerSectorDefault
end
go

CREATE TABLE dbo.PerSectorDefault
(
    NodeSetRef       varchar(30) NOT NULL,
    Currency         varchar(5)  NULL,
    SubTree          varchar(30) NOT NULL,
    ChainId          varchar(30) NOT NULL,
    AllBucketSizes   float       NOT NULL,
    AllBucketSpread  float       NOT NULL,
    SpreadType       varchar(10) NOT NULL,
    IsFinancial      varchar(4)  NOT NULL,
    HedgeTolerance   float       NOT NULL,
    HedgeMinSize     float       NOT NULL,
    AutoHedgeStatus  varchar(4)  NOT NULL,
    Version          int         NOT NULL,
    RecordStatus     char(1)     NOT NULL,
    ServerName       varchar(30) NOT NULL,
    CreatorRef       varchar(32) NOT NULL,
    CreationDatetime datetime    NOT NULL,
    UpdaterRef       varchar(32) NOT NULL,
    UpdateDatetime   datetime    NOT NULL
)
LOCK DATAROWS
go
IF OBJECT_ID('dbo.PerSectorDefault') IS NOT NULL
    PRINT '<<< CREATED TABLE dbo.PerSectorDefault >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE dbo.PerSectorDefault >>>'
go
EXEC sp_primarykey 'dbo.PerSectorDefault', NodeSetRef, Currency
go


GRANT SELECT ON dbo.PerSectorDefault TO cpratesread
go



/** This is required by the InstrumentEnlivener **/

IF OBJECT_ID('dbo.PerSectorDefaultView') IS NOT NULL
BEGIN
    DROP VIEW dbo.PerSectorDefaultView
    IF OBJECT_ID('dbo.PerSectorDefaultView') IS NOT NULL
        PRINT '<<< FAILED DROPPING VIEW dbo.PerSectorDefaultView >>>'
    ELSE
        PRINT '<<< DROPPED VIEW dbo.PerSectorDefaultView >>>'
END
go
create view PerSectorDefaultView
as
select
     NodeSetRef       =  NodeSetRef        ,
     Currency         =  Currency          ,
     SubTree          =  SubTree           ,
     ChainId          =  ChainId           ,
     AllBucketSizes   =  AllBucketSizes    ,
     AllBucketSpread  =  AllBucketSpread   ,
     SpreadType       =  SpreadType        ,
     IsFinancial      =  IsFinancial       ,
     HedgeTolerance   =  HedgeTolerance    ,
     HedgeMinSize     =  HedgeMinSize      ,
     AutoHedgeStatus  =  AutoHedgeStatus   ,
     Version          =  Version           ,
     RecordStatus     =  RecordStatus      ,
     ServerName       =  ServerName        ,
     CreatorRef       =  CreatorRef        ,
     CreationDatetime =  CreationDatetime  ,
     UpdaterRef       =  UpdaterRef        ,
     UpdateDatetime   =  UpdateDatetime
from PerSectorDefault
where RecordStatus = 'C'
go
IF OBJECT_ID('dbo.PerSectorDefaultView') IS NOT NULL
    PRINT '<<< CREATED VIEW dbo.PerSectorDefaultView >>>'
ELSE
    PRINT '<<< FAILED CREATING VIEW dbo.PerSectorDefaultView >>>'
go

/** This is required by the InstrumentEnlivener **/

IF OBJECT_ID('dbo.PerSectorDefaultStore') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.PerSectorDefaultStore
    IF OBJECT_ID('dbo.PerSectorDefaultStore') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.PerSectorDefaultStore >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.PerSectorDefaultStore >>>'
END
go
create procedure PerSectorDefaultStore (
      @NodeSetRef                    varchar(30),
      @Currency                      varchar(5),
      @SubTree                       varchar(30),
      @ChainId                       varchar(30),
      @AllBucketSizes                float,
      @AllBucketSpread               float,
      @SpreadType                    varchar(10),
      @IsFinancial                   varchar(4),
      @HedgeTolerance                float,
      @HedgeMinSize                  float,
      @AutoHedgeStatus               varchar(4),
      @Version                       int,
      @ServerName                    varchar(30),
      @UpdaterRef                    varchar(32))
as

declare @error    int,
       @rowcount int,
       @format   varchar(255)

select @error=0

begin transaction

 if exists (select 1 from PerSectorDefault
            where NodeSetRef=@NodeSetRef
            and (Currency=@Currency or (Currency is null and @Currency is null))
           )
 begin
   if (@Version = 0)
   begin
     select @Version = Version from PerSectorDefault
     where NodeSetRef=@NodeSetRef
     and (Currency=@Currency or (Currency is null and @Currency is null))
   end
   update PerSectorDefault set
     SubTree=@SubTree,
     ChainId=@ChainId,
     AllBucketSizes=@AllBucketSizes,
     AllBucketSpread=@AllBucketSpread,
     SpreadType=@SpreadType,
     IsFinancial=@IsFinancial,
     HedgeTolerance=@HedgeTolerance,
     HedgeMinSize=@HedgeMinSize,
     AutoHedgeStatus=@AutoHedgeStatus,
     Version=Version+1,
     RecordStatus='C',
     ServerName=@ServerName,
     UpdaterRef=@UpdaterRef,
     UpdateDatetime=getdate()
   where NodeSetRef=@NodeSetRef
     and (Currency=@Currency or (Currency is null and @Currency is null))

   select @error=@@error,@rowcount=@@rowcount
   if ((@error != 0) or (@rowcount!=1))
   begin
     while @@trancount != 0 rollback
     exec sp_getmessage 29000,@format OUTPUT
     select @format=@format+' NodeSetRef=%4! Currency=%5! Version=%6!'
     raiserror 29000 @format ,'PerSectorDefaultStore','update','PerSectorDefault',@NodeSetRef,@Currency,@Version
     return -1
   end
 end
 else
 begin
   select @Version = 1

   insert into PerSectorDefault (
     NodeSetRef,
     Currency,
     SubTree,
     ChainId,
     AllBucketSizes,
     AllBucketSpread,
     SpreadType,
     IsFinancial,
     HedgeTolerance,
     HedgeMinSize,
     AutoHedgeStatus,
     Version,
     RecordStatus,
     ServerName,
     CreatorRef,
     CreationDatetime,
     UpdaterRef,
     UpdateDatetime)
   values (
     @NodeSetRef,
     @Currency,
     @SubTree,
     @ChainId,
     @AllBucketSizes,
     @AllBucketSpread,
     @SpreadType,
     @IsFinancial,
     @HedgeTolerance,
     @HedgeMinSize,
     @AutoHedgeStatus,
     @Version,
     'C',
     @ServerName,
     @UpdaterRef,
     getdate(),
     @UpdaterRef,
     getdate())

   select @error=@@error,@rowcount=@@rowcount
   if ((@error != 0) or (@rowcount!=1))
   begin
     while @@trancount != 0 rollback
     exec sp_getmessage 29000,@format OUTPUT
     select @format=@format+' NodeSetRef=%4! Currency=%5! Version=%6!'
     raiserror 29000 @format ,'PerSectorDefaultStore','insert','PerSectorDefault',@NodeSetRef,@Currency,@Version
     return -1
   end
 end
commit transaction

select NodeSetRef,
      Currency,
      Version,
      CreatorRef,
      CreationDatetime,
      UpdaterRef,
      UpdateDatetime
from PerSectorDefault
where NodeSetRef=@NodeSetRef
     and (Currency=@Currency or (Currency is null and @Currency is null))

return 0
go
EXEC sp_procxmode 'dbo.PerSectorDefaultStore', 'anymode'
go
IF OBJECT_ID('dbo.PerSectorDefaultStore') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.PerSectorDefaultStore >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.PerSectorDefaultStore >>>'
go


/** The following is required for the staging tree **/

exec TreeStore 'StagingLatam', 'StagingLatam', 'StagingLatam', 0, 'script', 'gallane'
GO
exec SubTreeStore 'Staging', 'StagingLatam', 3, 0, 'script', 'gallane'
GO
exec NodeSetStore 'StagingLatam', 'Staging', 'All', 'All', 0, 'script', 'gallane'
GO

/** In order to get the client to be able to add bonds you need **/

exec PerSectorDefaultStore 	
      @NodeSetRef      = 'Staging',	
      @Currency        = 'USD',	
      @SubTree         = 'ALL',	
      @ChainId         = '',	
      @AllBucketSizes  = 0,	
      @AllBucketSpread = 0,	
      @SpreadType      = '',	
      @IsFinancial     = '',	
      @HedgeTolerance  = 0,	
      @HedgeMinSize    = 0,	
      @AutoHedgeStatus = 'OFF',	
      @Version         = 0,
      @ServerName      = 'script',
      @UpdaterRef      = 'gallane'     

    exec PerSectorDefaultStore 	
      @NodeSetRef      = 'LATAM_KY_Corp',	
      @Currency        = 'USD',	
      @SubTree         = 'ALL',	
      @ChainId         = '',	
      @AllBucketSizes  = 0,	
      @AllBucketSpread = 0,	
      @SpreadType      = '',	
      @IsFinancial     = '',	
      @HedgeTolerance  = 0,	
      @HedgeMinSize    = 0,	
      @AutoHedgeStatus = 'OFF',	
      @Version         = 0,
      @ServerName      = 'script',
      @UpdaterRef      = 'gallane'      

        exec PerSectorDefaultStore 	
      @NodeSetRef      = 'LATAM_AR_Corp',	
      @Currency        = 'USD',	
      @SubTree         = 'ALL',	
      @ChainId         = '',	
      @AllBucketSizes  = 0,	
      @AllBucketSpread = 0,	
      @SpreadType      = '',	
      @IsFinancial     = '',	
      @HedgeTolerance  = 0,	
      @HedgeMinSize    = 0,	
      @AutoHedgeStatus = 'OFF',	
      @Version         = 0,
      @ServerName      = 'script',
      @UpdaterRef      = 'gallane'   
go

/** Create the staging calculator **/


IF OBJECT_ID('dbo.appCreateStagingCalculator') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.appCreateStagingCalculator
    IF OBJECT_ID('dbo.appCreateStagingCalculator') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.appCreateStagingCalculator >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.appCreateStagingCalculator >>>'
END
go


 create proc appCreateStagingCalculator 
 (      
       @BondNodeRef                   varchar(20),
       @StageLiveStatus               varchar(25),
       @StageBook                     varchar(25),
       @PostStagingSectorOpts         varchar(30),
       @PostStagingSector             varchar(30),
       @StageBB               	      char(1) 	= 'Y',
       @StageALLQ                     char(1)	= 'Y',
       @StageRequestor                varchar(25) 
 )
as

declare @Version          int
declare @ServerName       varchar(30)
declare @UpdaterRef       varchar(32)
declare @CalculatorId     char(20)
declare @userName         char(10)

select @Version          = 1
select @CalculatorId     = 'StagingCalc'
select @userName         = ( select user_name() )
select @ServerName       = ( select @@servername )
select @UpdaterRef       = 'appCreateStagingCalculator'

declare @error                 int

select @Version =      (select Version from CalculatorAttribute where NodeRef =  @BondNodeRef
                        and CalculatorId = 'StagingCalc' and AttributeName = 'BondName' )

if @Version is null
begin
    select @Version = 0
end
else
begin
    select @Version = @Version + 1
end

begin tran

Print ' '
Print 'Populating CalculatorAttributes %1! staging data',@BondNodeRef

exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'stageLive',             'STRING',   0, 0, '1-1-1900', 'STAGE', @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'stageLiveStatus',       'STRING',   0, 0, '1-1-1900', @StageLiveStatus, @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'stageBook',             'STRING',   0, 0, '1-1-1900', @StageBook, @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'postStagingSectorOpts', 'STRING',   0, 0, '1-1-1900', @PostStagingSectorOpts, @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'postStagingSector',     'STRING',   0, 0, '1-1-1900', @PostStagingSector, @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'stageBB',     	    'STRING',   0, 0, '1-1-1900', @StageBB, @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'stageALLQ',     	    'STRING',   0, 0, '1-1-1900', @StageALLQ, @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'stageRequestor',        'STRING',   0, 0, '1-1-1900', @StageRequestor, @Version , @ServerName, @UpdaterRef


exec CalculatorStore @BondNodeRef, @CalculatorId, 'com.rbsfm.fi.pricing.dependency.staging.StagingCalculator', @Version , @ServerName, @UpdaterRef

Print 'CalculatorAttributes populated ok for Swiss bond [%1!]',@BondNodeRef


commit tran

go
EXEC sp_procxmode 'dbo.appCreateStagingCalculator','anymode'
go
IF OBJECT_ID('dbo.appCreateStagingCalculator') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.appCreateStagingCalculator >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.appCreateStagingCalculator >>>'
go

/** Add stored procedure to erase a calculator **/

--
-- $Id: appEraseStagingCalculator.sql,v 1.5 2009/08/14 16:32:44 wraypc Exp $
-- $Revision: 1.5 $
--

IF OBJECT_ID('dbo.appEraseStagingCalculator') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.appEraseStagingCalculator
    IF OBJECT_ID('dbo.appEraseStagingCalculator') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.appEraseStagingCalculator >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.appEraseStagingCalculator >>>'
END
GO


create proc appEraseStagingCalculator (      
       @BondNodeRef                   varchar(20)
)
as

--
-- Variables
--
declare @Version          int
declare @ServerName       varchar(30)
declare @UpdaterRef       varchar(32)
declare @CalculatorId     char(20)
declare @userName         char(10)


-- Variable defaults
select @CalculatorId     = 'StagingCalc'
select @userName         = ( select user_name() )
select @ServerName       = ( select @@servername )
select @UpdaterRef       = 'appEraseStagingCalculator'

-- return code checks etc.
declare @error                 int


select @Version =      (select Version from CalculatorAttribute where NodeRef =  @BondNodeRef
                        and CalculatorId = 'StagingCalc' and AttributeName = 'stageLive' )

if @Version is null
begin
    select @Version = 0
end



--
-- delete the staging calculator attributes (except stageRequestor which is useful for future reference) 
--

begin tran


    Print ' '
    Print 'Deleting Staging CalculatorAttributes %1! staging data',@BondNodeRef

    exec @error = CalculatorAttributeDelete @BondNodeRef, @CalculatorId, 'stageLiveStatus', @Version , @ServerName, @UpdaterRef
    if (@error != 0)
    begin
         rollback tran
         raiserror 999999 'appEraseStagingCalculator:Error CalculatorAttributeDelete:stageLiveStatus'
         return -1
    end  

    exec @error = CalculatorAttributeDelete @BondNodeRef, @CalculatorId, 'stageLive', @Version , @ServerName, @UpdaterRef
    if (@error != 0)
    begin
         rollback tran
         raiserror 999999 'appEraseStagingCalculator:Error CalculatorAttributeDelete:stageLive'
         return -1
    end  

    exec @error = CalculatorAttributeDelete @BondNodeRef, @CalculatorId, 'stageBook', @Version , @ServerName, @UpdaterRef
    if (@error != 0)
    begin
         rollback tran
         raiserror 999999 'appEraseStagingCalculator:Error CalculatorAttributeDelete:stageBook'
         return -1
    end  

    exec @error = CalculatorAttributeDelete @BondNodeRef, @CalculatorId, 'postStagingSectorOpts', @Version , @ServerName, @UpdaterRef
    if (@error != 0)
    begin
         rollback tran
         raiserror 999999 'appEraseStagingCalculator:Error CalculatorAttributeDelete:postStagingSectorOpts'
         return -1
    end  

    exec @error = CalculatorAttributeDelete @BondNodeRef, @CalculatorId, 'postStagingSector', @Version , @ServerName, @UpdaterRef
    if (@error != 0)
    begin
         rollback tran
         raiserror 999999 'appEraseStagingCalculator:Error CalculatorAttributeDelete:postStagingSector'
         return -1
    end 

    exec @error = CalculatorAttributeDelete @BondNodeRef, @CalculatorId, 'stageBB', @Version , @ServerName, @UpdaterRef
    if (@error != 0)
    begin
         rollback tran
         raiserror 999999 'appEraseStagingCalculator:Error CalculatorAttributeDelete:stageBB'
         return -1
    end 

    exec @error = CalculatorAttributeDelete @BondNodeRef, @CalculatorId, 'stageALLQ', @Version , @ServerName, @UpdaterRef
    if (@error != 0)
    begin
         rollback tran
         raiserror 999999 'appEraseStagingCalculator:Error CalculatorAttributeDelete:stageALLQ'
         return -1
    end 

    Print 'Staging CalculatorAttributes deleted ok for bond [%1!]',@BondNodeRef


commit tran

GO

IF OBJECT_ID('dbo.appEraseStagingCalculator') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.appEraseStagingCalculator >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.appEraseStagingCalculator >>>'
GO

EXEC sp_procxmode 'dbo.appEraseStagingCalculator', 'anymode'
GO

/** Fix the following procs **/

if exists (select 1 from sysobjects where name='EcnInstCtrlStore' and type='P')
begin
  drop procedure EcnInstCtrlStore
end
go
 
create procedure EcnInstCtrlStore (
       @BrokerRef                     varchar(30),
       @InstrumentRef                 char(30),
       @AttributeName                 char(30),
       @AttributeValue                varchar(50),
       @Version                       int,
       @ServerName                    varchar(30),
       @UpdaterRef                    varchar(32))
as
/** $Revision: 1.2 $ **/

declare @error    int,
        @rowcount int,
        @format   varchar(255)

select @error=0

begin transaction

  if exists (select 1 from EcnInstCtrl
             where BrokerRef=@BrokerRef
               and  InstrumentRef=@InstrumentRef
               and  AttributeName=@AttributeName
            )
  begin
    if (@Version = 0)
    begin
      select @Version = Version from EcnInstCtrl
      where BrokerRef=@BrokerRef
        and  InstrumentRef=@InstrumentRef
        and  AttributeName=@AttributeName
    end
    update EcnInstCtrl set
      AttributeValue=@AttributeValue,
      Version=Version+1,
      RecordStatus='C',
      ServerName=@ServerName,
      UpdaterRef=@UpdaterRef,
      UpdateDatetime=getdate()
    where BrokerRef=@BrokerRef
      and  InstrumentRef=@InstrumentRef
      and  AttributeName=@AttributeName

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      while @@trancount != 0 rollback
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' BrokerRef=%4! InstrumentRef=%5! AttributeName=%6! Version=%7!'
      raiserror 29000 @format ,'EcnInstCtrlStore','update','EcnInstCtrl',@BrokerRef,@InstrumentRef,@AttributeName,@Version
      return -1
    end
  end
  else
  begin
    select @Version = 1 

    insert into EcnInstCtrl (
      BrokerRef,
      InstrumentRef,
      AttributeName,
      AttributeValue,
      Version,
      RecordStatus,
      ServerName,
      CreatorRef,
      CreationDatetime,
      UpdaterRef,
      UpdateDatetime)
    values (
      @BrokerRef,
      @InstrumentRef,
      @AttributeName,
      @AttributeValue,
      @Version,
      'C',
      @ServerName,
      @UpdaterRef,
      getdate(),
      @UpdaterRef,
      getdate())

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      while @@trancount != 0 rollback
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' BrokerRef=%4! InstrumentRef=%5! AttributeName=%6! Version=%7!'
      raiserror 29000 @format ,'EcnInstCtrlStore','insert','EcnInstCtrl',@BrokerRef,@InstrumentRef,@AttributeName,@Version
      return -1
    end
  end
commit transaction

--select BrokerRef,
--       InstrumentRef,
--       AttributeName,
--       Version,
--       CreatorRef,
--       CreationDatetime,
--       UpdaterRef,
--       UpdateDatetime
--from EcnInstCtrl
--where BrokerRef=@BrokerRef
--  and  InstrumentRef=@InstrumentRef
--  and  AttributeName=@AttributeName


return 0
go
sp_procxmode EcnInstCtrlStore , 'anymode' 
go

/** Yet another stored procedure **/

if exists (select 1 from sysobjects where name='EcnInstrumentMappingStore' and type='P')
begin
  drop procedure EcnInstrumentMappingStore
end
GO
 
create procedure EcnInstrumentMappingStore (
       @InstrumentId                  char(30),
       @EcnId                         char(30),
       @MappingType                   char(30),
       @EcnInstrumentId               char(80),
       @Version                       int,
       @ServerName                    varchar(30),
       @UpdaterRef                    varchar(32))
as
/** $Revision: 1.7 $ **/

declare @error    int,
        @rowcount int,
        @format   varchar(255)

select @error=0

begin transaction

  if exists (select 1 from EcnInstrumentMapping
             where InstrumentId=@InstrumentId
               and  EcnId=@EcnId
               and  MappingType=@MappingType
            )
  begin
    if (@Version = 0)
    begin
      select @Version = Version from EcnInstrumentMapping
      where InstrumentId=@InstrumentId
        and  EcnId=@EcnId
        and  MappingType=@MappingType
    end
    update EcnInstrumentMapping set
      EcnInstrumentId=@EcnInstrumentId,
      Version=Version+1,
      RecordStatus='C',
      ServerName=@ServerName,
      UpdaterRef=@UpdaterRef,
      UpdateDatetime=getdate()
    where InstrumentId=@InstrumentId
      and  EcnId=@EcnId
      and  MappingType=@MappingType

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      rollback tran
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' InstrumentId=%4! EcnId=%5! MappingType=%6! Version=%7!'
      raiserror 29000 @format ,'EcnInstrumentMappingStore','update','EcnInstrumentMapping',@InstrumentId,@EcnId,@MappingType,@Version
      return -1
    end
  end
  else
  begin
    select @Version = 1 

    insert into EcnInstrumentMapping (
      InstrumentId,
      EcnId,
      MappingType,
      EcnInstrumentId,
      Version,
      RecordStatus,
      ServerName,
      CreatorRef,
      CreationDatetime,
      UpdaterRef,
      UpdateDatetime)
    values (
      @InstrumentId,
      @EcnId,
      @MappingType,
      @EcnInstrumentId,
      @Version,
      'C',
      @ServerName,
      @UpdaterRef,
      getdate(),
      @UpdaterRef,
      getdate())

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      rollback tran
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' InstrumentId=%4! EcnId=%5! MappingType=%6! Version=%7!'
      raiserror 29000 @format ,'EcnInstrumentMappingStore','insert','EcnInstrumentMapping',@InstrumentId,@EcnId,@MappingType,@Version
      return -1
    end
  end
commit transaction


return 0
GO
sp_procxmode EcnInstrumentMappingStore , 'anymode' 
GO

/** Yet another stored proc **/

if exists (select 1 from sysobjects where name='EcnInstrumentStatusStore' and type='P')
begin
    drop procedure EcnInstrumentStatusStore
end
go
create procedure EcnInstrumentStatusStore (
       @BrokerRef                     varchar(30)=null,
       @InstrumentRef                 char(30),
       @OwnerRef                      varchar(30),
       @BidEachDay                    float,
       @AskEachDay                    float,
       @BidToday                      float,
       @AskToday                      float,
       @Tolerance                     float,
       @ResendCount                   int,
       @WireTime                      int,
       @MarketStatus                  varchar(4),
       @AutoAcceptingStatus           varchar(4),
       @CheckTradeLimitStatus         varchar(4),
       @BookId                        varchar(30)=null,
       @Firm						  varchar(4),
       @Version                       int,
       @ServerName                    varchar(30),
       @UpdaterRef                    varchar(32))
as
/** $Revision: 1.11 $ **/

declare @error    int,
        @rowcount int,
        @format   varchar(255)

select @error=0

begin transaction

  if exists (select 1 from EcnInstrumentStatus
             where BrokerRef=@BrokerRef
               and  InstrumentRef=@InstrumentRef
            )
  begin
    if (@Version = 0)
    begin
      select @Version = Version from EcnInstrumentStatus
      where BrokerRef=@BrokerRef
        and  InstrumentRef=@InstrumentRef
    end
    update EcnInstrumentStatus set
      OwnerRef=@OwnerRef,
      BidEachDay=@BidEachDay,
      AskEachDay=@AskEachDay,
      BidToday=@BidToday,
      AskToday=@AskToday,
      Tolerance=@Tolerance,
      ResendCount=@ResendCount,
      WireTime=@WireTime,
      MarketStatus=@MarketStatus,
      AutoAcceptingStatus=@AutoAcceptingStatus,
      CheckTradeLimitStatus=@CheckTradeLimitStatus,
      BookId=@BookId,
      Firm=@Firm,
      Version=Version+1,
      RecordStatus='C',
      ServerName=@ServerName,
      UpdaterRef=@UpdaterRef,
      UpdateDatetime=getdate()
    where BrokerRef=@BrokerRef
      and  InstrumentRef=@InstrumentRef

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      while @@trancount != 0 rollback
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' BrokerRef=%4! InstrumentRef=%5! Version=%6!'
      raiserror 29000 @format ,'EcnInstrumentStatusStore','update','EcnInstrumentStatus',@BrokerRef,@InstrumentRef,@Version
      return -1
    end
  end
  else
  begin
    select @Version = 1 

    insert into EcnInstrumentStatus (
      BrokerRef,
      InstrumentRef,
      OwnerRef,
      BidEachDay,
      AskEachDay,
      BidToday,
      AskToday,
      Tolerance,
      ResendCount,
      WireTime,
      MarketStatus,
      AutoAcceptingStatus,
      CheckTradeLimitStatus,
      BookId,
      Firm,
      Version,
      RecordStatus,
      ServerName,
      CreatorRef,
      CreationDatetime,
      UpdaterRef,
      UpdateDatetime)
    values (
      @BrokerRef,
      @InstrumentRef,
      @OwnerRef,
      @BidEachDay,
      @AskEachDay,
      @BidToday,
      @AskToday,
      @Tolerance,
      @ResendCount,
      @WireTime,
      @MarketStatus,
      @AutoAcceptingStatus,
      @CheckTradeLimitStatus,
      @BookId,
      @Firm,
      @Version,
      'C',
      @ServerName,
      @UpdaterRef,
      getdate(),
      @UpdaterRef,
      getdate())

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      while @@trancount != 0 rollback
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' BrokerRef=%4! InstrumentRef=%5! Version=%6!'
      raiserror 29000 @format ,'EcnInstrumentStatusStore','insert','EcnInstrumentStatus',@BrokerRef,@InstrumentRef,@Version
      return -1
    end
  end
commit transaction

--select BrokerRef,
--       InstrumentRef,
--       Version,
--       CreatorRef,
--       CreationDatetime,
--       UpdaterRef,
--      UpdateDatetime
--from EcnInstrumentStatus
--where BrokerRef=@BrokerRef
--  and  InstrumentRef=@InstrumentRef


return 0
go
sp_procxmode EcnInstrumentStatusStore , 'anymode' 
go

/** Another stored proc change **/

if exists (select 1 from sysobjects where name='EcnInstrumentSubStore' and type='P')
begin
  drop procedure EcnInstrumentSubStore
end
GO
 
create procedure EcnInstrumentSubStore (
       @BrokerRef                     varchar(30),
       @InstrumentRef                 char(30),
       @SubscriptionStatus            varchar(4),
       @Version                       int,
       @ServerName                    varchar(30),
       @UpdaterRef                    varchar(32))
as
/** $Revision$ **/

declare @error    int,
        @rowcount int,
        @format   varchar(255)

select @error=0

begin transaction

  if exists (select 1 from EcnInstrumentSub
             where BrokerRef = @BrokerRef AND InstrumentRef=@InstrumentRef
            )
  begin
    if (@Version = 0)
    begin
      select @Version = Version from EcnInstrumentSub
      where BrokerRef = @BrokerRef AND InstrumentRef=@InstrumentRef
    end
    update EcnInstrumentSub set
      SubscriptionStatus=@SubscriptionStatus,
      Version=Version+1,
      RecordStatus='C',
      ServerName=@ServerName,
      UpdaterRef=@UpdaterRef,
      UpdateDatetime=getdate()
    where BrokerRef = @BrokerRef AND InstrumentRef=@InstrumentRef

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      while @@trancount != 0 rollback
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' BrokerRef=%4! InstrumentId=%5! SubscriptionType=%6! Version=%7!'
      raiserror 29000 @format ,'EcnInstrumentSubStore','update','EcnInstrumentSub',@BrokerRef,@InstrumentRef,@Version
      return -1
    end
  end
  else
  begin
    select @Version = 1 

    insert into EcnInstrumentSub (
      BrokerRef,
      InstrumentRef,
      SubscriptionStatus,
      Version,
      RecordStatus,
      ServerName,
      CreatorRef,
      CreationDatetime,
      UpdaterRef,
      UpdateDatetime)
    values (
      @BrokerRef,
      @InstrumentRef,
      @SubscriptionStatus,
      @Version,
      'C',
      @ServerName,
      @UpdaterRef,
      getdate(),
      @UpdaterRef,
      getdate())

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      while @@trancount != 0 rollback
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' BrokerRef=%4! InstrumentId=%5! SubscriptionType=%6! Version=%7!'
      raiserror 29000 @format ,'EcnInstrumentSubStore','insert','EcnInstrumentSub',@BrokerRef,@InstrumentRef,@Version
      return -1
    end
  end
commit transaction


return 0
GO
sp_procxmode EcnInstrumentSubStore , 'anymode' 
GO

/** Another stored proc **/

if exists (select 1 from sysobjects where name='EcnQuoteNewStore' and type='P')
begin
    drop procedure EcnQuoteNewStore
end
GO
create procedure EcnQuoteNewStore (
       @BrokerRef                     varchar(30),
       @InstrumentRef                 char(30),
       @BucketRef                     char(20),
       @BuySell                       char(1),
       @ChainId                       varchar(30),
       @Size                          float,
       @BlockSize                     float,
       @Version                       int,
       @ServerName                    varchar(30),
       @UpdaterRef                    varchar(32))
as
/** $Revision: 1.10 $ **/

declare @error    int,
        @rowcount int,
        @format   varchar(255)

select @error=0

begin transaction

  if exists (select 1 from EcnQuoteNew
             where BrokerRef=@BrokerRef
               and  InstrumentRef=@InstrumentRef
               and  BucketRef=@BucketRef
               and  BuySell=@BuySell
            )
  begin
    if (@Version = 0)
    begin
      select @Version = Version from EcnQuoteNew
      where BrokerRef=@BrokerRef
        and  InstrumentRef=@InstrumentRef
        and  BucketRef=@BucketRef
        and  BuySell=@BuySell
    end
    update EcnQuoteNew set
      ChainId=@ChainId,
      Size=@Size,
      BlockSize=@BlockSize,
      Version=Version+1,
      RecordStatus='C',
      ServerName=@ServerName,
      UpdaterRef=@UpdaterRef,
      UpdateDatetime=getdate()
    where BrokerRef=@BrokerRef
      and  InstrumentRef=@InstrumentRef
      and  BucketRef=@BucketRef
      and  BuySell=@BuySell

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      rollback tran
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' BrokerRef=%4! InstrumentRef=%5! BucketRef=%6! BuySell=%7! Version=%8!'
      raiserror 29000 @format ,'EcnQuoteNewStore','update','EcnQuote',@BrokerRef,@InstrumentRef,@BucketRef,@BuySell,@Version
      return -1
    end
  end
  else
  begin
    select @Version = 1 

    insert into EcnQuoteNew (
      BrokerRef,
      InstrumentRef,
      BucketRef,
      BuySell,
      ChainId,
      Size,
      BlockSize,
      Version,
      RecordStatus,
      ServerName,
      CreatorRef,
      CreationDatetime,
      UpdaterRef,
      UpdateDatetime)
    values (
      @BrokerRef,
      @InstrumentRef,
      @BucketRef,
      @BuySell,
      @ChainId,
      @Size,
      @BlockSize,
      @Version,
      'C',
      @ServerName,
      @UpdaterRef,
      getdate(),
      @UpdaterRef,
      getdate())

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      rollback tran
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' BrokerRef=%4! InstrumentRef=%5! BucketRef=%6! BuySell=%7! Version=%8!'
      raiserror 29000 @format ,'EcnQuoteNewStore','insert','EcnQuote',@BrokerRef,@InstrumentRef,@BucketRef,@BuySell,@Version
      return -1
    end
  end
commit transaction


return 0
GO
sp_procxmode EcnQuoteNewStore , 'anymode' 
GO

/** More stored procs **/

if exists (select 1 from sysobjects where name='EcnSanitizerInstCtrlStore' and type='P')
begin
  drop procedure EcnSanitizerInstCtrlStore
end
GO
 
create procedure EcnSanitizerInstCtrlStore (
       @BrokerRef                     varchar(30),
       @InstrumentRef                 char(30),
       @AttributeName                 char(30),
       @AttributeValue                varchar(50),
       @Version                       int,
       @ServerName                    varchar(30),
       @UpdaterRef                    varchar(32))
as

/** $Revision: 1.6 $ **/
declare @error    int,
        @rowcount int,
        @format   varchar(255)
        

begin transaction
    select @error=0
    

  if exists (select 1 from EcnSanitizerInstCtrl
             where BrokerRef=@BrokerRef
               and  InstrumentRef=@InstrumentRef
               and  AttributeName=@AttributeName
            )
  begin
    if (@Version = 0)
    begin
      select @Version = Version from EcnSanitizerInstCtrl
      where BrokerRef=@BrokerRef
        and  InstrumentRef=@InstrumentRef
        and  AttributeName=@AttributeName
    end
    update EcnSanitizerInstCtrl set
      AttributeValue=@AttributeValue,
      Version=Version+1,
      RecordStatus='C',
      ServerName=@ServerName,
      UpdaterRef=@UpdaterRef,
      UpdateDatetime=getdate()
    where BrokerRef=@BrokerRef
      and  InstrumentRef=@InstrumentRef
      and  AttributeName=@AttributeName

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      while @@trancount != 0 rollback
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' BrokerRef=%4! InstrumentRef=%5! AttributeName=%6! Version=%7!'
      raiserror 29000 @format ,'EcnSanitizerInstCtrlStore','insert','EcnSanitizerInstCtrl',@BrokerRef,@InstrumentRef,@AttributeName,@Version
      return -1
    end
  end
  else
  begin
    select @Version = 1 

    insert into EcnSanitizerInstCtrl (
      BrokerRef,
      InstrumentRef,
      AttributeName,
      AttributeValue,
      Version,
      RecordStatus,
      ServerName,
      CreatorRef,
      CreationDatetime,
      UpdaterRef,
      UpdateDatetime)
    values (
      @BrokerRef,
      @InstrumentRef,
      @AttributeName,
      @AttributeValue,
      @Version,
      'C',
      @ServerName,
      @UpdaterRef,
      getdate(),
      @UpdaterRef,
      getdate())

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      while @@trancount != 0 rollback
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' BrokerRef=%4! InstrumentRef=%5! AttributeName=%6! Version=%7!'
      raiserror 29000 @format ,'EcnSanitizerInstCtrlStore','insert','EcnSanitizerInstCtrl',@BrokerRef,@InstrumentRef,@AttributeName,@Version
      return -1
    end
  end



commit transaction 


return 0
GO
sp_procxmode EcnSanitizerInstCtrlStore , 'anymode' 
GO

/** One more proc **/

if exists (select 1 from sysobjects where name='EcnSpreadNewStore' and type='P')
begin
    drop procedure EcnSpreadNewStore
end
GO
create procedure EcnSpreadNewStore (
       @BrokerRef                     varchar(30),
       @InstrumentRef                 char(30),
       @BucketRef                     char(20),
       @Spread                        float,
       @Skew                          float,
       @Round                         float,
       @SpreadType                    char(2),
       @Version                       int,
       @ServerName                    varchar(30),
       @UpdaterRef                    varchar(32))
as
/** $Revision: 1.6 $ **/

declare @error    int,
        @rowcount int,
        @format   varchar(255)

select @error=0

begin transaction

  if exists (select 1 from EcnSpreadNew
             where BrokerRef=@BrokerRef
               and  InstrumentRef=@InstrumentRef
               and  BucketRef=@BucketRef
            )
  begin
    if (@Version = 0)
    begin
      select @Version = Version from EcnSpreadNew
      where BrokerRef=@BrokerRef
        and  InstrumentRef=@InstrumentRef
        and  BucketRef=@BucketRef
    end
    update EcnSpreadNew set
      Spread=@Spread,
      Skew=@Skew,
      Round=@Round,
      SpreadType=@SpreadType,
      Version=Version+1,
      RecordStatus='C',
      ServerName=@ServerName,
      UpdaterRef=@UpdaterRef,
      UpdateDatetime=getdate()
    where BrokerRef=@BrokerRef
      and  InstrumentRef=@InstrumentRef
      and  BucketRef=@BucketRef

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      rollback tran
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' BrokerRef=%4! InstrumentRef=%5! BucketRef=%6! Version=%7!'
      raiserror 29000 @format ,'EcnSpreadNewStore','update','EcnSpread',@BrokerRef,@InstrumentRef,@BucketRef,@Version
      return -1
    end
  end
  else
  begin
    select @Version = 1 

    insert into EcnSpreadNew (
      BrokerRef,
      InstrumentRef,
      BucketRef,
      Spread,
      Skew,
      Round,
      SpreadType,
      Version,
      RecordStatus,
      ServerName,
      CreatorRef,
      CreationDatetime,
      UpdaterRef,
      UpdateDatetime)
    values (
      @BrokerRef,
      @InstrumentRef,
      @BucketRef,
      @Spread,
      @Skew,
      @Round,
      @SpreadType,
      @Version,
      'C',
      @ServerName,
      @UpdaterRef,
      getdate(),
      @UpdaterRef,
      getdate())

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      rollback tran
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' BrokerRef=%4! InstrumentRef=%5! BucketRef=%6! Version=%7!'
      raiserror 29000 @format ,'EcnSpreadNewStore','insert','EcnSpread',@BrokerRef,@InstrumentRef,@BucketRef,@Version
      return -1
    end
  end
commit transaction


return 0
GO
sp_procxmode EcnSpreadNewStore , 'anymode' 
GO

/** Yet another one **/

--
-- $Id: appCreateLATAMCalcs.sql,v 1.18 2009/10/07 13:37:37 gallane Exp $
-- $Revision: 1.18 $
--

IF OBJECT_ID('dbo.appCreateLATAMCalcs') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.appCreateLATAMCalcs
    IF OBJECT_ID('dbo.appCreateLATAMCalcs') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.appCreateLATAMCalcs >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.appCreateLATAMCalcs >>>'
END
go

--
-- $Id: appCreateLATAMCalcs.sql,v 1.18 2009/10/07 13:37:37 gallane Exp $
-- $Revision: 1.18 $
--

create proc appCreateLATAMCalcs (
       @AliasName                  varchar(20),
       @SubTreeRef                 varchar(20),
       @NodeSetRef                 varchar(25),
       @Isin                       varchar(20),
       @DisplayName                varchar(255),
       @BondTicker                 varchar(20),
       @Coupon                     float,
       @AssociatedCurve            varchar(20),
       @BondCurveNodeRef           varchar(20),
       @ForwardRepoNodeRef		   varchar(20),
       @Master                     varchar(20), -- current master we will start with
       @IsOnRun                    int,
       @IncPosition                char(1) = 'Y',
       @Ccy						   char(3),
       @UserName                   varchar(20))
as

begin tran

  declare @DataSource varchar(20)
  declare @CalculatorId varchar(20)
  declare @error  int
  
  declare @TemplateId char(32)
  declare @DiscCurveId char(32) 
  declare @ProjCurveId char(32) 
  declare @BasisCrvId char(32)
  
  declare @PosNodeSetRef varchar(25)
 
  select  @TemplateId = 'LMLIBOR'+@Ccy
  select  @DiscCurveId = 'LMLIBOR_'+@Ccy
  select  @ProjCurveId = 'LMLIBOR_'+@Ccy
  
  select @PosNodeSetRef = 'LATAM'+@Ccy+'Position'

  exec SubTreeNodesStore @SubTreeRef, @Isin, 1, 'script', @UserName

  exec @error = appCreateInternalBondNode @NodeSetRef,@Isin,'manualPrice',0, 'script', @UserName, @SubTreeRef
  if (@error != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateLATAMCalcs:Error BondNodeStore'
    return -1
  end  
 
  -----------------------------------
  -- PriceYield Calculator
  -----------------------------------
  exec @error = appPriceYieldCalculator 
  					@BondNodeRef = @Isin , 
  					@SettlementDateOverride = '1-1-1900', 
  					@RiskFutureNodeRef = '',
  					@Version = 0, 
  					@ServerName = 'script', 
  					@UpdaterRef = @UserName   					
  if (@error != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateLATAMCalcs:Error appPriceYieldCalculator'
    return -1
  end
 
  -----------------------------------
  -- Ratings Calculator
  -----------------------------------
  exec @error = appRatingsDataCalcStore  @Isin, 'RatingsDataCalc',
                       '', '', '', 0, 'script', @UserName
  if (@error != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateLATAMCalcs:Error CreatePositionNodes'
    return -1
  end

 
  -----------------------------------
  -- BidAskManual Calculator
  -----------------------------------
  exec @error=  appBidAskManBondPriceCalcStore 
  					@BondNodeRef = @Isin, 
					@BidIsPrice = 'Y', 
  					@BidPriceOrYield = 1, 
  					@AskIsPrice = 'Y', 
				  	@AskPriceOrYield = 1, 
  					@Version = 0, 
  					@ServerName = 'script', 
  					@UpdaterRef = @UserName
  
  if (@error != 0)
  begin
     while @@trancount != 0 rollback
     raiserror 999999 'appCreateLATAMCalcs:Error appBidAskManBondPriceCalcStore'
     return -1
  end

  -----------------------------------
  -- BidAskSpread Calculator
  -----------------------------------  
  exec CalculatorStore @Isin, 'BidAskSpread', 'com.rbsfm.fi.pricing.dependency.bond.BidAskSpreadCalculator',  0, 'script', @UserName
  exec CalculatorAttributeStore @Isin, 'BidAskSpread', 'BidAskSpread', 'FLOAT', 0, 0, '1-1-1900', '', 0, 'script', @UserName
  exec CalculatorAttributeStore @Isin, 'BidAskSpread', 'IsOff', 'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', @UserName
  

  -----------------------------------
  -- Runs Calculator
  ----------------------------------- 
  exec @error = appRunsCalculatorStore
  					@BondNodeRef = @Isin,
  					@Version       = 1,
                    @ServerName  = 'script',
                    @UpdaterRef  = @UserName
  
  if (@error != 0)
  begin
     while @@trancount != 0 rollback
     raiserror 999999 'appCreateLATAMCalcs:Error appRunsCalculatorStore'
     return -1
  end 
  
  -----------------------------------
  -- CDSBasisCalc Calculator
  -----------------------------------    
  EXEC appCDSCurveCalcStore @Isin,'',0,1,'script',@UserName
   
  
  -----------------------------------
  -- ZSpread Calculator
  -----------------------------------    
  EXEC appCreateBidAskZSpreadCalc @Isin, '', @AssociatedCurve, @AssociatedCurve, 1, 'script',@UserName

  -----------------------------------
  -- BidAskYieldSpread Calculator
  -----------------------------------
  exec @error = appBidAskYieldSpreadCalcStore 
  						   @BondNodeRef = @Isin,
                           @BenchmarkId   = '', -- allow the user to select it
                           @MidBenchmarkSpread = 0.0,
                           @BidBenchmarkSpread = 0.0,
                           @AskBenchmarkSpread = 0.0,   
                           @BidPriceType = 'Bid',
					       @AskPriceType = 'Ask',                                                
                           @Version           = 1,
                           @ServerName     = 'script',
                           @UpdaterRef     = @UserName

  if (@error != 0)
  begin
     while @@trancount != 0 rollback
     raiserror 999999 'appCreateLATAMCalcs:Error appBidAskYieldSpreadCalcStore'
     return -1
  end  

  -----------------------------------
  -- BidAskYieldSpread Calculator for Sov. Benchamrks
  -----------------------------------
  exec @error = appBidAskYieldSpreadSCalcStore 
                           @BondNodeRef = @Isin,
                           @BenchmarkId   = '', -- allow the user to select it
                           @MidBenchmarkSpread = 0.0,
                           @BidBenchmarkSpread = 0.0,
                           @AskBenchmarkSpread = 0.0,   
                           @BidPriceType = 'Bid',
                           @AskPriceType = 'Ask',                                                
                           @Version           = 1,
                           @ServerName     = 'script',
                           @UpdaterRef     = @UserName

  if (@error != 0)
  begin
     while @@trancount != 0 rollback
     raiserror 999999 'appCreateLATAMCalcs:Error appBidAskYieldSpreadTCalcStore'
     return -1
  end  
  -----------------------------------
  -- BidAskAssetSwapSpread Calculator
  -----------------------------------
  exec @error =  appBidAskAssSwapSprdCalcStore 
  							@BondNodeRef = @Isin,
                         	@CurveID    = @AssociatedCurve,
                            @BidAssetSwapSpread = 0,
                            @AskAssetSwapSpread = 0,
                            @MidAssetSwapSpread = 0,                                                        
                            @Version     = 1,
                            @ServerName  = 'script',
                           	@UpdaterRef  = @UserName

  if (@error != 0)
  begin
     while @@trancount != 0 rollback
     raiserror 999999 'appCreateLATAMCalcs:Error appBidAskAssSwapSprdCalcStore'
     return -1
  end  

   
  -----------------------------------
  -- BidAskSwapSpread Calculator
  -----------------------------------
  exec @error = appCreateBASwapSpreadCalcStore 
  							@NodeSetRef = @Isin,
                       			@MidCurveNodeRef    = @AssociatedCurve,
                       			@BidCurveNodeRef    = @AssociatedCurve,
                       			@AskCurveNodeRef    = @AssociatedCurve,
                          	@TemplateRef = @TemplateId,
                          	@Spread      = 0 ,
                            @Version     = 1,
                           	@ServerName  = 'script',
                           	@UpdaterRef  = @UserName

  if (@error != 0)
  begin
     while @@trancount != 0 rollback
     raiserror 999999 'appCreateLATAMCalcs:Error appCreateBASwapSpreadCalcStore'
     return -1
  end  
  -----------------------------------
  -- appBondClose Calculator
  -----------------------------------
  exec @error = appBondCloseCalcStore @Isin, 0, 'script', @UserName, 'com.rbsfm.fi.pricing.dependency.bond.RatesBondCloseCalculator'

  if (@error != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateLATAMCalcs:Error appBondCloseCalcStore'
    return -1
  end

  -----------------------------------
  -- WhatIfPriceYield Calculator
  -----------------------------------
  exec @error = CalculatorStore @Isin, 'WhatIfPriceYieldCalculator', 'com.rbsfm.fi.pricing.dependency.bond.WhatIfPriceYieldCalculator', 1, 'script', @UserName
  if (@error != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateLATAMCalcs:Error CalculatorStore (WhatIfPriceYieldCalculator)'
    return -1
  end

  -----------------------------------
  -- BondUserData Calculator
  -----------------------------------
  exec @error = appBondUserDataStore @Isin, 0, 0, 0, 'script', @UserName
  if (@error != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateLATAMCalcs:Error appBondUserDataStore'
    return -1
  end
  
  -----------------------------------
  -- BondVsCurveCalculator 
  -----------------------------------  
  
if exists (select * from Node where NodeId = @BondCurveNodeRef)
begin  
  exec @error = appBidAskBondVsCurveCalcStore 
 					@BondNodeRef =  @Isin,
					@CurveId = @BondCurveNodeRef,
					@spread = 0,
					@Version     = 1,
                    @ServerName  = 'script',
                    @UpdaterRef  = @UserName	

  if (@error != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateLATAMCalcs:Error appBondVsCurveCalcStore'
    return -1
  end                    
end
  -----------------------------------
  -- GenericTimeStampAdjustmentCalculator
  -----------------------------------  
  exec @error = appAdjTimeCalcStore 
 					@BondNodeRef =  @Isin,
					@PriceType = 'Bid',
					@Version     = 1,
                    @ServerName  = 'script',
                    @UpdaterRef  = @UserName	
                    
  if (@error != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateLATAMCalcs:Error Bid appAdjTimeCalcStore'
    return -1
  end	                      
  
  exec @error = appAdjTimeCalcStore 
 					@BondNodeRef =  @Isin,
					@PriceType = 'Ask',
					@Version     = 1,
                    @ServerName  = 'script',
                    @UpdaterRef  = @UserName	
                    
  if (@error != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateLATAMCalcs:Error Ask appAdjTimeCalcStore'
    return -1
  end
  
  -----------------------------------
  -- IsInRunCalculator
  -----------------------------------  
  exec @error = CalculatorStore 
  					@NodeRef =@Isin, 
  					@CalculatorId = 'IsInRunCalculator', 
  					@JavaClass = 'com.rbsfm.fi.pricing.dependency.bond.IsInRunCalculator',
  					@Version     = 1,
                    @ServerName  = 'script',
                    @UpdaterRef  = @UserName

  if (@error != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateLATAMCalcs:Error IsInRunCalculator'
    return -1
  end   
  
  -----------------------------------
  -- WhatIfAxeCalculator
  -----------------------------------    
  exec @error = appCreateWIAxeCalcStore 
       				@BondNodeRef = @Isin,
			       	@CurveId = @AssociatedCurve,
			       	@bidSpread = 'NaN',
			       	@askSpread = 'NaN',
			       	@Version     = 1,
                    @ServerName  = 'script',
                    @UpdaterRef  = @UserName

  if (@error != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateLATAMCalcs:Error appCreateWIAxeCalcStore'
    return -1
  end                      
                    
  -----------------------------------
  -- WhatIfBidAskYieldSpreadCalculator
  -----------------------------------    
  exec @error = appWIBAYieldSpreadCalcStore 
       				@BondNodeRef   = @Isin,
       				@CurveId       = @AssociatedCurve,
      				@Version     = 1,
                    @ServerName  = 'script',
                    @UpdaterRef  = @UserName  
       
  if (@error != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateLATAMCalcs:Error appWIBAYieldSpreadCalcStore'
    return -1
  end                                              


  -----------------------------------
  -- Forward Price Calculator
  -----------------------------------
  exec @error =  appForwardPriceCalculator 
                             @BondNodeRef    = @Isin ,
							 @SettlementDate = '1-1-1900',
							 @RepoRate     = 0,
							 @FwdRepoNodeRef = @ForwardRepoNodeRef,
							 @CurveRef     = @AssociatedCurve,
                             @Version     = 1,
                           	 @ServerName  = 'script',
                           	 @UpdaterRef  = @UserName

  if (@error != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateLATAMCalcs:Error appForwardPriceCalculator'
    return -1
  end	
  
  ----------------------------------------------
  -- BidAskBestPriceMuxRealtimeCalculator 
  ----------------------------------------------
  exec @error =  appBidAskBestPxMuxRTCalcStore 
                             @BondNodeRef    = @Isin ,
                             @Version     = 1,
                             @ServerName  = 'script',
                             @UpdaterRef  = @UserName

  if (@error != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateLATAMCalcs:Error BidAskBestPriceMuxRealtimeCalculator'
    return -1
  end 

  
-- This needs to be uncommented for the non-USD currencies  
  ----------------------------------------------
  -- dollarASW CrossCcyAssetSwapSprdCalculator 
  ---------------------------------------------- 
--	select	@BasisCrvId = 'BasisCurve_'+@Ccy+'_USD'  
  
--  exec @error = appCrssCcyAsstSwpSprdCalc 
--  								@BondNodeRef = @Isin,
--  								@CalculatorId = 'dollarASW',
--		  							@TemplateId = @TemplateId,
--  								@DiscCurveId = @DiscCurveId,
--    								@ProjCurveId = @ProjCurveId,
--		    						@CrossCcyDiscCurveId ='LIBOR-HD_USD',
--    								@CrossCcyProjCurveId ='LIBOR-HD_USD',
--    								@CrossCcyTemplateId = 'USSB3',
--    								@Prefix = 'dollarASW', 
 --   								@BasisCrvId = @BasisCrvId,
--   								@BasisInterpCalcId = 'SpreadCurveCalc',
--                    @Version     = 1,
--                    @ServerName  = 'script',
--                    @UpdaterRef  = @UserName
--                           	
--
--  if (@error != 0)
--  begin
--     while @@trancount != 0 rollback
--     raiserror 999999 'appCreateLATAMCalcs:Error appCrssCcyAsstSwpSprdCalc -> dollarASW '
--     return -1
--  end  
	
  
--Uncomment in the future...  
  ----------------------------------------------
  -- euroASW CrossCcyAssetSwapSprdCalculator 
  ----------------------------------------------
-- 	select	@BasisCrvId = 'BasisCurve_'+@Ccy+'_EUR'  
--					  
--  exec @error = appCrssCcyAsstSwpSprdCalc 
--  									@BondNodeRef = @Isin,
--  									@CalculatorId = 'euroASW',
--		  							@TemplateId = @TemplateId,
--  									@DiscCurveId = @DiscCurveId,
--    								@ProjCurveId = @ProjCurveId,
--		    						@CrossCcyDiscCurveId ='6M_EUR',
--    								@CrossCcyProjCurveId ='6M_EUR',
--    								@CrossCcyTemplateId = '6MEUR',
--    								@Prefix = 'euroASW', 
--   								@BasisCrvId = @BasisCrvId,
--    								@BasisInterpCalcId = 'SpreadCurveCalc',
--                    @Version     = 1,
--                    @ServerName  = 'script',
--                    @UpdaterRef  = @UserName
                           	

--  if (@error != 0)
--  begin
--     while @@trancount != 0 rollback
--     raiserror 999999 'appCreateLATAMCalcs:Error appCrssCcyAsstSwpSprdCalc -> euroASW '
--     return -1
--  end  	

/*
  -----------------------------------
  -- BondVsFutsCalculator
  -----------------------------------
  exec @error =  appBondVsFutsCalcStore 
  					@BondNodeRef    = @Isin ,
  					@spread = 0
  					@Version     = 1,
                    @ServerName  = 'script',
                    @UpdaterRef  = @UserName
                    
  if (@error != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateLATAMCalcs:Error appBondVsFutsCalcStore'
    return -1
  end	                    
*/


  -----------------------------------
  -- Position Node
  -----------------------------------
  if (@IncPosition = 'Y')
  begin 	 
     exec @error = appCreateGenericPositionNode
        			@NodeSetRef=@PosNodeSetRef,
        			@NodeRef=@Isin,
        			@PortfolioId='Master',         			
        			@RiskPriceType='Mid',
        			@BenchmarkHedgePriceType='',
        			@FutureBarbellPriceType='',
        			@BenchmarkBarbellPriceType='',
        			@Cash4CashFwdRepoRef='',
        			@BarbellDateStrategy='maturity',
        			@Position = 0, 
        			@Axes = 0,
        			@Version=0,
        			@ServerName='script',
         			@UserName=@UserName

  if (@error != 0)
    begin
      while @@trancount != 0 rollback
      raiserror 999999 'appCreateLATAMCalcs:Error appCreatePositionNodes'
      return -1
    end
  end
  
  -----------------------------------
  -- Alias Node
  ----------------------------------- 
  if (@AliasName is not null And @AliasName != '')
  begin
     exec @error = appCreateAliasNode  @NodeSetRef , @AliasName , @Isin ,  0, 'script', @UserName
     Print 'Alias set to : %1!',@AliasName

  if (@error != 0)
     begin
        while @@trancount != 0 rollback
        raiserror 999999 'appCreateLATAMCalcs:Error AliasNode'
        return -1
     end
  end
  
  
  -----------------------------------
  -- set the current master
  -----------------------------------
  if (@Master<>'')
  begin
    update GenericNodeAttribute
    set ValueString=@Master, Version=Version+1
    where NodeRef=@Isin and AttributeName = 'CurrentMaster'
    Print 'Current master set to : %1!',@Master
  end


commit tran
go

EXEC sp_procxmode 'dbo.appCreateLATAMCalcs','anymode'
go

IF OBJECT_ID('dbo.appCreateLATAMCalcs') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.appCreateLATAMCalcs >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.appCreateLATAMCalcs >>>'
go

/** Another **/

--
-- $Id: appCreateLATAM.sql 24547 2009-11-02 11:48:19Z gallane $
-- $Revision: 24547 $
--

IF OBJECT_ID('dbo.appCreateLATAM') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.appCreateLATAM
    IF OBJECT_ID('dbo.appCreateLATAM') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.appCreateLATAM >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.appCreateLATAM >>>'
END
go


 create proc appCreateLATAM 
 (     
       @CorpOrSov                     varchar(10),
       @BondNodeRef                   varchar(20),
       @BondName                      varchar(30),
       @AliasName                     varchar(20)     =    '',
       @BondTicker                    varchar(20),
       @AssociatedCurve               varchar(20),
       @Coupon                        float,
       @MaturityDate                  datetime,
       @BondTypeRef                   varchar(30),       
       @Currency                      char(3), -- :NSM: is ignored
       @Country                       char(20),
       @CountryISO                    char(5),
       @BondCalcType                  varchar(255),
       @Series                        varchar(255),
       @IssueSize                     float          = 0.0,
       @FirstAccrualDate              datetime       = '01-Jan-1900',
       @FirstSettlementDate           datetime       = '01-Jan-1900',
       @FirstCouponAmount             float          = 0.0,
       @FirstCouponDate               datetime       = '01-Jan-1900',
       @LastCouponAmount              float          = 0.0,
       @LastCouponDate                datetime       = '01-Jan-1900',
       @RedemptionAmount              float          = 1,  
       @IsCodeISIN                    char(1)        = 'Y',            
       @IsOnRun                       int            = 0,
       @SubTreeRef                    varchar(20)    = 'ALL',
       @NodeSetRef                    varchar(25)    = null,
       @MarketIssue                   varchar(50)    = null,
       @LeadManager                   varchar(50)    = null,
       @Bearer                        varchar(50)    = null,
       @IndustryGroup                 varchar(50)    = null
       
 )
as

--
-- Variables
--
declare @Version          int
declare @ServerName       varchar(30)
declare @UpdaterRef       varchar(32)
declare @CalculatorId     char(20)
declare @BondId           char(20)
declare @PriceType        varchar(6)
-- :NSM: Pass this in now declare @NodeSetRef       varchar(25)
declare @PricingMethod    varchar(20)
declare @isBenchmark      char(1)
declare @userName         char(10)
declare @IsPerpetual      char(1)
declare @ReutersId        varchar(20)
declare @BloombergTicker  char(10)
declare @RIC              varchar(20)
declare @SuppressExternalPrice          char(1)
declare @ForwardRepoNode       char(10)


-- Variable defaults
--
select @RIC              = ''
select @Version          = 1
select @CalculatorId     = 'BondStaticCalc'
select @BondId           = @BondNodeRef
select @PriceType        = 'BidAsk'
-- :NSM: Passed in now --> select @NodeSetRef       = 'LATAMBond'
select @PricingMethod    = 'manualPrice'
select @isBenchmark      = 'Y'
select @userName         = ( select user_name() )
select @IsPerpetual      = 'N'
-- :NSM: select @RedemptionAmount =  1
-- :NSM: select @IsCodeISIN       = 'Y'
select @ReutersId        = @RIC
select @ServerName       = ( select @@servername )
select @UpdaterRef       = 'appCreateLATAM'
select @BloombergTicker  = ''
select @SuppressExternalPrice = ''
select @ForwardRepoNode = 'Fwd GC ' + @Currency

--
-- If the node set ref was not provided explicitly then
-- it should be created from the country ISO code
--
if ( @NodeSetRef is null )
begin
    select @NodeSetRef = 'LATAM_' + rtrim(@CountryISO) + '_' + @CorpOrSov
end    

--
-- return code checks etc.
--
declare @error                 int

--
-- We take the @Version value by incrementing what's already
-- in the database - if this is the first time we've created
-- something then we set the value to 0

select @Version =      (select Version from CalculatorAttribute where NodeRef =  @BondNodeRef
                        and CalculatorId = 'BondStaticCalc' and AttributeName = 'BondName' )

if @Version is null
begin
    select @Version = 0
end
else
begin
    select @Version = @Version + 1
end


--
-- create the static calculator attributes first and then
-- the actual bond node
--

if ( @BloombergTicker = '' )
begin
  select @BloombergTicker = @BondTicker
end

begin tran

Print ' '
Print 'Populating CalculatorAttributes for static data'

exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'BondId',                'STRING',   0, 0, '1-1-1900', @BondId, @Version , @ServerName, @UpdaterRef
Print 'id %1!',@BondId
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'BondName',              'STRING',   0, 0, '1-1-1900', @BondName, @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'BondTypeRef',           'STRING',   0, 0, '1-1-1900', @BondTypeRef, @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'Coupon',                'FLOAT',    0, @Coupon, '1-1-1900', '', @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'IsPerpetual',           'STRING',   0, 0, '1-1-1900', @IsPerpetual, @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'MaturityDate',          'DATETIME', 0, 0, @MaturityDate, '', @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'FirstSettlementDate',   'DATETIME', 0, 0, @FirstSettlementDate, '', @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'RedemptionAmount',      'FLOAT',    0, @RedemptionAmount, '', '', @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'IsCodeISIN',            'STRING',   0, 0, '1-1-1900', @IsCodeISIN, @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'BloombergTicker',       'STRING',   0, 0, '1-1-1900', @BloombergTicker, @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'IssueSize',             'FLOAT',    0, @IssueSize, '1-1-1900', '', @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'Country',               'STRING',   0, 0, '1-1-1900', @Country, @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'CountryISO',            'STRING',   0, 0, '1-1-1900', @CountryISO, @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'RIC',                   'STRING',   0, 0, '1-1-1900', '', @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'SuppressExternalPrice', 'STRING',   0, 0, '1-1-1900', @SuppressExternalPrice, @Version , @ServerName, @UpdaterRef
-- :NSM: Added BondCalcType
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'BondCalcType',          'STRING',   0, 0, '1-1-1900', @BondCalcType, @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'Currency',              'STRING',   0, 0, '1-1-1900', @Currency, @Version , @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'Series',                'STRING',   0, 0, '1-1-1900', @Series, @Version, @ServerName, @UpdaterRef

if (@Coupon != 0)
begin 
	exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'FirstAccrualDate',      'DATETIME', 0, 0, @FirstAccrualDate, '', @Version , @ServerName, @UpdaterRef
	exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'FirstCouponDate',       'DATETIME', 0, 0, @FirstCouponDate, '', @Version , @ServerName, @UpdaterRef
	exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'FirstCouponAmount',     'FLOAT',    0, @FirstCouponAmount, '', '', @Version , @ServerName, @UpdaterRef
	exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'LastCouponDate',        'DATETIME', 0, 0, @LastCouponDate, '', @Version , @ServerName, @UpdaterRef
	exec CalculatorAttributeStore @BondNodeRef, @CalculatorId, 'LastCouponAmount',      'FLOAT',    0, @LastCouponAmount, '', '', @Version , @ServerName, @UpdaterRef
end

exec CalculatorAttributeStore @BondNodeRef, 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', @MarketIssue, 0, 'script', 'script'
exec CalculatorAttributeStore @BondNodeRef, 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', @LeadManager, 0, 'script', 'script'
exec CalculatorAttributeStore @BondNodeRef, 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', @Bearer,  0, 'script', 'script'
exec CalculatorAttributeStore @BondNodeRef, 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', @IndustryGroup, 0, 'script', 'script'

exec CalculatorStore @BondNodeRef, @CalculatorId, 'com.rbsfm.fi.pricing.dependency.bond.BondStaticCalculator', @Version , @ServerName, @UpdaterRef

Print 'CalculatorAttributes populated ok for LATAM'

declare @BondCurveNodeRef varchar(20)
select @BondCurveNodeRef = 'BondCurve_' + @Currency + 'BondCur'

-- create the calculators for this bond
exec @error =  appCreateLATAMCalcs        @AliasName   = @AliasName,
                                        @SubTreeRef  = @SubTreeRef,
                                        @NodeSetRef  = @NodeSetRef,
                                        @Isin        = @BondNodeRef,
                                        @DisplayName = @BondName,
                                        @BondTicker      = @BondTicker ,
                                        @Coupon=@Coupon,
                                        @AssociatedCurve = @AssociatedCurve,
                                        @BondCurveNodeRef = @BondCurveNodeRef,
                                        @ForwardRepoNodeRef = @ForwardRepoNode,
                                        @Master      = 'manualPrice',
                                        @IsOnRun     = 0 ,
                                        @IncPosition = 'Y',
                                        @Ccy = @Currency,
                                        @UserName    = @userName

if (@error != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateLATAMCalcs:Error appCreateLATAMCalcs'
    return -1
  end


Print 'Calculators created for LATAM'

commit tran

Print 'LATAM bond successfully created %1! [ %2! ] ' , @BondNodeRef , @BondName



go
EXEC sp_procxmode 'dbo.appCreateLATAM','anymode'
go
IF OBJECT_ID('dbo.appCreateLATAM') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.appCreateLATAM >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.appCreateLATAM >>>'
go


/** Another proc **/

if exists (select 1 from sysobjects where name='appEcnCreateBond' and type='P')
begin
  drop procedure appEcnCreateBond
  IF OBJECT_ID('dbo.appEcnCreateBond') IS NOT NULL
      PRINT '<<< FAILED DROPPING PROCEDURE dbo.appEcnCreateBond >>>'
  ELSE
      PRINT '<<< DROPPED PROCEDURE dbo.appEcnCreateBond >>>'    
end
go

create proc appEcnCreateBond
       @InstrumentRef char(30),

       @BloombergCloseChainId varchar(30) = '',
       @BloombergCloseSpread float = 0.0,
       @BloombergCloseSpreadType char(2) = 'MP',

       @BloombergChainId varchar(30) = '',
       @BloombergSpread float = 0.0,
       @BloombergSize float = 0.0,
       @BloombergSpreadType char(2) = 'MP',

       @ReutersChainId varchar(30) = '',
       @ReutersSpread float = 0.0,
       @ReutersSpreadType char(2) = 'MP',

       @ProposalMarket varchar(30) = '',
       @ProposalSpread float = 0.0004,
       @ProposalSize float = 5000000,
       @ProposalRound float = 0.0001,
       @ProposalSpreadType char(2) = 'MP',

       @ReutersCode varchar(30) = '',
       
       @QuoteOnESpeed int = 0,
       @QuoteOnBrokerTec int = 0,    
       @QuoteOnHDAT int = 0, 
       
       @BloombergRound float = 0.0001   
       
as
/** $Revision: 1.3 $ **/
begin transaction
  declare @error         int
  
  if (@BloombergCloseChainId != '')
  begin
      exec @error = appEcnCreateQuoteNew 'BBClose', @InstrumentRef, 'B0', 0, 0, @BloombergCloseSpread, 0.0, 0.000001, @BloombergCloseChainId, @BloombergCloseSpreadType
      if (@error != 0)
      begin
        while @@trancount != 0 rollback
        raiserror 999999 'CreateEcnQuote:Error Bloomberg Close'
        return -1
      end
   end

  if (@BloombergChainId != '')
  begin
      exec @error = appEcnCreateQuoteNew 'AQ Orders', @InstrumentRef, 'B0', @BloombergSize, 0, @BloombergSpread, 0.0, @BloombergRound, @BloombergChainId, @BloombergSpreadType
      if (@error != 0)
      begin
        while @@trancount != 0 rollback
        raiserror 999999 'CreateEcnQuote:Error Bloomberg'
        return -1
      end

			/* only setup 1 tier/bucket */
			/* ok, we need a few more for testing */
			exec @error = appEcnCreateQuoteNew 'AQT2', @InstrumentRef, 'B1', @BloombergSize, 0, @BloombergSpread, 0.0, 0.00001, '', @BloombergSpreadType
			exec @error = appEcnCreateQuoteNew 'AQT2', @InstrumentRef, 'B2', @BloombergSize, 0, @BloombergSpread, 0.0, 0.00001, '', @BloombergSpreadType
			exec @error = appEcnCreateQuoteNew 'AQT2', @InstrumentRef, 'B3', @BloombergSize, 0, @BloombergSpread, 0.0, 0.00001, '', @BloombergSpreadType

      exec @error = EcnInstCtrlStore 'ECNDATA', @InstrumentRef, 'RepoT0', '', 0, 'script', 'script'
      exec @error = EcnInstCtrlStore 'ECNDATA', @InstrumentRef, 'RepoT1', '', 0, 'script', 'script'
      exec @error = EcnInstCtrlStore 'ECNDATA', @InstrumentRef, 'RepoT2', '', 0, 'script', 'script'
      exec @error = EcnInstCtrlStore 'ECNDATA', @InstrumentRef, 'RepoT3', '', 0, 'script', 'script'
      exec @error = EcnInstCtrlStore 'ECNDATA', @InstrumentRef, 'RepoT4', '', 0, 'script', 'script'
      exec @error = EcnInstCtrlStore 'ECNDATA', @InstrumentRef, 'RepoT5', '', 0, 'script', 'script'
      exec @error = EcnInstCtrlStore 'ECNDATA', @InstrumentRef, 'RepoT6', '', 0, 'script', 'script'
      exec @error = EcnInstCtrlStore 'ECNDATA', @InstrumentRef, 'RepoT7', '', 0, 'script', 'script'

      /** TODO here the firm value is '' **/
      exec EcnInstrumentStatusStore 'AQ', @InstrumentRef, 'script', 500000, 500000, 0, 0, 2, 0, 15, 'OFF', 'OFF', 'OFF', null,'',  0, 'script', 'script'
   end
   
  if ((@BloombergChainId != '') OR (@ProposalMarket != '') OR (@QuoteOnESpeed = 1) OR (@QuoteOnBrokerTec = 1) OR (@QuoteOnHDAT = 1))
  begin
      exec @error = appCreateFeedCtrls 'AQ Orders', @InstrumentRef
      if (@error != 0)
      begin
        while @@trancount != 0 rollback
        raiserror 999999 'CreateFeedControls:Error'
        return -1
      end
  end

  if (@ReutersChainId != '')
  begin
      exec @error = appEcnCreateQuoteNew 'Reuters', @InstrumentRef, 'B0', 0, 0, @ReutersSpread, 0, 0.00001, @ReutersChainId, @ReutersSpreadType
      if (@error != 0)
      begin
        while @@trancount != 0 rollback
        raiserror 999999 'CreateEcnQuote:Error Reuters'
        return -1
      end
  end

  if (@ProposalMarket != '')
  begin
      exec @error = appEcnCreateQuoteNew @ProposalMarket, @InstrumentRef, 'B0', @ProposalSize, @ProposalSize, @ProposalSpread, 0.0, @ProposalRound, 'LINK1', @ProposalSpreadType
      if (@error != 0)
      begin
        while @@trancount != 0 rollback
        raiserror 999999 'CreateEcnQuote:Error @ProposalMarket'
        return -1
      end

      exec @error = EcnAllocationStore @ProposalMarket, @InstrumentRef, @ProposalSpread, @ProposalSize, 0, '1-Jan-1970', 0, 'script', 'script'
      if (@error != 0)
      begin
        while @@trancount != 0 rollback
        raiserror 999999 'CreateEcnAllocation:Error @ProposalMarket'
        return -1
      end
  end
  
  if (@QuoteOnESpeed = 1)
  begin
      exec appEcnQuoteBond @InstrumentRef,'ESPD',@ProposalSpread,@ProposalSize,@ProposalRound,@ProposalSpreadType    
  end
       
  if (@QuoteOnBrokerTec = 1)
  begin
      exec appEcnQuoteBond @InstrumentRef,'BTEC',@ProposalSpread,@ProposalSize,@ProposalRound,@ProposalSpreadType    
  end
              
  if (@QuoteOnHDAT = 1)
  begin
      exec appEcnQuoteBond @InstrumentRef,'HDAT',@ProposalSpread,@ProposalSize,@ProposalRound,@ProposalSpreadType    
  end
  
  exec EcnInstrumentMappingStore @InstrumentRef, 'IonVM', 'MktDepth', @InstrumentRef,  0, 'script', 'script'
  if (@error != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'CreateEcnQuote:Error EcnInstrumentMapping IonVM'
    return -1
  end

  if (@ReutersCode != '')
  begin
    exec EcnInstrumentMappingStore @InstrumentRef, 'Reuters', 'BestPrice', @ReutersCode,  0, 'script', 'script'
    if (@error != 0)
    begin
      while @@trancount != 0 rollback
      raiserror 999999 'CreateEcnQuote:Error EcnInstrumentMapping Reuters'
      return -1
    end
  end    

  commit transaction

  return 0
go
IF OBJECT_ID('dbo.appEcnCreateBond') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.appEcnCreateBond >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.appEcnCreateBond >>>'
go
EXEC sp_procxmode 'dbo.appEcnCreateBond','anymode'
go

/** Final proc **/

--
-- $Id: appLATAMEcnCreateBond.sql 24508 2009-10-30 11:15:49Z gallane $
-- $Revision: 24508 $
--

if exists (select 1 from sysobjects where name='appLATAMEcnCreateBond' and type='P')

begin

drop procedure appLATAMEcnCreateBond
  IF OBJECT_ID('dbo.appLATAMEcnCreateBond') IS NOT NULL
      PRINT '<<< FAILED DROPPING PROCEDURE dbo.appLATAMEcnCreateBond >>>'
  ELSE
      PRINT '<<< DROPPED PROCEDURE dbo.appLATAMEcnCreateBond >>>'  
end

go

create proc appLATAMEcnCreateBond

@InstrumentRef char(30),
@Cusip char(30) = '',
@BloombergSpread float = 0,
@BloombergSize float = 0,
@SpreadType char(2) = 'SP'

as


declare @error int
declare @ccy char(3)
declare @NodeSetRef char(25)
declare @BloombergChainId varchar(30)

select @error = 0


select @ccy = ValueString, @NodeSetRef = Node.NodeSetRef
from CalculatorAttribute join Node on CalculatorAttribute.NodeRef = Node.NodeId
where CalculatorId = 'BondStaticCalc'
and AttributeName = 'Currency'
and NodeRef = @InstrumentRef
and CalculatorAttribute.RecordStatus = 'C'
 

-- Determine BloombergChainId (BrokerRef'AQOrders')
print 'Attempting to determine @BloombergChainId'
select @BloombergChainId = ''
if (@ccy = 'USD')
	if (@NodeSetRef in ('LATAM_BR_Sov'))
		select @BloombergChainId = 'BrSov'
	else if (@NodeSetRef in ('LATAM_MX_Sov', 'LATAM_EC_Sov'))
		select @BloombergChainId = 'EcMxSov'
	else if (@NodeSetRef in ('LATAM_PE_Sov', 'LATAM_VE_Sov'))
		select @BloombergChainId = 'PeVeSov'
	else if (@NodeSetRef in ('LATAM_AR_Sov', 'LATAM_PA_Sov'))
		select @BloombergChainId = 'ArPaSov'
	else if (@NodeSetRef in ('LATAM_CL_Sov', 'LATAM_CO_Sov', 'LATAM_CO_Sov'))
			select @BloombergChainId = 'ClCoUySov'
	else if (@NodeSetRef in 
		('LATAM_AR_Corp', 'LATAM_BM_Corp', 'LATAM_BR_Corp', 'LATAM_BS_Corp', 'LATAM_CL_Corp', 'LATAM_CO_Corp',         
 		 'LATAM_DO_Corp', 'LATAM_JM_Corp', 'LATAM_MX_Corp', 'LATAM_PA_Corp', 'LATAM_PE_Corp', 'LATAM_SV_Corp',         
 		 'LATAM_TT_Corp', 'LATAM_US_Corp', 'LATAM_VE_Corp'))
		select @BloombergChainId = 'USDCorp'		
	else
        BEGIN
        print 'Unable to determine @BloombergChainId, ccy=[%1!] and NodeSetRef=[%2!]. Using Dummy chain', @ccy, @NodeSetRef
        select @BloombergChainId = 'LINK1'
        END

else if (@ccy = 'EUR')
	if (@NodeSetRef in 
		('LATAM_AR_Sov', 'LATAM_BB_Sov', 'LATAM_BR_Sov', 'LATAM_BZ_Sov', 'LATAM_CO_Sov', 'LATAM_CR_Sov',  
 		 'LATAM_DO_Sov', 'LATAM_EC_Sov', 'LATAM_GT_Sov', 'LATAM_JM_Sov', 'LATAM_MX_Sov', 'LATAM_PA_Sov',  
 		 'LATAM_PE_Sov', 'LATAM_SV_Sov', 'LATAM_UY_Sov', 'LATAM_VE_Sov'))
		select @BloombergChainId = 'EurSov'
	else if (@NodeSetRef in 
		('LATAM_AR_Corp', 'LATAM_BM_Corp', 'LATAM_BR_Corp', 'LATAM_BS_Corp', 'LATAM_CL_Corp', 'LATAM_CO_Corp', 
 		 'LATAM_DO_Corp', 'LATAM_JM_Corp', 'LATAM_MX_Corp', 'LATAM_PA_Corp', 'LATAM_PE_Corp', 'LATAM_SV_Corp', 
 		 'LATAM_TT_Corp', 'LATAM_US_Corp', 'LATAM_VE_Corp'))
		select @BloombergChainId = 'EurCorp'		
	else
        BEGIN
        print 'Unable to determine @BloombergChainId, ccy=[%1!] and NodeSetRef=[%2!]. Using Dummy chain', @ccy, @NodeSetRef
        select @BloombergChainId = 'LINK1'
        END
else
        BEGIN
        print 'Unable to determine @BloombergChainId, ccy=[%1!] and NodeSetRef=[%2!]. Using Dummy chain', @ccy, @NodeSetRef
        select @BloombergChainId = 'LINK1'
        END
	
----------------------------------------------------------------------

-- Call appEcnCreateBond to setup generic ECn tables

----------------------------------------------------------------------
begin transaction

exec appEcnCreateBond

@InstrumentRef = @InstrumentRef,

@BloombergCloseChainId = 'BBGCEUR',

@BloombergCloseSpread = 0.0, 

@BloombergChainId = @BloombergChainId,

@BloombergSpread = @BloombergSpread, 

@BloombergSpreadType = @SpreadType, --always

@BloombergSize = @BloombergSize, --always

@ReutersChainId = '', 

@ProposalMarket = '', -- 'MTS' for MTS quoting, '' otherwise. (FINANCIALS: No MTS)

@ProposalSpread = 0.0000, --Should always be 0

@ProposalSpreadType = @SpreadType,

@ProposalSize = 5000000, --for example

@ProposalRound = 0.0001, --normally

@ReutersCode = '',--always blank as best price is done in fi_exchange_live DB now

--@IsCovered = 'N', -- (supras) / 'Y' (covered)

@QuoteOnESpeed = 0, --Set to 1 if you want to quote on Espeed

@QuoteOnBrokerTec = 0, --Set to 1 if you want to quote on BrokerTec

@BloombergRound = 0.0001

if (@error != 0)

begin

while @@trancount != 0 rollback

raiserror 999999 'appLATAMEcnCreateBond:Error calling appEcnCreateBond'

return -1

end 

----------------------------------------------------------------------

-- Update Tier sizes

----------------------------------------------------------------------

update EcnQuoteNew
set Size = 250000, Version=Version+1
where BucketRef = 'B1'
and BrokerRef = 'AQT2'
and InstrumentRef = @InstrumentRef

update EcnQuoteNew
set Size = 1000000, Version=Version+1
where BucketRef = 'B2'
and BrokerRef = 'AQT2'
and InstrumentRef = @InstrumentRef

update EcnQuoteNew
set Size = 0, Version=Version+1
where BucketRef = 'B3'
and BrokerRef = 'AQT2'
and InstrumentRef = @InstrumentRef

----------------------------------------------------------------------

-- Populate EcnInstrumentSub for betgateway subscriptions

----------------------------------------------------------------------


exec EcnInstrumentSubStore 'AQ', @InstrumentRef, 'ON', 0, 'script', 'dataload'

if (@error != 0)

begin

while @@trancount != 0 rollback

raiserror 999999 'appLATAMEcnCreateBond:Error calling EcnInstrumentSubStore'

return -1

end 

----------------------------------------------------------------------

-- Populate EcnQUoteNew and EcnSpreadNew for Closes

---------------------------------------------------------------------- 

exec @error = appEcnCreateQuoteNew 'BBClose', @InstrumentRef, 'B0', 0, 0, 0, 0.0, 0.000001, 'BBGCEUR', 'MP'

if (@error != 0)

begin

while @@trancount != 0 rollback

raiserror 999999 'CreateEcnQuote:Error Bloomberg Close'

return -1

end

----------------------------------------------------------------------

-- Populate EcnInstrumentMappingStore for cusip mappings

----------------------------------------------------------------------


exec EcnInstrumentMappingStore @InstrumentRef, 'Bloomberg', 'AutoQuoter', @Cusip, 1, 'script', 'script'

exec EcnInstrumentMappingStore @InstrumentRef, 'MarketAxess', 'AutoQuoter', @InstrumentRef, 1, 'script', 'script'

if (@error != 0)

begin

while @@trancount != 0 rollback

raiserror 999999 'appLATAMEcnCreateBond:Error calling EcnInstrumentMappingStore'

return -1

end 




----------------------------------------------------------------------

-- Populate EcnInstrumentSub for market depth subscriptions

---------------------------------------------------------------------- 

exec EcnInstrumentSubStore 'MarketDepth.Bond', @InstrumentRef, 'ON', 0, 'script' , 'mahavin' --*New exchange data requirement to get best prices in CP*

if (@error != 0)

begin

while @@trancount != 0 rollback

raiserror 999999 'appLATAMEcnCreateBond:Error calling EcnInstrumentSubStoremb'

return -1

end 

----------------------------------------------------------------------

-- Populate EcnSanitizerInstCtrl for market axess publication

---------------------------------------------------------------------- 

exec EcnSanitizerInstCtrlStore 'AQ Orders', @InstrumentRef, 'maPrcPub', 'ON', 1, 'script', 'script'

if (@error != 0)

begin

while @@trancount != 0 rollback

raiserror 999999 'appLATAMEcnCreateBond:Error calling EcnSanitizerInstCtrl'

return -1

end 

commit transaction

return 0

go

IF OBJECT_ID('dbo.appLATAMEcnCreateBond') IS NOT NULL

PRINT '<<< CREATED PROCEDURE dbo.appLATAMEcnCreateBond >>>'

ELSE

PRINT '<<< FAILED CREATING PROCEDURE dbo.appLATAMEcnCreateBond >>>'

go

EXEC sp_procxmode 'dbo.appLATAMEcnCreateBond','anymode'

go

/** Additional entry in GenericNodeStore **/

if exists (select 1 from sysobjects where name='GenericNodeStore' and type='P')
begin
  drop procedure GenericNodeStore
end
go
 
 
 
create procedure GenericNodeStore (
       @NodeSetRef                    char(25),
       @DisplayName                   varchar(255),
       @ExternalCode                  varchar(32),
       @NodeRef                       varchar(255),
       @JavaClass                     varchar(255),
       @Owner                         varchar(32) = NULL,
       @ClockPeriod                    int = 1,
       @Version                       int,
       @ServerName                    varchar(30),
       @UpdaterRef                    varchar(32),
       @SubTreeRef                    char(20) = 'ALL')
as
/** $Revision: 1.10 $ **/

declare @error    int,
        @rowcount int,
        @format   varchar(255)

select @error=0

begin transaction


  exec @error = NodeStore
                 @NodeId       = @NodeRef,
                 @NodeSetRef   = @NodeSetRef,
                 @NodeType     = 'GenericNode',
                 @DisplayName  = @DisplayName,
                 @ExternalCode = @ExternalCode,
                 @Owner        = @Owner,
                 @ClockPeriod   = @ClockPeriod,
                 @ServerName   = @ServerName,
                 @Version      = @Version,
                 @UpdaterRef   = @UpdaterRef,
                 @SubTreeRef   = @SubTreeRef
  if (@error != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 "Error on exec of NodeStore"
    return -1
  end

  if exists (select 1 from GenericNode
             where NodeRef=@NodeRef
            )
  begin
    if (@Version = 0)
    begin
      select @Version = Version from GenericNode
      where NodeRef=@NodeRef
    end
    update GenericNode set
      JavaClass=@JavaClass,
      Version=Version+1,
      RecordStatus='C',
      ServerName=@ServerName,
      UpdaterRef=@UpdaterRef,
      UpdateDatetime=getdate()
    where NodeRef=@NodeRef

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      while @@trancount != 0 rollback
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' NodeRef=%4! Version=%5!'
      raiserror 29000 @format ,'GenericNodeStore','update','GenericNode',@NodeRef,@Version
      return -1
    end
  end
  else
  begin
    select @Version = 1 

    insert into GenericNode (
      NodeRef,
      JavaClass,
      Version,
      RecordStatus,
      ServerName,
      CreatorRef,
      CreationDatetime,
      UpdaterRef,
      UpdateDatetime)
    values (
      @NodeRef,
      @JavaClass,
      @Version,
      'C',
      @ServerName,
      @UpdaterRef,
      getdate(),
      @UpdaterRef,
      getdate())

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      while @@trancount != 0 rollback
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' NodeRef=%4! Version=%5!'
      raiserror 29000 @format ,'GenericNodeStore','insert','GenericNode',@NodeRef,@Version
      return -1
    end
  end
commit transaction

-- select NodeRef,
--        Version,
--        CreatorRef,
--        CreationDatetime,
--        UpdaterRef,
--        UpdateDatetime
-- from GenericNode
-- where NodeRef=@NodeRef


return 0
go
sp_procxmode GenericNodeStore , 'anymode' 
go

/** Add clock period to node store **/

if exists (select 1 from sysobjects where name='NodeStore' and type='P')
begin
  drop procedure NodeStore
end
GO
 
create procedure NodeStore (
       @NodeSetRef                    char(25),
       @NodeId                        varchar(255),
       @NodeType                      char(20),
       @DisplayName                   varchar(255),
       @ExternalCode                  char(32),
       @Owner                         varchar(32) = NULL,
       @ClockPeriod                  int = 1,
       @Version                       int,
       @ServerName                    varchar(30),
       @UpdaterRef                    varchar(32),
       @SubTreeRef                    char(20) = 'ALL')
as
/** $Revision: 1.15 $ **/

declare @error    int,
        @rowcount int,
        @format   varchar(255)

select @error=0

if not exists (select 1 from NodeSet where NodeSetId=@NodeSetRef)
begin
    raiserror 21000 ,'NodeStore','NodeSet','@NodeSetRef',@NodeSetRef
    select @error=-1
end

if (@error != 0) return -1

begin transaction

  if exists (select 1 from Node
             where NodeId=@NodeId
            )
  begin
    if (@Version = 0)
    begin
      select @Version = Version from Node
      where NodeId=@NodeId
    end
    update Node set
      NodeSetRef=@NodeSetRef,
      NodeType=@NodeType,
      DisplayName=@DisplayName,
      ExternalCode=@ExternalCode,
      Owner=isnull(@Owner, @UpdaterRef),
      ClockPeriod = @ClockPeriod,
      Version=Version+1,
      RecordStatus='C',
      ServerName=@ServerName,
      UpdaterRef=@UpdaterRef,
      UpdateDatetime=getdate()
    where NodeId=@NodeId

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      while @@trancount != 0 rollback
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' NodeId=%4! Version=%5!'
      raiserror 29000 @format ,'NodeStore','update','Node',@NodeId,@Version
      return -1
    end
    exec @error = SubTreeNodesStore @SubTreeRef = @SubTreeRef,
                                    @NodeRef    = @NodeId, 
                                    @Version    = 0, 
                                    @ServerName = @ServerName, 
                                    @UpdaterRef = @UpdaterRef
    if (@error != 0)
    begin
      while @@trancount != 0 rollback
      raiserror 999999 'Error on exec of SubTreeNodesStore'
      return -1
    end
  end
  else
  begin
    select @Version = 1

    insert into Node (
      NodeSetRef,
      NodeId,
      NodeType,
      DisplayName,
      ExternalCode,
      Owner,
      ClockPeriod,
      Version,
      RecordStatus,
      ServerName,
      CreatorRef,
      CreationDatetime,
      UpdaterRef,
      UpdateDatetime)
    values (
      @NodeSetRef,
      @NodeId,
      @NodeType,
      @DisplayName,
      @ExternalCode,
      @UpdaterRef,
      @ClockPeriod,
      @Version,
      'C',
      @ServerName,
      @UpdaterRef,
      getdate(),
      @UpdaterRef,
      getdate())

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      while @@trancount != 0 rollback
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' NodeId=%4! Version=%5!'
      raiserror 29000 @format ,'NodeStore','insert','Node',@NodeId,@Version
      return -1
    end

    exec @error = SubTreeNodesStore @SubTreeRef = @SubTreeRef,
                                    @NodeRef    = @NodeId, 
                                    @Version    = 0, 
                                    @ServerName = @ServerName, 
                                    @UpdaterRef = @UpdaterRef
    if (@error != 0)
    begin
      while @@trancount != 0 rollback
      raiserror 999999 'Error on exec of SubTreeNodesStore'
      return -1
    end
  end
commit transaction

-- select NodeSetRef,
--        NodeId,
--        Version,
--        CreatorRef,
--        CreationDatetime,
--        UpdaterRef,
--        UpdateDatetime
-- from Node
-- where NodeId=@NodeId


return 0
GO
sp_procxmode NodeStore , 'anymode' 
GO

/** Node trigger update **/

f exists (select 1 from sysobjects where name='Node_TR' and type='TR')
begin
  drop trigger Node_TR
end
go
 
create trigger Node_TR
on Node
for insert, update as
  insert NodeAudit(
    NodeSetRef,
    NodeId,
    NodeType,
    DisplayName,
    ExternalCode,
    Owner,
    ClockPeriod,
    Version,
    RecordStatus,
    ServerName,
    CreatorRef,
    CreationDatetime,
    UpdaterRef,
    UpdateDatetime)
  select
    NodeSetRef,
    NodeId,
    NodeType,
    DisplayName,
    ExternalCode,
    Owner,
    ClockPeriod,
    Version,
    RecordStatus,
    ServerName,
    CreatorRef,
    CreationDatetime,
    UpdaterRef,
    UpdateDatetime
  from inserted

  if (@@rowcount = 1)
  begin

    declare @RowModificationId int,
            @type             char(10)
    
    select @type = "UPDATE"
    select @type = "INSERT" from inserted where Version = 1
    select @type = "DELETE" from inserted where RecordStatus = "D"
    --
    -- Only log RowModification if Owner column changed and then imitate specific Node table update
    --
    if ((@type = "UPDATE") and exists (select 1 from inserted i, deleted d where i.Owner != d.Owner))
    begin
      if exists (select 1 from RowModificationKey)
      begin
        update RowModificationKey set NextId=NextId+1
      end
      else
      begin
        insert RowModificationKey values (1)
      end
  
      select @RowModificationId = NextId
      from RowModificationKey
  
      insert RowModification (
        RowModificationId,
        ModificationDateTime,
        ServerName,
        TableName,
        ModificationType,
        Key1,
        Key2,
        Key3,
        Key4,
        Version)
      select @RowModificationId,
             UpdateDatetime,
             ServerName,
             NodeType,
             @type,
             NodeId,
             "",
             "",
             "",
             Version
      from inserted
    end
  end
go

/** Move the bonds live **/

--
-- $Id: appMoveLiveLATAMBond.sql,v 1.3 2009/09/23 11:05:22 turnese Exp $
-- $Revision: 1.3 $
--

IF OBJECT_ID('dbo.appMoveLiveLATAMBond') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.appMoveLiveLATAMBond
    IF OBJECT_ID('dbo.appMoveLiveLATAMBond') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.appMoveLiveLATAMBond >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.appMoveLiveLATAMBond >>>'
END
go
create proc appMoveLiveLATAMBond ( 
	@BondNodeRef varchar(255),
	@NodeSetRef varchar(25)
)
as
 
begin transaction

update Node set NodeSetRef = @NodeSetRef, Version = Version + 1 where NodeId = @BondNodeRef 
update SubTreeNodes set SubTreeRef = 'ALL', Version = Version + 1 where NodeRef = @BondNodeRef

commit transaction
go

EXEC sp_procxmode 'dbo.appMoveLiveLATAMBond','anymode'
go
IF OBJECT_ID('dbo.appMoveLiveLATAMBond') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.appMoveLiveLATAMBond >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.appMoveLiveLATAMBond >>>'
go

/** Fix the stored proc **/

IF OBJECT_ID('dbo.ScheduleStore') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.ScheduleStore
    IF OBJECT_ID('dbo.ScheduleStore') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.ScheduleStore >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.ScheduleStore >>>'
END
go

create procedure ScheduleStore (
       @Id                   	varchar(64),
       @Type                 	varchar(16),
       @Date                 	datetime,
       @Amount               	numeric(16,8),
       @Version                 int,
       @ServerName              varchar(30),
       @UpdaterRef              varchar(32))
as
/** $Revision: 1.3 $ **/

declare @error    int,
        @rowcount int,
        @format   varchar(255)

select @error=0

begin transaction

  if exists (select 1 from Schedule
             where Id=@Id
               and  Date=@Date
               and  Type=@Type
            )
  begin
    if (@Version = 0)
    begin
      select @Version = Version from Schedule
      where Id=@Id
        and  Date=@Date
	and  Type=@Type
    end
    update Schedule set
      Amount=@Amount,
      Version=Version+1,
      RecordStatus='C',
      ServerName=@ServerName,
      UpdaterRef=@UpdaterRef,
      UpdateDatetime=getdate()
    where Id=@Id
    and  Date=@Date
    and  Type=@Type

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      while @@trancount != 0 rollback
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' Id=%4! Date=%5! Version=%6!'
      raiserror 29000 @format ,'ScheduleStore','update','ScheduleStore',@Id,@Date,@Version
      return -1
    end
  end
  else
  begin
    select @Version = 1 

    insert into Schedule (
      Id,
      Date,
      Type,        
      Amount,      
      Version,
      RecordStatus,
      ServerName,
      CreatorRef,
      CreationDatetime,
      UpdaterRef,
      UpdateDatetime)
    values (
      @Id,
      @Date,
      @Type,
      @Amount,
      @Version,
      'C',
      @ServerName,
      @UpdaterRef,
      getdate(),
      @UpdaterRef,
      getdate())

    select @error=@@error,@rowcount=@@rowcount
    if ((@error != 0) or (@rowcount!=1))
    begin
      while @@trancount != 0 rollback
      exec sp_getmessage 29000,@format OUTPUT
      select @format=@format+' Id=%4! Date=%5! Version=%6!'
      raiserror 29000 @format ,'ScheduleStore','insert','Schedule',@Id,@Date,@Version
      return -1
    end
  end
commit transaction

--select Id,
--       Date,
--       Version,
--       CreatorRef,
--       CreationDatetime,
--       UpdaterRef,
--       UpdateDatetime
--from Schedule
--where Id=@Id
--  and  Date=@Date
--  and  Type=@Type


return 0
go
IF OBJECT_ID('dbo.ScheduleStore') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.ScheduleStore >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.ScheduleStore >>>'
go
EXEC sp_procxmode 'dbo.ScheduleStore','anymode'
go

/** Fix the node set **/
IF OBJECT_ID('dbo.appCreateCorporatesBondNode') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.appCreateCorporatesBondNode
    IF OBJECT_ID('dbo.appCreateCorporatesBondNode') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.appCreateCorporatesBondNode >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.appCreateCorporatesBondNode >>>'
END
go


create proc appCreateCorporatesBondNode
(
   @SubTreeRef                    varchar(20),
   @CorpOrSov                     varchar(10),
   @CountryISO                    char(5),
   @Isin                          varchar(20),
   @DisplayName                   varchar(255),
   @PriceType                     varchar(6),
   @Benchmark                     varchar(20),
   @PricingMethod                 varchar(20),
   @Currency                      varchar(3),
   @PortfolioId                   varchar(20),
   @Moodys                        varchar(10),
   @SandP                         varchar(10),
   @Fitch                         varchar(10),
   @BidSpread                     float,
   @AskSpread                     float,
   @IsFrn                         char(1),
   @UserName                      varchar(20),
   @NodeSetRef                    varchar(25) = null
)
as
begin tran
  declare @Curve                  char(20)
  declare @ZCurve                 char(20)
  declare @err                    int

  if ( @NodeSetRef is null )
  begin
      select @NodeSetRef = 'LATAM_' + rtrim(@CountryISO) + '_' + @CorpOrSov
  end    

  
  if (@Currency = 'CHF')
     select @Curve                    = 'GOTTEX_' + @Currency
  else  
     select @Curve                    = 'LIBOR_' + @Currency


  if (@Currency = 'GBP')
    select @ZCurve = 'IYC55_GBP'
  else if (@Currency = 'EUR')
    select @ZCurve = 'IYC53_EUR'
  else if (@Currency = 'USD')
    select @ZCurve = 'LIBOR-HD_USD'
  else  
    select @ZCurve = null


-- Create the GenericNode, Node and SubTreeNode entries.
 exec @err = appCreateGenericBondNode
         @NodeSetRef          = @NodeSetRef,
         @NodeRef             = @Isin,
         @CurrentMasterRef    = @PricingMethod,
         @DisplayName         = @DisplayName,
         @Version             = 0,
         @ServerName          = @UserName,
         @UserName            = @UserName,
         @SubTreeRef          = @SubTreeRef
exec @err = appCheckLastError @lastError=@err, @info=@Isin, @procName='appCreateGenericBondNode', @mainProc='appCreateCorporatesBondNode'
if (@err !=0) return

--
-- Create the appropriate manual calculator.
--

  if (@PriceType = 'Mid')
    exec @err = appManualBondPriceCalculator @Isin, 1, 'Y', 0, 'script', @UserName
  else if (@PriceType = 'BidAsk')
  begin
    if (@IsFrn = 'N')
        exec @err= appBidAskManBondPriceCalcStore @Isin,'Y', 1.0, 'Y', 1.0, 1, 'script', @UserName
    else
        exec @err= appBidAskManFrnPriceCalcStore @Isin,'Y', 1.0, 'Y', 1.0, 1, 'script', @UserName
  end

  if (@err != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateCorporatesBondNode:Error ManualBondPriceCalc'
    return -1
  end

--
-- Create a BidAskYieldPrice calculator if a benchmark is specified.
--

  if( @Benchmark <> @Isin and @IsFrn = 'N')
  begin
    if (@PriceType = 'BidAsk')
    begin
      exec @err= appBidAskYieldSpreadCalcStore @Isin, @Benchmark, 0, @BidSpread, @AskSpread, 'Bid', 'Ask', 0, 'script', @UserName
    end
    if (@err != 0)
    begin
      while @@trancount != 0 rollback
      raiserror 999999 'appCreateCorporatesBondNode:Error YieldSpreadCalc'
      return -1
    end
  end

  if( @Benchmark <> @Isin and @IsFrn = 'N')
  begin
    exec CalculatorStore @NodeRef = @Isin, @CalculatorId = 'ScheduleCalculator', @JavaClass = 'com.rbsfm.fi.pricing.dependency.bond.ScheduleCalculator', @Version = 1, @ServerName = 'script', @UpdaterRef = @UserName
    if (@err != 0)
    begin
      while @@trancount != 0 rollback
      raiserror 999999 'CalculatorStore:Error ScheduleCalculator'
      return -1
    end
  end

  /*if (@IsFrn = 'N')*/
  begin
    exec @err = appBidAskSpreadCalcStore @Isin, 0.00005, 0, 'script', @UserName

    if (@err != 0)
    begin
      while @@trancount != 0 rollback
      raiserror 999999 'appCreateCorporatesBondNode:Error appBidAskSpreadCalcStore'
      return -1
    end
  end

    --Create curve pricing calculator(s) depending on price type.

  if (@IsFrn = 'N')
  begin
    exec @err = appBidAskAssSwapSprdCalcStore @Isin, @Curve, 0.0000, 0.0, 0.0, 1,
                              'script', @UserName

    if (@err != 0)
    begin
      while @@trancount != 0 rollback
      raiserror 999999
                'appCreateCorporatesBondNode:Error appBidAskAssSwapSprdCalcStore'
      return -1
    end
  end

  if (@IsFrn = 'N')
  begin
    exec @err = appCreateZSpreadCalcStore @Isin, 1, 
                              'script', @UserName

    if (@err != 0)
    begin
      while @@trancount != 0 rollback
      raiserror 999999
                'appCreateCorporatesBondNode:Error appCreateZSpreadCalcStore'
      return -1
    end
  end
     
  exec @err = appPriceYieldCalculator @Isin, '1-1-1900', '', 0, 'script', @UserName
  if (@err != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateCorporatesBondNode:Error BondPriceYieldCalc'
    return -1
  end

--  exec @err = appCompBondPriceCalcStore @Isin, 0, 'script', @UserName
--  if (@err != 0)
---  begin
--     while @@trancount != 0 rollback
--    raiserror 999999 'appCreateCorporatesBondNode:Error CompBondPriceCalc'
--    return -1
--  end
  
  -- Add inside price calc to all new bonds, no point chaining sp calls - this calc requires no other action than ...
  exec @err = CalculatorStore @NodeRef = @Isin,
                              @CalculatorId = 'InsidePriceCalc',
                              @JavaClass = 'com.rbsfm.fi.pricing.dependency.bond.InsidePriceCalculator',
                              @Version = 0,
                              @ServerName = 'script',
                              @UpdaterRef = 'script'
  if (@err != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateCorporatesBondNode:Error calling CalculatorStore for InsidePriceCalc'
    return -1
  end

  exec @err = appBondCloseCalcStore @Isin, 0, 'script', 'script', 'com.rbsfm.fi.pricing.dependency.bond.CreditBondCloseCalculator'
  if (@err != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateCorporatesBondNode:Error BondCloseCalc5'
    return -1
  end

  exec @err = appBondUserDataStore    @Isin, 0, 0, 0, 'script', @UserName
  if (@err != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateCorporatesBondNode:Error appBondUserDataStore'
    return -1
  end

  exec @err = appRatingsDataCalcStore  @Isin, 'RatingsDataCalc',
                       @Moodys, @SandP, @Fitch,
                                       0, 'script', @UserName
  if (@err != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateCorporatesBondNode:Error CreatePositionNodes'
    return -1
  end

  if (@IsFrn = 'N')
  begin
    exec @err = appCDSCurveCalcStore    @Isin, '', 0.0, 0, 'script', @UserName
    if (@err != 0)
    begin
      while @@trancount != 0 rollback
      raiserror 999999 'appCreateCorporatesBondNode:Error appCDSCurveCalcStore'
      return -1
    end
  end

  if (@ZCurve != null)
  begin
    exec @err = CalculatorAttributeStore @Isin, 'ZSpreadCalc', 'zcurve', 'STRING', 0, 0, '1/1/1900', @ZCurve, 1, 'script', @UserName
    if (@err != 0)
    begin
      while @@trancount != 0 rollback
      raiserror 999999 'appCreateCorporatesBondNode:Error CalculatorAttributeStore'
      return -1
    end
  end

  if (@ZCurve != null)
  begin
    exec @err = CalculatorAttributeStore @Isin, 'ZSpreadCalcRBS', 'zcurve', 'STRING', 0, 0, '1/1/1900', @ZCurve, 1, 'script', @UserName
    if (@err != 0)
    begin
      while @@trancount != 0 rollback
      raiserror 999999 'appCreateCorporatesBondNode:Error CalculatorAttributeStore'
      return -1
    end
  end

  if (@ZCurve != null)
  begin
    exec @err = CalculatorAttributeStore @Isin, 'ZSpreadCalcRBS', 'zsuffix', 'STRING', 0, 0, '1/1/1900', 'RBS', 1, 'script', @UserName
    if (@err != 0)
    begin
      while @@trancount != 0 rollback
      raiserror 999999 'appCreateCorporatesBondNode:Error CalculatorAttributeStore'
      return -1
    end
  end

  exec @err = CalculatorAttributeStore @Isin, 'IsInRunCalculator', 'IsInRun', 'INT', 0, 0, '1/1/1900', '', 1, 'script', @UserName
  if (@err != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateCorporatesBondNode:Error CalculatorAttributeStore'
    return -1
  end

  exec @err = CalculatorStore @Isin, 'IsInRunCalculator', 'com.rbsfm.fi.pricing.dependency.bond.IsInRunCalculator', 1, 'script', @UserName
  if (@err != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appCreateCorporatesBondNode:Error CalculatorStore'
    return -1
  end

  if (@IsFrn = 'N')
  begin
    exec @err = appWIBAYieldSpreadCalcStore @Isin, @Curve, 1, 'script', @UserName
    if (@err != 0)
    begin
      while @@trancount != 0 rollback
      raiserror 999999 'appWIBAYieldSpreadCalcStore: Error'
      return -1
    end
  end

  if (@IsFrn = 'N')
  begin
    exec @err = appCreateWIAxeCalcStore @Isin, @Curve, 'NaN', 'NaN',
                                        1, 'script', @UserName
    if (@err != 0)
    begin
      while @@trancount != 0 rollback
      raiserror 999999 'appCreateWIAxeCalcStore: Error'
      return -1
    end
  end

  if (@IsFrn = 'N')
  begin
    exec @err = appCloseBAYSpreadCalcStore @Isin, 1, 'script', @UserName
    if (@err != 0)
    begin
      while @@trancount != 0 rollback
      raiserror 999999 'appCloseBAYSpreadCalcStore: Error'
      return -1
    end
  end

-- Adjustment timestamp calc.

   exec @err = appAdjTimeCalcStore @Isin, 'Bid', 1, 'script', @UserName

  if (@err != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appAdjTimeCalcStore: Error'
    return -1
  end

   exec @err = appAdjTimeCalcStore @Isin, 'Ask', 1, 'script', @UserName

  if (@err != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 'appAdjTimeCalcStore: Error'
    return -1
  end
  
  
  declare @positionNodeRef    varchar(30)
  declare @repoNode           varchar(30)
  
  select @positionNodeRef = @PortfolioId + '-' + @Isin
  select @repoNode        = 'Fwd GC ' +@Currency
  
  exec @err = appCreateGenericPositionNode
         @NodeSetRef                 = @NodeSetRef,
         @NodeRef                    = @Isin,
         @PortfolioId                = @PortfolioId,
         @RiskPriceType              = 'Mid',
         @BenchmarkHedgePriceType    = '',
         @FutureBarbellPriceType     = '',
         @BenchmarkBarbellPriceType  = '',
         @Cash4CashFwdRepoRef        = @repoNode,
         @BarbellDateStrategy        = '',
         @Position                   = 0,
       @Axes                       = 0.0,
         @Version                    = 0,
         @ServerName                 = @UserName,
         @UserName                   = @UserName,
         @SubTreeRef                 = @SubTreeRef
  exec @err = appCheckLastError @lastError=@err, @info=@Isin, @procName='appCreateGenericPositionNode', @mainProc='appCreateCorporatesBondNode'
  if (@err !=0) return
  
commit tran

go
IF OBJECT_ID('dbo.appCreateCorporatesBondNode') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.appCreateCorporatesBondNode >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.appCreateCorporatesBondNode >>>'
go
EXEC sp_procxmode 'dbo.appCreateCorporatesBondNode','anymode'
go

/** Remove the erase bond SQL **/

--
-- $Id: appEraseLATAMBond.sql,v 1.4 2009/10/21 17:24:57 gallane Exp $
-- $Revision: 1.4 $
--

IF OBJECT_ID('dbo.appEraseLATAMBond') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.appEraseLATAMBond
    IF OBJECT_ID('dbo.appEraseLATAMBond') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.appEraseLATAMBond >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.appEraseLATAMBond >>>'
END
go
create proc appEraseLATAMBond ( @BondNodeRef varchar(255))
as


declare @descr varchar(20) ,
        @alias      varchar(20),
        @aliasCount int

select @alias =  ( select rtrim(ltrim(NodeRef)) from GenericNodeAttribute 
                   where ValueString = @BondNodeRef and AttributeName = 'RealNodeId' )
                   
select @aliasCount = ( select count(*) from GenericNodeAttribute where ValueString = @BondNodeRef and AttributeName = 'RealNodeId' )                   

Print 'Starting to delete data for bond isin %1! ', @BondNodeRef

Print 'Deleting entries from CalculatorAttribute + Audit'                      
delete CalculatorAttributeAudit where NodeRef = @BondNodeRef
delete CalculatorAttribute where NodeRef = @BondNodeRef

Print 'Deleting entries from Calculator + Audit'   
delete Calculator where NodeRef = @BondNodeRef
delete CalculatorAudit where NodeRef = @BondNodeRef

Print 'Deleting entries from Schedule + Audit'   
delete Schedule where Id = @BondNodeRef
delete ScheduleAudit where Id = @BondNodeRef

Print 'Deleting entries from CashFlow + Audit'   
delete CashFlow where Id = @BondNodeRef
delete CashFlowAudit where Id = @BondNodeRef

Print 'Deleting entries from Node + Audit'   
delete NodeAudit where NodeId = @BondNodeRef
delete Node where NodeId = @BondNodeRef

Print 'Deleting entires from GenericNode + Audit'
delete GenericNodeAudit where NodeRef = @BondNodeRef
delete GenericNode where NodeRef = @BondNodeRef

Print 'Deleting entires from GenericNodeAttribute + Audit'
delete GenericNodeAttributeAudit where NodeRef = @BondNodeRef
delete GenericNodeAttribute where NodeRef = @BondNodeRef

print 'Deleting Sanitizer data'
delete EcnSanitizerInstCtrl where InstrumentRef = @BondNodeRef

print 'Deleting SubTreeNode'
delete SubTreeNodes where NodeRef = @BondNodeRef
delete SubTreeNodesAudit where NodeRef = @BondNodeRef

--print 'Deleting quotes data'
delete EcnQuote  where InstrumentRef = @BondNodeRef
delete EcnSpread where InstrumentRef = @BondNodeRef
delete EcnAllocation where InstrumentRef = @BondNodeRef
delete EcnObligation where InstrumentRef = @BondNodeRef
delete EcnQuoteNew where InstrumentRef = @BondNodeRef
delete EcnSpreadNew where InstrumentRef = @BondNodeRef
delete EcnAllocation where InstrumentRef = @BondNodeRef
delete EcnInstrumentMapping where InstrumentId = @BondNodeRef
delete EcnSanitizerInstCtrl where InstrumentRef = @BondNodeRef
delete EcnInstCtrl where InstrumentRef = @BondNodeRef
delete EcnInstrumentStatus where InstrumentRef = @BondNodeRef
delete EcnAutoQuoteClearing where InstrumentRef = @BondNodeRef
delete EcnInstrumentSub where InstrumentRef = @BondNodeRef

delete EcnQuoteAudit where InstrumentRef = @BondNodeRef
delete EcnSpreadAudit where InstrumentRef = @BondNodeRef
delete EcnAllocationAudit where InstrumentRef = @BondNodeRef
delete EcnObligationAudit where InstrumentRef = @BondNodeRef
delete EcnQuoteNewAudit where InstrumentRef = @BondNodeRef
delete EcnSpreadNewAudit where InstrumentRef = @BondNodeRef
delete EcnAllocationAudit where InstrumentRef = @BondNodeRef
delete EcnInstrumentMappingAudit where InstrumentId = @BondNodeRef
delete EcnSanitizerInstCtrlAudit where InstrumentRef = @BondNodeRef
delete EcnInstCtrlAudit where InstrumentRef = @BondNodeRef
delete EcnInstrumentStatusAudit where InstrumentRef = @BondNodeRef
delete EcnAutoQuoteClearingAudit where InstrumentRef = @BondNodeRef
delete EcnInstrumentSubAudit where InstrumentRef = @BondNodeRef


Print 'Successfully deleted pricing, sanitization & quote data for %1!' , @BondNodeRef


if (@aliasCount = 0 ) 
begin
    print '%1! does not have an alias',@BondNodeRef
end
else if (@aliasCount = 1)
begin
    print 'About to delete single alias %1! associated with %2!',@alias,@BondNodeRef
    
    delete GenericNode where NodeRef = @alias
    delete GenericNodeAudit where NodeRef = @alias
    
    delete GenericNodeAttribute where NodeRef = @alias
    delete GenericNodeAttributeAudit where NodeRef = @alias
    
    delete Node where NodeId = @alias
    delete GenericNodeAttributeAudit where NodeRef = @alias
    
    print 'done'
end
else
begin
    print 'More than one alias - delete manually'
end


go

IF OBJECT_ID('dbo.appEraseLATAMBond') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.appEraseLATAMBond >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.appEraseLATAMBond >>>'
go
EXEC sp_procxmode 'dbo.appEraseLATAMBond','anymode'
go

/** Grant execute permissions **/

grant execute on appEraseStagingCalculator to fi_latam_server
go

/** Stored proc permissions for appCreateLATAM **/

grant execute on CalculatorAttributeStore to fi_latam_server
grant execute on CalculatorStore to fi_latam_server
grant execute on GenericNodeAttributeStore to fi_latam_server
grant execute on GenericNodeStore to fi_latam_server
grant execute on SubTreeNodesStore to fi_latam_server
grant execute on appAdjTimeCalcStore to fi_latam_server
grant execute on appBidAskAssSwapSprdCalcStore to fi_latam_server
grant execute on appBidAskBestPxMuxRTCalcStore to fi_latam_server
grant execute on appBidAskBondVsCurveCalcStore to fi_latam_server
grant execute on appBidAskManBondPriceCalcStore to fi_latam_server
grant execute on appBidAskYieldSpreadCalcStore to fi_latam_server
grant execute on appBidAskYieldSpreadSCalcStore to fi_latam_server
grant execute on appBondCloseCalcStore to fi_latam_server
grant execute on appBondUserDataStore to fi_latam_server
grant execute on appBondVsFutsCalcStore to fi_latam_server
grant execute on appCreateAliasNode to fi_latam_server
grant execute on appCreateBASwapSpreadCalcStore to fi_latam_server
grant execute on appCreateGenericPositionNode to fi_latam_server
grant execute on appCreateInternalBondNode to fi_latam_server
grant execute on appCreateLATAM to fi_latam_server
grant execute on appCreateLATAMCalcs to fi_latam_server
grant execute on appCreateWIAxeCalcStore to fi_latam_server
grant execute on appCrssCcyAsstSwpSprdCalc to fi_latam_server
grant execute on appForwardPriceCalculator to fi_latam_server
grant execute on appPriceYieldCalculator to fi_latam_server
grant execute on appRatingsDataCalcStore to fi_latam_server
grant execute on appRunsCalculatorStore to fi_latam_server
grant execute on appWIBAYieldSpreadCalcStore to fi_latam_server
go

grant execute on EcnInstCtrlStore to fi_latam_server
grant execute on EcnInstrumentMappingStore to fi_latam_server
grant execute on EcnInstrumentStatusStore to fi_latam_server
grant execute on EcnInstrumentSubStore to fi_latam_server
grant execute on EcnQuoteNewStore to fi_latam_server
grant execute on EcnSanitizerInstCtrlStore to fi_latam_server
grant execute on EcnSpreadNewStore to fi_latam_server
grant execute on appEcnCreateBond to fi_latam_server
grant execute on appLATAMEcnCreateBond to fi_latam_server
go

grant execute on appEraseLATAMBond to fi_latam_server
go

/** Grant select permissions **/

grant select on GenericNodeView to fi_latam_server
go

/** Grant select permissions **/

grant select on PerSectorDefaultView to fi_latam_server
go

/** Grant execute permissions **/

grant execute on appCreateStagingCalculator to fi_latam_server
grant execute on GenericNodeStore to fi_latam_server
go

/** Grant permissions **/

grant execute on appMoveLiveLATAMBond to fi_latam_server
go

/** Grant permissions **/

grant execute on ScheduleStore to fi_latam_server
go

/** Grant permission **/

grant execute on  appCreateCorporatesBondNode to fi_latam_server
go

/** Grant permission **/

grant select on  EcnInstrumentStatusView to fi_latam_server
go

