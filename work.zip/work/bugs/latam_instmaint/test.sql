-- 77, 435 (these require cashflows)
appEraseLATAMBond 'US706448AR84'
go
appEraseLATAMBond 'USP19157AG48'
go

-- These should have Call dates (A bond can be callable regardless of its type it seems)
-- (133-multi coupon)
appEraseLATAMBond 'USP6558LAH26'
go
--(1-Street conventional)
appEraseLATAMBond 'US879246AA41'
go
 
-- These should have stepups (133-multi coupon):
appEraseLATAMBond 'XS0085661949'
go
appEraseLATAMBond 'USP09669BS37'
go
 
 
--These do not seem to have anything extraordinary, but would be good to test as well....
--1297-EUR
appEraseLATAMBond 'XS0170239932'
go
appEraseLATAMBond 'XS0222076449'
go

--1224
appEraseLATAMBond 'US917288BA96'
go
 
--1317
appEraseLATAMBond 'US917288BA96'
go
 
--373
appEraseLATAMBond 'USG2584XAA84'
go
 
--990
appEraseLATAMBond 'XS0444611296'
go

