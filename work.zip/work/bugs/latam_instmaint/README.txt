# If bond static fails there is still an empty row in cp client

US0234086196

# LOOKS LIKE THE AMOUNT IS INCORRECT WITH REGARD TO DECIMAL PLACES

call ScheduleStore( 'US105756BC32', 'Margin', 'Sep 29 2004', 575, 0, 'latam-pricing-instmaint', 'latam-pricing-instmaint' ) }

exec ScheduleStore @Id = 'US105756BC32', @Type = 'Margin', @Date = 'Sep 29 2004', @Amount = 0.0575, @Version = 1, @ServerName = 'BondStaticSQL', @UpdaterRef = 'BondStaticSQL'

# Exception in new build

2009-10-19 13:03:41.981 -0400 ERROR [pool-1-thread-1] unknown: Control[StaticDataMonitor]: Unable to process instrument message: (ChainedRunt
        at com.rbsfm.fi.instmaint.enrich.InstrumentMaintEnrichManager.enrichInstrument(InstrumentMaintEnrichManager.java:95)
        at com.rbsfm.fi.instmaint.persist.InstrumentMaintPersistenceManager.enrich(InstrumentMaintPersistenceManager.java:273)
        at com.rbsfm.fi.instmaint.persist.InstrumentMaintPersistenceManager.addInstrument(InstrumentMaintPersistenceManager.java:244)
        at com.rbsfm.fi.instmaint.persist.InstrumentMaintPersistenceManager.onEvent(InstrumentMaintPersistenceManager.java:142)
        at com.rbsfm.fi.instmaint.InstrumentMaintLifeCycleManagerImpl.notify(InstrumentMaintLifeCycleManagerImpl.java:148)
        at com.rbsfm.fi.instmaint.InstrumentMaintLifeCycleManagerImpl.newInstrumentRequest(InstrumentMaintLifeCycleManagerImpl.java:45)
        at com.rbsfm.fi.instmaint.StaticDataMonitor.processInstrumentStaticNew(StaticDataMonitor.java:175)
        at com.rbsfm.fi.instmaint.StaticDataMonitor.access$100(StaticDataMonitor.java:26)
        at com.rbsfm.fi.instmaint.StaticDataMonitor$2.handle(StaticDataMonitor.java:74)
        at com.rbsfm.fi.instmaint.StaticDataMonitor$6.run(StaticDataMonitor.java:119)
        at java.util.concurrent.ThreadPoolExecutor$Worker.runTask(ThreadPoolExecutor.java:885)
        at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:907)
        at java.lang.Thread.run(Thread.java:619)
Caused by: java.lang.NullPointerException
        at com.rbsfm.fi.pricing.external.attribute.AttributeMap.getIntValue(AttributeMap.java:152)
        at com.rbsfm.fi.instmaint.enrich.LatamBondTypeRefEnricher.generateEnrichAttributes(LatamBondTypeRefEnricher.java:55)
        at com.rbsfm.fi.instmaint.enrich.InstrumentMaintEnrichManager.enrichInstrument(InstrumentMaintEnrichManager.java:88)
        ... 12 more


# Addition of FRN

begin transaction
exec appCreateCorporatesBondNode 'Staging', 'Corp', 'AR', 'USP09669BT10', 'BNCGAL 0.0 01/01/10', 'BidAsk', '', 'discMargin', 'USD', 'Master', 'N.A.', 'N.A.', 'N.S', 0, 0, 'Y', 'latam-pricing-instmaint' 
exec appCorporatesBondStaticStore 'AR', 'USP09669BT10', 'USP09669BT10', 'BNCGAL 0.0 01/01/10', '21-USD-ACT360:F:S', 0.0, 'N', 'Jan 01 2010', 'Jan 01 2004', 'Jan 01 2004', 0.023603111, 'Jul 01 2004', 0.023603111, 'Jul 01 2009', 1.0, 'Y', 'BNCGAL', 3.52838846E8, 'USD', 'ARGENTINA', 'FLOAT RATE NOTE', 'REGS', 'Y', '', '', 0, 'latam-pricing-instmaint', 'latam-pricing-instmaint' 
exec ScheduleStore 'USP09669BT10', 'Margin', 'Jul 01 2004', 350, 0, 'latam-pricing-instmaint', 'latam-pricing-instmaint' 
exec appBADiscountMarginCalcStore 'USP09669BT10', 'LIUSD6M', 'MMLIUSD6M', 'LIUSDRepo', 0, 0, 'latam-pricing-instmaint', 'latam-pricing-instmaint' 
exec CalculatorStore 'USP09669BT10', 'ScheduleCalculator', 'com.rbsfm.fi.pricing.dependency.bond.ScheduleCalculator', 0, 'latam-pricing-instmaint', 'latam-pricing-instmaint' 
exec CalculatorStore 'USP09669BT10', 'bidAskCompCalc', 'com.rbsfm.fi.pricing.dependency.bond.BidAskYieldComparisonCalculator', 0, 'latam-pricing-instmaint', 'latam-pricing-instmaint' 
exec appLATAMEcnCreateBond 'USP09669BT10', 'Cusip', 3.5, 3.52838846E8, 'SP', 'LATAM_AR_Corp' 
exec appLoadLATAMSanData 'USP09669BT10', 'true' 
exec appCreateStagingCalculator 'USP09669BT10', 'Loaded', '', '', 'LATAM_AR_Corp', 'Y', 'Y', 'gallane' 
commit transaction


# Fix for latam_latest

2009-10-16 08:38:42.382 INFO [DbWriteQueue] unknown: : Created for GenericNodeStore: Stack Trace: java.lang.Exception: Created for GenericNodeStore
        at com.rbsfm.common.persist.Query.<init>(Query.java:160)
        at com.rbsfm.fi.pricing.db.DeadlockRetryQuery.<init>(DeadlockRetryQuery.java:37)
        at com.rbsfm.fi.pricing.db.DeadlockRetryQuery.forProc(DeadlockRetryQuery.java:29)
        at com.rbsfm.fi.pricing.dependency.db.AbstractDbNodeHome.writeNode(AbstractDbNodeHome.java:493)
        at com.rbsfm.fi.pricing.dependency.generic.DbGenericNodeHome.writeNode(DbGenericNodeHome.java:252)
        at com.rbsfm.fi.pricing.dependency.db.MasterDbNodeHome.commitNode(MasterDbNodeHome.java:229)
        at com.rbsfm.fi.pricing.dependency.tree.AbstractTreePersistenceManager.commitNode(AbstractTreePersistenceManager.java:226)
        at com.rbsfm.fi.pricing.dependency.tree.AbstractTreePersistenceManager.writeNode(AbstractTreePersistenceManager.java:209)
        at com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree.writeNode(AbstractDependencyTree.java:609)
        at com.rbsfm.fi.pricing.dependency.InternalNode.write(InternalNode.java:374)
        at com.rbsfm.fi.pricing.dependency.InternalNode.takeOwnership(InternalNode.java:242)
        at com.rbsfm.fi.pricing.dependency.NodeWithCalculators.takeOwnership(NodeWithCalculators.java:300)
        at com.rbsfm.fi.pricing.dependency.bond.InternalBondNode.processTakeOwnershipMessage(InternalBondNode.java:521)
        at com.rbsfm.fi.pricing.dependency.bond.InternalBondNode.processMessage(InternalBondNode.java:240)
        at com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessageWithoutRecalc(TreeMessageProcessingManagerImpl.java:130)
        at com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessage(TreeMessageProcessingManagerImpl.java:89)
        at com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessage(TreeMessageProcessingManagerImpl.java:79)
        at com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree.processMessage(AbstractDependencyTree.java:628)
        at com.rbsfm.fi.pricing.dependency.remote.ClientImpl.processMessage(ClientImpl.java:243)
        at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
        at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:39)
        at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:25)
        at java.lang.reflect.Method.invoke(Method.java:597)
        at electric.util.reflect.Invocation.execute(Unknown Source)
        at electric.util.reflect.Invocation.invoke(Unknown Source)
        at electric.service.object.ObjectService.invoke(Unknown Source)
        at electric.soap.local.handlers.service.SOAPToServiceHandler.invoke(Unknown Source)
        at electric.soap.local.handlers.service.SOAPToServiceHandler.handle(Unknown Source)
        at electric.soap.security.handlers.SecurityHandler.handle(Unknown Source)
        at electric.soap.handlers.interceptor.SOAPInterceptorHandler.handle(Unknown Source)
        at electric.soap.routing.RoutingHandler.handle(Unknown Source)
        at electric.soap.handlers.logging.SOAPLoggingHandler.handle(Unknown Source)
        at electric.soap.handlers.setup.SetupHandler.handle(Unknown Source)
        at electric.soap.http.handler.HTTPToSOAP.service(Unknown Source)
        at electric.server.http.ServletServer.service(Unknown Source)
        at javax.servlet.http.HttpServlet.service(HttpServlet.java:853)
        at electric.servlet.Config.service(Unknown Source)
        at electric.servlet.HTTPContext.service(Unknown Source)
        at electric.servlet.ServletEngine.service(Unknown Source)
        at electric.webserver.WebServer.service(Unknown Source)
        at electric.net.socket.SocketServer.run(Unknown Source)
        at electric.net.socket.SocketRequest.run(Unknown Source)
        at electric.util.thread.ThreadPool.run(Unknown Source)
        at java.lang.Thread.run(Thread.java:619)


# Fix the generic node st0re

DbGenericNodeHome


  public void writeObject( Object o, Query q ) {
    NodeData node = (NodeData) o;
    if (node.getHomeClass().equals(mNodeClass)) {
      q.put( node.getNodeSetId() );
      q.put( node.getDisplayName() );
      q.put( node.getExternalCode() );
      q.put( node.getId() );
      q.put( node.getHomeClass().getName() );
      q.put( node.getOwner() );
      q.put( 1 ); // ClockPeriod
      }
  }



# Can't take ownership

SOAPException( Server: Control[Client]: Client failed to process message: (ChainedRuntimeException:LATAM failed to process message: mTreeToken=StagingLatam.master, mNodeId=null, mCalculatorId=null, mForwarded=false, is remote? false )

# These are the parameters

SimpleAttributeMap[com.rbsfm.fi.pricing.util.SimpleAttributeMap: 
InstrumentIdType='ISIN',  
postStagingSector='LATAM_KY_Corp', 
MaturityDate='',  
CpDisplayName='',  
IsBill='',  
subTreeId='ALL',  
book='null',  
InstrumentId='USG1315RAA98',  
ChainId='',  
cloneIds='', ]

# Bond adder

\\lon0009ons\Internet\CentralisedPricing\bondAddingAuto\latam\uat\bin

# Addition of bond

begin transaction
exec appCreateLATAM 'Corp', 'USG1315RAA98', 'BRASKM 7.25 05/06/18', '', 'BRASKM', 'LIBOR-HD_USD', 0.0725, 'Jun 05 2018', '1-USD-30360:S', 'USD', 'CAYMAN ISLANDS', 'KY', 'STREET CONVENTION', 'REGS', 5.0E8, 'Jun 05 2008', 'Jun 05 2008', 0.03625, 'Dec 05 2008', 0.03625, 'Dec 05 2017', 1.0, 'Y', 0, 'Staging', 'Staging' 
exec appLATAMEcnCreateBond 'USG1315RAA98', 'Cusip', 0.0, 5.0E8, 'SP', 'LATAM_KY_Corp' 
exec appLoadLATAMSanData 'USG1315RAA98', 'false' 
exec appCreateStagingCalculator 'USG1315RAA98', 'Loaded', '', '', 'LATAM_KY_Corp', 'Y', 'Y', 'gallane' 
commit transaction

# Issue with take ownership

GenericNodeStore

'Staging', 
'BRASKM 7.25 05/06/18', 
'USG1315RAA98', 
'USG1315RAA98', 
'com.rbsfm.fi.pricing.dependency.bond.InternalBondNode', 
'gallane', 
1,
1, 
'STAMS00058::6668::latam pricing instmaintStagingLatam.master', 
'gallane', 
'Staging'  

GenericNodeStore( 
'ALL', 
'', 
'USG1315RAA98', 
'USG1315RAA98', 
'com.rbsfm.fi.pricing.dependency.bond.InternalBondNode', 
'gallane',
0, 
1,
'gallane', 
'gallane',
'ALL'

# Add this to the DependancyTreeImpl to pick up latam permissions

	<securityApp>LATAM</securityApp>

# In order to take ownership the following is needed

  <component name="LocalClientService" class_name="com.rbsfm.fi.pricing.mux.remote.LocalClient">
    <securityTokenFactory>SecurityModel</securityTokenFactory>
    <messageHandlerDelegates enabled="true"> <!-- THIS MUST BE TRUE TO TAKE OWNERSHIP -->
      <delegate>LocalClientMessageHandlerDelegate</delegate>
	</messageHandlerDelegates>    
  </component>

# Remove static data

appEraseStaticDataISIN 'XS0211229637'

# Add style to client

		<style Master="true" WhatIf="true">
			<name>Staging</name>
			<public>true</public>
			<in_grid_splitter>
				<in_name fixed_width="8">ownIndicator</in_name>
				<in_name fixed_width="8">ticker</in_name>
				<in_name fixed_width="8">cpn</in_name>
				<in_name fixed_width="8">matDt</in_name>
				<in_name fixed_width="8">nodeId</in_name>
			</in_grid_splitter>
			<in_grid>
				<in_name fixed_width="8">stageLive</in_name>
				<in_name fixed_width="8">stageRequestor</in_name>
				<in_name fixed_width="8">stageLiveStatus</in_name>
				<in_name fixed_width="8">setId</in_name>
			</in_grid>
		</style>


# Removal of a bond is done like so

appEraseLATAMBond XS0235386447

# Removed the following

USG1315RAA98 and XS0235386447 and XS0211229637

# Instmaint needs to be started with a different user

EXECUTE permission denied on object appCreateLATAM, database fi_LATAM_uat, owner dbo

# CAF needs to be upgraded

CAF version 4.32.0.4 in all.properties as [caf.version..latam=4.32.0.4]


# Marks changes to the db are here

http://twiki.fm.rbsgrp.net/twiki/bin/view/CP/CopyProdDatabase

# Note to addition of a staging bond

If the bond is added to staging the BloombergChainId will be '' meaning that the appEcnCreateBond.SQL script
will not add the entry, as the @BloombergChainId will be ''. It is called from appLATAMEcnCreateBond.sql.
<F5>
# SQL stored procedures modified added to latam_instmaint_1_sql

EcnInstCtrlStore.sql
EcnInstrumentMappingStore.sql
EcnInstrumentStatusStore.sql
EcnInstrumentSubStore.sql
EcnQuoteNewStore.sql
EcnSanitizerInstCtrlStore.sql
EcnSpreadNewStore.sql
appCreateLATAMCalcs.sql
appCreateLATAM.sql
appEcnCreateBond.sql
appLATAMEcnCreateBond.sql


# Static calculator is complainting 

2009-10-06 11:44:55.051 -0400 ERROR [StagingLatamCalcCycle] cpratesdev: Problems creating static based instrument BondStaticCalc,USP9308RAX19.Cannot assignMissingFields() as null template Bond passed in for USP9308RAX19. Remedial action taken[create-dummy-on-fail]: Cannot assignMissingFields() as null template Bond passed in for USP9308RAX19: Stack Trace: java.lang.IllegalArgumentException: Cannot assignMissingFields() as null template Bond passed in for USP9308RAX19
        at com.rbsfm.fi.pricing.dependency.bond.BondStaticCalculator.assignMissingFields(BondStaticCalculator.java:1719)
        at com.rbsfm.fi.pricing.dependency.bond.BondStaticCalculator.internalCreateInstrument(BondStaticCalculator.java:1707)
        at com.rbsfm.fi.pricing.dependency.util.StaticCalculator.createInstrument(StaticCalculator.java:287)
        at com.rbsfm.fi.pricing.dependency.util.StaticCalculator.reset(StaticCalculator.java:237)
        at com.rbsfm.fi.pricing.dependency.util.StaticCalculator.preCalculationInitialisation(StaticCalculator.java:194)
        at com.rbsfm.fi.pricing.dependency.bond.BondStaticCalculator.preCalculationInitialisation(BondStaticCalculator.java:751)
        at com.rbsfm.fi.pricing.dependency.NodeWithCalculators.preCalculationInitialisation(NodeWithCalculators.java:607)
        at com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.preCalculationInitialisation(TreeCalculationManagerImpl.java:464)
        at com.rbsfm.fi.pricing.dependency.tree.TreeCalculationManagerImpl.validate(TreeCalculationManagerImpl.java:241)
        at com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree.validate(AbstractDependencyTree.java:739)
        at com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl.doCalcCycle(SimpleTreeControl.java:425)
        at com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl.runCalcCycle(SimpleTreeControl.java:316)
        at com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl.access$000(SimpleTreeControl.java:41)
        at com.rbsfm.fi.pricing.dependency.simple.SimpleTreeControl$1.run(SimpleTreeControl.java:257)
        at java.lang.Thread.run(Thread.java:619)

# This is what is being executed

begin transaction

exec appCreateLATAM
@CorpOrSov= 'Corp',
@BondNodeRef='USG6710EAA85',
@BondName='ODB 7.5 18/10/17 ',
@AliasName='',
@BondTicker='ODB',
@AssociatedCurve='',
@Coupon=0.075,
@MaturityDate='Oct 18 2017',
@BondTypeRef='1-SC-USD-30G360-S',
@Currency='USD',
@Country='CAYMAN ISLANDS',
@CountryISO='KY',
@BondCalcType='STREET CONVENTION',
@Series='REGS',
@IssueSize=4.0E8,
@FirstAccrualDate='Oct 18 2007',
@FirstSettlementDate='Oct 18 2007',
@FirstCouponAmount=0.0375,
@FirstCouponDate='Apr 18 2008',
@LastCouponAmount=0.0375,
@LastCouponDate='Apr 18 2017',
@RedemptionAmount=1.0,
@IsCodeISIN='Y',
@IsOnRun=0,
@SubTreeRef='Staging',
@NodeSetRef='Staging'

exec appLATAMEcnCreateBond
@InstrumentRef= 'USG6710EAA85',
@Cusip='EG9259482',
@BloombergSpread=0.0,
@BloombergSize=4.0E8

exec appLoadLATAMSanData
@InstrumentId= 'USG6710EAA85',
@IsFRN='false'


exec appCreateStagingCalculator
@BondNodeRef= 'USG6710EAA85',
@StageLiveStatus='Loaded',
@StageBook='',
@PostStagingSectorOpts='',
@PostStagingSector='Staging',
@StageBB='Y',
@StageALLQ='Y',
@StageRequestor='gallane'

commit
go

# Failure for

select 
    STN.SubTreeRef, 
    STN.NodeRef, 
    ST.OutputFlags 
from 
    SubTreeNodesView STN, 
    TreeView T, 
    SubTreeView ST 
where 
    STN.SubTreeRef = ST.SubTreeId 
and 
    ST.TreeRef = T.TreeId  
and 
    STN.NodeRef = 'USG1315RAA98'
and 
    T.TreeId = 'StagingLatam' 

# Delete and update

exec NodeSetDelete 'StagingLatam', 'Staging', 0, 'script', 'gallane'
update NodeSet set TreeRef = 'StagingLatam', NodeSetId = 'Staging', PublishTopic = 'All', SecurityApp = 'All' where TreeRef = 'LATAM' and NodeSetId = 'LATAMLong'

# Add the following to the NodeSet

insert into NodeSet (
TreeRef,
NodeSetId,
PublishTopic,
SecurityApp,
Version,
RecordStatus,
ServerName,
CreatorRef,
CreationDatetime,
UpdaterRef,
UpdateDatetime) 
values
('StagingLatam',
'Staging',
'All',
'All',
2,
'C',
'script',
'gallane',
getdate(),
'gallane',
getdate())
go

# Add the following default

      exec PerSectorDefaultStore 	
      @NodeSetRef      =              'Staging',	
      @Currency         =             'USD',	
      @SubTree           =            'ALL',	
      @ChainId            =           '',	
      @AllBucketSizes      =          0,	
      @AllBucketSpread      =         0,	
      @SpreadType            =        '',	
      @IsFinancial            =       '',	
      @HedgeTolerance          =      0,	
      @HedgeMinSize             =     0,	
      @AutoHedgeStatus           =    'OFF',	
      @Version                    =   0,
      @ServerName                  =  'script',
      @UpdaterRef                   = 'gallane'


# Current state of the database

> select * from SubTreeNodesView where SubTreeRef = 'StagingLatam'
> select * from SubTreeView where SubTreeId = 'StagingLatam'
> select * from Tree where TreeId = 'StagingLatam'
> select * from NodeSetView where NodeSetId = 'LATAM_BR_Corp'

# This is how we get the calculator

select 
    C.NodeRef, 
    C.CalculatorId, 
    C.JavaClass, 
    C.Version, 
    C.CreatorRef, 
    C.CreationDatetime, 
    C.UpdaterRef, 
    C.UpdateDatetime 
from 
    CalculatorView C, 
    TreeView T, 
    SubTreeView ST, 
    SubTreeNodesView STN, 
    NodeView N, 
    NodeSetView NS 
where 
    C.NodeRef = STN.NodeRef // GOOD
and 
    C.JavaClass = 'com.rbsfm.fi.pricing.dependency.staging.StagingCalculator'  // GOOD
and 
    STN.SubTreeRef = ST.SubTreeId   // GOOD 
and 
    ST.TreeRef = T.TreeId   // GOOD
and 
    T.TreeId = 'StagingLatam' // GOOD
and 
    C.NodeRef = N.NodeId //  
and 
    N.NodeSetRef = NS.NodeSetId 
and 
    N.NodeId = STN.NodeRef 
and 
    T.TreeId = NS.TreeRef

# This is the tree that is selected

select 
    STN.SubTreeRef, 
    STN.NodeRef, 
    ST.OutputFlags 
from 
    SubTreeNodesView STN, 
    TreeView T, 
    SubTreeView ST 
where 
    STN.SubTreeRef = ST.SubTreeId 
and 
    ST.TreeRef = T.TreeId  
and 
    T.TreeId = 'StagingLatam'

# Success in adding a bond

2009-10-05 12:37:56.676 -0400 INFO [Subscription ender for SocketServerSource(Async)->stams00058:3108] unknown: Removed subscriptions from dead socket queue, destination=
2009-10-05 12:37:57.442 -0400 INFO [pool-1-thread-1] unknown: sub tree is StagingLatam
2009-10-05 12:37:57.520 -0400 INFO [pool-1-thread-1] unknown: refreshing home for - USG08010BH52 RatesBondCloseCalculatorHome[DbGenericCalculatorHome]
2009-10-05 12:37:57.598 -0400 INFO [pool-1-thread-1] unknown: refreshing home for - USG08010BH52 IsInRunCalculatorHome[DbGenericCalculatorHome]
2009-10-05 12:37:57.676 -0400 INFO [pool-1-thread-1] unknown: refreshing home for - USG08010BH52 BondStaticCalculatorHome[DbGenericCalculatorHome]
2009-10-05 12:37:57.755 -0400 INFO [pool-1-thread-1] unknown: refreshing home for - USG08010BH52 BidAskZSpreadCalculatorHome[DbGenericCalculatorHome]
2009-10-05 12:37:57.833 -0400 INFO [pool-1-thread-1] unknown: refreshing home for - USG08010BH52 WhatIfBidAskYieldSpreadCalculatorHome[DbGenericCalculatorHome]
2009-10-05 12:37:57.911 -0400 INFO [pool-1-thread-1] unknown: refreshing home for - USG08010BH52 CDSBasisCalculatorHome[DbGenericCalculatorHome]
2009-10-05 12:37:57.973 -0400 INFO [pool-1-thread-1] unknown: refreshing home for - USG08010BH52 PriceYieldCalculatorHome[DbGenericCalculatorHome]
2009-10-05 12:37:58.052 -0400 INFO [pool-1-thread-1] unknown: refreshing home for - USG08010BH52 BidAskSwapSpreadCalculatorHome[DbGenericCalculatorHome]
2009-10-05 12:37:58.130 -0400 INFO [pool-1-thread-1] unknown: refreshing home for - USG08010BH52 RatingsDataCalculatorHome[DbGenericCalculatorHome]
2009-10-05 12:37:58.208 -0400 INFO [pool-1-thread-1] unknown: refreshing home for - USG08010BH52 BidAskSpreadCalculatorHome[DbGenericCalculatorHome]
2009-10-05 12:37:58.286 -0400 INFO [pool-1-thread-1] unknown: refreshing home for - USG08010BH52 BidAskBestPriceMuxRealtimeCalculatorHome[DbGenericCalculatorHome]
2009-10-05 12:37:58.364 -0400 INFO [pool-1-thread-1] unknown: refreshing home for - USG08010BH52 ForwardPriceCalculatorHome[DbGenericCalculatorHome]
2009-10-05 12:37:58.427 -0400 INFO [pool-1-thread-1] unknown: refreshing home for - USG08010BH52 BondUserDataCalculatorHome[DbGenericCalculatorHome]
2009-10-05 12:37:58.505 -0400 INFO [pool-1-thread-1] unknown: refreshing home for - USG08010BH52 StagingCalculatorHome[DbGenericCalculatorHome]
2009-10-05 12:37:58.583 -0400 INFO [pool-1-thread-1] unknown: refreshing home for - USG08010BH52 BidAskYieldSpreadCalculatorHome[DbGenericCalculatorHome]
2009-10-05 12:37:58.661 -0400 INFO [pool-1-thread-1] unknown: refreshing home for - USG08010BH52 GenericTimeStampAdjustmentCalculator[DbGenericCalculatorHome]
2009-10-05 12:37:58.739 -0400 INFO [pool-1-thread-1] unknown: refreshing home for - USG08010BH52 WhatIfAxeCalculatorHome[DbGenericCalculatorHome]
2009-10-05 12:37:58.802 -0400 INFO [pool-1-thread-1] unknown: refreshing home for - USG08010BH52 BidAskManualBondPriceCalculatorHome[DbGenericCalculatorHome]
2009-10-05 12:37:58.880 -0400 INFO [pool-1-thread-1] unknown: refreshing home for - USG08010BH52 BidAskAssetSwapSpreadCalculatorHome[DbGenericCalculatorHome]
2009-10-05 12:37:59.036 -0400 INFO [pool-1-thread-1] unknown: Component [InstrumentMaintPersistenceManager]: Loaded USG08010BH52 from db
2009-10-05 12:37:59.036 -0400 ERROR [StagingLatamCalcCycle] cpratesdev: Last calc cycle #248 interval (6563ms) exceeded configured maximum


# The followign change is required to TransactionalQueryRunner

connection.setAutoCommit(true); // because of unchained

# Check the following

    insert into SubTreeNodes (
      SubTreeRef,
      NodeRef,
      Version,
      RecordStatus,
      ServerName,
      CreatorRef,
      CreationDatetime,
      UpdaterRef,
      UpdateDatetime)
    values (
      "StagingLatam",
      "USG08010BH52",
      1,
      'C',
      "script",
      "gallane",
      getdate(),
      "gallane",
      getdate())

# Problem query when loading instruments

select 
    STN.SubTreeRef, 
    STN.NodeRef, 
    ST.OutputFlags 
from 
    SubTreeNodesView STN, 
    TreeView T, 
    SubTreeView ST 
where 
    STN.SubTreeRef = ST.SubTreeId 
and 
    ST.TreeRef = T.TreeId  
and 
    STN.NodeRef = 'XS0282340230' 
and 
    T.TreeId = 'StagingLatam'

# Run this to find good bonds

select * from Node where NodeSetRef = 'LATAM_BR_Corp'

# For some reason the following SQL error occurs

2009-10-02 10:54:43.052 -0400 ERROR [pool-1-thread-1] unknown: Error running queries for: 196: Error executing Query { call appLATAMEcnCreateBond( 'Corp', 196, 'TGNOAR 7.5 31/12/12 ', '', 'TGNOAR', '', 0.075, 'Dec 31 2012', '129-ISMA-USD', 'USD', 'ARGENTINA', 'AR', '** IN DEFAULT **', 'REGS', 4.3529466E7, 'Sep 30 2006', 'Sep 30 2006', 0.0, 'Dec 31 2006', 0.01875, 'Sep 30 2012', 1.0, 'Y', '0' ) } | Stored procedure 'appLATAMEcnCreateBond' may be run only in unchained transaction mode. The 'SET CHAINED OFF' command will cause the current session to use unchained transaction mode.
(state:ZZZZZ) | : Stack Trace: com.rbsfm.common.persist.SQLRuntimeException: Error executing Query { call appLATAMEcnCreateBond( 'Corp', 196, 'TGNOAR 7.5 31/12/12 ', '', 'TGNOAR', '', 0.075, 'Dec 31 2012', '129-ISMA-USD', 'USD', 'ARGENTINA', 'AR', '** IN DEFAULT **', 'REGS', 4.3529466E7, 'Sep 30 2006', 'Sep 30 2006', 0.0, 'Dec 31 2006', 0.01875, 'Sep 30 2012', 1.0, 'Y', '0' ) } | Stored procedure 'appLATAMEcnCreateBond' may be run only in unchained transaction mode. The 'SET CHAINED OFF' command will cause the current session to use unchained transaction mode.
(state:ZZZZZ) | 
	at com.rbsfm.common.persist.Query.executeStatement(Query.java:408)
	at com.rbsfm.common.persist.Query.execute(Query.java:680)
	at com.rbsfm.fi.staticdata.persist.TransactionalQueryRunner.runQuery(TransactionalQueryRunner.java:103)
	at com.rbsfm.fi.staticdata.persist.TransactionalQueryRunner.runQueries(TransactionalQueryRunner.java:58)
	at com.rbsfm.fi.instmaint.persist.InstrumentMaintPersistenceManager.persist(InstrumentMaintPersistenceManager.java:323)
	at com.rbsfm.fi.instmaint.persist.InstrumentMaintPersistenceManager.addInstrument(InstrumentMaintPersistenceManager.java:237)
	at com.rbsfm.fi.instmaint.persist.InstrumentMaintPersistenceManager.onEvent(InstrumentMaintPersistenceManager.java:139)
	at com.rbsfm.fi.instmaint.InstrumentMaintLifeCycleManager.notify(InstrumentMaintLifeCycleManager.java:137)
	at com.rbsfm.fi.instmaint.InstrumentMaintLifeCycleManager.newInstrumentRequest(InstrumentMaintLifeCycleManager.java:43)
	at com.rbsfm.fi.instmaint.StaticDataMonitor.processInstrumentStaticNew(StaticDataMonitor.java:131)
	at com.rbsfm.fi.instmaint.StaticDataMonitor.access$100(StaticDataMonitor.java:24)
	at com.rbsfm.fi.instmaint.StaticDataMonitor$2.handle(StaticDataMonitor.java:52)
	at com.rbsfm.fi.instmaint.StaticDataMonitor$5.run(StaticDataMonitor.java:90)
	at java.util.concurrent.ThreadPoolExecutor$Worker.runTask(ThreadPoolExecutor.java:885)
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:907)
	at java.lang.Thread.run(Thread.java:619)
Caused by: com.sybase.jdbc3.jdbc.SybSQLException: Stored procedure 'appLATAMEcnCreateBond' may be run only in unchained transaction mode. The 'SET CHAINED OFF' command will cause the current session to use unchained transaction mode.

	at com.sybase.jdbc3.tds.Tds.processEed(Tds.java:3069)
	at com.sybase.jdbc3.tds.Tds.nextResult(Tds.java:2373)
	at com.sybase.jdbc3.jdbc.ResultGetter.nextResult(ResultGetter.java:69)
	at com.sybase.jdbc3.jdbc.SybStatement.nextResult(SybStatement.java:220)
	at com.sybase.jdbc3.jdbc.SybStatement.nextResult(SybStatement.java:203)
	at com.sybase.jdbc3.jdbc.SybStatement.executeLoop(SybStatement.java:1875)
	at com.sybase.jdbc3.jdbc.SybCallableStatement.execute(SybCallableStatement.java:157)
	at com.rbsfm.common.persist.Query.tryExecuteStatement(Query.java:507)
	at com.rbsfm.common.persist.Query.executeStatement(Query.java:405)
	... 15 more


# Generates this

[{ call appLATAMEcnCreateBond( 'Corp', 196, 'TGNOAR 7.5 31/12/12 ', '', 'TGNOAR', '', 0.075, 'Dec 31 2012', '129-ISMA-USD', 'USD', 'ARGENTINA', 'AR', '** IN DEFAULT **', 'REGS', 4.3529466E7, 'Sep 30 2006', 'Sep 30 2006', 0.0, 'Dec 31 2006', 0.01875, 'Sep 30 2012', 1.0, 'Y', '0' ) }, { call appLATAMEcnCreateBond( 196, 'EF7533211', 0.0, 4.3529466E7 ) }, { call appLoadLATAMSanData( 196, false ) }, { call appCreateStagingCalculator( 196, 'Loaded', '', '', 'LATAM_BR_Corp', 'Y', 'Y', 'gallane' ) }]

# SQL as XML
           <sqlSP name="appCreateLATAM" onUpdate="false" onUpdateLive="false">
                <parameters>
		    <parameter name="@CorpOrSov" from="${AttributeNames.SD_MARKET_SECTOR}"/>
                    <parameter name="@BondNodeRef" from="${AttributeNames.SD_ALT_INSTRUMENT_TYPE_ISIN}"/>
                    <parameter name="@BondName" from="${AttributeNames.SD_BOND_DISPLAY_NAME}"/>
                    <parameter name="@AliasName" value=""/>
                    <parameter name="@BondTicker" from="${AttributeNames.SD_BLOOMBERG_TICKER}"/>
                    <parameter name="@AssociatedCurve" value=""/>
                    <parameter name="@Coupon" from="${AttributeNames.SD_COUPON}" type="Double"/>
                    <parameter name="@MaturityDate" from="${AttributeNames.SD_MATURITY_DATE}"/>
                    <parameter name="@BondTypeRef" from="${AttributeNames.SD_BOND_TYPE_REF}"/>
		    <parameter name="@Currency" from="${AttributeNames.SD_CURRENCY}"/>
                    <parameter name="@Country" from="${AttributeNames.SD_COUNTRY_FULL_NAME}"/>
                    <parameter name="@CountryISO" from="${AttributeNames.SD_COUNTRY_CODE}"/> 
		    <parameter name="@BondCalcType" from="${AttributeNames.SD_CALC_TYPE_DES}"/> 
                    <parameter name="@Series" from="${AttributeNames.SD_SERIES}" type="Double"/>
                    <parameter name="@IssueSize" from="${AttributeNames.SD_ISSUE_SIZE}" type="Double"/>
                    <parameter name="@FirstAccrualDate" from="${AttributeNames.SD_FIRST_ACCRUAL_DATE}"/>
                    <parameter name="@FirstSettlementDate" from="${AttributeNames.SD_FIRST_SETTLEMENT_DATE}"/>
                    <parameter name="@FirstCouponAmount" from="${AttributeNames.SD_FIRST_COUPON_AMOUNT}" type="Double" default="0.0"/>
                    <parameter name="@FirstCouponDate" from="${AttributeNames.SD_FIRST_COUPON_DATE}"/>
                    <parameter name="@LastCouponAmount" from="${AttributeNames.SD_LAST_COUPON_AMOUNT}" type="Double" default="0.0"/>
                    <parameter name="@LastCouponDate" from="${AttributeNames.SD_LAST_COUPON_DATE}"/>
                    <parameter name="@RedemptionAmount" from="${AttributeNames.SD_REDEMPTION_AMOUNT}" type="Double"/>
                    <parameter name="@IsCodeISIN" value="Y"/>
		    <parameter name="@IsOnRun" value="0" type="Integer"/>
		    <parameter name="@SubTreeRef" value="StagingLatam"/>
                </parameters>
            </sqlSP>
            <sqlSP name="appLATAMEcnCreateBond" onUpdate="false" onUpdateLive="false">
                <parameters>
                    <parameter name="@InstrumentRef" from="${AttributeNames.SD_ALT_INSTRUMENT_TYPE_ISIN}"/>
                    <parameter name="@Cusip" from="${AttributeNames.SD_ALT_INSTRUMENT_TYPE_CUSIP}"/>
		    <parameter name="@BloombergSpread" from="${AttributeNames.SD_BASIC_SPREAD}" type="Double"/> 
		    <parameter name="@BloombergSize" from="${AttributeNames.SD_ISSUE_SIZE}" type="Double"/> 
                </parameters>
            </sqlSP>
            <sqlSP name="appLoadLATAMSanData" onUpdate="false" onUpdateLive="false">
                <parameters>
                    <parameter name="@InstrumentId" from="${AttributeNames.SD_ALT_INSTRUMENT_TYPE_ISIN}"/>
		    <parameter name="@IsFRN" from="${AttributeNames.SD_IS_FRN}" type="String"/>
                </parameters>
	    </sqlSP>
            <sqlSP name="appCreateStagingCalculator" >
               <parameters>
                 <parameter name="@BondNodeRef" from="${AttributeNames.SD_ALT_INSTRUMENT_TYPE_ISIN}"/>
                 <parameter name="@StageLiveStatus" value="Loaded" />
                 <parameter name="@StageBook" value="" />
                 <parameter name="@PostStagingSectorOpts" value="" />
                 <parameter name="@PostStagingSector" from="${AttributeNames.IM_SECTOR}"/>
                 <parameter name="@StageBB" value="Y" />
                 <parameter name="@StageALLQ" value="Y" />
                 <parameter name="@StageRequestor" from="${AttributeNames.IM_REQUESTOR}" />
           </parameters>

# Persistence error with he bond static stuff

2009-10-02 07:20:26.078 -0400 ERROR [pool-1-thread-1] unknown: Control[StaticDataMonitor]: Unable to process instrument message: (PersistableObject.NotFoundException:Expected one object but instead found 0 in the database using query  select STN.SubTreeRef, STN.NodeRef, ST.OutputFlags from SubTreeNodesView STN, TreeView T, SubTreeView ST where STN.SubTreeRef = ST.SubTreeId and ST.TreeRef = T.TreeId  and STN.NodeRef = '196' and T.TreeId = 'StagingLatam': Expected one object but instead found 0 in the database using query  select STN.SubTreeRef, STN.NodeRef, ST.OutputFlags from SubTreeNodesView STN, TreeView T, SubTreeView ST where STN.SubTreeRef = ST.SubTreeId and ST.TreeRef = T.TreeId  and STN.NodeRef = '196' and T.TreeId = 'StagingLatam': Stack Trace: com.rbsfm.common.persist.PersistableObject$NotFoundException: Expected one object but instead found 0 in the database using query  select STN.SubTreeRef, STN.NodeRef, ST.OutputFlags from SubTreeNodesView STN, TreeView T, SubTreeView ST w
here STN.SubTreeRef = ST.SubTreeId and ST.TreeRef = T.TreeId  and STN.NodeRef = '196' and T.TreeId = 'StagingLatam'
        at com.rbsfm.common.persist.PersistableObject.get(PersistableObject.java:36)
        at com.rbsfm.fi.pricing.dependency.simple.DbSubTreeNodeHome.reloadSubTree(DbSubTreeNodeHome.java:338)
        at com.rbsfm.fi.pricing.dependency.tree.AbstractTreePersistenceManager.refreshSubTree(AbstractTreePersistenceManager.java:298)
        at com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree.refreshSubTree(AbstractDependencyTree.java:564)
        at com.rbsfm.fi.instmaint.persist.InstrumentMaintPersistenceManager.loadBond(InstrumentMaintPersistenceManager.java:381)
        at com.rbsfm.fi.instmaint.persist.InstrumentMaintPersistenceManager.addInstrument(InstrumentMaintPersistenceManager.java:241)
        at com.rbsfm.fi.instmaint.persist.InstrumentMaintPersistenceManager.onEvent(InstrumentMaintPersistenceManager.java:139)
        at com.rbsfm.fi.instmaint.InstrumentMaintLifeCycleManager.notify(InstrumentMaintLifeCycleManager.java:137)
        at com.rbsfm.fi.instmaint.InstrumentMaintLifeCycleManager.newInstrumentRequest(InstrumentMaintLifeCycleManager.java:43)
        at com.rbsfm.fi.instmaint.StaticDataMonitor.processInstrumentStaticNew(StaticDataMonitor.java:131)
        at com.rbsfm.fi.instmaint.StaticDataMonitor.access$100(StaticDataMonitor.java:24)
        at com.rbsfm.fi.instmaint.StaticDataMonitor$2.handle(StaticDataMonitor.java:52)
        at com.rbsfm.fi.instmaint.StaticDataMonitor$5.run(StaticDataMonitor.java:90)
        at java.util.concurrent.ThreadPoolExecutor$Worker.runTask(ThreadPoolExecutor.java:885)
        at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:907)
        at java.lang.Thread.run(Thread.java:619)

2009-10-02 07:20:29.500 -0400 INFO [InstMaintSink:4868<-stams00058:25550] unknown: SocketClientSink [InstMaintSink]: connected
2009-10-02 07:20:29.500 -0400 INFO [SocketServerSource] unknown: accepted connection from stams00058:4868
2009-10-02 07:20:29.516 -0400 INFO [SocketServerSource(bind)stams00058:4868] unknown: Control[SocketServerSource]: internalHandleConnection(): HANDLING connection STAMS00058.fm.rbsgrp.net/11.176.198.188:25550
2009-10-02 07:20:29.516 -0400 INFO [SocketServerSource(bind)stams00058:4868] unknown: Subscription delegate [SubscriptionDelegate is configured to unpack multipart subscription messages automatically
2009-10-02 07:20:29.516 -0400 INFO [SocketServerSource(bind)stams00058:4868] unknown: SocketQueueMonitor[SocketServerSource(Async)->stams00058:4868]:start(): STARTING
2009-10-02 07:20:29.516 -0400 INFO [SocketServerSource(bind)stams00058:4868] unknown: SocketQueueMonitor[SocketServerSource(Async)->stams00058:4868]:start(): STARTED.
2009-10-02 07:20:29.516 -0400 INFO [SocketServerSource(bind)stams00058:4868] unknown: Requesting bootstrap

# Arrival from the static data server

com.rbsfm.fi.instmaint.persist.InstrumentMaintPersistenceManager.persist(com.rbsfm.fi.pricing.util.AttributeMap, com.rbsfm.fi.instmaint.InstrumentEventListener$Event, com.rbsfm.fi.pricing.util.AttributeMap) line: 306	
com.rbsfm.fi.instmaint.persist.InstrumentMaintPersistenceManager.addInstrument(com.rbsfm.fi.pricing.util.AttributeMap, com.rbsfm.fi.instmaint.InstrumentEventListener$Event) line: 237	
com.rbsfm.fi.instmaint.persist.InstrumentMaintPersistenceManager.onEvent(com.rbsfm.fi.pricing.util.AttributeMap, com.rbsfm.fi.instmaint.InstrumentEventListener$Event) line: 139	
com.rbsfm.fi.instmaint.InstrumentMaintLifeCycleManager.notify(com.rbsfm.fi.pricing.util.AttributeMap, java.util.List<com.rbsfm.fi.instmaint.InstrumentEventListener>, com.rbsfm.fi.instmaint.InstrumentEventListener.Event) line: 137	
com.rbsfm.fi.instmaint.InstrumentMaintLifeCycleManager.newInstrumentRequest(com.rbsfm.fi.pricing.util.AttributeMap) line: 43	
com.rbsfm.fi.instmaint.StaticDataMonitor.processInstrumentStaticNew(com.rbsfm.fi.pricing.mux.Message) line: 131	
com.rbsfm.fi.instmaint.StaticDataMonitor.access$100(com.rbsfm.fi.instmaint.StaticDataMonitor, com.rbsfm.fi.pricing.mux.Message) line: 24	
com.rbsfm.fi.instmaint.StaticDataMonitor$2.handle(com.rbsfm.fi.pricing.mux.Message) line: 52	
com.rbsfm.fi.instmaint.StaticDataMonitor$5.run() line: 90	
java.util.concurrent.ThreadPoolExecutor$Worker.runTask(java.lang.Runnable) line: 885	
java.util.concurrent.ThreadPoolExecutor$Worker.run() line: 907	
java.lang.Thread.run() line: 619	

# Copied the EuroGov bond implementation to the LATAM one

com.rbsfm.fi.pricing.bloomberg.EuroGovBloombergBondDataImpl -> com.rbsfm.fi.pricing.bloomberg.LATAMBloombergBondDataImpl

# This is the log required

2009-10-02 12:01:30.502 +0100 INFO [pool-4-thread-1] unknown: ConfigurableComponentManager creating component. Name: 'DESEncryption' Class: 'com.rbsfm.commonx.bloomberg.bdl.DESEncryption'...
2009-10-02 12:01:30.518 +0100 INFO [pool-4-thread-1] unknown: <BloombergDataRetriever> About to add 1 request items
2009-10-02 12:01:30.518 +0100 INFO [pool-4-thread-1] unknown: <BloombergDataRetriever> Added 1 bonds to request
2009-10-02 12:01:30.518 +0100 INFO [pool-4-thread-1] unknown: <BloombergDataRetriever> About to add 1 request items
2009-10-02 12:01:30.518 +0100 INFO [pool-4-thread-1] unknown: <BloombergDataRetriever> Added 1 bonds to request
2009-10-02 12:01:30.518 +0100 INFO [pool-4-thread-1] unknown: <BloombergDataRetriever> About to add 1 request items
2009-10-02 12:01:30.518 +0100 INFO [pool-4-thread-1] unknown: <BloombergDataRetriever> Added 1 bonds to request
2009-10-02 12:01:30.518 +0100 INFO [pool-4-thread-1] unknown: <BloombergDataRetriever> About to add 1 request items
2009-10-02 12:01:30.518 +0100 INFO [pool-4-thread-1] unknown: <BloombergDataRetriever> Added 1 bonds to request
2009-10-02 12:01:30.518 +0100 INFO [pool-4-thread-1] unknown: <BloombergDataRetriever> About to add 1 request items
2009-10-02 12:01:30.534 +0100 INFO [pool-4-thread-1] unknown: <BloombergDataRetriever> Added 1 bonds to request
2009-10-02 12:01:30.534 +0100 INFO [pool-4-thread-1] unknown: <BloombergDataRetriever> About to add 1 request items
2009-10-02 12:01:30.534 +0100 INFO [pool-4-thread-1] unknown: <BloombergDataRetriever> Added 1 bonds to request
2009-10-02 12:01:30.534 +0100 INFO [pool-4-thread-1] unknown: <BloombergDataRetriever> About to add 1 request items
2009-10-02 12:01:30.534 +0100 INFO [pool-4-thread-1] unknown: <BloombergDataRetriever> Added 1 bonds to request
2009-10-02 12:01:30.534 +0100 INFO [pool-4-thread-1] unknown: Reusing existing static response
2009-10-02 12:01:30.534 +0100 INFO [pool-4-thread-1] unknown: Reusing existing cashflow response
2009-10-02 12:01:30.534 +0100 INFO [pool-4-thread-1] unknown: Reusing existing call schedule response
2009-10-02 12:01:30.534 +0100 INFO [pool-4-thread-1] unknown: Reusing existing put schedule response
2009-10-02 12:01:30.534 +0100 INFO [pool-4-thread-1] unknown: Reusing existing step up response
2009-10-02 12:01:30.534 +0100 INFO [pool-4-thread-1] unknown: Reusing existing margin response
2009-10-02 12:01:30.534 +0100 INFO [pool-4-thread-1] unknown: Reusing existing syndicate response
2009-10-02 12:01:30.534 +0100 WARNING [pool-4-thread-1] unknown: data length not the same as headings supplied ignoring, US05963GAF54|0|1| |
2009-10-02 12:01:30.534 +0100 WARNING [pool-4-thread-1] unknown: data length not the same as headings supplied ignoring, US05963GAF54|0|1| |
2009-10-02 12:01:30.534 +0100 WARNING [pool-4-thread-1] unknown: data length not the same as headings supplied ignoring, US05963GAF54|0|1| |
2009-10-02 12:01:30.534 +0100 WARNING [pool-4-thread-1] unknown: data length not the same as headings supplied ignoring, US05963GAF54|0|1| |
2009-10-02 12:01:30.534 +0100 WARNING [pool-4-thread-1] unknown: data length not the same as headings supplied ignoring, US05963GAF54|0|1| |
2009-10-02 12:02:31.443 +0100 INFO [pool-4-thread-1] unknown: Control[InstrumentHome]: Running: { call appInitialiseStaticData( 'BOND', 'US05963GAF54', 'ISIN', 1, 'StaticDataServer', 'InstrumentStaticPersistenceManager', null(4) ) }
2009-10-02 12:02:31.568 +0100 INFO [pool-4-thread-1] unknown: Control[InstrumentHome]: Created initial skeleton instrument for US05963GAF54 - internal instrumentId = 195
2009-10-02 12:02:31.568 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'FirstCouponDate', 'DATETIME', 0, 0.0, 'Feb 01 2008', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.615 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'MtgDealName', 'STRING', 0, 0.0, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.615 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'RatingFitch', 'STRING', 0, 0.0, 'N/A', 'N.S.', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.615 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'BasicSpread', 'FLOAT', 0, 0.0, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.615 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'requestor', 'STRING', 0, 0.0, 'N/A', 'gallane', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.630 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'IssueSize', 'FLOAT', 0, 1.492E8, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.630 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'IndustrySector', 'STRING', 0, 0.0, 'N/A', 'Financial', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.630 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'BondTypeRef', 'STRING', 0, 0.0, 'N/A', 'CORP-USD-30E360:S', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.630 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'UnderReg144A', 'BOOLEAN', 0, 0.0, 'N/A', 'N', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.646 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'FirstCouponAmount', 'FLOAT', 0, 0.0425, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.646 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'StaticVersion', 'INT', 1, 0.0, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.646 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'Currency', 'STRING', 0, 0.0, 'N/A', 'USD', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.646 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'MtgPrincWinCall', 'STRING', 0, 0.0, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.646 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'MtgPxSpd', 'STRING', 0, 0.0, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.646 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'BondDisplayName', 'STRING', 0, 0.0, 'N/A', 'BMAAR 8.5 01/02/17 ', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.662 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'IsPerpetual', 'BOOLEAN', 0, 0.0, 'N/A', 'N', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.662 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'CalcTypeDes', 'STRING', 0, 0.0, 'N/A', 'STREET CONVENTION', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.662 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'CouponFrequency', 'INT', 2, 0.0, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.677 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'FirstSettlementDate', 'DATETIME', 0, 0.0, 'Sep 18 2007', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.677 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'RatingStandardAndPoor', 'STRING', 0, 0.0, 'N/A', 'N.A.', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.677 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'MtgOrigWac', 'FLOAT', 0, 0.0, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.677 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'MtgFaceAmount', 'FLOAT', 0, 0.0, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.677 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'Series', 'STRING', 0, 0.0, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.677 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'Coupon', 'FLOAT', 0, 0.085, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.677 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'DayCount', 'STRING', 0, 0.0, 'N/A', '30E360', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.693 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'BBCountryCode', 'STRING', 0, 0.0, 'N/A', 'AR', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.693 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'BondDescription', 'STRING', 0, 0.0, 'N/A', 'BMAAR 8 1/2 02/01/17', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.693 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'CallableNoticePeriod', 'INT', 0, 0.0, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.693 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'Called', 'BOOLEAN', 0, 0.0, 'N/A', 'N', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.693 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'RedemptionAmount', 'FLOAT', 0, 1.0, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.693 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'IsFrn', 'BOOLEAN', 0, 0.0, 'N/A', 'N', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.693 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'MarketSector', 'STRING', 0, 0.0, 'N/A', 'Corp', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.693 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'MtgOrigWal', 'FLOAT', 0, 0.0, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.693 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'MtgOrigWam', 'FLOAT', 0, 0.0, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.693 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'MaturityDate', 'DATETIME', 0, 0.0, 'Feb 01 2017', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.693 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'ResetIndex', 'STRING', 0, 0.0, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.709 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'IndustrySubgroup', 'STRING', 0, 0.0, 'N/A', 'Commer Banks Non-US', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.709 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'Sinkable', 'BOOLEAN', 0, 0.0, 'N/A', 'N', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.709 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'FirstAccrualDate', 'DATETIME', 0, 0.0, 'Aug 01 2007', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.709 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'CountryCode', 'STRING', 0, 0.0, 'N/A', 'AR', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.709 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'CountryFullName', 'STRING', 0, 0.0, 'N/A', 'ARGENTINA', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.709 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'LastCouponAmount', 'FLOAT', 0, 0.0425, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.709 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'NextCouponDate', 'DATETIME', 0, 0.0, 'Feb 01 2010', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.709 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'MtgOrigAmount', 'FLOAT', 0, 0.0, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.709 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'RatingMoody', 'STRING', 0, 0.0, 'N/A', 'B2', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.709 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'CouponType', 'STRING', 0, 0.0, 'N/A', 'FIXED', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.709 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'LastCouponDate', 'DATETIME', 0, 0.0, 'Aug 01 2016', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.724 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'InstrumentId', 'INT', 195, 0.0, 'N/A', '', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.724 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'BloombergTicker', 'STRING', 0, 0.0, 'N/A', 'BMAAR', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.724 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentAttributeStore( 195, 'FullBondName', 'STRING', 0, 0.0, 'N/A', 'Banco Macro Sa', 1, 0, 'StaticDataServer', 'InstrumentAttributeDbHome' ) }
2009-10-02 12:02:31.724 +0100 INFO [pool-4-thread-1] unknown: Running: { call AltInstrumentIdStore( 195, '05963GAF5', 'Cusip', 1, 0, 'StaticDataServer', 'AltInstrumentIdDbHome' ) }
2009-10-02 12:02:31.724 +0100 INFO [pool-4-thread-1] unknown: Running: { call AltInstrumentIdStore( 195, 'COEG7514144', 'BloombergUnique', 1, 0, 'StaticDataServer', 'AltInstrumentIdDbHome' ) }
2009-10-02 12:02:31.724 +0100 INFO [pool-4-thread-1] unknown: Running: { call AltInstrumentIdStore( 195, 'EG7514144', 'Bloomberg', 1, 0, 'StaticDataServer', 'AltInstrumentIdDbHome' ) }
2009-10-02 12:02:31.724 +0100 INFO [pool-4-thread-1] unknown: Running: { call AltInstrumentIdStore( 195, 'US05963GAF54', 'ISIN', 1, 0, 'StaticDataServer', 'AltInstrumentIdDbHome' ) }
2009-10-02 12:02:31.724 +0100 INFO [pool-4-thread-1] unknown: Running: { call ScheduleStore( 195, 'CashFlow', 'BLOOMBERG', 'Feb 01 2010', 0.0, 0.0, 42500.0, 0.0, 0.0, 1, 0, 'StaticDataServer', 'SchedulesDbHome' ) }
2009-10-02 12:02:31.771 +0100 INFO [pool-4-thread-1] unknown: Running: { call ScheduleStore( 195, 'CashFlow', 'BLOOMBERG', 'Aug 01 2010', 0.0, 0.0, 42500.0, 0.0, 0.0, 1, 0, 'StaticDataServer', 'SchedulesDbHome' ) }
2009-10-02 12:02:31.771 +0100 INFO [pool-4-thread-1] unknown: Running: { call ScheduleStore( 195, 'CashFlow', 'BLOOMBERG', 'Feb 01 2011', 0.0, 0.0, 42500.0, 0.0, 0.0, 1, 0, 'StaticDataServer', 'SchedulesDbHome' ) }
2009-10-02 12:02:31.771 +0100 INFO [pool-4-thread-1] unknown: Running: { call ScheduleStore( 195, 'CashFlow', 'BLOOMBERG', 'Aug 01 2011', 0.0, 0.0, 42500.0, 0.0, 0.0, 1, 0, 'StaticDataServer', 'SchedulesDbHome' ) }
2009-10-02 12:02:31.771 +0100 INFO [pool-4-thread-1] unknown: Running: { call ScheduleStore( 195, 'CashFlow', 'BLOOMBERG', 'Feb 01 2012', 0.0, 0.0, 42500.0, 0.0, 0.0, 1, 0, 'StaticDataServer', 'SchedulesDbHome' ) }
2009-10-02 12:02:31.787 +0100 INFO [pool-4-thread-1] unknown: Running: { call ScheduleStore( 195, 'CashFlow', 'BLOOMBERG', 'Aug 01 2012', 0.0, 0.0, 42500.0, 0.0, 0.0, 1, 0, 'StaticDataServer', 'SchedulesDbHome' ) }
2009-10-02 12:02:31.787 +0100 INFO [pool-4-thread-1] unknown: Running: { call ScheduleStore( 195, 'CashFlow', 'BLOOMBERG', 'Feb 01 2013', 0.0, 0.0, 42500.0, 0.0, 0.0, 1, 0, 'StaticDataServer', 'SchedulesDbHome' ) }
2009-10-02 12:02:31.787 +0100 INFO [pool-4-thread-1] unknown: Running: { call ScheduleStore( 195, 'CashFlow', 'BLOOMBERG', 'Aug 01 2013', 0.0, 0.0, 42500.0, 0.0, 0.0, 1, 0, 'StaticDataServer', 'SchedulesDbHome' ) }
2009-10-02 12:02:31.787 +0100 INFO [pool-4-thread-1] unknown: Running: { call ScheduleStore( 195, 'CashFlow', 'BLOOMBERG', 'Feb 01 2014', 0.0, 0.0, 42500.0, 0.0, 0.0, 1, 0, 'StaticDataServer', 'SchedulesDbHome' ) }
2009-10-02 12:02:31.787 +0100 INFO [pool-4-thread-1] unknown: Running: { call ScheduleStore( 195, 'CashFlow', 'BLOOMBERG', 'Aug 01 2014', 0.0, 0.0, 42500.0, 0.0, 0.0, 1, 0, 'StaticDataServer', 'SchedulesDbHome' ) }
2009-10-02 12:02:31.787 +0100 INFO [pool-4-thread-1] unknown: Running: { call ScheduleStore( 195, 'CashFlow', 'BLOOMBERG', 'Feb 01 2015', 0.0, 0.0, 42500.0, 0.0, 0.0, 1, 0, 'StaticDataServer', 'SchedulesDbHome' ) }
2009-10-02 12:02:31.787 +0100 INFO [pool-4-thread-1] unknown: Running: { call ScheduleStore( 195, 'CashFlow', 'BLOOMBERG', 'Aug 01 2015', 0.0, 0.0, 42500.0, 0.0, 0.0, 1, 0, 'StaticDataServer', 'SchedulesDbHome' ) }
2009-10-02 12:02:31.802 +0100 INFO [pool-4-thread-1] unknown: Running: { call ScheduleStore( 195, 'CashFlow', 'BLOOMBERG', 'Feb 01 2016', 0.0, 0.0, 42500.0, 0.0, 0.0, 1, 0, 'StaticDataServer', 'SchedulesDbHome' ) }
2009-10-02 12:02:31.802 +0100 INFO [pool-4-thread-1] unknown: Running: { call ScheduleStore( 195, 'CashFlow', 'BLOOMBERG', 'Aug 01 2016', 0.0, 0.0, 42500.0, 0.0, 0.0, 1, 0, 'StaticDataServer', 'SchedulesDbHome' ) }
2009-10-02 12:02:31.802 +0100 INFO [pool-4-thread-1] unknown: Running: { call ScheduleStore( 195, 'CashFlow', 'BLOOMBERG', 'Feb 01 2017', 0.0, 0.0, 42500.0, 0.0, 1000000.0, 1, 0, 'StaticDataServer', 'SchedulesDbHome' ) }
2009-10-02 12:02:31.802 +0100 INFO [pool-4-thread-1] unknown: Running: { call InstrumentStatusStore( 195, 'STAGING', 0, 'StaticDataServer', 'InstrumentStatusDbHome' ) }
2009-10-02 12:02:31.849 +0100 INFO [pool-4-thread-1] unknown: Component [StaticDataMessageDispatcher]: Sending instrument message for US05963GAF54 with status STAGING
2009-10-02 12:02:31.865 +0100 INFO [pool-4-thread-1] unknown: Component [StaticDataMessageDispatcher]: Instrument message = id=US05963GAF54, type=StaticDataNew msg=sector[LATAM_BR_Corp,OK] InstrumentIdType[ISIN,OK] FirstCouponDate[2008-02-01,OK] MtgDealName[,OK] RatingFitch[N.S.,OK] BasicSpread[0.0,OK] requestor[gallane,OK] IndustrySector[Financial,OK] IssueSize[1.492E8,OK] BondTypeRef[CORP-USD-30E360:S,OK] UnderReg144A[false,OK] CashFlow[Source=BLOOMBERG:Amount=0.0:Repayment=0.0:Principal=0.0:Interest=42500.0:Date=2010-02-01:Type=CashFlow:Coupon=0.0,Source=BLOOMBERG:Amount=0.0:Repayment=0.0:Principal=0.0:Interest=42500.0:Date=2010-08-01:Type=CashFlow:Coupon=0.0,Source=BLOOMBERG:Amount=0.0:Repayment=0.0:Principal=0.0:Interest=42500.0:Date=2011-02-01:Type=CashFlow:Coupon=0.0,Source=BLOOMBERG:Amount=0.0:Repayment=0.0:Principal=0.0:Interest=42500.0:Date=2011-08-01:Type=CashFlow:Coupon=0.0,Source=BLOOMBERG:Amount=0.0:Repayment=0.0:Principal=0.0:Interest=42500.0:Date=2012-02-01:Type=CashFlo
w:Coupon=0.0,Source=BLOOMBERG:Amount=0.0:Repayment=0.0:Principal=0.0:Interest=42500.0:Date=2012-08-01:Type=CashFlow:Coupon=0.0,Source=BLOOMBERG:Amount=0.0:Repayment=0.0:Principal=0.0:Interest=42500.0:Date=2013-02-01:Type=CashFlow:Coupon=0.0,Source=BLOOMBERG:Amount=0.0:Repayment=0.0:Principal=0.0:Interest=42500.0:Date=2013-08-01:Type=CashFlow:Coupon=0.0,Source=BLOOMBERG:Amount=0.0:Repayment=0.0:Principal=0.0:Interest=42500.0:Date=2014-02-01:Type=CashFlow:Coupon=0.0,Source=BLOOMBERG:Amount=0.0:Repayment=0.0:Principal=0.0:Interest=42500.0:Date=2014-08-01:Type=CashFlow:Coupon=0.0,Source=BLOOMBERG:Amount=0.0:Repayment=0.0:Principal=0.0:Interest=42500.0:Date=2015-02-01:Type=CashFlow:Coupon=0.0,Source=BLOOMBERG:Amount=0.0:Repayment=0.0:Principal=0.0:Interest=42500.0:Date=2015-08-01:Type=CashFlow:Coupon=0.0,Source=BLOOMBERG:Amount=0.0:Repayment=0.0:Principal=0.0:Interest=42500.0:Date=2016-02-01:Type=CashFlow:Coupon=0.0,Source=BLOOMBERG:Amount=0.0:Repayment=0.0:Principal=0.0:Interest=42500.0:Da
te=2016-08-01:Type=CashFlow:Coupon=0.0,Source=BLOOMBERG:Amount=0.0:Repayment=0.0:Principal=1000000.0:Interest=42500.0:Date=2017-02-01:Type=CashFlow:Coupon=0.0,OK] FirstCouponAmount[0.0425,OK] StaticVersion[1,OK] Bloomberg[EG7514144,OK] MtgPrincWinCall[,OK] Currency[USD,OK] MtgPxSpd[,OK] BondDisplayName[BMAAR 8.5 01/02/17 ,OK] IsPerpetual[false,OK] Put[,OK] Call[,OK] CalcTypeDes[STREET CONVENTION,OK] CouponFrequency[2,OK] Valoren[,OK] FirstSettlementDate[2007-09-18,OK] RatingStandardAndPoor[N.A.,OK] MtgOrigWac[0.0,OK] MtgFaceAmount[0.0,OK] Series[,OK] Coupon[0.085,OK] BloombergUnique[COEG7514144,OK] PutNoticePeriod[null,OK] DayCount[30E360,OK] BBCountryCode[AR,OK] BondDescription[BMAAR 8 1/2 02/01/17,OK] CallableNoticePeriod[0,OK] Called[false,OK] StepUp[,OK] Cusip[05963GAF5,OK] RedemptionAmount[1.0,OK] IsFrn[false,OK] Redemption[null,OK] MarketSector[Corp,OK] MtgOrigWal[0.0,OK] MtgOrigWam[0.0,OK] MaturityDate[2017-02-01,OK] ResetIndex[,OK] IndustrySubgroup[Commer Banks Non-US,OK] Sinka
ble[false,OK] JapanShortCode[,OK] FirstAccrualDate[2007-08-01,OK] CountryCode[AR,OK] CountryFullName[ARGENTINA,OK] InstrumentStatus[STAGING,OK] LastCouponAmount[0.0425,OK] NextCouponDate[2010-02-01,OK] MtgOrigAmount[0.0,OK] ISIN[US05963GAF54,OK] ExDivDays[null,OK] RatingMoody[B2,OK] CouponType[FIXED,OK] LastCouponDate[2016-08-01,OK] FullBondName[Banco Macro Sa,OK] BloombergTicker[BMAAR,OK] InstrumentId[195,OK] Japan[,OK]
2009-10-02 12:02:31.865 +0100 INFO [pool-4-thread-1] unknown: Component [InstrumentStaticRequestHandler]: Finished handling request InstrumentStaticRequest[instrumentIdentifiers=[US05963GAF54],instrumentIdentifierType=ISIN,instrumentSource=BLOOMBERG,instrumentType=BOND,requestorDesk=LATAM,requestor=gallane,sector=LATAM_BR_Corp,reload=false,noSourceCache=false] . There were 1 results.

# Static data mappings

[< getPutSchedule->[Put] > < getStepupSchedule->[StepUp] > < getCashFlows->[CashFlow] > < getStaticData->[StaticData, AltInstrumentIds] > < getMarginSchedule->[Margin] > < getCallSchedule->[Call] > ]

# This is the config needed for static data

   <component name="BBInstrumentStaticDataSourceMapperLATAM" class_name="com.rbsfm.fi.staticdata.maintenance.InstrumentStaticDataSourceMapper">
    <mappedClass>com.rbsfm.fi.pricing.bloomberg.LATAMBloombergBondDataImpl</mappedClass>
    <methodMaps>
      <!--  sdRef values should be based on constants for example from AttributeNames
      		 NOTE: the mappedTo elements can be found in the mappedClass
      		 For a simple implementation you may only need the STATIC_DATA mapping
	    -->
	    <map sdRef="${AttributeNames.SD_CASH_FLOW}" mappedTo="getCashFlows">
	      <mappings><mapping key="${AttributeNames.SD_CASH_FLOW}" translator="CashFlowTranslator" /></mappings>
	    </map> 
	    <map sdRef="${AttributeNames.SD_CALL_SCHEDULE}" mappedTo="getCallSchedule">
	      <mappings><mapping key="${AttributeNames.SD_CALL_SCHEDULE}" translator="CallScheduleTranslator" /></mappings>
	    </map>
	    <map sdRef="${AttributeNames.SD_MARGIN_SCHEDULE}" mappedTo="getMarginSchedule">
	      <mappings></mappings>
	    </map>
	    <map sdRef="${AttributeNames.SD_PUT_SCHEDULE}" mappedTo="getPutSchedule">
	      <mappings><mapping key="${AttributeNames.SD_PUT_SCHEDULE}" translator="PutScheduleTranslator" /></mappings>
	    </map>
	    <map sdRef="${AttributeNames.SD_STEPUP_SCHEDULE}" mappedTo="getStepupSchedule">
	      <mappings><mapping key="${AttributeNames.SD_STEPUP_SCHEDULE}" translator="StepupScheduleTranslator" /></mappings>
	    </map>
	    <map sdRef="${AttributeNames.SD_STATIC_DATA}" mappedTo="getStaticData">
	      <mappings>
	        <mapping key="${AttributeNames.SD_BASIC_SPREAD}" translator="BasicSpreadTranslator" />
	        <mapping key="${AttributeNames.SD_COUPON_FREQUENCY}" translator="CouponFrequencyTranslator" />
          <mapping key="${AttributeNames.SD_CURRENCY}" translator="CurrencyTranslator" />
          <mapping key="${AttributeNames.SD_IS_FRN}" translator="FloatingRateNoteTranslator" />
          <mapping key="${AttributeNames.SD_FIRST_COUPON_DATE}" translator="FirstCouponDateTranslator" />
          <mapping key="${AttributeNames.SD_SINKABLE}" translator="SinkableTranslator" />
          <mapping key="${AttributeNames.SD_BOND_TYPE_REF}" translator="BondTypeRefTranslator" />
          <mapping key="${AttributeNames.SD_FULL_BOND_NAME}" translator="FullInstrumentNameTranslator" />
          <mapping key="${AttributeNames.SD_BOND_DESCRIPTION}" translator="BondDescriptionTranslator" />
          <mapping key="${AttributeNames.SD_BOND_DISPLAY_NAME}" translator="DisplayNameTranslator" />
          <mapping key="${AttributeNames.SD_IS_PERP}" translator="PerpetualTranslator" />
          <mapping key="${AttributeNames.SD_FIRST_SETTLEMENT_DATE}" translator="FirstSettlementDateTranslator" />
          <mapping key="${AttributeNames.SD_MATURITY_DATE}" translator="MaturityDateTranslator" />
          <mapping key="${AttributeNames.SD_NEXT_COUPON_DATE}" translator="NextCouponDateTranslator" />
          <mapping key="${AttributeNames.SD_BLOOMBERG_TICKER}" translator="TickerTranslator" />
          <mapping key="${AttributeNames.SD_CALC_TYPE_DES}" translator="CalcTypeDesTranslator" />
          <mapping key="${AttributeNames.SD_COUNTRY_CODE}" translator="CountryCodeTranslator" />
          <mapping key="${AttributeNames.SD_COUNTRY_FULL_NAME}" translator="CountryFullNameTranslator" />
          <mapping key="${AttributeNames.SD_COUPON}" translator="CouponTranslator" />
          <mapping key="${AttributeNames.SD_FIRST_ACCRUAL_DATE}" translator="FirstAccrualDateTranslator" />
          <mapping key="${AttributeNames.SD_FIRST_COUPON_AMOUNT}" translator="FirstCouponAmountTranslator" />
          <mapping key="${AttributeNames.SD_LAST_COUPON_AMOUNT}" translator="LastCouponAmountTranslator" />
          <mapping key="${AttributeNames.SD_LAST_COUPON_DATE}" translator="LastCouponDateTranslator" />
          <mapping key="${AttributeNames.SD_ISSUE_SIZE}" translator="IssueSizeTranslator" />
          <mapping key="${AttributeNames.SD_REDEMPTION_AMOUNT}" translator="RedemptionAmountTranslator" />
          <mapping key="${AttributeNames.SD_BB_COUNTRY_CODE}" translator="BBCountryCodeTranslator" />
          <mapping key="${AttributeNames.SD_CALLABLE_NOTICE_PERIOD}" translator="CallableNoticePeriodTranslator" />
          <mapping key="${AttributeNames.SD_CALLED}" translator="CalledTranslator" />
          <mapping key="${AttributeNames.SD_COUPON_TYPE}" translator="CouponType" />
          <mapping key="${AttributeNames.SD_DAY_COUNT}" translator="DayCountTranslator" />
          <mapping key="${AttributeNames.SD_EX_DIV_DAYS}" translator="ExDividendDays" />
          <mapping key="${AttributeNames.SD_INDUSTRY_SECTOR}" translator="IndustrySectorTranslator" />
          <mapping key="${AttributeNames.SD_INDUSTRY_SUBGROUP}" translator="IndustrySubgroupTranslator" />
          <mapping key="${AttributeNames.SD_MARKET_SECTOR}" translator="MarketSectorTranslator" />
          <mapping key="${AttributeNames.SD_MTG_DEAL_NAME}" translator="MtgDealNameTranslator" />
          <mapping key="${AttributeNames.SD_MTG_FACE_AMT}" translator="MtgFaceAmtTranslator" />
          <mapping key="${AttributeNames.SD_MTG_ORIG_AMT}" translator="MtgOrigAmtTranslator" />
          <mapping key="${AttributeNames.SD_MTG_ORIG_WAC}" translator="MtgOrigWacTranslator" />
          <mapping key="${AttributeNames.SD_MTG_ORIG_WAL}" translator="MtgOrigWalTranslator" />
          <mapping key="${AttributeNames.SD_MTG_ORIG_WAM}" translator="MtgOrigWamTranslator" />
          <mapping key="${AttributeNames.SD_MTG_PRINC_WIN_CALL}" translator="MtgPrincWinCallTranslator" />
          <mapping key="${AttributeNames.SD_MTG_PX_SPD}" translator="MtgPxSpdTranslator" />
          <mapping key="${AttributeNames.SD_REDEMPTION}" translator="RedemptionTranslator" />
          <mapping key="${AttributeNames.SD_RESET_INDEX}" translator="ResetIndexTranslator" />
          <mapping key="${AttributeNames.SD_PUT_NOTICE_PERIOD}" translator="PutNoticePeriodTranslator" />
          <mapping key="${AttributeNames.SD_RATING_FITCH}" translator="RatingFitchTranslator" />
          <mapping key="${AttributeNames.SD_RATING_MOODY}" translator="RatingMoodyTranslator" />
          <mapping key="${AttributeNames.SD_RATING_STANDARD_AND_POOR}" translator="RatingStandardAndPoorTranslator" />
          <mapping key="${AttributeNames.SD_SERIES}" translator="SeriesTranslator" />
          <mapping key="${AttributeNames.SD_UNDER_REG_144A}" translator="UnderReg144ATranslator" />
        </mappings>
      </map>
      <map sdRef="${AttributeNames.SD_ALT_INSTRUMENT_IDS}" mappedTo="getStaticData">
        <mappings>
          <mapping key="${AttributeNames.SD_ALT_INSTRUMENT_TYPE_BLOOMBERG}" translator="BloombergIdTranslator" />
          <mapping key="${AttributeNames.SD_ALT_INSTRUMENT_TYPE_BLOOMBERG_UNIQUE}" translator="BloombergUniqueIdTranslator" />
          <mapping key="${AttributeNames.SD_ALT_INSTRUMENT_TYPE_CUSIP}" translator="CusipIdTranslator" />
          <mapping key="${AttributeNames.SD_ALT_INSTRUMENT_TYPE_ISIN}" translator="IsinIdTranslator" />
          <mapping key="${AttributeNames.SD_ALT_INSTRUMENT_TYPE_JAPAN}" translator="JapanIdTranslator" />
          <mapping key="${AttributeNames.SD_ALT_INSTRUMENT_TYPE_JAPAN_SHORT}" translator="JapanIdShortCodeTranslator" />
	      <mapping key="${AttributeNames.SD_ALT_INSTRUMENT_TYPE_VALOREN}" translator="ValorenIdTranslator" />
	    </mappings>
	   </map>         
	  </methodMaps>
  </component>

# Got the following error for static data

2009-10-02 10:58:50.968 +0100 ERROR [pool-14-thread-1] unknown: Failed to create class : class com.rbsfm.fi.pricing.bloomberg.CorpBloombergBondDataImpl: Received source class of type com.rbsfm.fi.pricing.bloomberg.LATAMBloombergBondDataImpl but configured to handle type class com.rbsfm.fi.pricing.bloomberg.CorpBloombergBondDataImpl: Stack Trace: java.lang.IllegalStateException: Received source class of type com.rbsfm.fi.pricing.bloomberg.LATAMBloombergBondDataImpl but configured to handle type class com.rbsfm.fi.pricing.bloomberg.CorpBloombergBondDataImpl
        at com.rbsfm.fi.staticdata.maintenance.InstrumentStaticDataSourceMapper.createAttributeMap(InstrumentStaticDataSourceMapper.java:67)
        at com.rbsfm.fi.staticdata.maintenance.InstrumentStaticDataMapImpl.generateParentMap(InstrumentStaticDataMapImpl.java:71)
        at com.rbsfm.fi.staticdata.maintenance.BloombergInstrumentStaticRequestor.doStandardDeskTasks(BloombergInstrumentStaticRequestor.java:122)
        at com.rbsfm.fi.staticdata.maintenance.BloombergInstrumentStaticRequestor.getInstrumentStatic(BloombergInstrumentStaticRequestor.java:70)
        at com.rbsfm.fi.staticdata.maintenance.StaticSourceManager.getStatic(StaticSourceManager.java:38)
        at com.rbsfm.fi.staticdata.maintenance.InstrumentLifeCycleManager.loadNewInstruments(InstrumentLifeCycleManager.java:123)
        at com.rbsfm.fi.staticdata.maintenance.InstrumentLifeCycleManager.newInstrumentRequest(InstrumentLifeCycleManager.java:42)
        at com.rbsfm.fi.staticdata.maintenance.InstrumentStaticRequestHandler.createInstrument(InstrumentStaticRequestHandler.java:72)
        at com.rbsfm.fi.instmaint.InstMaintMonitor.handleLoadInstrumentRequest(InstMaintMonitor.java:101)
        at com.rbsfm.fi.instmaint.InstMaintMonitor.access$000(InstMaintMonitor.java:27)
        at com.rbsfm.fi.instmaint.InstMaintMonitor$1.run(InstMaintMonitor.java:60)
        at java.util.concurrent.ThreadPoolExecutor$Worker.runTask(ThreadPoolExecutor.java:885)
        at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:907)
        at java.lang.Thread.run(Thread.java:619)

2009-10-02 10:58:50.983 +0100 ERROR [pool-14-thread-1] unknown: Component [InstMaintDelegate]: Unable to process load instrument request: (ChainedRuntimeException:Error retrieving static data: Error retrieving static data: Stack Trace: com.rbsfm.common.exception.ChainedRuntimeException: Error retrieving static data
        at com.rbsfm.fi.staticdata.maintenance.StaticSourceManager.getStatic(StaticSourceManager.java:41)
        at com.rbsfm.fi.staticdata.maintenance.InstrumentLifeCycleManager.loadNewInstruments(InstrumentLifeCycleManager.java:123)
        at com.rbsfm.fi.staticdata.maintenance.InstrumentLifeCycleManager.newInstrumentRequest(InstrumentLifeCycleManager.java:42)
        at com.rbsfm.fi.staticdata.maintenance.InstrumentStaticRequestHandler.createInstrument(InstrumentStaticRequestHandler.java:72)
        at com.rbsfm.fi.instmaint.InstMaintMonitor.handleLoadInstrumentRequest(InstMaintMonitor.java:101)
        at com.rbsfm.fi.instmaint.InstMaintMonitor.access$000(InstMaintMonitor.java:27)
        at com.rbsfm.fi.instmaint.InstMaintMonitor$1.run(InstMaintMonitor.java:60)
        at java.util.concurrent.ThreadPoolExecutor$Worker.runTask(ThreadPoolExecutor.java:885)
        at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:907)
        at java.lang.Thread.run(Thread.java:619)
Caused by: com.rbsfm.common.exception.ChainedRuntimeException: com.rbsfm.common.exception.ChainedRuntimeException: java.lang.IllegalStateException: Received source class of type com.rbsfm.fi.pricing.bloomberg.LATAMBloombergBondDataImpl but configured to handle type class com.rbsfm.fi.pricing.bloomberg.CorpBloombergBondDataImpl
        at com.rbsfm.fi.staticdata.maintenance.BloombergInstrumentStaticRequestor.getInstrumentStatic(BloombergInstrumentStaticRequestor.java:75)
        at com.rbsfm.fi.staticdata.maintenance.StaticSourceManager.getStatic(StaticSourceManager.java:38)
        ... 9 more
Caused by: com.rbsfm.common.exception.ChainedRuntimeException: java.lang.IllegalStateException: Received source class of type com.rbsfm.fi.pricing.bloomberg.LATAMBloombergBondDataImpl but configured to handle type class com.rbsfm.fi.pricing.bloomberg.CorpBloombergBondDataImpl
        at com.rbsfm.fi.staticdata.maintenance.InstrumentStaticDataSourceMapper.createAttributeMap(InstrumentStaticDataSourceMapper.java:95)
        at com.rbsfm.fi.staticdata.maintenance.InstrumentStaticDataMapImpl.generateParentMap(InstrumentStaticDataMapImpl.java:71)
        at com.rbsfm.fi.staticdata.maintenance.BloombergInstrumentStaticRequestor.doStandardDeskTasks(BloombergInstrumentStaticRequestor.java:122)
        at com.rbsfm.fi.staticdata.maintenance.BloombergInstrumentStaticRequestor.getInstrumentStatic(BloombergInstrumentStaticRequestor.java:70)
        ... 10 more
Caused by: java.lang.IllegalStateException: Received source class of type com.rbsfm.fi.pricing.bloomberg.LATAMBloombergBondDataImpl but configured to handle type class com.rbsfm.fi.pricing.bloomberg.CorpBloombergBondDataImpl
        at com.rbsfm.fi.staticdata.maintenance.InstrumentStaticDataSourceMapper.createAttributeMap(InstrumentStaticDataSourceMapper.java:67)
        ... 13 more

# Static data sees the followign

2009-10-02 10:57:37.963 +0100 INFO [pool-14-thread-1] unknown: Handling newInstrumentRequest: InstrumentStaticRequest[instrumentIdentifiers=[US05963GAF54],instrumentIdentifierType=ISIN,instrumentSource=BLOOMBERG,instrumentType=BOND,requestorDesk=LATAM,requestor=gallane,sector=LATAM_BR_Corp,reload=false,noSourceCache=false]
2009-10-02 10:57:37.963 +0100 INFO [pool-14-thread-1] unknown: <BloombergDataRetriever> About to add 1 request items
2009-10-02 10:57:37.963 +0100 INFO [pool-14-thread-1] unknown: <BloombergDataRetriever> Added 1 bonds to request
2009-10-02 10:57:37.963 +0100 INFO [pool-14-thread-1] unknown: <BloombergDataRetriever> About to add 1 request items
2009-10-02 10:57:37.963 +0100 INFO [pool-14-thread-1] unknown: <BloombergDataRetriever> Added 1 bonds to request
2009-10-02 10:57:37.963 +0100 INFO [pool-14-thread-1] unknown: <BloombergDataRetriever> About to add 1 request items
2009-10-02 10:57:37.963 +0100 INFO [pool-14-thread-1] unknown: <BloombergDataRetriever> Added 1 bonds to request
2009-10-02 10:57:37.963 +0100 INFO [pool-14-thread-1] unknown: <BloombergDataRetriever> About to add 1 request items
2009-10-02 10:57:37.963 +0100 INFO [pool-14-thread-1] unknown: <BloombergDataRetriever> Added 1 bonds to request
2009-10-02 10:57:37.963 +0100 INFO [pool-14-thread-1] unknown: <BloombergDataRetriever> About to add 1 request items
2009-10-02 10:57:37.963 +0100 INFO [pool-14-thread-1] unknown: <BloombergDataRetriever> Added 1 bonds to request
2009-10-02 10:57:37.963 +0100 INFO [pool-14-thread-1] unknown: <BloombergDataRetriever> About to add 1 request items
2009-10-02 10:57:37.963 +0100 INFO [pool-14-thread-1] unknown: <BloombergDataRetriever> Added 1 bonds to request
2009-10-02 10:57:37.963 +0100 INFO [pool-14-thread-1] unknown: <BloombergDataRetriever> About to add 1 request items
2009-10-02 10:57:37.963 +0100 INFO [pool-14-thread-1] unknown: <BloombergDataRetriever> Added 1 bonds to request
2009-10-02 10:57:37.963 +0100 INFO [pool-14-thread-1] unknown: BDLRequestor submitting Request cpbs_US05963GAF54
2009-10-02 10:57:37.979 +0100 INFO [pool-14-thread-1] unknown: BDL Attempting FTP connect to server fm-eu-lon-ftp:21 for user [dl616551@205.216.112.8]
2009-10-02 10:57:37.979 +0100 INFO [pool-14-thread-1] unknown: Connected to fm-eu-lon-ftp.
2009-10-02 10:57:37.979 +0100 INFO [pool-14-thread-1] unknown: 220 Blue Coat FTP Service

2009-10-02 10:57:39.323 +0100 INFO [pool-14-thread-1] unknown: BDLRequestor submitting Request cpcf_US05963GAF54
2009-10-02 10:57:39.323 +0100 INFO [pool-14-thread-1] unknown: BDL Attempting FTP connect to server fm-eu-lon-ftp:21 for user [dl616551@205.216.112.8]
2009-10-02 10:57:39.338 +0100 INFO [pool-14-thread-1] unknown: Connected to fm-eu-lon-ftp.
2009-10-02 10:57:39.338 +0100 INFO [pool-14-thread-1] unknown: 220 Blue Coat FTP Service

2009-10-02 10:57:40.714 +0100 INFO [pool-14-thread-1] unknown: BDLRequestor submitting Request cpcs_US05963GAF54
2009-10-02 10:57:40.714 +0100 INFO [pool-14-thread-1] unknown: BDL Attempting FTP connect to server fm-eu-lon-ftp:21 for user [dl616551@205.216.112.8]
2009-10-02 10:57:40.729 +0100 INFO [pool-14-thread-1] unknown: Connected to fm-eu-lon-ftp.
2009-10-02 10:57:40.729 +0100 INFO [pool-14-thread-1] unknown: 220 Blue Coat FTP Service

2009-10-02 10:57:42.104 +0100 INFO [pool-14-thread-1] unknown: BDLRequestor submitting Request cpps_US05963GAF54
2009-10-02 10:57:42.104 +0100 INFO [pool-14-thread-1] unknown: BDL Attempting FTP connect to server fm-eu-lon-ftp:21 for user [dl616551@205.216.112.8]
2009-10-02 10:57:42.120 +0100 INFO [pool-14-thread-1] unknown: Connected to fm-eu-lon-ftp.
2009-10-02 10:57:42.120 +0100 INFO [pool-14-thread-1] unknown: 220 Blue Coat FTP Service

2009-10-02 10:57:46.698 +0100 INFO [pool-14-thread-1] unknown: BDLRequestor submitting Request cpss_US05963GAF54
2009-10-02 10:57:46.698 +0100 INFO [pool-14-thread-1] unknown: BDL Attempting FTP connect to server fm-eu-lon-ftp:21 for user [dl616551@205.216.112.8]
2009-10-02 10:57:46.714 +0100 INFO [pool-14-thread-1] unknown: Connected to fm-eu-lon-ftp.
2009-10-02 10:57:46.714 +0100 INFO [pool-14-thread-1] unknown: 220 Blue Coat FTP Service


# The following request is sent

2009-10-02 05:56:40.650 -0400 INFO [RequestBondsConsumer:ConsumerThread] unknown: Component [StaticDataMessageDispatcher]: Sending request instrument message = id=RequestBondsConsumer_20091002055132792_1, type=StaticRequestLoad msg=sector[LATAM_BR_Corp,OK] instrumentSource[BLOOMBERG,OK] desk[LATAM,OK] cloneIds[,OK] instrumentIds[US05963GAF54,,OK] requestor[gallane,OK] instrumentIdType[ISIN,OK]

# The static data server needs the following

<deskSourceMappings>
   <mapping desk="LATAM" sourceMapper="BBInstrumentStaticDataSourceMapperLATAM" />
</deskSourceMappings>

# Here is where we publish out

InstrumentEnlivener.publishSectorsList() line: 415	
InstrumentEnlivener.configure(Config) line: 103	
ConfigurableComponentManager.createComponent(Config) line: 177	
ConfigurableComponentManager.configure(Config) line: 117	
App.getComponentManager() line: 276	
ControlManager.getInstance(String) line: 70	
ControlManager.getDefaultInstance() line: 74	
ControlServer.main0(String[]) line: 62	
ControlServer$1.run() line: 34	
Thread.run() line: 619	


# Add this to the client mux

<control enabled="true">InstrumentMaintenanceSink</control>

<host_selector name="InstrumentMaintenanceSink" enabled="true" startup_wait="false" startup_wait_secs="${startup_wait_pricing}"/>

# Add the following configuration settings

<!-- InstrumentMaintenance -->
<instmaint_use_staticdata>true</instmaint_use_staticdata>
<use_instmaint>false</use_instmaint>
<instmaint_subscriber>false</instmaint_subscriber>

# Addition of the following property to all.properties

tree.id..latam.pricing.instmaint=StagingLatam

# Upgrade the caf version to

4.32.0.4

# Disable best price

<control enabled="false">BestPriceSink</control>
<control enabled="false">BestPriceDS</control>
<host_selector name="EcnBestPriceServerHostSelector" enabled="false" />

# The CDS server needs to be disabled

cds.server.enabled..latam=false
cds.server.enabled..latam.pricing.instmaint=false <<<----- this did not work ???

# The dependancy tree needs to be changed, below is eurogov

<treeId>StagingEuroGov</treeId>
<treeType>master</treeType>
<treeName>EuroGov</treeName>

# Instrument maintenance must be enabled

<instmaint_use_staticdata>true</instmaint_use_staticdata>
<use_instmaint>true</use_instmaint>
<instmaint_subscriber>true</instmaint_subscriber>


# The following config needs to be consdered

<cds_server_enabled>false</cds_server_enabled>
<ion_enabled>true</ion_enabled>

# Requires the following version of CAF

d:/caf/4.32.0.4/bin

# In order for it to connect to the database it needs the following in fi_server_details.xml

		<server servername="database_cp_us_test" virtual="true" servertype="INF">
			<!-- NOTE: not yet linked to services -->
			<hosts>
				<hostdetails name="primary">
					<hostattribute name="hostname" value="lon3841xus.fm.rbsgrp.net" />
					<hostattribute name="port" value="2050" />
				</hostdetails>
			</hosts>
        </server>

Referenced in all.properties via 

sybase.service.cp..latam=database_cp_us_test


# The following entries are used for instmaint to connect

    <server servername="latam-pricing-instmaint" servertype="PS" baseport="20050">
      <hostattribute name="ExchangeDataServer" value="latam-exchangedata-offshore" />
      <hostattribute name="StaticDataServer" value="staticdata-staticdata-master" /> 
      <!-- Dangerous that we have pricing and instmaint talking to same expricepub ??? -->
      <hostattribute name="USSwapMux" value="usswap-expricepub-master" />      
      <hostattribute name="EcnBestPriceServer" value="latam-exchangedata-offshore" />
    </server>

# This is the initial mail

Marion/Neil,
 
As a starting point have a look at the below. Some basic starting points.
 
Instrument meaintenance service:
Current Dev Eurogov built from egpricing wk 30 - see eurogov_instmaint.xml
 
 
----------------------------------------------------------------------------------------------------------------
StaticData service: for configuration see components BBInstrumentStaticDataSourceMapperDefault and BBInstrumentStaticDataSourceMapperEUROGOV.
These components populate maps (using BDL data) which are available to the instrument maintenance service for the  persistence mechanism.
 
      <map sdRef="${AttributeNames.SD_CASH_FLOW}" mappedTo="getCashFlows">
        <mappings><mapping key="${AttributeNames.SD_CASH_FLOW}" translator="CashFlowTranslator" /></mappings>
     </map> 
 
getCashFlows() is in class EuroGovBloombergBondDataImpl and the translator populates entires in the map. These entries are used in the instrument maintenance template to
call stored procedures e.g.:
      <sqlSP name="CashFlowStore" >
          <parameters>
          <parameter name="@Id" from="${AttributeNames.SD_ALT_INSTRUMENT_TYPE_ISIN}" />
          <parameter name="@Date" from="${AttributeNames.SD_SCHEDULE_DATE}" type="Date" dateFormat="yyyy-MM-dd" iterative="true" />
          <parameter name="@Coupon" from="${AttributeNames.SD_SCHEDULE_COUPON}" type="Double" iterative="true" />
          <parameter name="@Interest" from="${AttributeNames.SD_SCHEDULE_INTEREST}" type="Double" iterative="true"/>
          <parameter name="@Repayment" from="${AttributeNames.SD_SCHEDULE_REPAYMENT}" type="Double" iterative="true" />
          <parameter name="@Principal" from="${AttributeNames.SD_SCHEDULE_PRINCIPAL}" type="Double" iterative="true" />
          <parameter name="@Version" value="0" type="Integer"/>
          <parameter name="@ServerName" value="${serverName}" />
          <parameter name="@UpdaterRef" value="${serverName}" />            
        </parameters>
      </sqlSP>
 
Clientmux: An instrument maintenance sink needs to be added with a predicate such as:
<map rpc_source="InstrumentMaintenanceSink" predicate="BondStaticPredicate"/>
 
 
Grid.config - to allow bond adding from the client: <add key="Config.RequestBonds" value="true"/>
 
Database changes - see Vicky's Twiki and (http://twiki.fm.rbsgrp.net/twiki/bin/view/CP/CopyProdDatabase) for the changes required for Eurogov.
 
 
Vicky/Phil's Twiki is the main source of info but I'll come over to 280 to discuss next week if you like. Contact me any time.
Having a look at the dev staticdata and eurogov instmaint pricer is a good place to start and eurogov bondadding is currently functional,  if not perfect.
 
Regards,

