package com.rbsfm.fi.pricing.dependency.bond;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.rbsfm.common.config.Config;
import com.rbsfm.common.config.Configurable;
import com.rbsfm.common.date.Date;
import com.rbsfm.common.system.Log;
import com.rbsfm.common.util.MathUtil;
import com.rbsfm.fi.pricing.dependency.Calculator;
import com.rbsfm.fi.pricing.dependency.DependencyTree;
import com.rbsfm.fi.pricing.dependency.Status;
import com.rbsfm.fi.pricing.dependency.currentdate.CurrentDateNode;
import com.rbsfm.fi.pricing.dependency.future.BondFutureNode;
import com.rbsfm.fi.pricing.dependency.generic.GenericAttribute;
import com.rbsfm.fi.pricing.dependency.generic.GenericCalculator;
import com.rbsfm.fi.pricing.dependency.override.SettlementDateOverrideNode;
import com.rbsfm.fi.pricing.dependency.risk.InstrumentRisk;
import com.rbsfm.fi.pricing.dependency.util.AssignmentChangeType;
import com.rbsfm.fi.pricing.dependency.util.PriceType;
import com.rbsfm.fi.pricing.external.StatusType;
import com.rbsfm.fi.pricing.external.attribute.Attribute;
import com.rbsfm.fi.pricing.external.attribute.AttributeNames;
import com.rbsfm.fi.pricing.external.message.ManualAskPriceMessage;
import com.rbsfm.fi.pricing.external.message.ManualAskYieldMessage;
import com.rbsfm.fi.pricing.external.message.ManualBidPriceMessage;
import com.rbsfm.fi.pricing.external.message.ManualBidYieldMessage;
import com.rbsfm.fi.pricing.external.message.ManualPriceMessage;
import com.rbsfm.fi.pricing.external.message.ManualYieldMessage;
import com.rbsfm.fi.pricing.external.message.SetDateMessage;
import com.rbsfm.fi.pricing.external.message.TreeMessage;
import com.rbsfm.fi.pricing.newanalytics.bond.Bond;
import com.rbsfm.fi.pricing.newanalytics.bond.BondAnalyticsException;
import com.rbsfm.fi.pricing.newanalytics.bond.BondResults;
import com.rbsfm.fi.pricing.util.MathHelper;

/**
 * Price/yield Calculator implementation.
 * This also calculates derived data such as Duration and Bpv.
 * <p>
 * Is apparently required as of 20081020 to support instruments that do not have 'yield'
 * simply to compute some auxiliary parameters such as settlement date.
 */
public class PriceYieldCalculator
	extends Calculator implements GenericCalculator, Configurable  {

  public static final String SETT_DATE_OVERRIDE_ATT_ID = "SettDateOverride";
  public static final String FUTURE_NODE_ATT_ID = "FutureNodeId";

	private CurrentDateNode mCurrentDateNode;
	private Date mCurrentDate;

	private SettlementDateOverrideNode mSettlementDateOverrideNode;
	private Date mSettlementDateOverride;
	private Date mGlobalSettlementDateOverride;
	private Date mDefaultSettlementDate= Date.BLANK_OBJECT;

	//the calculated value
	private Date mSettlementDate;
	private String mReferenceFutureNodeId;
	private BondFutureNode mFutureNode;
    private InstrumentRiskImpl instrumentRisk;
    // PPP days accrued
    private int mDaysAcc;

	public static final String DEFAULT_CALC_ID= "priceYield";
	
  private static String APPLY_ROUNDING = "applyRounding";
  private static double ROUNDING = 0;

  /** Generic Calculator constructor */
  public PriceYieldCalculator(final DependencyTree tree, final String ownerId, final String id) {
    super(tree, ownerId, id, false);
  }

	public PriceYieldCalculator(
		final DependencyTree tree,
		final String ownerId,
		final String calculatorId,
		final Date settlementDateOverride,
		final String referenceFutureNodeId)
	{
		//each bond has one and ony one price yield calculator - hance ok to
		// only allow the calculator to bae called by its default name.
		super(tree, ownerId, calculatorId, false);
		mSettlementDateOverride= settlementDateOverride;
		mReferenceFutureNodeId= referenceFutureNodeId;
	}
	
  public void configure(Config config) {
    if (config.containsValue(APPLY_ROUNDING)) {
      ROUNDING = config.getDoubleValue(APPLY_ROUNDING);
    }
  } 	

	@Override
  protected void assignment(final Calculator rhs)
	{
		final PriceYieldCalculator calc= (PriceYieldCalculator) rhs;
		mReferenceFutureNodeId= assignStringChange(
			mReferenceFutureNodeId,
			calc.mReferenceFutureNodeId,
			AssignmentChangeType.RESTRUCTURE);
		mSettlementDateOverride= assignDateChange(
			mSettlementDateOverride,
			calc.mSettlementDateOverride,
			AssignmentChangeType.VALUE);
	}

	/**
	 * Has as parents
	 * CurrentDateNode
	 * SettlementDateOverrideNode
	 */
	@Override
  public List<String> getParentNodesIds()
	{
		final List<String> parents= new ArrayList<String>();
		parents.add(CurrentDateNode.CURRENT_WORKING_DATE);
		parents.add(SettlementDateOverrideNode.DEFAULT_NODE_ID);
		return parents;
	}

	@Override
	public void resolveNodeReferences()
	{
	  flushCache();
	  mCurrentDateNode= (CurrentDateNode)
	  getOwner().getParent(CurrentDateNode.CURRENT_WORKING_DATE);
	  if((SettlementDateOverrideNode) getOwner().getParent(SettlementDateOverrideNode.DEFAULT_NODE_ID)!=null){
	    mSettlementDateOverrideNode= (SettlementDateOverrideNode)
	    getOwner().getParent(SettlementDateOverrideNode.DEFAULT_NODE_ID);
	  }else{
	    mSettlementDateOverrideNode= new SettlementDateOverrideNode(super.getTree(), this.getOwner().getNodeSetId(), this.getOwner().getDisplayName() , this.getOwner().getExternalCode(), super.getOwnerId(), super.getId());
	  }
	  if ((mReferenceFutureNodeId != null) && !"".equals(mReferenceFutureNodeId)) {
	    mFutureNode= (BondFutureNode) getTree().getNode(mReferenceFutureNodeId);
	  }
	}

	private double getCurrentPrice()
	{
		final BondNode bondNode= getBondOwner();
		propagateStatus(bondNode.getCurrentMaster());
		return bondNode.getMasterPrice(getPriceType());
	}

	private void flushCache() { mSettlementDate = null;}

	@Override
  public void processMessage( final TreeMessage mssg )
	{
		if (mssg instanceof SetDateMessage) {
		  processSetDateMessage( (SetDateMessage) mssg);
		} else if ((mssg instanceof ManualPriceMessage) || (mssg instanceof ManualYieldMessage)) {
			try {
			  Log.INFO.report("Processing manual price/yield message: " + mssg.getNodeId());
			  TreeMessage newMessage = null;
			  if (mssg instanceof ManualBidPriceMessage) {
			    final ManualBidPriceMessage message = (ManualBidPriceMessage)mssg;
			    newMessage = new ManualBidPriceMessage(message.getTreeToken(), message.getNodeId(), message.getNewPrice());
			  } else if (mssg instanceof ManualAskPriceMessage) {
			    final ManualAskPriceMessage message = (ManualAskPriceMessage)mssg;
			    newMessage = new ManualAskPriceMessage(message.getTreeToken(), message.getNodeId(), message.getNewPrice());
			  } else if (mssg instanceof ManualBidYieldMessage) {
			    final ManualBidYieldMessage message = (ManualBidYieldMessage)mssg;
			    newMessage = new ManualBidYieldMessage(message.getTreeToken(), message.getNodeId(), message.getNewYield());
			  } else if (mssg instanceof ManualAskYieldMessage) {
			    final ManualAskYieldMessage message = (ManualAskYieldMessage)mssg;
			    newMessage = new ManualAskYieldMessage(message.getTreeToken(), message.getNodeId(), message.getNewYield());
			  }
			  if (newMessage != null) {
			    Log.INFO.report("Forwarding manual price/yield message for " + newMessage.getNodeId());
			    getTree().processMessage(newMessage, mssg.isLocal());
			  }
			} catch (final Throwable e) {
			  Log.ERROR.report("Unexpected error forwarding manual price message", e);
			}
		}
	}

	private void processSetDateMessage(final SetDateMessage msg )
	{
		flushCache();
		mSettlementDateOverride= msg.getDate();
		write();
		inputsChanged();
	}

	@Override
  protected boolean calculateMasterImpl() { return false;}

	@Override
  protected void propagateAdditionalDerivedErrors() {
		propagateStatus(getBondOwner().getCurrentMaster());
	}

	@Override
  protected boolean calculateDerivedImpl() { return false;}

	private BondResults getBondResults(){
        return getBondResults(PriceType.MID);
	}
    private BondResults getBondResults(final PriceType priceType){
        return getBondOwner().getMasterBondResults(priceType);
    }

	// Risk interface implementation
	public double getContractSize() { return 1.0;}	// Bond positions are in currency units.

	public double getBpv() {return getBondResults().getBpv() ;}

	public double getDBpv() { return getBondResults().getDBpv() ;}

	public Date getMaturityDate() { return getBondInstrument().getMaturityDate();}

	public double getDuration() {
    return getBondResults().getDuration();
  }

  public double getConvexity() {
    return getBondResults().getConvexity();
  }

  public double getAccruedInterest() {
    return getBondResults().getAccruedInterest();
  }

  public Date getAverageLife() {
    return getBondResults().getAverageLife();
  }

	public String getRiskCurrency()
	{
        String retVal;
		final Bond bond= getBondInstrument();
        if(bond != null){
            retVal = bond.getCurrency();
        } else {
            retVal = null;
        }
        return retVal;
	}
/**
	private String getCurrency() {
		return getBondInstrument().getCurrency();
	}
*/
	public Date getSettlementDate()
	{
		//lazy instantiation or if the day or overide has changed
		if (settlementDateNeedsCalculating()) {
			try {
				if (dateChanged()) {
                    final Bond bond= getBondInstrument();
					//set the current date
					mCurrentDate= mCurrentDateNode.getDate();
					// Since the date has just changed for this bond then
					// flush out the bond caches
					if (Log.DEBUG.isActive()){
						Log.DEBUG.report("Flushing the cache for ", bond.getDescription());
					}
					bond.clearCaches();
					mDefaultSettlementDate = bond.defaultSettlementDate(mCurrentDate);
				} else if (((InternalBondNode)getBondOwner()).hasStaticDataChanged()){
					//first settlement date may have changed
					mDefaultSettlementDate =  getBondInstrument().defaultSettlementDate(mCurrentDate);
				}
				// calculate the settlement date taking in to account overrides, but using cache default settlement date
				mSettlementDate = calculateSettlementDateForDate(mCurrentDate);
			}
			catch (final BondAnalyticsException e) {
				propagateStatus(StatusType.ANALYTICS_ERROR,
					this +" failed to get default settlement date", e);
				mSettlementDate= Date.BLANK_OBJECT;
			}
		}
		return mSettlementDate;
	}

	/**
	 * Calculates a settlement date for a specified date taking in to account
	 * override dates
	 */
	private Date calculateSettlementDateForDate(final Date forDate)
	{
		//Bond bond= getBondInstrument();
		if ((mSettlementDateOverride != null) && !mSettlementDateOverride.equals(Date.BLANK_OBJECT) && mSettlementDateOverride.after(mCurrentDate)) {
			return mSettlementDateOverride;
		}

		if ((mGlobalSettlementDateOverride != null) && mGlobalSettlementDateOverride.after(mCurrentDate)) {
			return mGlobalSettlementDateOverride;
		}

		return mDefaultSettlementDate;
	}

	private boolean settlementDateNeedsCalculating()
	{
		getGlobalSettlementDateOverride();
		return  (mSettlementDate == null) ||
			dateChanged() ||						                                  // The current date has changed
      ((InternalBondNode)getBondOwner()).hasStaticDataChanged() ||  // Static Data has been changed
			useOverrideSettlementDate() ||			                          // A bond level settlement date has been set
			hasGlobalSettlementDateJustChanged() ||	                      // Global settlement date overrides have changed
			useGlobalOverrideSettlementDate();		                        // There is a Global settlement date
	}

	private Date getGlobalSettlementDateOverride()
	{
		if (hasGlobalSettlementDateJustChanged()) {
			mGlobalSettlementDateOverride = retrieveGlobalSettlementDateOverride();
		}
		return mGlobalSettlementDateOverride;
	}

	private boolean hasGlobalSettlementDateJustChanged() {
		if(mSettlementDate == null) { return(true); }

		// Avoid NPE.
		if(null == mSettlementDateOverrideNode) { throw new IllegalStateException("Missing SettlementDateOverrideNode for "+getOwnerId()); }

		return(mSettlementDateOverrideNode.hasJustSetChildrenDirty());
	}

	/**Get the override date, or null if none. */
	private Date retrieveGlobalSettlementDateOverride()
	{
		// Avoid NPE.
		if(null == mSettlementDateOverrideNode) { throw new IllegalStateException("Missing SettlementDateOverrideNode for "+getOwnerId()); }

		return mSettlementDateOverrideNode.getSettlementDateOverride(
			getBondOwner().getTicker(),
			getBondInstrument().getBondType().getId(),
			getBondInstrument().getBondType().getCountry(),
			getBondInstrument().getBondType().getCurrency());
	}

	private boolean dateChanged() {
		return !mCurrentDateNode.getDate().equals( mCurrentDate );
	}

	private boolean useOverrideSettlementDate()
	{
		return (mSettlementDateOverride != null) &&
			!mSettlementDateOverride.before(mCurrentDateNode.getDate()) &&
			!mSettlementDateOverride.after(mSettlementDate);
	}

	private boolean useGlobalOverrideSettlementDate()
	{
		return (mGlobalSettlementDateOverride != null) &&
			!mGlobalSettlementDateOverride.before(mCurrentDateNode.getDate()) &&
			!mGlobalSettlementDateOverride.after(mSettlementDate);
	}

	public final Date getCurrentWorkingDate() { return mCurrentDate; }

	/*
	public final double getYield() { return getBondResults().getYield(); }
	public final double getDuration() { return getBondResults().getDuration(); }
	public final double getConvexity() { return getBondResults().getConvexity(); }
	*/

	/**Computed value. */
	public double getSimpleFutureHedge()
	{
		if (mFutureNode != null) {
			final double futBpv = mFutureNode.getBpv();
			if (futBpv == 0) {
				return 0;
			}
      final double lotsPerMillion = 1000000/mFutureNode.getContractSize();
      return getBpv()/futBpv * lotsPerMillion;
		}
    return -9999;
	}

	/**
	 * A bond often has its risk measured relative to a particular BondFuture.
	 * <p>
	 * This BondFuture can be retrieved here.
	 * It can be null. If this reference BondFuture has not been set.
	 */
	public String getReferenceFutureNodeId() { return mReferenceFutureNodeId;}

	//package scope - for use by the DbHome
	Date getSettlementDateOverride() { return mSettlementDateOverride;}

	public BondResults getResults() { return getBondResults();}
    public InstrumentRisk getInstrumentRisk(final PriceType priceType){
        return ((instrumentRisk != null) && (instrumentRisk.forPriceType() == priceType)) ?
                    instrumentRisk :
                    (instrumentRisk = new InstrumentRiskImpl(priceType));
    }

	@Override
  public void addAttributes(final Collection<Attribute> atts)
	{
		final int status= getStatusId();

		atts.add(createAttribute(AttributeNames.TODAY_DATE_ATT,
			mCurrentDate, status));
		atts.add(createAttribute(AttributeNames.SETTLEMENT_DATE_ATT,
			mSettlementDate, status));
		atts.add(createPriceAttribute(AttributeNames.PRICE_ATT, MathHelper.roundPrice(getCurrentPrice(),ROUNDING), status));
		atts.add(createPriceAttribute(AttributeNames.SIMPLE_FUTURE_HEDGE_ATT,
			getSimpleFutureHedge(), status));
                atts.add(createAttribute(AttributeNames.DEFAULT_SETTLEMENT_DATE_ATT,
                mDefaultSettlementDate, status));


		final BondResults brd= getResults();
		final int masterStatusId= getOwner().getCurrentMaster().getStatusId();

    atts.add(createAttribute(AttributeNames.EFFECTIVE_MATURITY_DATE,
                           brd.getEffectiveMaturityDate(), status));
    final BondResults bidBondResults = getBondResults(PriceType.BID);

    atts.add(createAttribute(AttributeNames.BID_EFFECTIVE_MATURITY_DATE,
                           bidBondResults.getEffectiveMaturityDate(), status));
    final BondResults askBondResults = getBondResults(PriceType.ASK);
    atts.add(createAttribute(AttributeNames.ASK_EFFECTIVE_MATURITY_DATE,
                           askBondResults.getEffectiveMaturityDate(), status));

		atts.add(createAttribute(AttributeNames.VALUE_DATE_ATT,
			brd.getValueDate(), masterStatusId));
		atts.add(createAttribute(AttributeNames.PREV_COUPON_DATE_ATT,
			brd.getPrevCouponDate(), masterStatusId));
		atts.add(createAttribute(AttributeNames.NEXT_COUPON_DATE_ATT,
			brd.getNextCouponDate(), masterStatusId));
		atts.add(createAttribute(AttributeNames.IS_EX_DIVIDEND_ATT,
			brd.getIsExDividend(), masterStatusId));
		atts.add(createPriceAttribute(AttributeNames.NEXT_COUPON_AMOUNT_ATT,
			brd.getNextCouponAmount(), masterStatusId));
		atts.add(createPriceAttribute(AttributeNames.TIME_TO_NEXT_COUPON_ATT,
			brd.getTimeToNextCoupon(), masterStatusId));
		atts.add(createAccrualAttribute(AttributeNames.ACCRUED_INTEREST_ATT,
			brd.getAccruedInterest(), masterStatusId));
		atts.add(createPriceAttribute(AttributeNames.CLEAN_PRICE_ATT,
			brd.getCleanPrice(), masterStatusId));
		atts.add(createYieldAttribute(AttributeNames.YIELD_ATT,
			brd.getYield(), masterStatusId));

		final InternalBondNode bond = (InternalBondNode)getBondOwner();
        final InsidePriceCalculator insideCalc = (InsidePriceCalculator) bond.lookupCalculator(InsidePriceCalculator.DEFAULT_CALC_ID);
        // If inside is outside, use these values.....
        if ((insideCalc!=null) && insideCalc.isEnabled() ){
        	final BondResults iBrd = insideCalc.getPricingHelper().getBondResults(PriceType.MID);
			atts.add(createPriceAttribute(AttributeNames.BPV_ATT,
					iBrd.getBpv(), masterStatusId));
			atts.add(createPriceAttribute(AttributeNames.DBPV_ATT,
					iBrd.getDBpv(), masterStatusId));
			atts.add(createDurationAttribute(AttributeNames.MODIFIED_DURATION_ATT,
					iBrd.getModifiedDuration(), masterStatusId));
			atts.add(createDurationAttribute(AttributeNames.DURATION_ATT,
					iBrd.getDuration(), masterStatusId));
			atts.add(createPriceAttribute(AttributeNames.CONVEXITY_ATT,
				MathUtil.round(iBrd.getConvexity(), 8), masterStatusId));
			//Average life
			atts.add(createAttribute(AttributeNames.AVERAGE_LIFE_ATT,
					iBrd.getAverageLife(), status));
        }else{
			atts.add(createPriceAttribute(AttributeNames.BPV_ATT,
				brd.getBpv(), masterStatusId));
			atts.add(createPriceAttribute(AttributeNames.DBPV_ATT,
				brd.getDBpv(), masterStatusId));
			atts.add(createDurationAttribute(AttributeNames.MODIFIED_DURATION_ATT,
				brd.getModifiedDuration(), masterStatusId));
			atts.add(createDurationAttribute(AttributeNames.DURATION_ATT,
				brd.getDuration(), masterStatusId));
			atts.add(createPriceAttribute(AttributeNames.CONVEXITY_ATT,
					MathUtil.round(brd.getConvexity(), 8), masterStatusId));
			//Average life
			atts.add(createAttribute(AttributeNames.AVERAGE_LIFE_ATT,
					brd.getAverageLife(), status));
        }

	final BondResults midBr = getBondOwner().getMasterBondResults(PriceType.MID);
	if (midBr != BondResults.BLANK_OBJECT) {
	  atts.add(createPriceAttribute(AttributeNames.MASTER_MID_DISC_MRG_ATT, midBr.getDiscountMargin(), masterStatusId));
	}

		final BondResults bidBr = getBondOwner().getMasterBondResults(PriceType.BID);
		atts.add(createPriceAttribute(AttributeNames.BID_PRICE_ATT, MathHelper.roundPrice(bidBr.getCleanPrice(),ROUNDING), masterStatusId));
    atts.add(createPriceAttribute(AttributeNames.BID_YIELD_ATT, bidBr.getYield(), masterStatusId));
    atts.add(createPriceAttribute(AttributeNames.BID_BPV_ATT, bidBr.getBpv(), masterStatusId));
    atts.add(createPriceAttribute(AttributeNames.BID_DBPV_ATT, bidBr.getDBpv(), masterStatusId));
    
    if (bidBr != BondResults.BLANK_OBJECT){
    atts.add(createDurationAttribute(AttributeNames.BID_MODIFIED_DURATION_ATT, bidBr.getModifiedDuration(), masterStatusId));
    atts.add(createPriceAttribute(AttributeNames.MASTER_BID_DISC_MRG_ATT, bidBr.getDiscountMargin(), masterStatusId));
//    atts.add(createDurationAttribute(AttributeNames.BID_DURATION_ATT, bidBr.getDuration(), masterStatusId));
//    atts.add(createPriceAttribute(AttributeNames.BID_CONVEXITY_ATT, bidBr.getConvexity(), masterStatusId));
    }
    
    final BondResults askBr = getBondOwner().getMasterBondResults(PriceType.ASK);
    atts.add(createPriceAttribute(AttributeNames.ASK_PRICE_ATT, MathHelper.roundPrice(askBr.getCleanPrice(),ROUNDING), masterStatusId));
    atts.add(createPriceAttribute(AttributeNames.ASK_YIELD_ATT, askBr.getYield(), masterStatusId));
    atts.add(createPriceAttribute(AttributeNames.ASK_BPV_ATT, askBr.getBpv(), masterStatusId));
    atts.add(createPriceAttribute(AttributeNames.ASK_DBPV_ATT, askBr.getDBpv(), masterStatusId));    

    if (askBr != BondResults.BLANK_OBJECT) {
      atts.add(createDurationAttribute(AttributeNames.ASK_MODIFIED_DURATION_ATT, askBr.getModifiedDuration(), masterStatusId));
      maybeAddDaysAcc(atts, askBr, askBr, masterStatusId);
      atts.add(createPriceAttribute(AttributeNames.MASTER_ASK_DISC_MRG_ATT, askBr.getDiscountMargin(), masterStatusId));
//    atts.add(createDurationAttribute(AttributeNames.ASK_DURATION_ATT, askBr.getDuration(), masterStatusId));
//    atts.add(createPriceAttribute(AttributeNames.ASK_CONVEXITY_ATT, askBr.getConvexity(), masterStatusId));
    }
	}

    /**
     * Only add DAYS_ACC_ATT if dates are non-null
     */
    private void maybeAddDaysAcc(final Collection<Attribute> atts, final BondResults bidBr, final BondResults askBr, int statusId) {
        mDaysAcc = 0;
        if((askBr.getPrevCouponDate() != null) && (askBr.getValueDate() != null)) {
            mDaysAcc = Date.daysBetween(askBr.getPrevCouponDate(), askBr.getValueDate());
        } else {
            statusId = StatusType.NOT_POPULATED.getId();
        }
        atts.add(createAttribute(AttributeNames.DAYS_ACC_ATT, mDaysAcc, statusId));
    }

	/**
	 * Utility method for retrieving the owner as an {@link InternalBondNode}
	 * @return the owner as an {@link InternalBondNode}
	 */
	private BondNode getBondOwner() { return(BondNode) getOwner();}

	/**
	 * Utility method for retrieving the {@link Bond} instrument from the
	 * associated bond owner.
	 * the bond owner.
	 * @return the <code>Bond</code> instrument of the associated bond owner.
	 */
	private Bond getBondInstrument() {
		return getBondOwner().getBondInstrument();
	}

    private class InstrumentRiskImpl implements InstrumentRisk{
        private final PriceType priceType;
        private InstrumentRiskImpl(final PriceType priceType){
            this.priceType = priceType;
        }
        private BondResults results(){
            return PriceYieldCalculator.this.getBondResults(priceType);
        }
        PriceType forPriceType(){
            return priceType;
        }
         /**
         * @see com.rbsfm.fi.pricing.dependency.risk.InstrumentRisk#getBpv()
         */
        public double getBpv() {
          return results().getBpv();
      }

      public double getRepoBpv() {
          return 0d;
      }

        /**
         * @see com.rbsfm.fi.pricing.dependency.risk.InstrumentRisk#getContractSize()
         */
        public double getContractSize() {
            return PriceYieldCalculator.this.getContractSize();
        }

        /**
         * @see com.rbsfm.fi.pricing.dependency.risk.InstrumentRisk#getDBpv()
         */
        public double getDBpv() {
            return results().getDBpv();
        }

        /**
         * @see com.rbsfm.fi.pricing.dependency.risk.InstrumentRisk#getDuration()
         */
        public double getDuration() {
            return results().getDuration();
        }

        /**
         * @see com.rbsfm.fi.pricing.dependency.risk.InstrumentRisk#getMaturityDate()
         */
        public Date getMaturityDate() {
            return PriceYieldCalculator.this.getMaturityDate();
        }

        /**
         * @see com.rbsfm.fi.pricing.dependency.risk.InstrumentRisk#getRiskCurrency()
         */
        public String getRiskCurrency() {
            return PriceYieldCalculator.this.getRiskCurrency();
        }

        /**
         * @see com.rbsfm.fi.pricing.dependency.StatusProvider#getStatus()
         */
        public Status getStatus() {
            return PriceYieldCalculator.this.getStatus();
        }
    }

    /**
     * Returns the generic attributes of the calculator.
     */
    @Override
    public GenericAttribute[] getGenericAttributes() {
      return new GenericAttribute[] {
                                  new GenericAttribute(SETT_DATE_OVERRIDE_ATT_ID, mSettlementDateOverride),
                                      new GenericAttribute(FUTURE_NODE_ATT_ID, mReferenceFutureNodeId)
      };
    }

    /**
     * Sets the generic attributes of the calculator.
     */
    @Override
    public void setGenericAttributes(final Map<String, GenericAttribute> genericAttributes) {
      mReferenceFutureNodeId = GenericAttribute.getStringValue(genericAttributes, FUTURE_NODE_ATT_ID, this);
      mSettlementDateOverride = GenericAttribute.getDateValue(genericAttributes, SETT_DATE_OVERRIDE_ATT_ID, this);
    }


}

