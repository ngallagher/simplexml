package com.rbsfm.fi.pricing.dependency.maintenance;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.rbsfm.common.config.Config;
import com.rbsfm.common.system.AbstractConsumerControl;
import com.rbsfm.common.util.StringUtil;
import com.rbsfm.fi.instmaint.InstrumentMaintLifeCycleManager;
import com.rbsfm.fi.pricing.dependency.TreeMessageConsumer;
import com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessing;
import com.rbsfm.fi.pricing.external.attribute.AttributeMap;
import com.rbsfm.fi.pricing.external.attribute.AttributeNames;
import com.rbsfm.fi.pricing.external.attribute.StringAttribute;
import com.rbsfm.fi.pricing.external.message.MessageTypeRepository;
import com.rbsfm.fi.pricing.external.message.TreeMessage;
import com.rbsfm.fi.staticdata.maintenance.StaticDataMessageDispatcher;

/**
 * @author walkedn
 */
public class RequestBondsConsumer extends AbstractConsumerControl implements TreeMessageConsumer {
  
  private static final AtomicLong requestId = new AtomicLong(0);
  private static final String start = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
  public static class RequestBonds {
    private final List<String> bondIds = new ArrayList<String>();
    private final String sector;
    private final String owner;
    private final String desk;
    private final String user;
    private final String idType;
    private final String source;
 


    public RequestBonds(String owner, String sector, String desk, String source, List<String> bondIds, String idType, String user, String pass) {
      this.owner = owner;
      this.sector = sector;
      this.desk = desk;
      this.source = source;
      // convert to upper, which is fine for all isins, have had problems when using lowercase
      if (null != bondIds){
        for (String bondId : bondIds){
          if (null != bondId){
            this.bondIds.add(bondId.toUpperCase());
          }
        }
      }
      this.user = user;
      this.idType = idType;
    }

    public String toString() {
      return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
      .append("owner", this.owner)
      .append("sector", this.sector)
      .append("idType", this.idType)
      .append("desk", this.desk)
      .append("source", this.source)
      .append("user", this.user)
      .append("bondIds", this.bondIds)
      .toString();
    }
  }

  private final Map<String, BondRequestor> bondRequestors = new HashMap<String, BondRequestor>();
  private BondMaintenanceManager bondMaintenanceMgr;
  private String defaultDesk;
  private String defaultSource;
  private String defaultIdType;
  private InstrumentMaintLifeCycleManager instMaint;
  private StaticDataMessageDispatcher sdMsgDispatcher;
  private Boolean fetchFromSource;
  private Boolean reloadBonds;

  public void configure(Config config) {
    super.configure(config);

    if (isEnabled()) {
      Config[] bondRequestorConfigs = config.getChildren("bondRequestors.bondRequestor");
      for(int i = 0; i < bondRequestorConfigs.length; i++) {
        String name = bondRequestorConfigs[i].getStringValue("name");
        bondRequestors.put(name,(BondRequestor)getComponent(name,true));
      }

      if (config.containsValue("treeMessageProcessor")) {
        TreeMessageProcessing tmProc=(TreeMessageProcessing)getComponent(config.getStringValue("treeMessageProcessor"));
        tmProc.registerMessageConsumer(this, RequestBondsMessage.class);
      }
      defaultDesk = config.getStringValue("defaultDesk", AttributeNames.SD_DESK_CORP);
      defaultSource = config.getStringValue("defaultSource", AttributeNames.SD_SOURCE_BLOOMBERG);
      defaultIdType = config.getStringValue("deskIdType", AttributeNames.SD_ALT_INSTRUMENT_TYPE_ISIN);
      bondMaintenanceMgr = (BondMaintenanceManager) getReferencedComponent(config, "bondMaintenanceMgr");
 
      // hook to allow the request for static to be handled by the Static Data server
      if (config.containsValue("useStaticData")) {
 	    if (config.getBooleanValue("useStaticData")) {
 	      instMaint = (InstrumentMaintLifeCycleManager) getReferencedComponent(config, "instrumentMaintLifeCycleMgr");   
    	  sdMsgDispatcher = (StaticDataMessageDispatcher) getReferencedComponent(config, "staticDataMsgDispatcher");
        }
      }  
      // these attributes are useful when testing as it forces a full load
      fetchFromSource = config.getBooleanValue("fetchFromSource", false);
      reloadBonds = config.getBooleanValue("reloadBonds", false);
    }    
  }

  protected void internalConsume(Object object) {
    handleRequest((RequestBonds) object);
  }

  private void handleRequest(RequestBonds requestBonds) {
    logInfo("Handling: " + requestBonds);

    BondRequestor bondRequestor = getBondRequestor();
    List<String>[] bondsAndClones = getClones(requestBonds.bondIds);
    //split into a list of clones and bonds to be added
    List<String> extractedClones = new ArrayList<String>(bondsAndClones[0]);
    List<String> extractedBonds = new ArrayList<String>(bondsAndClones[1]);
    
    if(reloadBonds) {
	    logInfo("Fetching following bonds: " + extractedBonds);
	    getStaticAndAdd(bondRequestor, extractedBonds, extractedClones, requestBonds);  
    } else {
	    // determine if any bonds already exist and only return those that don't
	    List<String> newBondIds = (List<String>)getBondMaintenanceMgr().listUnstoredBonds(extractedBonds);
	    
	    for(String i: extractedBonds)
	    {
	      if(!newBondIds.contains(i))
	      {
	        int bondPos = extractedBonds.indexOf(i);
	        extractedClones.remove(bondPos);
	      }
	    }
	    
	    if (newBondIds.isEmpty()){
	      logInfo("All bonds already exist. no need to fetch: " + requestBonds.bondIds);
	    } else {
	      List<String> existingBonds = new ArrayList<String>(requestBonds.bondIds);
	      existingBonds.removeAll(newBondIds);
	      if (!existingBonds.isEmpty()){
	        logInfo("Already have following bonds - will not fetch: " + existingBonds);
	      }
	      logInfo("Fetching following bonds: " + newBondIds);
	      getStaticAndAdd(bondRequestor, newBondIds, extractedClones, requestBonds);  
	    }
    }
 }
  
  private List<String>[] getClones(List<String> bondIds)
  {
    List<String> cloneIds = new ArrayList<String>();
    List<String> newBonds = new ArrayList<String>();
    List<String>[] bondsAndClones = (ArrayList<String>[]) new ArrayList[2];
    bondsAndClones[0] = cloneIds;
    bondsAndClones[1] = newBonds;
    boolean nextBondIsClone = false;
    String bondToAdd = "";

    if (bondIds != null && bondIds.size() > 0) {      
      for (String bondId : bondIds){     
        if(bondId.length() == 12){
          if(!nextBondIsClone){
            newBonds.add(bondId);
            cloneIds.add("");
            bondToAdd = bondId;
          }
          else{
            if (!getBondMaintenanceMgr().getStrategy().testExists(bondId)){
              logInfo("Clone " + bondId + " does not exist for bond " + bondToAdd + ". " + bondToAdd + " will not be added");
              newBonds.remove(newBonds.size()-1);
              cloneIds.remove(cloneIds.size()-1);
              bondToAdd = "";
              continue;
            }
            cloneIds.remove(cloneIds.size()-1);
            cloneIds.add(bondId);
            bondToAdd = "";
            nextBondIsClone=false;
          }
        }      
        else if(bondId.equals("CLONE")){
          nextBondIsClone=true;
          continue;
        }
      }
    }
    return bondsAndClones;
  }

  private BondRequestor getBondRequestor() {
    if (bondRequestors.size() > 0) {
      return (BondRequestor) bondRequestors.values().toArray()[0];
    }
    else {
      return null;
    }
  }

  public void processMessage(TreeMessage message) {
    RequestBondsMessage msg = (RequestBondsMessage) message;
    RequestBondsConsumer.RequestBonds request = new RequestBondsConsumer.RequestBonds(msg.getOwner(), msg.getSector(), msg.getDesk(), null, msg.getIds(), null, null, null);
    
    BondRequestor bondRequestor = (BondRequestor) bondRequestors.get("BDLBondRequestor");
    // convert requested ids to uppercase
    List<String> requestedBondIds = new ArrayList<String>();
    if (requestedBondIds != null){
      for (String bondId : msg.getIds()){
        if (null != bondId){
          requestedBondIds.add(bondId.toUpperCase());
        }
      }
    }
        
    // determine if any bonds already exist and only return those that don't
    List<String> newBondIds = (List<String>)getBondMaintenanceMgr().listUnstoredBonds(requestedBondIds);
    List<String> cloneIds = new ArrayList<String>();
    getStaticAndAdd(bondRequestor, newBondIds, cloneIds, request);
  }
  
  private void getStaticAndAdd(BondRequestor bondRequestor, List<String> newBondIds, List<String> cloneIds, RequestBonds request) {

    if (instMaint != null) {
      try {
        String desk = getDesk(request);
        String idType = getIdType(request);
        String source = getSource(request);
        String requestor = getRequestor(request);
         
        sdMsgDispatcher.dispatchRequest(getRequestId(), createStaticDataRequest(newBondIds, cloneIds, idType, source, request.sector, requestor, desk, fetchFromSource), MessageTypeRepository.INSTRUMENT_STATIC_REQUEST_LOAD);
      } catch (Exception e) { 
        logError (e);
      }
    } else {
      // request bond static from Bloomberg for all non-existent bonds
      List<BondData> bondDataList = bondRequestor.handleRequest(newBondIds, defaultDesk);

      // add bonds
      try {
        getBondMaintenanceMgr().add(bondDataList, request.sector, null, request.owner);
      } catch (InstrumentCreationException e) {
        logError (e);
      } 
    }	    
  }
  
  
  private String getDesk(RequestBonds request){
    String desk = request.desk;
    if (StringUtil.isNullOrEmpty(desk)){
     desk = this.defaultDesk; 
    }
    return desk;
  }

  private String getSource(RequestBonds request){
    String source = request.source;
    if (StringUtil.isNullOrEmpty(source)){
     source = this.defaultSource; 
    }
    return source;
  }
  
  private String getRequestor(RequestBonds request){
    String requestor = request.user;
    if (StringUtil.isNullOrEmpty(requestor)){
     requestor = request.owner; 
    }
    return requestor;
  }


  
  private String getIdType(RequestBonds request){
    String idType = request.idType;
    if (StringUtil.isNullOrEmpty(idType)){
      idType = this.defaultIdType; 
    }
    return idType;
  }

 
  public static AttributeMap createStaticDataRequest(List<String> newBondIds, List<String> newCloneIds, String idType, String source, String sector, String user, String desk, Boolean fetchFromSource) {
    StringBuilder delimIds = new StringBuilder();
    StringBuilder cloneIds = new StringBuilder();
    for (String id : newBondIds){
      delimIds.append(id).append(",");
    }
    for (String id : newCloneIds){
      cloneIds.append(id).append(",");
    }
    AttributeMap attributes = new AttributeMap();
    attributes.put(new StringAttribute(AttributeNames.IM_REQUEST_IDS, delimIds.toString()));
    attributes.put(new StringAttribute(AttributeNames.IM_REQUEST_ID_TYPE, idType));
    attributes.put(new StringAttribute(AttributeNames.IM_REQUEST_SOURCE, source));
    attributes.put(new StringAttribute(AttributeNames.IM_REQUESTOR, user));
    attributes.put(new StringAttribute(AttributeNames.IM_SECTOR, sector));
    attributes.put(new StringAttribute(AttributeNames.IM_REQUEST_DESK, desk));
    attributes.put(new StringAttribute(AttributeNames.IM_CLONE_IDS, cloneIds.toString()));
    attributes.put(new StringAttribute(AttributeNames.IM_RELOAD, fetchFromSource.toString()));
    return attributes;
  }
  
  public BondMaintenanceManager getBondMaintenanceMgr() {
    return bondMaintenanceMgr;
  }

  /** Not the best but probably good enough - request ids should be unique across lifetime of an instance, and unique across instances as use startup time. */ 
  private String getRequestId(){
    return "RequestBondsConsumer_" + start + "_" + requestId.incrementAndGet();
  }
}


