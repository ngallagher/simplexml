package com.rbsfm.fi.instmaint.persist;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.rbsfm.common.config.Config;
import com.rbsfm.common.exception.ChainedRuntimeException;
import com.rbsfm.common.persist.Query;
import com.rbsfm.common.system.AbstractConfigurable;
import com.rbsfm.common.system.Log;
import com.rbsfm.fi.pricing.dependency.maintenance.SqlGenerationException;
import com.rbsfm.fi.pricing.external.attribute.StringSeriesAttribute;
import com.rbsfm.fi.pricing.util.AttributeMap;
import com.rbsfm.fi.pricing.util.SimpleAttributeMap;
import com.rbsfm.fi.staticdata.maintenance.ListMapSerializer;
import com.rbsfm.fi.staticdata.maintenance.StaticTranslator;
import com.rbsfm.fi.staticdata.translator.MapAttributeCondition;
import com.rbsfm.fi.staticdata.translator.SimpleFieldTranslator;
import com.rbsfm.fi.staticdata.translator.StaticMapper;
import com.rbsfm.fi.staticdata.translator.transformer.Transformer;
import com.tangosol.run.xml.MapAdapter;

/** 
 * Composite class of elements needed to run a stored proc.
 * <p>
 * Contains a list of parameters,
 * each of which can come from a configured value,or fetched from an AttributeMap 
 * these are implemented using staticMappers - map a key to a staticTranslator. 
 * <p>   
 * Optionally can have conditions - also based on static mappers, 
 * which are checked before stored proc is run.
 * Conditions allow special provision for deltas where may only have
 * a small subset of values.
 * <p>
 * For example:
 * <pre>
 * {@code
  <sqlSP name="CalculatorAttributeStore">
  <conditions>
    <condition onDeltaOnly="true" check="notNull" ><testField>LastCouponAmount</testField></condition>
    <condition check="notEquals" ><testField>Coupon</testField><testValue>0</testValue><type>Integer</type></condition>
  </conditions>
  <parameters>
    <parameter name="@NodeRef" from="InstrumentId" />
    <parameter name="@CalculatorId" value="BondStaticCalc" />
    <parameter name="@AttributeName" value="LastCouponAmount" />
    <parameter name="@ValueFloat" from="lastCouponAmount" type="Double" default="0" />
  </parameters>
</sqlSP>
 * }
 * </pre>
 * 
 * @author wraypc
 */
public class StoredProc extends AbstractConfigurable {
  
  
  private final List<StaticMapper> paramMappings = new ArrayList<StaticMapper>();
  /** List of conditions, mapped to boolean indicating if apply to deltas only */
  private LinkedHashMap<MapAttributeConditionGroup, Boolean> conditions;
  private MapAttributeCondition iterativeCondition;
  private String storedProc;
  /** For iterative stored procs need to know which of its params are iterative */
  private final List<String> iterativeParamNames = new ArrayList<String>();
  

  public StoredProc(String storedProc, LinkedHashMap<MapAttributeConditionGroup, Boolean> conditions, MapAttributeCondition iterativeCondition, List<StaticMapper> paramMappings, List<String> iterativeParamNames){
    this.init(storedProc, conditions, iterativeCondition, paramMappings, iterativeParamNames);
  }

  /** Must call configure, or init if default constructor used */
  public StoredProc(){
  }

  
  void init(String storedProc, LinkedHashMap<MapAttributeConditionGroup, Boolean> conditions, MapAttributeCondition iterativeCondition, List<StaticMapper> paramMappings, List<String> iterativeParamNames){
    this.storedProc = storedProc;
    this.conditions = conditions;
    this.iterativeCondition = iterativeCondition;
    if (null != paramMappings){
      this.paramMappings.addAll(paramMappings);
    }
    if (null != iterativeParamNames){
      this.iterativeParamNames.addAll(iterativeParamNames);
    }
  }

  
  
  public void configure(Config methodMapConfig){
    String spName = methodMapConfig.getStringValue("name");
    try {
      
      List<String> iterativeParams = null;
      Config[] parameterConfigs = methodMapConfig.getChild("parameters").getChildren("parameter");
  
      // get predicate/condition - tells us if we want to use this SP or not
      // for example IsFrn=true
      // condition is optional, if null then sp will always be applied
      LinkedHashMap<MapAttributeConditionGroup, Boolean> conditions = new LinkedHashMap<MapAttributeConditionGroup, Boolean>();
      
      if (methodMapConfig.containsValue("condition")){
    	MapAttributeConditionGroup group = new MapAttributeConditionGroup(); // a group with only one condition
        addCondition(group, methodMapConfig.getChild("condition"));
        addConditions(conditions, group, methodMapConfig);
      } else if (methodMapConfig.containsValue("conditions")){
        Config[] conditionsConfigs = methodMapConfig.getChildren("conditions"); // get conditions block
        	
        for(Config conditionsConfig : conditionsConfigs) {
        	Config[] conditionConfigs = conditionsConfig.getChildren("condition"); // get condition entries
        	String evaluate = conditionsConfig.getStringValue("evaluate"); // how do we evaluate
        	MapAttributeConditionGroup group = new MapAttributeConditionGroup(evaluate.equalsIgnoreCase("or"));
        	for (Config conditionConfig : conditionConfigs){        		
        		addCondition(group, conditionConfig);
        	}
        	addConditions(conditions, group, conditionsConfig);
        }
      }
      
      // need another conditional map - may have a condition (as above) AND be iterative
      MapAttributeCondition iterativeCondition = null;
      if (methodMapConfig.containsValue("iterativeField")){
        String field = methodMapConfig.getStringValue("iterativeField");
        iterativeCondition = new MapAttributeCondition();
        iterativeCondition = MapAttributeCondition.createIterative(field);      
        iterativeParams = new ArrayList<String>();
        for (Config parameter : parameterConfigs){
          if (parameter.containsValue("iterative")){
            if (parameter.getBooleanValue("iterative")){
              iterativeParams.add(parameter.getStringValue("name"));
            }
          }
        }
      }
      List<StaticMapper> paramMappings = new ArrayList<StaticMapper>();
      for (Config parameter : parameterConfigs) {
        paramMappings.add(generateStoredProcTranslator(parameter));
      }
      init(spName, conditions, iterativeCondition, paramMappings, iterativeParams);
    } catch (Exception e){
      throw new ChainedRuntimeException("Unable to configure stored proc " + spName, e);
    }
  }
  
  private void addCondition(MapAttributeConditionGroup conditions, Config conditionConfig){
    MapAttributeCondition condition = new MapAttributeCondition();
    condition.configure(conditionConfig);
    conditions.addCondition(condition);
  }
  
  private void addConditions(Map<MapAttributeConditionGroup, Boolean> conditions, MapAttributeConditionGroup group, Config conditionConfig){
    boolean conditionOnDeltaOnly = conditionConfig.getBooleanValue("onDeltaOnly", false);
    conditions.put(group, conditionOnDeltaOnly);
  }
  
  
  public boolean conditionalProceed(AttributeMap initial) {
    if (conditions == null || conditions.isEmpty()){
      return true;
    }
    // check all conditions, ignoring delta only ones. return false as soon as any fail
    for (MapAttributeConditionGroup group : conditions.keySet()){
      if (!conditions.get(group)){ // IGNORE onDeltaOnly conditions
        if (!group.testCondition(initial)){
          return false;
        }
      } 
    }
    return true;
  }
  
  /**
   * Checks if the stored procedure has an associated condition,
   * and if whether the stored proc should be applied.
   * @param attributeMap <tt>com.rbsfm.fi.pricing.util.AttributeMap</tt> holding the values to test condition against.
   */
  public boolean conditionalProceed(AttributeMap delta, AttributeMap full) {
    if (conditions == null || conditions.isEmpty()){
      return true;
    }
    // check all conditions, testing delta only ones on delta, and others on the full version. 
    //return false as soon as any fail
    for (MapAttributeConditionGroup group : conditions.keySet()){
      if (conditions.get(group)){ // EVALUATE onDeltaOnly conditions
        if (!group.testCondition(delta)){
          return false;
        }
      } else {
        if (!group.testCondition(full)){
          return false;
        }
      }
    }
    return true;
  }
  
  private boolean testCondition(AttributeMap map, MapAttributeCondition condition){
    if(map instanceof SimpleAttributeMap) {
      return condition.testStringCondition(map);
    } else {
      return condition.testCondition(map);
    }
  }
 
  /**
   * Checks if the stored procedure needs to be run iteratively
   */
  public boolean isIterative() {
    return iterativeCondition != null && iterativeCondition.isIterative();
  }
  
  public List<Query> buildSql(AttributeMap attributeMap, InstrumentMaintSQLGenerator persister, String dataSource) throws SqlGenerationException{

    List<Query> sqlList = new ArrayList<Query>();

    if (isIterative()) return buildIterativeSQL(attributeMap, persister, dataSource);
    LinkedHashMap<String, Object> spParamsAndValues = createParamValueMap(attributeMap);            
    sqlList.add(persister.generateSQLQuery(storedProc, spParamsAndValues, dataSource));
    return sqlList;
    
  }
  
  
  /**
   * Creates an ordered parameter and value list for the stored proc in spName 
   * @param spName Stored procedure to create param/value list for
   * @param attributeMap <tt>com.rbsfm.fi.pricing.util.AttributeMap</tt> holding the values
   * @return <tt>map<String, Object></tt> Params and values
   */
  private LinkedHashMap<String, Object> createParamValueMap(AttributeMap attributeMap) { 

    LinkedHashMap<String, Object> orderedParamList = new LinkedHashMap<String, Object>(); 

    try {
      for (StaticMapper mapping : paramMappings){
        mapping.map(orderedParamList, attributeMap);
      }     
    } catch (Exception e) {
      Log.ERROR.report(" Attempting to use translators for " + this.toString(), e);
      throw new ChainedRuntimeException(e);
    }
    return orderedParamList;    
  }


  
  
  /**
   * Add list of queries for a series of elements.
   * <p>
   * Structures such as schedules and cashflows (for example) arrive in the attribute map as follows:
   * Call=Amount=1.0:Date=2008-10-07:Type=Call,Amount=1.0:Date=2009-01-07:Type=Call ... to n structures
   * Use StringSeriesAttribute and ListMapSerializer to break this down into a List of Map<String,String>
   * Translators then handle typing any fields.
   * <p>
   * Some of the param values will come from the top level attribute map - for example ISIN,
   * whereas others will come from the series -  for example schedule amount/date.
   * 
   * @param spName Stored procedure to create param/value list for
   * @param attributeMap <tt>com.rbsfm.fi.pricing.util.AttributeMap</tt> holding the values
   * @param sqlList List of <tt>Query</tt> objects that is added to
   */
  private List<Query> buildIterativeSQL(AttributeMap attributeMap, InstrumentMaintSQLGenerator persister, String dataSource) {
    List<Query> sqlList = new ArrayList<Query>();
    if (!isIterative())throw new IllegalStateException("Called build iterativeSql on non-iterative stored proc " + this.toString());
    String iterativeField = iterativeCondition.getCondtionField();
    
    String[] series = StringSeriesAttribute.toSeries(attributeMap.get(iterativeField));
    List<Map<String, String>> seriesMaps = ListMapSerializer.deserializeListOfMaps(series);
    for (Map<String, String> seriesItem : seriesMaps) {
      LinkedHashMap<String, Object> paramValues = generateParamsForIteration(attributeMap, seriesItem, paramMappings, iterativeParamNames);
      try {
        sqlList.add(persister.generateSQLQuery(storedProc, paramValues, dataSource));
      } catch (Exception e){ 
        throw new ChainedRuntimeException("Unable to generate sql for " + storedProc, e);
      }
    }
    return sqlList;
  }
  
  private LinkedHashMap<String, Object> generateParamsForIteration(AttributeMap attributeMap, Map<String, String> elementValues, List<StaticMapper> mappings, List<String> iterativeParams){
    LinkedHashMap<String, Object> translatedValues = new LinkedHashMap<String, Object>();
    
    for (StaticMapper mapping : mappings){
      // get the value either from the top level (AttributeMap) or the iterative element depending on config for param
      if (iterativeParams.contains(mapping.getKey())){
        mapping.map(translatedValues, elementValues);
      } else {
        mapping.map(translatedValues, attributeMap);
      }
    }
    return translatedValues; 
  }






  public List<StaticMapper> getParamMappings() {
    return paramMappings;
  }


  public String getStoredProc() {
    return storedProc;
  }


  public List<String> getIterativeParamNames() {
    return iterativeParamNames;
  }
  
  
  StaticMapper generateStoredProcTranslator(Config parameter){
    
    String paramName = parameter.getStringValue("name");
    
    if (parameter.containsValue("translator")){
      return StaticMapper.createTranslatorMapping(paramName, (StaticTranslator)getReferencedComponent(parameter, "translator"));
    }
    
    // type is optional - only needed for defaults/hardcoded values
    String type = null;
    if (parameter.containsValue("type")){
      type = parameter.getStringValue("type");
    }
    // if have "value" then treat as a hardcoded field - implemented using FieldTranslator, but use a dummy from field that won't be found so always uses default 
    if (parameter.containsValue("value")){
      return StaticMapper.createSimpleFieldMapping("_Hardcoded_DummyFrom", paramName, parameter.getStringValue("value"), type);
    }

    String fromField = parameter.getStringValue("from");
    Transformer transformer = null;
    if (parameter.containsValue("transformer")){
      transformer = (Transformer) getReferencedComponent(parameter, "transformer"); 
    }

    if (parameter.containsValue("default")){
      // to support defaults - need to know the correct type, will use a SimpleFieldTranslator which handles all this
      String defaultString = parameter.getStringValue("default");
      return StaticMapper.createSimpleFieldMapping(fromField, paramName, defaultString, type);
    }
    
    if (parameter.containsValue(SimpleFieldTranslator.FORMAT)){
      String defaultString=null;
      String format = parameter.getStringValue(SimpleFieldTranslator.FORMAT);
      return StaticMapper.createSimpleFieldMapping(fromField, paramName, defaultString, type, format);
    }
    
    if (type != null){
      return StaticMapper.createSimpleFieldMapping(fromField, paramName, null, type);
    }

    // ideally just use a mapped field - which simply uses whatever type is in map
    return StaticMapper.createSimpleMappedField(fromField, paramName, transformer);
  }
  
  @Override
  public String toString(){
    return storedProc;
  }
  
  private class MapAttributeConditionGroup {
	  
	  private List<MapAttributeCondition> conditions;
	  private boolean evaluateOr;

	  public MapAttributeConditionGroup() {
		  this(false);
	  }
	  
	  public MapAttributeConditionGroup(boolean evaluateOr) {
		  this.conditions = new ArrayList<MapAttributeCondition>();
		  this.evaluateOr = evaluateOr;
	  }
	  
	  public void addCondition(MapAttributeCondition condition) {
		  conditions.add(condition);
	  }
	  
	  public boolean testCondition(AttributeMap attributeMap) {
		  if(evaluateOr) {
			  for(MapAttributeCondition condition : conditions) {
				  if(StoredProc.this.testCondition(attributeMap, condition)) {
					  return true;
				  }
			  }			  
		  }else {
			  for(MapAttributeCondition condition : conditions) {
				  if(!StoredProc.this.testCondition(attributeMap, condition)) {
					  return false;
				  }
			  }
			  return true;
		  }
		  return false;
	  }
  }
}

