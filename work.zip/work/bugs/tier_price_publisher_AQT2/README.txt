# Problem with NaN price in the EcnQuote

owns: EcnQuote  (id=4489)	
MathHelper.roundPrice(double, double) line: 10	
EcnQuote.truncateOrRound(double, double) line: 931	
EcnQuote.spreadPriceEx(double, double, boolean) line: 864	
EcnQuote.calculatePrice(ExternalBondPriceDetails, boolean, EcnQuoteRounder) line: 1150	
EcnQuote.calculatePrice(ExternalBondPriceDetails, EcnQuoteRounder) line: 1235	
SanitizingPriceBroker(AbstractPriceFeedBroker).computePriceQuote(EcnQuote, double, ExternalBondPriceDetails, boolean) line: 1370	
SanitizingPriceBroker(AbstractPriceFeedBroker).computeQuote(EcnQuote, ExternalBondPriceDetails, boolean) line: 1339	
SanitizingPriceBroker.consumeBondPrice(EcnQuote, EcnQuote, ExternalBondPriceDetails, boolean) line: 521	
SanitizingPriceBroker(AbstractPriceFeedBroker).consumePrice(EcnQuote, EcnQuote, Object, boolean) line: 1248	
SanitizingPriceBroker(AbstractPriceFeedBroker).consumePrice(String, Object, boolean) line: 1309	
SanitizingPriceBroker(AbstractPriceFeedBroker).consumePrice(String, Object) line: 1274	
SanitizingPriceBroker(IndicativePriceBroker).consumePrice(String, Object) line: 29	
ExternalDetailsSubscriber.notifyPriceConsumers(ExternalDetails) line: 237	
ExternalDetailsSubscriber.processPrice(ExternalDetails) line: 368	
ExternalDetailsSubscriber.processDetails(Collection) line: 141	
ExternalDetailsSource$ConsumerDetails.processDetails(Message, Object) line: 65	
ExternalDetailsSource.notifyConsumers(Object, Message) line: 295	
ExternalDetailsSource.internalProcessMessage(Message) line: 258	
ExternalDetailsSource(QueueSourceSink).internalRunWorker() line: 265	

