    private boolean calculateZSpread() {
        InternalBondNode bondNode = getInternalBondNode();
        Bond bond = bondNode.getBondInstrument();
        Date settlementDate = bondNode.getSettlementDate();        
        String curveName = getCurveName();
        double zSpread = runZSpread;
        
        if(curveName != null) { 
            BondPricingInfo pricingInfo = bondNode.getBondPricingInfo().setCurveName(curveName);
            double price = getPrice(PriceType.MID);
            
            runZSpread = bond.priceToZspread(settlementDate, price, pricingInfo);
        }        
        BondCloseCalculator calculator = findCalculator(BondCloseCalculator.DEFAULT_CALC_ID);
        
        if(calculator != null) {
            BondPricingInfo bidPricingInfo = bondNode.getBondPricingInfo().setCurveName(curveName);
            BondPricingInfo askPricingInfo = bondNode.getBondPricingInfo().setCurveName(curveName);
            BondPricingInfo midPricingInfo = bondNode.getBondPricingInfo().setCurveName(curveName);            
            double previousBid = calculator.getPreviousSet().getCloseBidPrice();
            double previousAsk = calculator.getPreviousSet().getCloseAskPrice();
            double previousMid = calculator.getPreviousSet().getClosePrice();
            
            double bidZSpread = bond.priceToZspread(settlementDate, previousBid, bidPricingInfo);
            double askZSpread = bond.priceToZspread(settlementDate, previousAsk, askPricingInfo);  
            double midZSpread = bond.priceToZspread(settlementDate, previousMid, midPricingInfo);
            
            double closeBrokenZSpread = (bidZSpread + askZSpread) / 2;
            double closeGoodZSpread = midZSpread;;
            
            BondPricingInfo nowBidPricingInfo = bondNode.getBondPricingInfo().setCurveName(curveName);
            BondPricingInfo nowAskPricingInfo = bondNode.getBondPricingInfo().setCurveName(curveName);
            double askPrice = getMasterPrice(PriceType.ASK);
            double bidPrice = getMasterPrice(PriceType.BID);
            double nowAskZSpread = bond.priceToZspread(settlementDate, askPrice, nowAskPricingInfo);
            double nowBidZSpread = bond.priceToZspread(settlementDate, bidPrice, nowBidPricingInfo);
            double brokenZSpread = (nowAskZSpread + nowBidZSpread) / 2;
            
            BidAskZSpreadCalculator calc = findCalculator(CalculatorNames.Z_SPREAD);
            double actualAskZSpread = calc.getAskZSpread();
            double actualBidZSpread = calc.getBidZSpread();
            
            // compare the broken mid zspreads
            double shouldBeZero = brokenZSpread - ((actualAskZSpread + actualBidZSpread) / 2);
            
            
            double oldDiff = brokenZSpread - closeBrokenZSpread;
            double changeDiff = runZSpread - closeBrokenZSpread;
            double goodDiff = runZSpread - closeGoodZSpread;
            
            
            if(oldDiff != goodDiff) {
                Log.INFO.report(String.format("%s bidPrc=%s askPrc=%s oldDZSpread=%s changeDZSpread=%s newDZSpread=%s shouldBeZero="+
                        shouldBeZero+" actualAsk=%s["+(nowAskZSpread * 10000.0)+"] actualBid=%s["+
                        (nowBidZSpread * 10000.0)+"]", 
                        bond.getInstrumentId(), 
                        (bidPrice * 100.0), 
                        (askPrice * 100.0), 
                        (oldDiff * 10000.0),
                        (changeDiff * 10000.0), 
                        (goodDiff * 10000.0), 
                        (actualAskZSpread * 10000.0),
                        (actualBidZSpread * 10000.0)));
            }
            
        }        
        return runZSpread != zSpread;            
    }

