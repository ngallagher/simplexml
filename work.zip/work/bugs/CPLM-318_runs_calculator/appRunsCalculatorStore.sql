if exists (select 1 from sysobjects where name='appRunsCalculatorStore' and type='P')
begin
  drop procedure appRunsCalculatorStore
end
go

create proc appRunsCalculatorStore (
       @BondNodeRef     char(20),
       @Version         int,
       @ServerName      varchar(30),
       @UpdaterRef      varchar(32))
as

exec CalculatorAttributeStore @BondNodeRef, 'RunsCalculator', 'runSpread', 'FLOAT', 0, 0, '1-1-1900', '', @Version, @ServerName, @UpdaterRef
exec CalculatorAttributeStore @BondNodeRef, 'RunsCalculator', 'runSkew', 'FLOAT', 0, 0, '1-1-1900', '', @Version, @ServerName, @UpdaterRef
exec CalculatorStore @BondNodeRef, 'RunsCalculator', 'com.rbsfm.fi.pricing.dependency.bond.RunsCalculator', @Version, @ServerName, @UpdaterRef
go

sp_procxmode appRunsCalculatorStore , 'anymode' 
go


