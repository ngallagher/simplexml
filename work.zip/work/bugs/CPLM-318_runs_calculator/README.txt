# The following was added to the bond.xml for runs

  <field name="runSpread" displayName="runSpread" longName="runSpread" dataType="System.Double" editType="edit" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#FF0000" fontFormat="Bold"/>
  <field name="runSkew" displayName="runSkew" longName="runSkew" dataType="System.Double" editType="edit" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#FF0000" fontFormat="Bold"/>
  <field name="runBidPrc" displayName="runBidPrc" longName="runBidPrc" dataType="System.Double" editType="none" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#000000" contextField='ticker'/>
  <field name="runMidPrc" displayName="runMidPrc" longName="runMidPrc" dataType="System.Double" editType="none" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#000000" contextField='ticker'/>
  <field name="runAskPrc" displayName="runAskPrc" longName="runAskPrc" dataType="System.Double" editType="none" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#000000" contextField='ticker'/>
  <field name="runBidYld" displayName="runBidYld" longName="runBidYld" dataType="System.Double" editType="none" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#000000" contextField='ticker'/>
  <field name="runMidYld" displayName="runMidYld" longName="runMidYld" dataType="System.Double" editType="none" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#000000" contextField='ticker'/>
  <field name="runAskYld" displayName="runAskYld" longName="runAskYld" dataType="System.Double" editType="none" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#000000" contextField='ticker'/>
  <field name="runDur" displayName="runDur" longName="runDur" dataType="System.Double" editType="none" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#000000" contextField='ticker'/>
  <field name="runBpv" displayName="runBpv" longName="runBpv" dataType="System.Double" editType="none" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#000000" contextField='ticker'/>
  <field name='runZSpread' displayName='runZSpread' longName='runZSpread' dataType='System.Double' editType='none' multiplier='100' width='65' format='0.0000' backColour='#FFFFC0' foreColour='#000000' contextField='ticker'/>
  <field name='runCloseDiff' displayName='runCloseDiff' longName='runCloseDiff' dataType='System.Double' editType='none' multiplier='100' width='65' format='0.0000' backColour='#FFFFC0' foreColour='#000000' contextField='ticker'/>

# The following XML added for the RunsOverride style LATAM.grid.config

    <style>
      <name>RunsOverride</name>
      <public>True</public>
      <fixed_screen_export>True</fixed_screen_export>
      <fixed_width>80</fixed_width>
      <fixed_height>-1</fixed_height>
      <visible>True</visible>
      <in_grid_splitter>
        <in_name>jotter3</in_name>
        <in_name fixed_width="21">runSpread</in_name>
        <in_name fixed_width="5">runSkew</in_name>
        <in_name fixed_width="5">runBidPrc</in_name>
        <in_name fixed_width="8">runMidPrc</in_name>
        <in_name fixed_width="8">runAskPrc</in_name>   
        <in_name fixed_width="4">runBidYld</in_name>
        <in_name fixed_width="4">runMidYld</in_name>
        <in_name fixed_width="5">runAskYld</in_name>
        <in_name fixed_width="5">runDur</in_name>
        <in_name fixed_width="5">runBpv</in_name>
        <in_name fixed_width="8">runZSpread</in_name>
        <in_name fixed_width="8">runCloseDiff</in_name>
      </in_grid_splitter>
    </style>

# New addition of bond for runs calculator

exec CalculatorStore 'US20441XAB82', 'RunsCalculator', 'com.rbsfm.fi.pricing.dependency.bond.RunsCalculator', 1, 'script', 'gallane'
exec CalculatorAttributeStore 'US20441XAB82', 'RunsCalculator', 'runSpread', 'FLOAT', 0, 0, '1-1-1900', '', 1, 'script', 'gallane'
exec CalculatorAttributeStore 'US20441XAB82', 'RunsCalculator', 'runSkew', 'FLOAT', 0, 0, '1-1-1900', '', 1, 'script', 'gallane'

# Addition of a test bond for the completed calculator

exec CalculatorAttributeStore "US105756BJ84", "RunsCalculator", "runBidPrc", "FLOAT", 0, 0, '1-1-1900', "", 1, "script", "gallane" 
exec CalculatorAttributeStore "US105756BJ84", "RunsCalculator", "runAskPrc", "FLOAT", 0, 0, '1-1-1900', "", 1, "script", "gallane" 
exec CalculatorAttributeStore "US105756BJ84", "RunsCalculator", "runBidYld", "FLOAT", 0, 0, '1-1-1900', "", 1, "script", "gallane" 
exec CalculatorAttributeStore "US105756BJ84", "RunsCalculator", "runAskYld", "FLOAT", 0, 0, '1-1-1900', "", 1, "script", "gallane" 
exec CalculatorStore "US105756BJ84", "RunsCalculator", "com.rbsfm.fi.pricing.dependency.bond.RunsCalculator", 1, "script", "gallane"

# Add the following to the cpbuild/config/templates/pricing.xml file

                <rule name="runBidPrc" action="set" id="SetAttributeMessage5" />
                <rule name="runAskPrc" action="set" id="SetAttributeMessage5" />   
                <rule name="runBidYld" action="set" id="SetAttributeMessage5" />   
                <rule name="runAskYld" action="set" id="SetAttributeMessage5" />  

# Find the attributes of the runs calculator

select * from CalculatorAttribute where NodeRef = 'USP20037AA89' and CalculatorId = 'RunsCalculator'

# Initialize with several double values

(N.B '1-1-1900' single quotes important)
exec CalculatorAttributeStore "USP20037AA89", "RunsCalculator", "runBidPrc", "FLOAT", 0, 0, '1-1-1900', "", 1, "script", "gallane" 
exec CalculatorAttributeStore "USP20037AA89", "RunsCalculator", "runAskPrc", "FLOAT", 0, 0, '1-1-1900', "", 1, "script", "gallane" 
exec CalculatorAttributeStore "USP20037AA89", "RunsCalculator", "runBidYld", "FLOAT", 0, 0, '1-1-1900', "", 1, "script", "gallane" 
exec CalculatorAttributeStore "USP20037AA89", "RunsCalculator", "runAskYld", "FLOAT", 0, 0, '1-1-1900', "", 1, "script", "gallane" 
exec CalculatorStore "USP20037AA89", "RunsCalculator", "com.rbsfm.fi.pricing.dependency.bond.RunsCalculator", 1, "script", "gallane"

# Select the following to see your entry

select * from Calculator where NodeRef = 'US105756AV22'

# To log in to the dev database use the following command

isql -Ufip_dbo -Pfip_dbo_pwd -SDEV -w20000
use fi_LATAM_dev
go

# To add the new calculator the following needs to be used

(N.B '1-1-1900' single quotes important)
exec CalculatorAttributeStore "US105756AV22", "RunsCalculator", "TestAttribute", "STRING", 0, 0, '1-1-1900', "", 1, "script", "gallane" 
exec CalculatorStore "US105756AV22", "RunsCalculator", "com.rbsfm.fi.pricing.dependency.bond.RunsCalculator", 1, "script", "gallane"

# Modified process to use local confing as follows

env="LOCAL"
debug="true"
monitor="true"
token="FIPricing-LATAM-All-Read"
title="LatAm"
client="LATAM"
server="latam-clientmux-offshore"
servers="latam-pricing-offshore"
usesoap="false"
fi_server_details="C:\work\Development\rbsfm\cpbuild\config\install\local-all_server_details.xml"
autologin="true"
region="GREENWICH"

# The original Visual Studion debug configuration is as follows

env="UAT"
debug="true"
monitor="true"
token="FIPricing-LATAM-All-Read"
title="LatAm"
client="LATAM"
server="latam-clientmux-offshore"
servers="latam-pricing-offshore"
usesoap="false"
fi_server_details="http://lon3617xns.fm.rbsgrp.net:8080/uat-all_server_details.xml"
autologin="true"
region="GREENWICH"

# Example of some calculator attributes

	public GenericAttribute[] getGenericAttributes() {
		if (mPersistManualPrice) {
			return new GenericAttribute[] {
				new GenericAttribute(IS_PRICE_ATTRIBUTE_REF, isPriceHolder.get()),
				new GenericAttribute(BID_PRICE_OR_YIELD_ATTRIBUTE_REF, bidPriceOrYieldHolder.get()),
				new GenericAttribute(ASK_PRICE_OR_YIELD_ATTRIBUTE_REF, askPriceOrYieldHolder.get()),
				new GenericAttribute(BID_CHANGED_ATTRIBUTE_REF, mBidChanged),
				new GenericAttribute(ASK_CHANGED_ATTRIBUTE_REF, mAskChanged) };
		}
		else {
			return new GenericAttribute[] {};
		}
	}

# Here is how we get the calculator attributes

"com.rbsfm.fi.pricing.dependency.bond.BidAskManualBondPriceCalculator.getGenericAttributes() line: 187"	 <<<<<------- GET THE CALC ATTRIBS
com.rbsfm.fi.pricing.dependency.tree.TreePersistenceManagerImpl(com.rbsfm.fi.pricing.dependency.tree.AbstractTreePersistenceManager).createCalculatorData(com.rbsfm.fi.pricing.dependency.Calculator) line: 453	
com.rbsfm.fi.pricing.dependency.tree.TreePersistenceManagerImpl(com.rbsfm.fi.pricing.dependency.tree.AbstractTreePersistenceManager).commitCalculator(com.rbsfm.fi.pricing.dependency.InternalNode, com.rbsfm.fi.pricing.dependency.Calculator) line: 289	
com.rbsfm.fi.pricing.dependency.tree.TreePersistenceManagerImpl(com.rbsfm.fi.pricing.dependency.tree.AbstractTreePersistenceManager).writeCalculator(com.rbsfm.fi.pricing.dependency.InternalNode, com.rbsfm.fi.pricing.dependency.Calculator) line: 268	
com.rbsfm.fi.pricing.dependency.tree.DependencyTreeImpl(com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree).writeCalculator(com.rbsfm.fi.pricing.dependency.InternalNode, com.rbsfm.fi.pricing.dependency.Calculator) line: 603	
com.rbsfm.fi.pricing.dependency.bond.BidAskManualBondPriceCalculator(com.rbsfm.fi.pricing.dependency.Calculator).write() line: 1061	
com.rbsfm.fi.pricing.dependency.bond.BidAskManualBondPriceCalculator.setBidPrice(double) line: 303	
com.rbsfm.fi.pricing.dependency.bond.BidAskManualBondPriceCalculator.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 242	
com.rbsfm.fi.pricing.dependency.bond.InternalBondNode.processManualPriceOrYieldMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 456	
com.rbsfm.fi.pricing.dependency.bond.InternalBondNode.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 218	
com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessageWithoutRecalc(com.rbsfm.fi.pricing.external.message.TreeMessage, boolean) line: 130	
com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage, boolean) line: 89	
com.rbsfm.fi.pricing.dependency.tree.DependencyTreeImpl(com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree).processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage, boolean) line: 633	
com.rbsfm.fi.pricing.dependency.bond.PriceYieldCalculator.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 173	
com.rbsfm.fi.pricing.dependency.bond.InternalBondNode(com.rbsfm.fi.pricing.dependency.NodeWithCalculators).forward2Calculator(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 1200	
com.rbsfm.fi.pricing.dependency.bond.InternalBondNode.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 279	
com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessageWithoutRecalc(com.rbsfm.fi.pricing.external.message.TreeMessage, boolean) line: 130	
com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage, boolean) line: 89	
com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 79	
com.rbsfm.fi.pricing.dependency.tree.DependencyTreeImpl(com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree).processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 628	
com.rbsfm.fi.pricing.dependency.remote.ClientImpl.processMessage(java.lang.String, java.lang.String) line: 243	



# Here is how messages are intercepted by the BidAskManualBondPriceCalculator class

com.rbsfm.fi.pricing.dependency.bond.BidAskManualBondPriceCalculator.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 241	
com.rbsfm.fi.pricing.dependency.bond.InternalBondNode.processManualPriceOrYieldMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 456	
com.rbsfm.fi.pricing.dependency.bond.InternalBondNode.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 218	
com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessageWithoutRecalc(com.rbsfm.fi.pricing.external.message.TreeMessage, boolean) line: 130	
com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage, boolean) line: 89	
com.rbsfm.fi.pricing.dependency.tree.DependencyTreeImpl(com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree).processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage, boolean) line: 633	
com.rbsfm.fi.pricing.dependency.bond.PriceYieldCalculator.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 173	
com.rbsfm.fi.pricing.dependency.bond.InternalBondNode(com.rbsfm.fi.pricing.dependency.NodeWithCalculators).forward2Calculator(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 1200	
com.rbsfm.fi.pricing.dependency.bond.InternalBondNode.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 279	
com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessageWithoutRecalc(com.rbsfm.fi.pricing.external.message.TreeMessage, boolean) line: 130	
com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage, boolean) line: 89	
com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 79	
com.rbsfm.fi.pricing.dependency.tree.DependencyTreeImpl(com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree).processMessage(com.rbsfm.fi.pricing.external.message.TreeMessage) line: 628	
com.rbsfm.fi.pricing.dependency.remote.ClientImpl.processMessage(java.lang.String, java.lang.String) line: 243	
sun.reflect.NativeMethodAccessorImpl.invoke0(java.lang.reflect.Method, java.lang.Object, java.lang.Object[]) line: not available [native method]	
sun.reflect.NativeMethodAccessorImpl.invoke(java.lang.Object, java.lang.Object[]) line: 39	
sun.reflect.DelegatingMethodAccessorImpl.invoke(java.lang.Object, java.lang.Object[]) line: 25	
java.lang.reflect.Method.invoke(java.lang.Object, java.lang.Object...) line: 597	
electric.util.reflect.Invocation.execute(java.lang.Object, java.lang.reflect.Method, java.lang.Object[]) line: not available	
electric.util.reflect.Invocation.invoke(java.lang.Object, java.lang.reflect.Method, java.lang.Object[]) line: not available	
electric.service.object.ObjectService.invoke(java.lang.reflect.Method, java.lang.Object[], electric.util.Context) line: not available	
electric.soap.local.handlers.service.SOAPToServiceHandler.invoke(electric.soap.SOAPMessage, electric.util.Context) line: not available	
electric.soap.local.handlers.service.SOAPToServiceHandler.handle(electric.soap.SOAPMessage, electric.util.Context) line: not available	
electric.soap.security.handlers.SecurityHandler.handle(electric.soap.SOAPMessage, electric.util.Context) line: not available	
electric.soap.handlers.interceptor.SOAPInterceptorHandler.handle(electric.soap.SOAPMessage, electric.util.Context) line: not available	
electric.soap.routing.RoutingHandler.handle(electric.soap.SOAPMessage, electric.util.Context) line: not available	
electric.soap.handlers.logging.SOAPLoggingHandler.handle(electric.soap.SOAPMessage, electric.util.Context) line: not available	
electric.soap.handlers.setup.SetupHandler.handle(electric.soap.SOAPMessage, electric.util.Context) line: not available	
electric.soap.http.handler.HTTPToSOAP.service(electric.server.http.ServletServer, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse) line: not available	
electric.server.http.ServletServer.service(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse) line: not available	
electric.server.http.ServletServer(javax.servlet.http.HttpServlet).service(javax.servlet.ServletRequest, javax.servlet.ServletResponse) line: 853	
electric.servlet.Config.service(javax.servlet.ServletRequest, javax.servlet.ServletResponse) line: not available	
electric.servlet.HTTPContext.service(java.lang.String, javax.servlet.ServletRequest, javax.servlet.ServletResponse) line: not available	
electric.servlet.ServletEngine.service(java.lang.String, javax.servlet.ServletRequest, javax.servlet.ServletResponse) line: not available	
electric.webserver.WebServer.service(electric.net.channel.IChannel) line: not available	
electric.net.socket.SocketServer.run(electric.net.socket.SocketRequest) line: not available	
electric.net.socket.SocketRequest.run() line: not available	
electric.util.thread.ThreadPool.run() line: not available	
java.lang.Thread.run() line: 619	


# The following calculator is a good starting point

BidAskManualBondPriceCalculator

Take a look at the doc i sent you on your first about how to add a calc and at  BidAskManualBondPriceCalculator - this is a pretty straightforward calculator which allows the trader to type in price into CP and calcs the anlytics from that.

