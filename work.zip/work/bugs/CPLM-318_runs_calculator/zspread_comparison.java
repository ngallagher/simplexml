    private boolean calculateZSpread() {
        InternalBondNode bondNode = getInternalBondNode();
        Bond bond = bondNode.getBondInstrument();
        Date settlementDate = bondNode.getSettlementDate();        
        String curveName = getCurveName();
        
        if(curveName != null) { 
            BondPricingInfo bidPricingInfo = bondNode.getBondPricingInfo().setCurveName(curveName);
            BondPricingInfo askPricingInfo = bondNode.getBondPricingInfo().setCurveName(curveName);
            BondPricingInfo midPricingInfo = bondNode.getBondPricingInfo().setCurveName(curveName);
            double bidPrice = getPrice(PriceType.BID);
            double askPrice = getPrice(PriceType.ASK);
            double midPrice = getPrice(PriceType.MID);
            double bidZSpread = bond.priceToZspread(settlementDate, bidPrice, bidPricingInfo);
            double askZSpread = bond.priceToZspread(settlementDate, askPrice, askPricingInfo);            
            double midZSpread = bond.priceToZspread(settlementDate, midPrice, midPricingInfo);
            double zSpread = (bidZSpread + askZSpread) / 2;
            
            if(MathUtil.round(midZSpread, 6) != MathUtil.round(zSpread, 6) && MathUtil.round(midPrice, 6) == MathUtil.round(((askPrice - bidPrice)/2) + bidPrice, 6)) {
                Log.INFO.report(String.format("Calculating Z spread for %s bidPrice=%s askPrice=%s midPrice=%s bidZSpread=%s askZSpread=%s midZSpread=%s ZSpread=%s curveName=%s",
                        bond.getInstrumentId(), bidPrice, askPrice, midPrice, bidZSpread, askZSpread, midZSpread, zSpread, curveName));
            }
 
            if(runZSpread != zSpread) {
                runZSpread = zSpread;
                return true;            
            }                       
        }
        return false;
    }

