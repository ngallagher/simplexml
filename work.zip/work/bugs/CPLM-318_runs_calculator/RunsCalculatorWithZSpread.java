package com.rbsfm.fi.pricing.dependency.bond;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import com.rbsfm.common.date.Date;
import com.rbsfm.common.system.Log;
import com.rbsfm.fi.pricing.dependency.Calculator;
import com.rbsfm.fi.pricing.dependency.DependencyTree;
import com.rbsfm.fi.pricing.dependency.Status;
import com.rbsfm.fi.pricing.dependency.generic.GenericAttribute;
import com.rbsfm.fi.pricing.dependency.generic.GenericCalculator;
import com.rbsfm.fi.pricing.dependency.util.AssignmentChangeType;
import com.rbsfm.fi.pricing.dependency.util.PriceType;
import com.rbsfm.fi.pricing.external.CalculatorNames;
import com.rbsfm.fi.pricing.external.attribute.Attribute;
import com.rbsfm.fi.pricing.external.message.SetAttributeMessage;
import com.rbsfm.fi.pricing.external.message.TreeMessage;
import com.rbsfm.fi.pricing.newanalytics.bond.Bond;
import com.rbsfm.fi.pricing.newanalytics.bond.BondPricingInfo;
import com.rbsfm.fi.pricing.newanalytics.bond.BondResults;

/**
 * This is the {@link RunsCalculator} used to calculate run overrides.
 * 
 * <field name="runBidPrc" displayName="runBidPrc" longName="runBidPrc" dataType="System.Double" editType="edit" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#FF0000" fontFormat="Bold" contextField="ticker" local="true"/>
 * <field name="runAskPrc" displayName="runAskPrc" longName="runAskPrc" dataType="System.Double" editType="edit" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#FF0000" fontFormat="Bold" contextField="ticker" local="true"/>
 * <field name="runBidYld" displayName="runBidYld" longName="runBidYld" dataType="System.Double" editType="edit" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#FF0000" fontFormat="Bold" contextField="ticker" local="true"/>
 * <field name="runAskYld" displayName="runAskYld" longName="runAskYld" dataType="System.Double" editType="edit" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#FF0000" fontFormat="Bold" contextField="ticker" local="true"/>
 * <field name="runDur" displayName="runDur" longName="runDur" dataType="System.Double" editType="none" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#FF0000" fontFormat="Bold" contextField="ticker" local="true"/>
 * <field name="runBpv" displayName="runBpv" longName="runBpv" dataType="System.Double" editType="none" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#FF0000" fontFormat="Bold" contextField="ticker" local="true"/>
 *
 * @author Niall Gallagher
 */
public class RunsCalculator extends AbstractBondPriceCalculator implements GenericCalculator {
    
    public static final String DEFAULT_CALC_ID = "RunsCalculator";    
    
    public static final String RUN_BID_PRICE_OVERRIDE = "runBidPrc";
    public static final String RUN_ASK_PRICE_OVERRIDE = "runAskPrc";
    public static final String RUN_BID_YIELD_OVERRIDE = "runBidYld";
    public static final String RUN_ASK_YIELD_OVERRIDE = "runAskYld";
    public static final String RUN_DURATION_OVERRIDE = "runDur";
    public static final String RUN_BPV_OVERRIDE = "runBpv";
    public static final String RUN_ZSPREAD_OVERRIDE = "runZSpread";
    
    /**
     * Represent what is actually stored in the underlying database.
     */
    private final DoubleReference runBidPrice = new DoubleReference();
    private final DoubleReference runAskPrice = new DoubleReference();
    
    public RunsCalculator(DependencyTree tree, String ownerId, String id) {
        super(tree, ownerId, id, false);
    }

    /**
     * In order for this to be executed the status needs to be OK. This
     * is determined from the {@link Status#isOK()}. The status may not be
     * OK if the bond does not have a price or if some other calculator
     * sets the status to be an error.
     * 
     * @return true if the calculation succeeded
     */
    @Override
    protected boolean calculateDerivedImpl() {   
        // TODO set the master price on the bond results
        // TODO this can be used to set calculate the values
        return false;
    }

    @Override
    protected boolean calculateMasterImpl() {
        return false;
    }

    /**
     * This is used to acquire a snapshot of the state of this
     * calculator instance. The values returned by this method will 
     * be used to populate the database.
     * 
     * @return this returns the attributes for this calculator
     */
    @Override
    public GenericAttribute[] getGenericAttributes() {
        return new GenericAttribute[]{
                new GenericAttribute(RUN_BID_PRICE_OVERRIDE, runBidPrice.toDouble()),
                new GenericAttribute(RUN_ASK_PRICE_OVERRIDE, runAskPrice.toDouble()),
        };
    }

    /**
     * This method is used to recover state from the database. Each
     * attribute represents a state variable keyed by a known name.
     * <p>
     * The map of attributes must contain the full state of the calculator
     * so that it can be used to populate its members.    
     *  
     * @param atts the state of this calculator
     */
    @Override
    public void setGenericAttributes(Map<String, GenericAttribute> atts) {
        double bidPrice = GenericAttribute.getDoubleValue(atts, RUN_BID_PRICE_OVERRIDE, this);
        double askPrice = GenericAttribute.getDoubleValue(atts, RUN_ASK_PRICE_OVERRIDE, this);

        if(bidPrice != Double.NaN && bidPrice != 0.0) {
            runAskPrice.set(askPrice);
        }
        if(askPrice != Double.NaN && askPrice != 0.0) {
            runAskPrice.set(askPrice);
        }        
    }
    
    /**
     * This method is invoked after the {@link Calculator#setGenericAttributes)} method
     * is called. It allows for a one time initialisation of the calculator. This is
     * useful as the prices can no be set until all node references are resolved.
     * <p>
     * Here the internal {@link BondPricingHelper} is initialised with the values from
     * the database. This ensures that the state of the calculator is good and that
     * the yield and price overrides have been calculated.
     */
    @Override
    public void preCalculationInitialisation() {
        double askPrice = getPrice(PriceType.ASK);
        double bidPrice = getPrice(PriceType.BID);
        
        setPrice(bidPrice, askPrice);
    }
    
    /**
     * This method is used to populate the given collection with
     * attributes that are to be delivered to the client.
     * <p>
     * An important note on the attributes added by this method is that
     * it makes it appear on the client grid. If the attribute is not
     * added then the client grid will not display it, or at the very 
     * least it will not allow it to be edited. Also, only nodes
     * configured with this calculator can have attributes added.
     * 
     * @param the client side attributes
     */
    @Override
    public void addAttributes(Collection<Attribute> atts) {
        super.addAttributes(atts);
        
        atts.add(createAttribute(RUN_BID_PRICE_OVERRIDE, getPrice(PriceType.BID), getStatusId()));
        atts.add(createAttribute(RUN_ASK_PRICE_OVERRIDE, getPrice(PriceType.ASK), getStatusId()));
        atts.add(createAttribute(RUN_BID_YIELD_OVERRIDE, getYield(PriceType.BID), getStatusId()));
        atts.add(createAttribute(RUN_ASK_YIELD_OVERRIDE, getYield(PriceType.ASK), getStatusId()));
        atts.add(createAttribute(RUN_DURATION_OVERRIDE, getDuration(), getStatusId()));
        atts.add(createAttribute(RUN_BPV_OVERRIDE, getBpv(), getStatusId()));
        atts.add(createAttribute(RUN_ZSPREAD_OVERRIDE, getZSpread(), getStatusId()));
    }    
    
    /**
     * This is used to process a message from the server when a property
     * associated with a bond changes.
     * 
     * @param message this is the message
     */
    @Override
    public void processMessage(TreeMessage message) {
        if(message instanceof SetAttributeMessage) {
           processMessage((SetAttributeMessage) message);
        }
    }
    
    /**
     * This is used process the message from the client.
     * 
     * @param message the message from the client
     */
    private void processMessage(SetAttributeMessage message) {
        String attributeName = message.getAttributeName();
        
        if(attributeName.equals(RUN_BID_PRICE_OVERRIDE)) {
            setPriceOverride(message.getDoubleValue(), PriceType.BID);
        } else if(attributeName.equals(RUN_ASK_PRICE_OVERRIDE)) {
            setPriceOverride(message.getDoubleValue(), PriceType.ASK);            
        } else if(attributeName.equals(RUN_BID_YIELD_OVERRIDE)) {
            setYieldOverride(message.getDoubleValue(), PriceType.BID);
        } else if(attributeName.equals(RUN_ASK_YIELD_OVERRIDE)) {
            setYieldOverride(message.getDoubleValue(), PriceType.ASK);
        } 
    }
    
    private InternalBondNode getInternalBondNode() {
        return (InternalBondNode) getOwner();
    }
    
    private String getCurveName() {
        InternalBondNode bondNode = getInternalBondNode();
        Calculator calculator = bondNode.lookupCalculator(CalculatorNames.Z_SPREAD);
        
        if(calculator != null) {
            return ((BidAskZSpreadCalculator)calculator).getCurve().getName();
        }
        // TODO: Fix this so that you can get the curve name
        return "IYC23.USD";
    }
    
    private double getZSpread() {
        InternalBondNode bondNode = getInternalBondNode();
        Bond bond = bondNode.getBondInstrument();
        Date settlementDate = bondNode.getSettlementDate();
        String curveName = getCurveName();           
        double price = getBondResults(PriceType.MID).getCleanPrice();
        BondPricingInfo bpi = bondNode.getBondPricingInfo().setCurveName(curveName);
        
        return bond.priceToZspread(settlementDate, price, bpi);        
    }
    
    private double getDuration() {
        return getBondResults(PriceType.MID).getDuration();
    }

    private double getBpv() {
        return getBondResults(PriceType.MID).getBpv();
    }
    
    private double getPrice(PriceType type) {
        if(isPriceOverridden(type)) {
            return runAskPrice.get();
        }
        return getMasterPrice(type);
    }
    
    private double getMasterPrice(PriceType type) {
        return getOwnerBondNode().getMasterPrice(type);
    }
    
    private void setPriceOverride(double price, PriceType type) {
        DoubleReference priceOverride = getPriceOverride(type);        
       
        if(price == 0.0 || price == Double.NaN) { // Zero means clear override
            price = getMasterPrice(type);
        }
        priceOverride.set(price); // Set the persistable override value
        setPrice(price, type); // Update the internal state for calculation
        write(); // Persist the change
        inputsChanged(); // Notify of the changes
    }
    
    private void setYieldOverride(double yield, PriceType type) {
        if(setYield(yield, type)) {        
            BondResults bondResults = getBondResults(type);
            double newPrice = bondResults.getCleanPrice();
        
            setPriceOverride(newPrice, type);
        }
    }
    
    private double getYield(PriceType type) {
        if(isPriceOverridden(type)) {
            return getBondResults(type).getYield();
        }
        return getMasterYield(type);
    }
    
    private double getMasterYield(PriceType type) {
        return getOwnerBondNode().getMasterYield(type);
    }
    
    private boolean isPriceOverridden(PriceType type) {
        return getPriceOverride(type).isSet();
    }
    
    private DoubleReference getPriceOverride(PriceType type) {
        if(PriceType.ASK.equals(type)) {
            return runAskPrice;
        }
        if(PriceType.BID.equals(type)) {
            return runAskPrice;
        }
        return null;
    }

    /**
     * This method is called when there are changes to the calculators
     * state in the database. The provided calculator is instantiated
     * directly from the database.
     * 
     * @param rhs the newly created calculator
     */    
    @Override
    protected void assignment(Calculator rhs) {
        super.assignment(rhs);
        
        RunsCalculator calc = (RunsCalculator) rhs;        
        double bidPrice = assignDoubleChange(getPrice(PriceType.BID), calc.getPrice(PriceType.BID), AssignmentChangeType.VALUE);
        double askPrice = assignDoubleChange(getPrice(PriceType.ASK), calc.getPrice(PriceType.ASK), AssignmentChangeType.VALUE);
        
        setPrice(bidPrice, askPrice);
    }
    
    
    /**
     * This is a simple reference to a double value, which may or may
     * not be set depending on the values from the database.
     */
    private static class DoubleReference extends AtomicReference<Double> {
        
        public double toDouble() {
            return get() == null ? 0.0 : get();
        }
        
        public boolean isSet() {
            return get() != null;
        }            
    }
}

