package com.rbsfm.fi.pricing.dependency.bond;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import com.rbsfm.fi.pricing.dependency.Calculator;
import com.rbsfm.fi.pricing.dependency.DependencyTree;
import com.rbsfm.fi.pricing.dependency.Status;
import com.rbsfm.fi.pricing.dependency.generic.GenericAttribute;
import com.rbsfm.fi.pricing.dependency.generic.GenericCalculator;
import com.rbsfm.fi.pricing.dependency.util.AssignmentChangeType;
import com.rbsfm.fi.pricing.dependency.util.PriceType;
import com.rbsfm.fi.pricing.external.attribute.Attribute;
import com.rbsfm.fi.pricing.external.message.SetAttributeMessage;
import com.rbsfm.fi.pricing.external.message.TreeMessage;

/**
 * This is the {@link RunsCalculator} used to calculate run overrides.
 * 
 * <field name="runBidPrc" displayName="runBidPrc" longName="runBidPrc" dataType="System.Double" editType="edit" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#FF0000" fontFormat="Bold" contextField="ticker" local="true"/>
 * <field name="runAskPrc" displayName="runAskPrc" longName="runAskPrc" dataType="System.Double" editType="edit" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#FF0000" fontFormat="Bold" contextField="ticker" local="true"/>
 * <field name="runBidYld" displayName="runBidYld" longName="runBidYld" dataType="System.Double" editType="edit" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#FF0000" fontFormat="Bold" contextField="ticker" local="true"/>
 * <field name="runAskYld" displayName="runAskYld" longName="runAskYld" dataType="System.Double" editType="edit" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#FF0000" fontFormat="Bold" contextField="ticker" local="true"/>
 * <field name="runDur" displayName="runDur" longName="runDur" dataType="System.Double" editType="none" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#FF0000" fontFormat="Bold" contextField="ticker" local="true"/>
 * <field name="runBpv" displayName="runBpv" longName="runBpv" dataType="System.Double" editType="none" multiplier="100" width="65" format="0.0000" backColour="#FFFFC0" foreColour="#FF0000" fontFormat="Bold" contextField="ticker" local="true"/>
 *
 * @author Niall Gallagher
 */
public class RunsCalculator extends AbstractBondPriceCalculator implements GenericCalculator {
    
    public static final String DEFAULT_CALC_ID = "RunsCalculator";    
    
    public static final String RUN_BID_PRICE_OVERRIDE = "runBidPrc";
    public static final String RUN_ASK_PRICE_OVERRIDE = "runAskPrc";
    public static final String RUN_BID_YIELD_OVERRIDE = "runBidYld";
    public static final String RUN_ASK_YIELD_OVERRIDE = "runAskYld";
    public static final String RUN_DURATION_OVERRIDE = "runDur";
    public static final String RUN_BPV_OVERRIDE = "runBpv";
    
    /**
     * Represent what is actually stored in the underlying database.
     */
    private final DoubleReference runBidPrice = new DoubleReference();
    private final DoubleReference runAskPrice = new DoubleReference();
    
    public RunsCalculator(DependencyTree tree, String ownerId, String id) {
        super(tree, ownerId, id, false);
    }

    /**
     * In order for this to be executed the status needs to be OK. This
     * is determined from the {@link Status#isOK()}. The status may not be
     * OK if the bond does not have a price or if some other calculator
     * sets the status to be an error.
     * 
     * @return true if the calculation succeeded
     */
    @Override
    protected boolean calculateDerivedImpl() {   
        return false;
    }

    @Override
    protected boolean calculateMasterImpl() {
        return false;
    }

    /**
     * This is used to acquire a snapshot of the state of this
     * calculator instance.
     * 
     * @return this returns the attributes for this calculator
     */
    @Override
    public GenericAttribute[] getGenericAttributes() {
        return new GenericAttribute[]{
                new GenericAttribute(RUN_BID_PRICE_OVERRIDE, getBidPrice()),
                new GenericAttribute(RUN_ASK_PRICE_OVERRIDE, getAskPrice()),
        };
    }

    /**
     * This method is used to recover state from the database. Each
     * attribute represents a state variable keyed by a known name.
     * <p>
     * The map of attributes must contain the full state of the calculator
     * so that it can be used to populate its members.    
     *  
     * @param atts the state of this calculator
     */
    @Override
    public void setGenericAttributes(Map<String, GenericAttribute> atts) {
        double bidPrice = GenericAttribute.getDoubleValue(atts, RUN_BID_PRICE_OVERRIDE, this);
        double askPrice = GenericAttribute.getDoubleValue(atts, RUN_ASK_PRICE_OVERRIDE, this);

        if(bidPrice != Double.NaN && bidPrice != 0.0) {
            runAskPrice.set(askPrice);
        }
        if(askPrice != Double.NaN && askPrice != 0.0) {
            runAskPrice.set(askPrice);
        }        
    }
    
    /**
     * This method is invoked after the {@link Calculator#setGenericAttributes)} method
     * is called. It allows for a one time initialisation of the calculator. This is
     * useful as the prices can no be set until all node references are resolved. 
     */
    @Override
    public void preCalculationInitialisation() {
        Double askPrice = runAskPrice.get();
        Double bidPrice = runBidPrice.get();
        
        if(askPrice != null) {
            setPrice(askPrice, PriceType.ASK);
        }
        if(bidPrice != null) {
            setPrice(bidPrice, PriceType.BID);
        }
    }
    
    /**
     * This method is used to populate the given collection with
     * attributes that are to be delivered to the client.
     * <p>
     * An important note on the attributes added by this method is that
     * it makes it appear on the client grid. If the attribute is not
     * added then the client grid will not display it, or at the very 
     * least it will not allow it to be edited. Also, only nodes
     * configured with this calculator can have attributes added.
     * 
     * @param the client side attributes
     */
    @Override
    public void addAttributes(Collection<Attribute> atts) {
        super.addAttributes(atts);
        
        atts.add(createAttribute(RUN_BID_PRICE_OVERRIDE, getBidPrice(), getStatusId()));
        atts.add(createAttribute(RUN_ASK_PRICE_OVERRIDE, getAskPrice(), getStatusId()));
        atts.add(createAttribute(RUN_BID_YIELD_OVERRIDE, getBidYield(), getStatusId()));
        atts.add(createAttribute(RUN_ASK_YIELD_OVERRIDE, getAskYield(), getStatusId()));
        atts.add(createAttribute(RUN_DURATION_OVERRIDE, getDuration(), getStatusId()));
        atts.add(createAttribute(RUN_BPV_OVERRIDE, getBpv(), getStatusId()));
    }    
    
    /**
     * This is used to process a message from the server when a property
     * associated with a bond changes.
     * 
     * @param message this is the message
     */
    @Override
    public void processMessage(TreeMessage message) {
        if(message instanceof SetAttributeMessage) {
           processMessage((SetAttributeMessage) message);
        }
    }
    
    /**
     * This is used process the message from the client.
     * 
     * @param message the message from the client
     */
    private void processMessage(SetAttributeMessage message) {
        String attributeName = message.getAttributeName();
        
        if(attributeName.equals(RUN_BID_PRICE_OVERRIDE)) {
            setBidPrice(message.getDoubleValue());
        } else if(attributeName.equals(RUN_ASK_PRICE_OVERRIDE)) {
            setAskPrice(message.getDoubleValue());            
        } else if(attributeName.equals(RUN_BID_YIELD_OVERRIDE)) {
            setBidYield(message.getDoubleValue());
        } else if(attributeName.equals(RUN_ASK_YIELD_OVERRIDE)) {
            setAskYield(message.getDoubleValue());
        } 
    }
    
    // TODO Fix me
    public double getDuration() {
        double bidPrice = getBondResults(PriceType.BID).getCleanPrice();
        
        if(bidPrice == Double.NaN || bidPrice == 0.0) {
            return getBondResults(PriceType.BID).getDuration();
        }
        double askPrice = getBondResults(PriceType.ASK).getCleanPrice();
        
        if(askPrice == Double.NaN || askPrice == 0.0) {
            return getBondResults(PriceType.ASK).getDuration();
        }
        return 0.0;
    }

    // TODO Fix me
    public double getBpv() {
        double bidPrice = getBondResults(PriceType.BID).getCleanPrice();
        
        if(bidPrice == Double.NaN || bidPrice == 0.0) {
            return getBondResults(PriceType.BID).getBpv();
        }
        double askPrice = getBondResults(PriceType.ASK).getCleanPrice();
        
        if(askPrice == Double.NaN || askPrice == 0.0) {
            return getBondResults(PriceType.ASK).getBpv();
        }
        return 0.0;
    }
    
    /**
     * This is used to set the bid price. The data managed by
     * this calculator will be persisted after this invocation.
     * 
     * @param bidPrice the bid price to be set
     */
    public void setBidPrice(double bidPrice) {
        double runBidPrice = getBidPrice();

        if(runBidPrice != bidPrice) {
            setPrice(bidPrice, PriceType.BID);
            write();
            inputsChanged();
        }
    }
    
    public double getBidPrice() {
        double bidPrice = getBondResults(PriceType.BID).getCleanPrice();
        
        if(bidPrice == Double.NaN || bidPrice == 0.0) {
            bidPrice = getOwnerBondNode().getMasterPrice(PriceType.BID);
        }
        return bidPrice;
    }
    
    /**
     * This is used to set the ask price. The data managed by
     * this calculator will be persisted after this invocation.
     * 
     * @param askPrice the ask price to be set
     */
    public void setAskPrice(double askPrice) {
        double runAskPrice = getAskPrice();
        
        if(runAskPrice != askPrice) {
            setPrice(askPrice, PriceType.ASK);
            write();
            inputsChanged();
        }
    }
    
    public double getAskPrice() {
        double askPrice = getBondResults(PriceType.ASK).getCleanPrice();
        
        if(askPrice == Double.NaN || askPrice == 0.0) {
            askPrice = getOwnerBondNode().getMasterPrice(PriceType.BID);
        }
        return askPrice;
    }
    
    /**
     * This is used to set the bid yield. The data managed by
     * this calculator will be persisted after this invocation.
     * 
     * @param bidYield the bid yield to be set
     */
    public void setBidYield(double bidYield) {
        double runBidYield = getBidYield();
        
        if(runBidYield != bidYield) {
            setYield(bidYield, PriceType.BID);
            write();
            inputsChanged();
        }
    }
    
    public double getBidYield() {
        double bidYield = getBondResults(PriceType.BID).getYield();
        
        if(bidYield == Double.NaN || bidYield == 0.0) {
            bidYield = getOwnerBondNode().getMasterYield(PriceType.BID);
        }
        return bidYield;
    }
    
    /**
     * This is used to set the ask yield. The data managed by
     * this calculator will be persisted after this invocation.
     * 
     * @param bidPrice the ask yield to be set
     */
    public void setAskYield(double askYield) {
        double runAskYield = getAskYield();
        
        if(runAskYield != askYield) {
            setYield(askYield, PriceType.ASK);
            write();
            inputsChanged();
        }
    }
    
    public double getAskYield() {
        double askYield = getBondResults(PriceType.ASK).getYield();
        
        if(askYield == Double.NaN || askYield == 0.0) {
            askYield = getOwnerBondNode().getMasterYield(PriceType.ASK);
        }
        return askYield;
    }

    /**
     * This method is called when there are changes to the calculators
     * state in the database. The provided calculator is instantiated
     * directly from the database.
     * 
     * @param rhs the newly created calculator
     */    
    @Override
    protected void assignment(Calculator rhs) {
        super.assignment(rhs);
        
        RunsCalculator calc = (RunsCalculator) rhs;        
        double bidPrice = assignDoubleChange(getBidPrice(), calc.getBidPrice(), AssignmentChangeType.VALUE);
        double askPrice = assignDoubleChange(getAskPrice(), calc.getAskPrice(), AssignmentChangeType.VALUE);
        
        setPrice(bidPrice, PriceType.BID);
        setPrice(askPrice, PriceType.ASK);
    }
    
    
    /**
     * This is a simple reference to a double value, which may or may
     * not be set depending on the values from the database.
     */
    private static class DoubleReference extends AtomicReference<Double> {
        
        public boolean isSet() {
            return get() != null;
        }            
    }
}

