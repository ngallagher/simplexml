while(<>){
    chomp;
    if(/\w+/){
  print "exec CalculatorAttributeStore '$_', 'RunsCalculator', 'runBidPrc', 'FLOAT', 0, 0, '1-1-1900', '', 1, 'script', 'gallane'\n"; 
  print "exec CalculatorAttributeStore '$_', 'RunsCalculator', 'runAskPrc', 'FLOAT', 0, 0, '1-1-1900', '', 1, 'script', 'gallane'\n"; 
  print "exec CalculatorAttributeStore '$_', 'RunsCalculator', 'runBidYld', 'FLOAT', 0, 0, '1-1-1900', '', 1, 'script', 'gallane'\n"; 
  print "exec CalculatorAttributeStore '$_', 'RunsCalculator', 'runAskYld', 'FLOAT', 0, 0, '1-1-1900', '', 1, 'script', 'gallane'\n"; 
  print "exec CalculatorStore '$_', 'RunsCalculator', 'com.rbsfm.fi.pricing.dependency.bond.RunsCalculator', 1, 'script', 'gallane'\n";          
    }
}
