# Color of the status

Alive && !Enabled && !IsPending = RED

######## BELOW HERE IS LATAM #########

# Added this to the CompositeEcnPublisher to get everything working

	/**
	 * The message composed here is used to send a BrokerStatus message to the 
	 * client. Which will reflect the message in a D2C sizes button. See the
	 * {@link ExchangeMessageFormatter} to see how the object is converted to
	 * a message for consumption by the client.
	 * <p>
	 * The client colors the D2C sizes button using the enabled, alive, and
	 * pending attributes in a BrokerStatus message. The following states
	 * color the button accordingly.	  
	 * <pre>
	 * alive=false D2C=grey
	 * alive=true enabled=true D2C=green
	 * alive=true enabled=false D2C=red
	 * alive=true enabled=false pending=true D2C=amber
	 * alive=true enabled=false pending=false D2C=red
	 * </pre>
	 * Here we say that pending=true when there is at least one gateway enabled.
	 * If all gateways are disabled or disconnected then pending=false and 
	 * enabled=false.
	 *
	 * @return the object representing the D2C status message
	 * 
	 * @see com.rbsfm.fi.pricing.ecn.mux.ExchangeMessageFormatter
	 */
	private void publish() {
        List<EcnStats> stats;
        synchronized (statistics) {
            stats = new ArrayList<EcnStats>(statistics.values());
        }
	        
        StringBuilder builder = new StringBuilder();
	    boolean alive = true;
	    boolean enabled = true;
	    boolean pending = false;
        int available = 0;
        int turnedOn = 0;
	    
        for (EcnStats stat : stats) {           
            synchronized (stat) {
                if(stat.id != null) {
                    appendD2CStatus(stat, builder);
                }
                available += stat.available;
                turnedOn += stat.turnedOn;
                
                // the translation between EcnStats objects
                // and the broker status is not very
                // intuitive here, but it is correct
                if(!stat.enabled || !stat.alive) {
                    enabled = false;                    
                }
                if(stat.enabled && stat.alive) {
                    pending = true;
                }                
            }
        }
        EcnPublisherDetails status = new EcnPublisherDetails(
                id, enabled, "", alive, "", "Multiple",
                Integer.toString(available), Integer.toString(turnedOn), 
                true, true, builder.toString(), pending);
        
        
        listeners.notifyListeners(status);
	}


# In the C# code the broker status is found at 

C:\work\development\client\cpclient\CPClient\src\util\BrokerDetails.cs

# Confirmation that heartbeat causes connection established to be called

        at com.rbsfm.fi.pricing.ecn.pricefeed.AbstractEcnPublisher.setEnabled(AbstractEcnPublisher.java:995)
        at com.rbsfm.fi.pricing.ecn.pricefeed.MuxPublisher.setEnabled(MuxPublisher.java:173)
        at com.rbsfm.fi.pricing.ecn.pricefeed.MuxPublisher.connectionEstablised(MuxPublisher.java:194)
        at com.rbsfm.fi.pricing.mux.socket.SocketClientSource.notifyConnectionEstablished(SocketClientSource.java:259)
        at com.rbsfm.fi.pricing.mux.socket.SocketClientSource$RemoteSink.getSocketQueue(SocketClientSource.java:420)
        at com.rbsfm.fi.pricing.mux.socket.SocketClientSource$RemoteSink.addMessage(SocketClientSource.java:354)
        at com.rbsfm.fi.pricing.mux.socket.XMLProtocolConverter.sendMessage(XMLProtocolConverter.java:64)
        at com.rbsfm.fi.pricing.mux.socket.XMLProtocolConverter.sendMessage(XMLProtocolConverter.java:54)
        at com.rbsfm.fi.pricing.mux.socket.SocketClientSource.processMessage(SocketClientSource.java:216)
        at com.rbsfm.fi.pricing.mux.HeartbeatGenerator$HeartbeatSourceThread.sendHeartbeatMessage(HeartbeatGenerator.java:163)
        at com.rbsfm.fi.pricing.mux.HeartbeatGenerator$HeartbeatSourceThread.run(HeartbeatGenerator.java:118)



# To turn the bank on if the D2C says for example "MA Connected and OFF" you can invoke

name=BankOnOffProcessor JMX component it can turn the bank back on.

# The ___ONLY___ way the price feed adapter becomes connected is when the following occurs

com.rbsfm.fi.marketaxess.pricefeed.MarketAxessPriceFeedAdaptor.connectionEstablised(SocketClientSource, InetSocketAddress)
com.rbsfm.fi.pricing.mux.socket.SocketClientSource.notifyConnectionEstablished(InetSocketAddress)
com.rbsfm.fi.pricing.mux.socket.SocketClientSource.RemoteSink.getSocketQueue()
com.rbsfm.fi.pricing.mux.socket.SocketClientSource.RemoteSink.addMessage(Message)
com.rbsfm.fi.pricing.mux.socket.ProtocolConverterDebuggerImpl.Stream.addMessage(Message)

So __ONLY__ when there is a message added is the connection lazily established and the connection
established flag is set to true. This allows the prices to flood through the gateway. BUT HOW
THE MESSAGE GETS ADDED IS A MYSTERY RIGHT NOW. TO GET IT WORKING I HAD TO MANUALLY TOGGLE IT.

# EXTREME weirdness on startup of the MarketAxessPriceFeedAdapter to get a connectionEstablished

com.rbsfm.fi.marketaxess.pricefeed.MarketAxessPriceFeedAdaptor.connectionEstablised(com.rbsfm.fi.pricing.mux.socket.SocketClientSource, java.net.InetSocketAddress) line: 139	
com.rbsfm.fi.pricing.mux.socket.SocketClientSource.notifyConnectionEstablished(java.net.InetSocketAddress) line: 259	
com.rbsfm.fi.pricing.mux.socket.SocketClientSource$RemoteSink.getSocketQueue() line: 420	
com.rbsfm.fi.pricing.mux.socket.SocketClientSource$RemoteSink.addMessage(com.rbsfm.fi.pricing.mux.Message) line: 354	
com.rbsfm.fi.pricing.mux.socket.XMLProtocolConverter.sendMessage(com.rbsfm.fi.pricing.mux.Message, com.rbsfm.fi.pricing.mux.socket.MessageChannel[], com.rbsfm.fi.pricing.mux.socket.MessageChannel) line: 64	
com.rbsfm.fi.pricing.mux.socket.XMLProtocolConverter.sendMessage(com.rbsfm.fi.pricing.mux.Message, com.rbsfm.fi.pricing.mux.socket.MessageChannel[]) line: 54	
com.rbsfm.fi.pricing.mux.socket.SocketClientSource.processMessage(com.rbsfm.fi.pricing.mux.Message) line: 216	
com.rbsfm.fi.marketaxess.pricefeed.MarketAxessPriceFeedAdaptor.performQuoteUpdated(com.rbsfm.fi.pricing.external.detail.EcnFeedPriceDetails) line: 185	
com.rbsfm.fi.marketaxess.pricefeed.MarketAxessPriceFeedAdaptor(com.rbsfm.fi.pricing.ecn.pricefeed.AbstractEcnPublisher).throttledQuoteUpdated(com.rbsfm.fi.pricing.external.detail.EcnFeedPriceDetails) line: 775	
com.rbsfm.fi.pricing.ecn.pricefeed.AbstractEcnPublisher$ThrottleConsumer.run() line: 71	


# MA Connected and OFF caused by the following for the autoquoter

2009-08-27 07:46:25.912 ERROR [MA-090827-617955] cpratesdev: Control[ConversationHandler]: ERROR PROCESSING CONVERSATION (DUMP BELOW): (NullPointerException:null: null: Stack Trace: java.lang.NullPointerException
 at com.rbsfm.fi.bet.autoquoter.business.action.ConversationExpiredAction.executeBusinessLogic(ConversationExpiredAction.java:34)
 at com.rbsfm.fi.bet.autoquoter.business.action.AbstractBusinessAction.executeStepsThenBusinessLogic(AbstractBusinessAction.java:138)
 at com.rbsfm.fi.bet.autoquoter.business.action.AbstractBusinessAction.carryOutNextBusinessLogic(AbstractBusinessAction.java:76)
 at com.rbsfm.fi.bet.autoquoter.business.action.StartBusinessAction.executeBusinessLogic(StartBusinessAction.java:100)
 at com.rbsfm.fi.bet.autoquoter.business.conversation.ConversationRequestHandler.doAction(ConversationRequestHandler.java:418)
 at com.rbsfm.fi.bet.autoquoter.business.conversation.ConversationRequestHandler.processIncoming(ConversationRequestHandler.java:190)
 at com.rbsfm.fi.bet.autoquoter.business.conversation.ConversationRequestHandler.handleConversationMessage(ConversationRequestHandler.java:157)
 at com.rbsfm.fi.bet.autoquoter.business.conversation.ConversationRequestDispatcher$1.dispatch(ConversationRequestDispatcher.java:237)
 at com.rbsfm.fi.bet.autoquoter.business.conversation.ConversationRequestDispatcher$ConversationRequests.runConversationRequestDispatcher.java:83)
 at com.rbsfm.fi.pricing.util.ThreadPool$DefaultThreadPool$WorkerThread.internalRun(ThreadPool.java:217)
 at com.rbsfm.fi.pricing.util.ThreadPool$DefaultThreadPool$WorkerThread$1.run(ThreadPool.java:191)
 at java.lang.Thread.run(Thread.java:619)


# Why is MA connected and OFF

grep BankOnOff * | grep MA | less | grep "brkEnable\[false" | grep "brkAlive\[true"

latam-autoquoter-offshore.log.4:2009-08-26 10:10:41.699 INFO [BETBrokerConnection.Receiver:ConsumerThread] unknown: Control[AutoQuoterMuxClient]: d2cBrokerStatus: onBankOnOff: id=D2CAQ, type=BrokerStatus msg=brkEnable[false,OK] brkId[D2CAQ,OK] brkReason[Connected to broker BET,OK] brkAlive[true,OK] tdrId[,OK] tdrEnable[,OK] tdrReason[,OK] brkEnabledGroups[null,OK] brkManual[false,OK] brkInfo[BET Connected and ON|MA Disconnected and OFF|,OK] brkD2C[true,OK] brkConsolidated[true,OK] brkPending[true,OK]
latam-autoquoter-offshore.log.5:2009-08-26 04:09:04.074 INFO [MABrokerConnection.Receiver:ProducerThread] unknown: Control[AutoQuoterMuxClient]: d2cBrokerStatus: onBankOnOff: id=D2CAQ, type=BrokerStatus msg=brkEnable[false,OK] brkId[D2CAQ,OK] brkReason[Lost connection to broker MA,OK] brkAlive[true,OK] tdrId[,OK] tdrEnable[,OK] tdrReason[,OK] brkEnabledGroups[null,OK] brkManual[false,OK] brkInfo[BET Connected and ON|MA Disconnected and OFF|,OK] brkD2C[true,OK] brkConsolidated[true,OK] brkPending[true,OK]
latam-autoquoter-offshore.log.5:2009-08-26 04:09:45.308 INFO [BETBrokerConnection.Receiver:ConsumerThread] unknown: Control[AutoQuoterMuxClient]: d2cBrokerStatus: onBankOnOff: id=D2CAQ, type=BrokerStatus msg=brkEnable[false,OK] brkId[D2CAQ,OK] brkReason[Connected to broker BET,OK] brkAlive[true,OK] tdrId[,OK] tdrEnable[,OK] tdrReason[,OK] brkEnabledGroups[null,OK] brkManual[false,OK] brkInfo[BET Connected and ON|MA Disconnected and OFF|,OK] brkD2C[true,OK] brkConsolidated[true,OK] brkPending[true,OK]
latam-autoquoter-offshore.log.5:2009-08-26 04:15:35.761 INFO [MA-090826-617442] cpratesdev: Control[AutoQuoterMuxClient]: onBankOnOff: id=MAAQ1, type=BrokerStatus msg=brkEnable[false,OK] brkId[MAAQ1,OK] brkReason[BANK OFF[MA]: AUTOQUOTER SYSTEM ERROR: PHONE SUPPORT,OK] brkAlive[true,OK] tdrId[,OK] tdrEnable[,OK] tdrReason[,OK] brkEnabledGroups[,OK] brkManual[false,OK] brkInfo[,OK] brkD2C[true,OK] brkConsolidated[false,OK] brkPending[false,OK]

latam-autoquoter-offshore.log.5:2009-08-26 04:15:35.761 INFO [MA-090826-617442] cpratesdev: Control[AutoQuoterMuxClient]: d2cBrokerStatus: onBankOnOff: id=D2CAQ, type=BrokerStatus msg=brkEnable[false,OK] brkId[D2CAQ,OK] brkReason[BANK OFF[MA]: AUTOQUOTER SYSTEM ERROR: PHONE SUPPORT,OK] brkAlive[true,OK] tdrId[,OK] tdrEnable[,OK] tdrReason[,OK] brkEnabledGroups[null,OK] brkManual[false,OK] brkInfo[BET Connected and ON|MA Connected and OFF|,OK] brkD2C[true,OK] brkConsolidated[true,OK] brkPending[true,OK]

latam-autoquoter-offshore.log.5:2009-08-26 04:18:52.621 INFO [MABrokerConnection.Receiver:ProducerThread] unknown: Control[AutoQuoterMuxClient]: d2cBrokerStatus: onBankOnOff: id=D2CAQ, type=BrokerStatus msg=brkEnable[false,OK] brkId[D2CAQ,OK] brkReason[Lost connection to broker MA,OK] brkAlive[true,OK] tdrId[,OK] tdrEnable[,OK] tdrReason[,OK] brkEnabledGroups[null,OK] brkManual[false,OK] brkInfo[BET Connected and ON|MA Disconnected and OFF|,OK] brkD2C[true,OK] brkConsolidated[true,OK] brkPending[true,OK]
latam-autoquoter-offshore.log.5:2009-08-26 04:19:36.214 INFO [BETBrokerConnection.Receiver:ConsumerThread] unknown: Control[AutoQuoterMuxClient]: d2cBrokerStatus: onBankOnOff: id=D2CAQ, type=BrokerStatus msg=brkEnable[false,OK] brkId[D2CAQ,OK] brkReason[Connected to broker BET,OK] brkAlive[true,OK] tdrId[,OK] tdrEnable[,OK] tdrReason[,OK] brkEnabledGroups[null,OK] brkManual[false,OK] brkInfo[BET Connected and ON|MA Disconnected and OFF|,OK] brkD2C[true,OK] brkConsolidated[true,OK] brkPending[true,OK]
latam-autoquoter-offshore.log.5:2009-08-26 04:25:38.339 INFO [MA-090826-617446] cpratesdev: Control[AutoQuoterMuxClient]: onBankOnOff: id=MAAQ1, type=BrokerStatus msg=brkEnable[false,OK] brkId[MAAQ1,OK] brkReason[BANK OFF[MA]: AUTOQUOTER SYSTEM ERROR: PHONE SUPPORT,OK] brkAlive[true,OK] tdrId[,OK] tdrEnable[,OK] tdrReason[,OK] brkEnabledGroups[,OK] brkManual[false,OK] brkInfo[,OK] brkD2C[true,OK] brkConsolidated[false,OK] brkPending[false,OK]


# For the autoquoter the client mux requests the status like so

com.rbsfm.fi.pricing.ecn.mux.AutoQuoterMuxPublisher.appendD2CStatus(com.rbsfm.fi.pricing.ecn.mux.AutoQuoterMuxPublisher$BrokerStatus, java.lang.StringBuilder) line: 1269	
com.rbsfm.fi.pricing.ecn.mux.AutoQuoterMuxPublisher.getBrokerStatus() line: 331	
com.rbsfm.fi.pricing.ecn.mux.AutoQuoterMuxPublisher.getBrokerStatus(java.lang.String) line: 676	
sun.reflect.NativeMethodAccessorImpl.invoke0(java.lang.reflect.Method, java.lang.Object, java.lang.Object[]) line: not available [native method]	
sun.reflect.NativeMethodAccessorImpl.invoke(java.lang.Object, java.lang.Object[]) line: 39	
sun.reflect.DelegatingMethodAccessorImpl.invoke(java.lang.Object, java.lang.Object[]) line: 25	
java.lang.reflect.Method.invoke(java.lang.Object, java.lang.Object...) line: 597	
electric.util.reflect.Invocation.execute(java.lang.Object, java.lang.reflect.Method, java.lang.Object[]) line: not available	
electric.util.reflect.Invocation.invoke(java.lang.Object, java.lang.reflect.Method, java.lang.Object[]) line: not available	
electric.service.object.ObjectService.invoke(java.lang.reflect.Method, java.lang.Object[], electric.util.Context) line: not available	
electric.soap.local.handlers.service.SOAPToServiceHandler.invoke(electric.soap.SOAPMessage, electric.util.Context) line: not available	
electric.soap.local.handlers.service.SOAPToServiceHandler.handle(electric.soap.SOAPMessage, electric.util.Context) line: not available	
electric.soap.security.handlers.SecurityHandler.handle(electric.soap.SOAPMessage, electric.util.Context) line: not available	
electric.soap.handlers.interceptor.SOAPInterceptorHandler.handle(electric.soap.SOAPMessage, electric.util.Context) line: not available	
electric.soap.routing.RoutingHandler.handle(electric.soap.SOAPMessage, electric.util.Context) line: not available	
electric.soap.handlers.logging.SOAPLoggingHandler.handle(electric.soap.SOAPMessage, electric.util.Context) line: not available	
electric.soap.handlers.setup.SetupHandler.handle(electric.soap.SOAPMessage, electric.util.Context) line: not available	
electric.soap.http.handler.HTTPToSOAP.service(electric.server.http.ServletServer, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse) line: not available	electric.server.http.ServletServer.service(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse) line: not available	
electric.server.http.ServletServer(javax.servlet.http.HttpServlet).service(javax.servlet.ServletRequest, javax.servlet.ServletResponse) line: 853	
electric.servlet.Config.service(javax.servlet.ServletRequest, javax.servlet.ServletResponse) line: not available	
electric.servlet.HTTPContext.service(java.lang.String, javax.servlet.ServletRequest, javax.servlet.ServletResponse) line: not available	
electric.servlet.ServletEngine.service(java.lang.String, javax.servlet.ServletRequest, javax.servlet.ServletResponse) line: not available	
electric.webserver.WebServer.service(electric.net.channel.IChannel) line: not available	
electric.net.socket.SocketServer.run(electric.net.socket.SocketRequest) line: not available	
electric.net.socket.SocketRequest.run() line: not available	
electric.util.thread.ThreadPool.run() line: not available	
java.lang.Thread.run() line: 619	


# Added the status messages

	/**
	 * Format the additional information.
	 * 
	 * @see com.rbsfm.fi.pricing.ecn.mux.AutoQuoterMuxPublisher#appendD2CStatus
	 */
    private static void appendD2CStatus(EcnStats stat, StringBuilder sb) {
      sb.append(stat.id);
      sb.append(stat.alive ? " Connected" : " Disconnected");
      sb.append(" and ");
      sb.append(stat.enabled ? "ON" : "OFF");
      sb.append("\n");
    }


# For the ECN price feed the D2C message comes from

CompositeEcnPublisher.publish where there are EcnStats objects that contain the stats on the 
price publications for the connected gateways.

# ECN price feed message to the CP client

DataSet	{ID=[D2C] Type=[BrokerStatus] Sources=[EI=>latam-ecnpricefeed-offshore] Attributes=[dataSetId=>D2C,dataSetType=>BrokerStatus,sourceNames=>latam-ecnpricefeed-offshore(EI),brkEnabledGroups=>,brkPubEnabled=>0,tdrsWithQuotes=>Multiple,tdrsQuoteCounters=>335,brkConsolidated=>True,brkId=>D2C,brkAlive=>True,tdrsEnabledCounters=>112,brkReason=>,brkPubAvailable=>0,brkEnable=>True,brkD2C=>True]}	Rbsfm.Common.Messaging.Data.IFieldDataSet {Rbsfm.Common.Messaging.Data.FieldDataSet}


# The tooltip is provided in a broker status attribute brkInfo

BET Connected and ON
MA Connected and ON

This is held on the C# client as BROKER_INFO

					if (data.ContainsField(Attributes.BROKER_INFO))
					{
						BrokerInfo = data.GetString(Attributes.BROKER_INFO);
					}


# Real delivery of messages

com.rbsfm.fi.pricing.mux.mlist.MessageQueue.tryPush(com.rbsfm.fi.pricing.mux.Message) line: 279	
com.rbsfm.fi.pricing.mux.socket.SocketQueue.enqueueOrWrite(com.rbsfm.fi.pricing.mux.Message) line: 286	
com.rbsfm.fi.pricing.mux.socket.SocketQueue.addMessage(com.rbsfm.fi.pricing.mux.Message) line: 256	
com.rbsfm.fi.pricing.mux.socket.BINV2ProtocolConverter(com.rbsfm.fi.pricing.mux.socket.AbstractBINProtocolConverter).sendMessage(com.rbsfm.fi.pricing.mux.Message, com.rbsfm.fi.pricing.mux.socket.MessageChannel[], com.rbsfm.fi.pricing.mux.socket.MessageChannel) line: 203	
com.rbsfm.fi.pricing.mux.socket.SocketServerSource.processMessage(com.rbsfm.fi.pricing.mux.Message, com.rbsfm.fi.pricing.mux.socket.SocketQueue) line: 243	
com.rbsfm.fi.pricing.mux.socket.SocketServerSource.processMessage(com.rbsfm.fi.pricing.mux.Message) line: 107	
com.rbsfm.fi.pricing.ecn.mux.FeedPricePublisher(com.rbsfm.fi.pricing.ecn.mux.AbstractMuxPublisher).publishBootstrap() line: 284	
com.rbsfm.fi.pricing.ecn.mux.FeedPricePublisher(com.rbsfm.fi.pricing.ecn.mux.AbstractMuxPublisher).connectionEstablished(com.rbsfm.fi.pricing.mux.socket.SocketServerSource, com.rbsfm.fi.pricing.mux.socket.SocketQueue) line: 292	
com.rbsfm.fi.pricing.mux.socket.SocketConnectionListener$ListenerCollection.connectionEstablished(com.rbsfm.fi.pricing.mux.socket.SocketServerSource, com.rbsfm.fi.pricing.mux.socket.SocketQueue) line: 46	
com.rbsfm.fi.pricing.mux.socket.SocketServerSource.internalHandleConnection(java.nio.channels.SocketChannel) line: 343	
com.rbsfm.fi.pricing.mux.socket.SocketServerSource.access$000(com.rbsfm.fi.pricing.mux.socket.SocketServerSource, java.nio.channels.SocketChannel) line: 52	
com.rbsfm.fi.pricing.mux.socket.SocketServerSource$1.handleConnection(java.nio.channels.SocketChannel) line: 164	
com.rbsfm.fi.pricing.mux.socket.TCPServer$HandleConnectionThread.run() line: 106	
java.lang.Thread.run() line: 619	


# After bounce of the ECN price feed the status is

Alive=true
Broker=true

# The heartbeat messages control the broker status

If the heartbeat takes a long time the Broker=false occurs. Upon reciept of 
a new heartbeat the Broker=true occurs. The alive boolean remains unaffected.

# Looks like for LATAM the socket queue is closed for BrokerStatus

# GOOD
Messageid=BB,type=BrokerStatus,destination=*,sourcename=latam-ecnpricefeed-offshore,sourcetype=EI

# BAD
Messageid=BB,type=BrokerStatus,destination=*,sourcename=latam-ecnpricefeed-offshore,sourcetype=EI

id=BB, type=BrokerStatus msg=brkEnable[false,OK] brkId[BB,OK] brkReason[lost connection to gateway,OK] brkAlive[false,OK] brkEnabledGroups[,OK] tdrsWithQuotes[turnese,kumarng,mccarmd,OK] tdrsQuoteCounters[87,51,0,OK] tdrsEnabledCounters[14,43,0,OK] brkPubAvailable[0,OK] brkPubEnabled[0,OK] brkD2C[true,OK] brkConsolidated[false,OK] 


com.rbsfm.fi.pricing.mux.socket.SocketQueue.addMessage(com.rbsfm.fi.pricing.mux.Message) line: 243	
com.rbsfm.fi.pricing.mux.socket.BINV2ProtocolConverter(com.rbsfm.fi.pricing.mux.socket.AbstractBINProtocolConverter).sendMessage(com.rbsfm.fi.pricing.mux.Message, com.rbsfm.fi.pricing.mux.socket.MessageChannel[], com.rbsfm.fi.pricing.mux.socket.MessageChannel) line: 203	
com.rbsfm.fi.pricing.mux.socket.SocketServerSource.processMessage(com.rbsfm.fi.pricing.mux.Message, com.rbsfm.fi.pricing.mux.socket.SocketQueue) line: 243	
com.rbsfm.fi.pricing.mux.socket.SocketServerSource.processMessage(com.rbsfm.fi.pricing.mux.Message) line: 107	
com.rbsfm.fi.pricing.ecn.mux.FeedPricePublisher(com.rbsfm.fi.pricing.ecn.mux.AbstractMuxPublisher).publishMessagesInQueue() line: 158	
com.rbsfm.fi.pricing.ecn.mux.AbstractMuxPublisher$ProcessMessageQueue.run() line: 94	
java.util.TimerThread.mainLoop() line: 512	
java.util.TimerThread.run() line: 462	


# This is where the messages are sent in LMEB

com.rbsfm.common.thread.IQueue$CombiningQueue.tryPush(java.lang.Object) line: 265	
com.rbsfm.fi.pricing.mux.MessageThrottler.processMessage(com.rbsfm.fi.pricing.mux.Message) line: 303	
com.rbsfm.fi.pricing.mux.Source$SourceCollection.processMessage(com.rbsfm.fi.pricing.mux.Message) line: 60	
com.rbsfm.fi.pricing.mux.socket.SocketClientSink(com.rbsfm.fi.pricing.mux.socket.AbstractSocketMessageReader).notifySources(com.rbsfm.fi.pricing.mux.Message) line: 254	
com.rbsfm.fi.pricing.mux.socket.SocketClientSink.onMessage(com.rbsfm.fi.pricing.mux.Message, java.nio.channels.SocketChannel) line: 465	
com.rbsfm.fi.pricing.mux.socket.SocketClientSink(com.rbsfm.fi.pricing.mux.socket.AbstractSocketMessageReader).readAndDispatch(java.nio.channels.SocketChannel) line: 189	
com.rbsfm.fi.pricing.mux.socket.SocketClientSink.readAndDispatch() line: 740	
com.rbsfm.fi.pricing.mux.socket.SocketClientSink.connectAndRead() line: 671	
com.rbsfm.fi.pricing.mux.socket.SocketClientSink.connectAndReadWhileActive() line: 614	
com.rbsfm.fi.pricing.mux.socket.SocketClientSink.access$000(com.rbsfm.fi.pricing.mux.socket.SocketClientSink) line: 59	
com.rbsfm.fi.pricing.mux.socket.SocketClientSink$2.run() line: 226	
java.lang.Thread.run() line: 619	


# In LMEB here is where the broker status messages arrive

SocketClientSink.onMessage(Message, SocketChannel) line: 451	
SocketClientSink(AbstractSocketMessageReader).readAndDispatch(SocketChannel) line: 189	
SocketClientSink.readAndDispatch() line: 740	
SocketClientSink.connectAndRead() line: 671	
SocketClientSink.connectAndReadWhileActive() line: 614	
SocketClientSink.access$000(SocketClientSink) line: 59	
SocketClientSink$2.run() line: 226	
Thread.run() line: 619	


# Broker status messages are being sent but not used

$ cpadmin tail uat-latam-clientmux-offshore | grep BrokerStatus
2009-08-21 11:02:22.527 INFO [PricingSink:1161<-stams00058:20400] unknown: PricingThrottler throttler received 15000 messages, broken down as follows: latam-ecnpricefeed-offshore.stale: 3, latam-exchangedata-offshore.MappingDepth: 310, corpus-pricing-cds.ItraxxCrv: 8, latam-ecnpricefeed-offshore.DummyNode: 1, latam-pricing-offshore.Bond: 11654, latam-pricing-offshore.Swap: 436, latam-pricing-offshore.ForwardCurveNode: 27, latam-pricing-offshore.MoneyMarket: 416, latam-ecnpricefeed-offshore.Bond: 1404, latam-exchangedata-offshore.MarketDepth: 4, latam-pricing-offshore.CurvePoint: 262, latam-pricing-offshore.BondCurve: 10, latam-pricing-offshore.FXRate: 4, latam-pricing-offshore.Curve: 26, latam-exchangedata-offshore.Bond: 407, latam-ecnpricefeed-offshore.Sanitizer: 1, latam-ecnpricefeed-offshore.BrokerStatus: 3, corpus-pricing-cds.CDS: 24
BrokerStatus                          152              213             1658           230520
2009-08-21 11:02:52.718 INFO [CDSPricingSink:1472<-shlms00003:20000] unknown: PricingThrottler throttler received 15000 messages, broken down as follows: latam-ecnpricefeed-offshore.stale: 3, latam-exchangedata-offshore.MappingDepth: 297, latam-ecnpricefeed-offshore.DummyNode: 1, latam-pricing-offshore.Bond: 11586, latam-pricing-offshore.Swap: 453, latam-pricing-offshore.ForwardCurveNode: 26, latam-pricing-offshore.MoneyMarket: 417, latam-ecnpricefeed-offshore.Bond: 1404, latam-exchangedata-offshore.MarketDepth: 5, latam-pricing-offshore.CurvePoint: 314, latam-pricing-offshore.BondCurve: 12, latam-pricing-offshore.FXRate: 3, latam-pricing-offshore.Curve: 26, latam-exchangedata-offshore.Bond: 407, latam-ecnpricefeed-offshore.Sanitizer: 1, latam-ecnpricefeed-offshore.BrokerStatus: 3, corpus-pricing-cds.CDS: 42
BrokerStatus                          152              213             1661           230984
2009-08-21 11:03:10.102 INFO [PricingSink:1161<-stams00058:20400] unknown: PricingThrottler throttler received 15000 messages, broken down as follows: latam-ecnpricefeed-offshore.stale: 3, latam-exchangedata-offshore.MappingDepth: 295, corpus-pricing-cds.ItraxxCrv: 14, latam-ecnpricefeed-offshore.DummyNode: 1, latam-pricing-offshore.Bond: 11057, latam-pricing-offshore.Swap: 421, latam-pricing-offshore.ForwardCurveNode: 25, latam-pricing-offshore.MoneyMarket: 417, latam-ecnpricefeed-offshore.Bond: 1446, corpus-pricing-cds.Curve: 508, latam-exchangedata-offshore.MarketDepth: 8, latam-pricing-offshore.CurvePoint: 266, latam-pricing-offshore.BondCurve: 6, latam-pricing-offshore.FXRate: 4, latam-pricing-offshore.Curve: 26, latam-exchangedata-offshore.Bond: 371, latam-ecnpricefeed-offshore.Sanitizer: 1, latam-ecnpricefeed-offshore.BrokerStatus: 3, corpus-pricing-cds.CDS: 128


# Message confirmed sent from market axess mainventory but no client update

com.rbsfm.fi.pricing.ecn.mux.FeedPricePublisher(com.rbsfm.fi.pricing.ecn.mux.AbstractMuxPublisher).publishMessagesInQueue() line: 142	
com.rbsfm.fi.pricing.ecn.mux.AbstractMuxPublisher$ProcessMessageQueue.run() line: 94	
java.util.TimerThread.mainLoop() line: 512	
java.util.TimerThread.run() line: 462	


# Actual message sent from latam ECN price feed

[id=MA, type=BrokerStatus msg=brkEnable[true,OK] brkId[MA,OK] brkReason[Auto-Enabling pricefeed [MA],OK] brkAlive[false,OK] brkEnabledGroups[,OK] tdrsWithQuotes[loughna,tofti,walkerl1,gallane,grootag,turnese,kumarng,mccarmd,OK] tdrsQuoteCounters[0,0,0,0,0,0,0,0,OK] tdrsEnabledCounters[0,0,0,0,0,0,0,0,OK] brkPubAvailable[0,OK] brkPubEnabled[0,OK] brkD2C[true,OK] brkConsolidated[false,OK] , id=D2C, type=BrokerStatus msg=brkEnable[true,OK] brkId[D2C,OK] brkReason[,OK] brkAlive[true,OK] brkEnabledGroups[,OK] tdrsWithQuotes[Multiple,OK] tdrsQuoteCounters[307,OK] tdrsEnabledCounters[95,OK] brkPubAvailable[0,OK] brkPubEnabled[0,OK] brkD2C[true,OK] brkConsolidated[true,OK] , Bond:ARARGE03F342, Bond:ARARGE03F243, Bond:US105756BN96, Bond:US715638AW21, Bond:US715638AQ52, Bond:US715638AN22, Bond:US715638AL65]

######## BELOW HERE IS LMEB ##########

# Here is where we send on the socket

AsyncSocketQueue(SocketQueue).enqueueOrWrite(Message) line: 277	
AsyncSocketQueue(SocketQueue).addMessage(Message) line: 247	
BINV2ProtocolConverter(AbstractBINProtocolConverter).sendMessage(Message, MessageChannel[], MessageChannel) line: 203	
SocketServerSource.processMessage(Message, SocketQueue) line: 229	
SocketServerSource.processMessage(Message) line: 105	
FeedPricePublisher(AbstractMuxPublisher).publishMessagesInQueue() line: 150	
AbstractMuxPublisher$ProcessMessageQueue.run() line: 90	
TimerThread.mainLoop() line: 512 [local variables unavailable]	
TimerThread.run() line: 462	


# Actual message toString results in

Messageid=BB,type=BrokerStatus,destination=*,sourcename=lmeb-ecnpricefeed-master,sourcetype=EI

# Actual binary message is sent from here

BINV2ProtocolConverter.convertMessage(Message, AbstractBINProtocolConverter$ReusableDataOutputStream) line: 1077	
BINV2ProtocolConverter.convertMessage(Message) line: 1018	
BINV2ProtocolConverter(AbstractBINProtocolConverter).sendMessage(Message, MessageChannel[], MessageChannel) line: 133	
SocketServerSource.processMessage(Message, SocketQueue) line: 229	
SocketServerSource.processMessage(Message) line: 105	
FeedPricePublisher(AbstractMuxPublisher).publishMessagesInQueue() line: 150	
AbstractMuxPublisher$ProcessMessageQueue.run() line: 90	
TimerThread.mainLoop() line: 512 [local variables unavailable]	
TimerThread.run() line: 462	

# Here is where the broker status message is sent from

FeedPricePublisher(AbstractMuxPublisher).publishMessagesInQueue() line: 127	
AbstractMuxPublisher$ProcessMessageQueue.run() line: 90	
TimerThread.mainLoop() line: 512 [local variables unavailable]	
TimerThread.run() line: 462	

# This is the broker status message that is sent

[id=BB, type=BrokerStatus msg=brkEnable[false] brkId[BB] brkReason[lost connection to gateway] brkAlive[false] brkEnabledGroups[] tdrsWithQuotes[tofti,gallane,singhah,NONE] tdrsQuoteCounters[0,0,0,0] tdrsEnabledCounters[0,0,0,0] ]

# When a connection is lost the socket source notifies the server

MuxPublisher.connectionLost(SocketClientSource, InetSocketAddress) line: 181	
SocketClientSource.notifyConnectionLost(InetSocketAddress) line: 275	
SocketClientSource$RemoteSink.handleConnectionFailed() line: 478	
SocketClientSource$RemoteSink.socketClosed(SocketQueue) line: 501	
AsyncSocketQueue(SocketQueue).close0() line: 636	
AsyncSocketQueue(SocketQueue).close() line: 345	
AsyncSocketQueue(SocketQueue).runWriter() line: 621	
SocketQueue.access$100(SocketQueue) line: 55	
SocketQueue$1.run() line: 144	

