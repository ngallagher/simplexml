exec CalculatorAttributeStore 'USG7028BAB74', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG7028BAB74', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG7028BAB74', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG7028BAB74', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0300179198', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO NON-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0300179198', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BARCBK,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0300179198', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0300179198', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'USU0390YAA83', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USU0390YAA83', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USU0390YAA83', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USU0390YAA83', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP8718AAA45', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP8718AAA45', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP8718AAA45', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP8718AAA45', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Chemicals', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG2440JAF24', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG2440JAF24', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN,HSBC,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG2440JAF24', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG2440JAF24', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Iron/Steel', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828KX70', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KX70', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KX70', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KX70', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP18533AD48', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP18533AD48', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ML-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP18533AD48', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP18533AD48', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Chemicals', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0179680920', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0179680920', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0179680920', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0179680920', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756BL31', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BL31', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BL31', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BL31', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'ARARGE034678', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'DOMESTIC', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE034678', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE034678', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE034678', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0108907303', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0108907303', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,SSB', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0108907303', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'Y',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0108907303', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'ARARGE03F243', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'DOMESTIC', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03F243', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03F243', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03F243', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US879403AS24', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US879403AS24', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US879403AS24', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US879403AS24', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0211229637', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0211229637', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BNPPAR,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0211229637', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0211229637', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91086QAD07', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAD07', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CHASE,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAD07', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAD07', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0460546525', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'DOMESTIC', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0460546525', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0460546525', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0460546525', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3143NAH72', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3143NAH72', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB,HSBCL', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3143NAH72', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3143NAH72', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Mining', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0444611296', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'DOMESTIC', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0444611296', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0444611296', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0444611296', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0251389457', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0251389457', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB,GS', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0251389457', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'Y',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0251389457', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91911TAG85', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91911TAG85', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN,CS,SANT,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91911TAG85', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91911TAG85', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Mining', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912810QC53', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912810QC53', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912810QC53', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912810QC53', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP0245MAC30', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP0245MAC30', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,STNDRD', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP0245MAC30', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP0245MAC30', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Real Estate', 0, 'script', 'script'

exec CalculatorAttributeStore 'US151191AF03', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'YANKEE', 0, 'script', 'script'
exec CalculatorAttributeStore 'US151191AF03', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US151191AF03', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US151191AF03', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Forest Products&Paper', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG6710EAA85', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG6710EAA85', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG6710EAA85', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG6710EAA85', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Engineering&Construction', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756BH29', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BH29', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BH29', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BH29', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0213272122', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0213272122', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0213272122', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0213272122', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG70415AC18', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG70415AC18', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG70415AC18', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG70415AC18', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP6464EAE88', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP6464EAE88', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MS-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP6464EAE88', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP6464EAE88', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'US71645WAQ42', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAQ42', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JOINT LEADS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAQ42', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAQ42', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US879378AK31', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US879378AK31', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US879378AK31', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US879378AK31', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'US69829VAD73', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'YANKEE', 0, 'script', 'script'
exec CalculatorAttributeStore 'US69829VAD73', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US69829VAD73', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US69829VAD73', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Beverages', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0201926663', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0201926663', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,HSBCL,ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0201926663', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0201926663', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP19157AG48', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP19157AG48', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP19157AG48', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP19157AG48', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Media', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3143NAD68', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3143NAD68', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3143NAD68', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3143NAD68', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Mining', 0, 'script', 'script'

exec CalculatorAttributeStore 'US02364WAN56', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US02364WAN56', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS,GS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US02364WAN56', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US02364WAN56', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG1970BAA01', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG1970BAA01', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MS-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG1970BAA01', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG1970BAA01', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Building Materials', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG9191BFV56', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG9191BFV56', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ML,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG9191BFV56', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG9191BFV56', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP59974AA66', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP59974AA66', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP59974AA66', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP59974AA66', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP2867PAB15', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP2867PAB15', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'HSBC,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP2867PAB15', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP2867PAB15', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Iron/Steel', 0, 'script', 'script'

exec CalculatorAttributeStore 'US922646BJ29', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US922646BJ29', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US922646BJ29', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US922646BJ29', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP18533AK80', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP18533AK80', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP18533AK80', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP18533AK80', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Chemicals', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG30376AA86', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG30376AA86', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG30376AA86', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG30376AA86', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Aerospace/Defense', 0, 'script', 'script'

exec CalculatorAttributeStore 'US706451BF73', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451BF73', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451BF73', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US706451BF73', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US90400XAC83', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US90400XAC83', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US90400XAC83', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US90400XAC83', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Transportation', 0, 'script', 'script'

exec CalculatorAttributeStore 'US92851FAC77', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US92851FAC77', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,CSFB', 0, 'script', 'script'
exec CalculatorAttributeStore 'US92851FAC77', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US92851FAC77', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Packaging&Containers', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3100SAA26', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3100SAA26', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BAML,HSBC', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3100SAA26', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3100SAA26', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Household Products/Wares', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0234087590', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0234087590', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0234087590', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0234087590', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Regional(state/provnc)', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP97475AD26', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AD26', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AD26', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AD26', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3505EBZ80', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3505EBZ80', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DKIB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3505EBZ80', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3505EBZ80', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Engineering&Construction', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91086QAK40', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAK40', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAK40', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAK40', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'ARARGE03E147', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'DOMESTIC', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03E147', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03E147', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03E147', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG9317UAB10', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG9317UAB10', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG9317UAB10', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG9317UAB10', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Mining', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP1330HBD54', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP1330HBD54', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP1330HBD54', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP1330HBD54', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG27649AA34', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG27649AA34', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG27649AA34', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG27649AA34', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'US71645WAM38', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAM38', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,UBSINV', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAM38', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAM38', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0214851874', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0214851874', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0214851874', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0214851874', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP09669BS37', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP09669BS37', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP09669BS37', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP09669BS37', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756BD15', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BD15', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BD15', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BD15', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US466110AA16', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US466110AA16', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ING,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US466110AA16', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US466110AA16', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Food', 0, 'script', 'script'

exec CalculatorAttributeStore 'US698299AD63', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AD63', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BSI,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AD63', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AD63', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US195325BJ38', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BJ38', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BJ38', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BJ38', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756AJ93', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AJ93', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,CHASE', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AJ93', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AJ93', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG77650AA01', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG77650AA01', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG77650AA01', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG77650AA01', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Food', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0206170390', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0206170390', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0206170390', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0206170390', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP02468AH21', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP02468AH21', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP02468AH21', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP02468AH21', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Forest Products&Paper', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG2440JAE58', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG2440JAE58', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN,HSBC,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG2440JAE58', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG2440JAE58', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Iron/Steel', 0, 'script', 'script'

exec CalculatorAttributeStore 'ARARGE03E931', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'DOMESTIC', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03E931', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03E931', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03E931', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US02364WAJ45', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US02364WAJ45', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB', 0, 'script', 'script'
exec CalculatorAttributeStore 'US02364WAJ45', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US02364WAJ45', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP2559EAA12', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP2559EAA12', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP2559EAA12', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP2559EAA12', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'US71656MAA71', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71656MAA71', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JOINT LEADS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71656MAA71', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US71656MAA71', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP5015VAC02', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP5015VAC02', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'UBS-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP5015VAC02', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP5015VAC02', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828KP47', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KP47', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KP47', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KP47', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP06064AB83', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP06064AB83', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BAML,CS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP06064AB83', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP06064AB83', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'US706451AN17', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451AN17', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'HSBC', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451AN17', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US706451AN17', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US29081YAC03', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US29081YAC03', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US29081YAC03', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US29081YAC03', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Aerospace/Defense', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91086QAG38', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAG38', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAG38', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAG38', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US593048AX90', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US593048AX90', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US593048AX90', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US593048AX90', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG19863AA06', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG19863AA06', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BNPPAR,CS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG19863AA06', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG19863AA06', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0234085461', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0234085461', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0234085461', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0234085461', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Regional(state/provnc)', 0, 'script', 'script'

exec CalculatorAttributeStore 'US593048BA88', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US593048BA88', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS,ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'US593048BA88', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US593048BA88', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP9030AAA36', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP9030AAA36', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP9030AAA36', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP9030AAA36', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'US05461YAB20', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US05461YAB20', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US05461YAB20', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US05461YAB20', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP1923GAE90', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP1923GAE90', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP1923GAE90', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP1923GAE90', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Media', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0282340230', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0282340230', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0282340230', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0282340230', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP01165AB82', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP01165AB82', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BEAR-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP01165AB82', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP01165AB82', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Airlines', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG0110XAA57', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG0110XAA57', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG0110XAA57', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG0110XAA57', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP8056GAB97', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP8056GAB97', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP8056GAB97', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP8056GAB97', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP47773AJ81', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP47773AJ81', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP47773AJ81', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP47773AJ81', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'US20441XAD49', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US20441XAD49', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US20441XAD49', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US20441XAD49', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Beverages', 0, 'script', 'script'

exec CalculatorAttributeStore 'US70645JAB89', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US70645JAB89', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS,LEH', 0, 'script', 'script'
exec CalculatorAttributeStore 'US70645JAB89', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US70645JAB89', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828KW97', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KW97', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KW97', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KW97', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP01548AC30', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP01548AC30', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP01548AC30', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP01548AC30', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91086QAN88', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAN88', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BCLY,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAN88', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAN88', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US25030WAB63', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US25030WAB63', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US25030WAB63', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US25030WAB63', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Home Builders', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828LQ11', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LQ11', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LQ11', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LQ11', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0085661949', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0085661949', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0085661949', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'Y',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0085661949', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756BK57', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BK57', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB,UBSINV', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BK57', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BK57', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US715638AW21', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AW21', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AW21', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AW21', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US879378AJ67', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US879378AJ67', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US879378AJ67', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US879378AJ67', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3143NAG99', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3143NAG99', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3143NAG99', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3143NAG99', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Mining', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828KL33', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KL33', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KL33', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KL33', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US05968LAA08', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'US05968LAA08', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US05968LAA08', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US05968LAA08', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP4987VAR44', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP4987VAR44', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'HSBC,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP4987VAR44', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP4987VAR44', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Media', 0, 'script', 'script'

exec CalculatorAttributeStore 'US593048BN00', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US593048BN00', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US593048BN00', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US593048BN00', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'ARARGE035709', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'DOMESTIC', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE035709', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE035709', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE035709', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP16394AF89', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP16394AF89', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP16394AF89', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP16394AF89', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US10553HAE27', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US10553HAE27', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US10553HAE27', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US10553HAE27', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Chemicals', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0460546442', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'DOMESTIC', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0460546442', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0460546442', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0460546442', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US922646BM57', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US922646BM57', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BCLY,ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'US922646BM57', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US922646BM57', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG4490RAA08', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG4490RAA08', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BCLY,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG4490RAA08', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG4490RAA08', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0273345982', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0273345982', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0273345982', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0273345982', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0133244763', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0133244763', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,DBAB', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0133244763', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0133244763', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP04568AA23', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP04568AA23', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JOINT LEADS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP04568AA23', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP04568AA23', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Retail', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0161351191', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0161351191', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BARCBK,HSBC', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0161351191', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0161351191', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG24419AA47', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG24419AA47', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG24419AA47', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG24419AA47', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'US05965XAA72', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US05965XAA72', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US05965XAA72', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US05965XAA72', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'US195325AL92', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325AL92', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325AL92', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US195325AL92', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912810QB70', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912810QB70', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912810QB70', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912810QB70', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828LM07', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LM07', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LM07', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LM07', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP4954BAA46', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP4954BAA46', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,CS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP4954BAA46', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP4954BAA46', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Holding Companies-Divers', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG2024RAA98', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG2024RAA98', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BCLY,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG2024RAA98', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG2024RAA98', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Building Materials', 0, 'script', 'script'

exec CalculatorAttributeStore 'US219868BL92', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US219868BL92', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US219868BL92', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US219868BL92', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Multi-National', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP98100AA12', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP98100AA12', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS,LEH,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP98100AA12', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP98100AA12', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Packaging&Containers', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828KS85', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KS85', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KS85', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KS85', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP97475AG56', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AG56', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABNHOL,CAI,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AG56', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AG56', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US879246AA41', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US879246AA41', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US879246AA41', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US879246AA41', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP37064AA30', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP37064AA30', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP37064AA30', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP37064AA30', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Iron/Steel', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91086QAJ76', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAJ76', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAJ76', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAJ76', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US02364WAF23', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US02364WAF23', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US02364WAF23', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US02364WAF23', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'US715638AS19', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AS19', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AS19', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AS19', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US71654QAM42', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71654QAM42', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71654QAM42', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US71654QAM42', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0289333048', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-ZONE', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0289333048', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JOINT LEADS', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0289333048', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'Y',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0289333048', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Building Materials', 0, 'script', 'script'

exec CalculatorAttributeStore 'US71645WAP68', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAP68', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAP68', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAP68', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756BG46', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BG46', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BG46', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BG46', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG25842AA66', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG25842AA66', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG25842AA66', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG25842AA66', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Iron/Steel', 0, 'script', 'script'

exec CalculatorAttributeStore 'US195325BM66', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BM66', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BAS,GS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BM66', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BM66', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0460546798', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'DOMESTIC', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0460546798', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0460546798', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0460546798', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG70415AB35', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG70415AB35', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG70415AB35', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG70415AB35', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0234088994', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO NON-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0234088994', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0234088994', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0234088994', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Regional(state/provnc)', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP8055KGV19', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP8055KGV19', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP8055KGV19', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP8055KGV19', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828LT59', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LT59', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LT59', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LT59', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US059644AG91', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US059644AG91', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'SAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US059644AG91', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US059644AG91', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'US195325AY14', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325AY14', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325AY14', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US195325AY14', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP9395PAB78', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP9395PAB78', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP9395PAB78', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP9395PAB78', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG57058AA01', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG57058AA01', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG57058AA01', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG57058AA01', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Metal Fabricate/Hardware', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP59695AC39', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP59695AC39', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ING,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP59695AC39', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP59695AC39', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Food', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756BN96', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BN96', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BN96', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BN96', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP07785AB71', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP07785AB71', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP07785AB71', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP07785AB71', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'US698299AT16', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AT16', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AT16', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AT16', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US195325BB02', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BB02', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BB02', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BB02', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'ARARGE03F144', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'DOMESTIC', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03F144', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03F144', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03F144', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US760942AX01', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US760942AX01', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BCLY,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US760942AX01', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US760942AX01', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0052684601', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'RESTRUCTURD DEBT', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0052684601', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0052684601', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'Y',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0052684601', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG23491AA40', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG23491AA40', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BCLY,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG23491AA40', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG23491AA40', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0243486957', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0243486957', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0243486957', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0243486957', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Food', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP4162LAA00', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP4162LAA00', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BEAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP4162LAA00', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP4162LAA00', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'US71654XAK37', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71654XAK37', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'SSB', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71654XAK37', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US71654XAK37', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0430799725', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0430799725', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BARCBK,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0430799725', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0430799725', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0086327581', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO NON-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0086327581', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JOINT LEADS', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0086327581', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'Y',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0086327581', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US71645WAL54', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAL54', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MS,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAL54', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAL54', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756BC32', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BC32', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS,ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BC32', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BC32', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP09669BR53', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP09669BR53', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP09669BR53', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP09669BR53', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828KD17', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KD17', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KD17', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KD17', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP74828AA55', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP74828AA55', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP74828AA55', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP74828AA55', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US151191AH68', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'YANKEE', 0, 'script', 'script'
exec CalculatorAttributeStore 'US151191AH68', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US151191AH68', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US151191AH68', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Forest Products&Paper', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP97475AJ95', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AJ95', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BCLY', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AJ95', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AJ95', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP1330HAZ75', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP1330HAZ75', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP1330HAZ75', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP1330HAZ75', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'US29244AAJ16', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US29244AAJ16', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US29244AAJ16', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US29244AAJ16', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP1655PAB96', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP1655PAB96', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP1655PAB96', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP1655PAB96', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Food', 0, 'script', 'script'

exec CalculatorAttributeStore 'US71654YAK10', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71654YAK10', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'SSB', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71654YAK10', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US71654YAK10', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP18533AF95', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP18533AF95', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP18533AF95', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP18533AF95', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Chemicals', 0, 'script', 'script'

exec CalculatorAttributeStore 'US12503JAA34', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US12503JAA34', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BRADSC,MS,SANT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US12503JAA34', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US12503JAA34', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG6149AAA72', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG6149AAA72', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG6149AAA72', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG6149AAA72', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG5814RAA61', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG5814RAA61', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ML-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG5814RAA61', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG5814RAA61', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Distribution/Wholesale', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756BJ84', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BJ84', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BJ84', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BJ84', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0043118172', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'RESTRUCTURD DEBT', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0043118172', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0043118172', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0043118172', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG27631AB90', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG27631AB90', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG27631AB90', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG27631AB90', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'US29245SAD45', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US29245SAD45', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US29245SAD45', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US29245SAD45', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'US040114GK09', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GK09', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GK09', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GK09', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91086QAF54', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAF54', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAF54', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAF54', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP1393WAB11', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP1393WAB11', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP1393WAB11', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP1393WAB11', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP07867AA57', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP07867AA57', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'LEH', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP07867AA57', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP07867AA57', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP5159KCP95', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP5159KCP95', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP5159KCP95', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP5159KCP95', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828LP38', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LP38', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LP38', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LP38', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP8055QDE90', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP8055QDE90', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP8055QDE90', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP8055QDE90', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0232141134', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0232141134', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0232141134', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0232141134', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'US71645WAH43', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAH43', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,LEH', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAH43', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAH43', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US470160AW29', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AW29', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AW29', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AW29', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USU16790AB00', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USU16790AB00', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'USU16790AB00', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USU16790AB00', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'US01446PAG90', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US01446PAG90', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US01446PAG90', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US01446PAG90', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'US195325BE41', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BE41', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BE41', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BE41', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US71654QAP72', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'YANKEE', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71654QAP72', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71654QAP72', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US71654QAP72', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0234084738', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0234084738', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0234084738', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0234084738', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Regional(state/provnc)', 0, 'script', 'script'

exec CalculatorAttributeStore 'ARARGE03F482', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'DOMESTIC', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03F482', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03F482', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03F482', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0294364954', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0294364954', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0294364954', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0294364954', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0217249126', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0217249126', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'C,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0217249126', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0217249126', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756AV22', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AV22', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AV22', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AV22', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828LW88', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LW88', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LW88', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LW88', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0209139244', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO NON-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0209139244', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0209139244', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'Y',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0209139244', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP58931AE90', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP58931AE90', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BEAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP58931AE90', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP58931AE90', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP4983GAH31', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP4983GAH31', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP4983GAH31', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP4983GAH31', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Lodging', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP1047VAB38', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP1047VAB38', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP1047VAB38', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP1047VAB38', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'US984245AF78', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'YANKEE', 0, 'script', 'script'
exec CalculatorAttributeStore 'US984245AF78', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'US984245AF78', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US984245AF78', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US70645KAR05', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'US70645KAR05', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'HSBC,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US70645KAR05', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US70645KAR05', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0190174861', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO NON-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0190174861', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BNPPAR-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0190174861', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0190174861', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912810QA97', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912810QA97', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912810QA97', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912810QA97', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US922646BL74', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US922646BL74', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US922646BL74', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US922646BL74', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US698299AW45', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AW45', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'HSBC,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AW45', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AW45', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US84265VAA35', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US84265VAA35', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US84265VAA35', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US84265VAA35', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Mining', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828LL24', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LL24', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LL24', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LL24', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP93081AF78', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP93081AF78', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP93081AF78', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP93081AF78', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US040114GN48', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GN48', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GN48', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GN48', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP9379RAA51', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP9379RAA51', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BAML,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP9379RAA51', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP9379RAA51', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'US470160AS17', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AS17', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BEAR-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AS17', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AS17', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP97475AF73', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AF73', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABNHOL,CAI,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AF73', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AF73', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP30982AA34', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP30982AA34', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP30982AA34', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP30982AA34', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Household Products/Wares', 0, 'script', 'script'

exec CalculatorAttributeStore 'US22111YAB11', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US22111YAB11', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US22111YAB11', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US22111YAB11', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Food', 0, 'script', 'script'

exec CalculatorAttributeStore 'US715638AR36', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AR36', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AR36', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AR36', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP68166AA81', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP68166AA81', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP68166AA81', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP68166AA81', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Transportation', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756BF62', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BF62', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BF62', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BF62', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0146173371', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0146173371', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0146173371', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0146173371', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3R23NAA86', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3R23NAA86', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MS,SANT', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3R23NAA86', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3R23NAA86', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Home Builders', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG86665AA70', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG86665AA70', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JOINT LEADS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG86665AA70', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG86665AA70', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Airlines', 0, 'script', 'script'

exec CalculatorAttributeStore 'US168863AP36', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US168863AP36', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US168863AP36', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US168863AP36', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US29274FAB04', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'YANKEE', 0, 'script', 'script'
exec CalculatorAttributeStore 'US29274FAB04', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US29274FAB04', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US29274FAB04', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'US195325BL83', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BL83', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BCLY,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BL83', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BL83', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828LS76', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LS76', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LS76', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LS76', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756AR10', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AR10', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AR10', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AR10', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US040114BC38', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114BC38', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114BC38', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US040114BC38', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US400489AB66', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US400489AB66', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US400489AB66', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US400489AB66', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Lodging', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP07785AA98', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP07785AA98', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP07785AA98', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP07785AA98', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG86667AA37', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG86667AA37', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG86667AA37', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG86667AA37', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0075866128', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0075866128', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0075866128', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'Y',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0075866128', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG2025MAA92', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG2025MAA92', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MSDW', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG2025MAA92', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG2025MAA92', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US195325BA29', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BA29', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB,GS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BA29', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BA29', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP14486AC11', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP14486AC11', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS,HSBC', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP14486AC11', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP14486AC11', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3097WAC49', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3097WAC49', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3097WAC49', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3097WAC49', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Retail', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP31573AB77', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP31573AB77', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP31573AB77', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP31573AB77', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Food', 0, 'script', 'script'

exec CalculatorAttributeStore 'US706451AP64', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451AP64', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'HSBC,LEH', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451AP64', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US706451AP64', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828KN98', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KN98', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KN98', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KN98', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US698299AS33', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AS33', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AS33', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AS33', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0173605311', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO NON-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0173605311', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0173605311', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0173605311', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP48864AF26', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP48864AF26', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP48864AF26', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP48864AF26', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG0732RAB45', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG0732RAB45', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG0732RAB45', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG0732RAB45', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'US917288BC52', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US917288BC52', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'UBS-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'US917288BC52', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US917288BC52', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756AY60', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AY60', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AY60', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AY60', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828LH12', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LH12', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LH12', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LH12', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG87734AA00', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG87734AA00', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG87734AA00', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG87734AA00', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Transportation', 0, 'script', 'script'

exec CalculatorAttributeStore 'US922646AT10', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US922646AT10', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US922646AT10', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US922646AT10', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756BB58', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BB58', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BB58', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BB58', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US715638AN22', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AN22', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB,ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AN22', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AN22', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP39848AA70', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP39848AA70', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP39848AA70', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP39848AA70', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'US917288AZ56', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'US917288AZ56', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US917288AZ56', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US917288AZ56', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0328448047', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0328448047', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'UBSINV', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0328448047', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0328448047', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP0605BAF42', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP0605BAF42', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP0605BAF42', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP0605BAF42', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Commercial Services', 0, 'script', 'script'

exec CalculatorAttributeStore 'US195325BH71', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BH71', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BH71', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BH71', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828KC34', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KC34', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KC34', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KC34', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US02364WAH88', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US02364WAH88', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US02364WAH88', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US02364WAH88', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'US151191AG85', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'YANKEE', 0, 'script', 'script'
exec CalculatorAttributeStore 'US151191AG85', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US151191AG85', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US151191AG85', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Forest Products&Paper', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91086QAV05', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAV05', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAV05', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAV05', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP93369AA76', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP93369AA76', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MS-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP93369AA76', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP93369AA76', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3579EAG28', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3579EAG28', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3579EAG28', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3579EAG28', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'ARARGE035162', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'DOMESTIC', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE035162', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE035162', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE035162', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US760942AS16', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US760942AS16', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US760942AS16', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US760942AS16', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US05963GAF54', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US05963GAF54', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US05963GAF54', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US05963GAF54', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'US29245SAC61', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US29245SAC61', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US29245SAC61', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US29245SAC61', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'US29274FAE43', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US29274FAE43', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US29274FAE43', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US29274FAE43', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828LD08', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LD08', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LD08', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LD08', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US168863AS74', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US168863AS74', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US168863AS74', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US168863AS74', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US040114AV28', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114AV28', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114AV28', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US040114AV28', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0244421953', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0244421953', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ING,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0244421953', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0244421953', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Food', 0, 'script', 'script'

exec CalculatorAttributeStore 'US71645WAG69', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAG69', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BEAR,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAG69', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAG69', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG93085AA94', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG93085AA94', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG93085AA94', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG93085AA94', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Iron/Steel', 0, 'script', 'script'

exec CalculatorAttributeStore 'US803895AF81', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US803895AF81', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US803895AF81', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US803895AF81', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'US706448AR84', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706448AR84', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706448AR84', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US706448AR84', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'US195325BD67', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BD67', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BD67', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BD67', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG08010BH52', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG08010BH52', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BBBBI,HSBC', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG08010BH52', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG08010BH52', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'ARARGE03F441', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'DOMESTIC', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03F441', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03F441', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03F441', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US71654XAF42', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71654XAF42', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71654XAF42', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US71654XAF42', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP21963AA44', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP21963AA44', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP21963AA44', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP21963AA44', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Forest Products&Paper', 0, 'script', 'script'

exec CalculatorAttributeStore 'US470160AV46', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AV46', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AV46', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AV46', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US20441XAB82', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US20441XAB82', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US20441XAB82', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US20441XAB82', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Beverages', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP01012AN67', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP01012AN67', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP01012AN67', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP01012AN67', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91911TAJ25', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91911TAJ25', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS,HSBC,SANT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91911TAJ25', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91911TAJ25', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Mining', 0, 'script', 'script'

exec CalculatorAttributeStore 'US715638AU64', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AU64', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AU64', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AU64', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0218481744', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0218481744', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0218481744', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0218481744', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG2584XAA84', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG2584XAA84', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG2584XAA84', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG2584XAA84', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Iron/Steel', 0, 'script', 'script'

exec CalculatorAttributeStore 'US879403AP84', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US879403AP84', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US879403AP84', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US879403AP84', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756BE97', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BE97', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BE97', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BE97', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US706451AH49', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451AH49', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451AH49', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US706451AH49', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG6710EAD25', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG6710EAD25', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JOINT LEADS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG6710EAD25', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG6710EAD25', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Engineering&Construction', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP78954AC19', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP78954AC19', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP78954AC19', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP78954AC19', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3579EAC14', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3579EAC14', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3579EAC14', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3579EAC14', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US591668AA66', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US591668AA66', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DRKW', 0, 'script', 'script'
exec CalculatorAttributeStore 'US591668AA66', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US591668AA66', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG3980PAB16', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG3980PAB16', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG3980PAB16', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG3980PAB16', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Airlines', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0242966017', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0242966017', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS,DBSING', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0242966017', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0242966017', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Iron/Steel', 0, 'script', 'script'

exec CalculatorAttributeStore 'US040114AR16', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114AR16', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114AR16', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US040114AR16', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US70645KAQ22', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'US70645KAQ22', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,LEH', 0, 'script', 'script'
exec CalculatorAttributeStore 'US70645KAQ22', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US70645KAQ22', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP63347AA92', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP63347AA92', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP63347AA92', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP63347AA92', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Building Materials', 0, 'script', 'script'

exec CalculatorAttributeStore 'US36298DAA46', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US36298DAA46', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US36298DAA46', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US36298DAA46', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'US698299AV61', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AV61', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AV61', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AV61', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828LK41', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LK41', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LK41', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LK41', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US040114GM64', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GM64', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BCLY,ML,UBSINV', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GM64', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'Y',  0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GM64', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US470160AR34', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AR34', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AR34', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AR34', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP20037AA89', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP20037AA89', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BEAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP20037AA89', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP20037AA89', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Leisure Time', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP01012AJ55', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP01012AJ55', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP01012AJ55', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP01012AJ55', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0294364103', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0294364103', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0294364103', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0294364103', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0213101073', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO NON-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0213101073', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BCLY,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0213101073', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0213101073', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US698299AK07', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AK07', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AK07', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AK07', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US715638AQ52', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AQ52', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AQ52', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AQ52', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3699PEM51', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3699PEM51', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3699PEM51', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3699PEM51', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0205537581', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO NON-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0205537581', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0205537581', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0205537581', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US10553MAA99', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US10553MAA99', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'US10553MAA99', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US10553MAA99', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0043119147', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'RESTRUCTURD DEBT', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0043119147', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0043119147', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0043119147', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US195325AW57', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325AW57', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325AW57', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US195325AW57', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP37110AB25', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP37110AB25', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP37110AB25', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP37110AB25', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP09097AA71', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP09097AA71', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP09097AA71', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP09097AA71', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828KF64', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KF64', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KF64', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KF64', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP6460MAC84', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP6460MAC84', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BA', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP6460MAC84', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP6460MAC84', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Food', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828LR93', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LR93', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LR93', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LR93', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP21963AD82', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP21963AD82', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BBVA,BSSA,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP21963AD82', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP21963AD82', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Forest Products&Paper', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0205545840', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO NON-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0205545840', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0205545840', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0205545840', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USU70577AJ73', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USU70577AJ73', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'HSBC,LEH', 0, 'script', 'script'
exec CalculatorAttributeStore 'USU70577AJ73', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USU70577AJ73', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US917288AY81', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'US917288AY81', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US917288AY81', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US917288AY81', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US29244TAC53', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'YANKEE', 0, 'script', 'script'
exec CalculatorAttributeStore 'US29244TAC53', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CHASE', 0, 'script', 'script'
exec CalculatorAttributeStore 'US29244TAC53', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US29244TAC53', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP6830JAA27', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP6830JAA27', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP6830JAA27', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP6830JAA27', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'US760942AV45', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US760942AV45', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'US760942AV45', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US760942AV45', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756AX87', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AX87', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB,GS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AX87', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AX87', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP31573AA94', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP31573AA94', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP31573AA94', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP31573AA94', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Food', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828LG39', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LG39', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LG39', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LG39', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US922646AS37', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US922646AS37', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CHASE,GS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US922646AS37', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US922646AS37', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756BR01', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BR01', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BCLY,HSBC', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BR01', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BR01', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91911TAF03', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91911TAF03', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91911TAF03', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91911TAF03', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Mining', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0356521160', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0356521160', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0356521160', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0356521160', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'US40048CAB90', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'YANKEE', 0, 'script', 'script'
exec CalculatorAttributeStore 'US40048CAB90', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ING-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'US40048CAB90', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US40048CAB90', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Mining', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG4756WAB66', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG4756WAB66', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'SIB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG4756WAB66', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG4756WAB66', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0234082872', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO NON-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0234082872', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0234082872', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0234082872', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Regional(state/provnc)', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756BA75', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BA75', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BA75', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BA75', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0166205053', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO NON-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0166205053', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BNPPAR,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0166205053', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0166205053', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3699PAC16', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3699PAC16', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DBAB-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3699PAC16', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3699PAC16', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US872402AK85', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US872402AK85', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US872402AK85', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US872402AK85', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Transportation', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG9393UAA00', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG9393UAA00', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JOINT LEADS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG9393UAA00', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG9393UAA00', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Building Materials', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG61473AA59', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG61473AA59', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG61473AA59', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG61473AA59', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Distribution/Wholesale', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG2583XAA93', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG2583XAA93', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ITAU,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG2583XAA93', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG2583XAA93', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Iron/Steel', 0, 'script', 'script'

exec CalculatorAttributeStore 'US12517HAF01', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'US12517HAF01', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BANFIN,STANBK', 0, 'script', 'script'
exec CalculatorAttributeStore 'US12517HAF01', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US12517HAF01', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP5537SAD47', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP5537SAD47', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MLPFS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP5537SAD47', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP5537SAD47', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Metal Fabricate/Hardware', 0, 'script', 'script'

exec CalculatorAttributeStore 'US40049JAT43', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US40049JAT43', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DBAB,JPM,SB', 0, 'script', 'script'
exec CalculatorAttributeStore 'US40049JAT43', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US40049JAT43', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Media', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP98100AB94', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP98100AB94', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS,LEH,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP98100AB94', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP98100AB94', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Packaging&Containers', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP6988YAK75', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP6988YAK75', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP6988YAK75', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP6988YAK75', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Media', 0, 'script', 'script'

exec CalculatorAttributeStore 'US45767DAD12', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US45767DAD12', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US45767DAD12', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US45767DAD12', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'US21988JAA88', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US21988JAA88', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US21988JAA88', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US21988JAA88', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Entertainment', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP97475AN08', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AN08', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AN08', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AN08', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91086QAU22', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAU22', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAU22', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAU22', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG1317RAA70', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG1317RAA70', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG1317RAA70', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG1317RAA70', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP41625AA59', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP41625AA59', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BEAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP41625AA59', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP41625AA59', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0197620411', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO NON-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0197620411', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB,DRKW', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0197620411', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0197620411', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US760942AR33', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US760942AR33', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US760942AR33', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US760942AR33', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756AT75', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AT75', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AT75', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AT75', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP7652MAG52', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP7652MAG52', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP7652MAG52', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP7652MAG52', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828LC25', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LC25', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LC25', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LC25', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US219868AN67', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US219868AN67', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US219868AN67', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US219868AN67', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Multi-National', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3143NAJ39', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3143NAJ39', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'HSBC,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3143NAJ39', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3143NAJ39', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Mining', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP28148AA54', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP28148AA54', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BEAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP28148AA54', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP28148AA54', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Mining', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG07402AF04', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG07402AF04', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'C', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG07402AF04', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG07402AF04', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91724RAA23', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91724RAA23', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91724RAA23', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91724RAA23', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Home Builders', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828KZ29', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KZ29', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KZ29', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KZ29', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'ARBNAC030255', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'DOMESTIC', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARBNAC030255', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARBNAC030255', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'ARBNAC030255', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US040114GP95', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GP95', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GP95', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GP95', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG0744GAA60', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG0744GAA60', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG0744GAA60', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG0744GAA60', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828LJ77', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LJ77', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LJ77', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LJ77', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US470160AU62', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AU62', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AU62', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AU62', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USN29037AA10', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USN29037AA10', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN', 0, 'script', 'script'
exec CalculatorAttributeStore 'USN29037AA10', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USN29037AA10', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP6480JAD92', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP6480JAD92', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP6480JAD92', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP6480JAD92', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP01012AM84', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP01012AM84', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP01012AM84', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP01012AM84', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105532AA36', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105532AA36', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ML-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105532AA36', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105532AA36', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Chemicals', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG2938AAA19', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG2938AAA19', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JOINT LEADS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG2938AAA19', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG2938AAA19', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP5880CAA82', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP5880CAA82', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,CS,CS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP5880CAA82', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP5880CAA82', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Real Estate', 0, 'script', 'script'

exec CalculatorAttributeStore 'US195325AZ88', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325AZ88', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ML,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325AZ88', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US195325AZ88', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91086QAQ10', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAQ10', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS,GS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAQ10', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAQ10', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP7448MAF60', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP7448MAF60', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP7448MAF60', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP7448MAF60', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Forest Products&Paper', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3142LAN93', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3142LAN93', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3142LAN93', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3142LAN93', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Entertainment', 0, 'script', 'script'

exec CalculatorAttributeStore 'US706451AG65', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451AG65', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451AG65', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US706451AG65', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US00105DAB10', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US00105DAB10', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US00105DAB10', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US00105DAB10', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828KE99', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KE99', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KE99', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KE99', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US70645KAP49', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'US70645KAP49', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,LEH', 0, 'script', 'script'
exec CalculatorAttributeStore 'US70645KAP49', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US70645KAP49', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US706451BS94', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451BS94', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451BS94', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US706451BS94', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP06064AA01', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP06064AA01', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP06064AA01', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP06064AA01', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0072223190', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'RESTRUCTURD DEBT', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0072223190', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0072223190', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0072223190', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US698299AU88', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AU88', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AU88', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AU88', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG3980PAA33', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG3980PAA33', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG3980PAA33', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG3980PAA33', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Airlines', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP5881CAB56', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP5881CAB56', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP5881CAB56', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP5881CAB56', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP4948KAC91', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP4948KAC91', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ML-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP4948KAC91', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP4948KAC91', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Food', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP70809AB71', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP70809AB71', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,LEH', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP70809AB71', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP70809AB71', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91086QAX60', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAX60', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS,DB,HSBC', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAX60', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAX60', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP93960AA38', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP93960AA38', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP93960AA38', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP93960AA38', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP01165AA00', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP01165AA00', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BEAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP01165AA00', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP01165AA00', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Airlines', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756AE07', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AE07', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AE07', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AE07', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP8056GAA15', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP8056GAA15', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP8056GAA15', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP8056GAA15', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91911TAE38', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91911TAE38', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91911TAE38', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91911TAE38', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Mining', 0, 'script', 'script'

exec CalculatorAttributeStore 'US715638AP79', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AP79', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AP79', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AP79', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828KV15', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KV15', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KV15', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KV15', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP9592YAF09', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP9592YAF09', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP9592YAF09', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP9592YAF09', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Home Builders', 0, 'script', 'script'

exec CalculatorAttributeStore 'US040114GL81', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GL81', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GL81', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'Y',  0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GL81', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US470160AQ50', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AQ50', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BEAR-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AQ50', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AQ50', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0290125391', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0290125391', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BCLY,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0290125391', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0290125391', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Regional(state/provnc)', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0170239932', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0170239932', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'C,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0170239932', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0170239932', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP7182PAA05', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP7182PAA05', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BEAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP7182PAA05', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP7182PAA05', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Real Estate', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756AP53', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AP53', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CHASE,GS,MSDW', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AP53', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AP53', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0129675350', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0129675350', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0129675350', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'Y',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0129675350', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP84477AB73', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP84477AB73', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'PRESIC', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP84477AB73', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP84477AB73', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Auto Parts&Equipment', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP37110AA42', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP37110AA42', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP37110AA42', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP37110AA42', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'ARARGE03F342', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'DOMESTIC', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03F342', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03F342', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03F342', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US040114GA27', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GA27', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GA27', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GA27', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP7161AAC47', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP7161AAC47', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP7161AAC47', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP7161AAC47', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Media', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP14486AA54', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP14486AA54', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP14486AA54', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP14486AA54', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3058XAJ48', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3058XAJ48', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3058XAJ48', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3058XAJ48', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP5122QAG21', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP5122QAG21', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MLPFS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP5122QAG21', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP5122QAG21', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3143NAF17', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3143NAF17', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,HSBC', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3143NAF17', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3143NAF17', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Mining', 0, 'script', 'script'

exec CalculatorAttributeStore 'US02364WAP05', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US02364WAP05', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS,GS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US02364WAP05', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US02364WAP05', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912810PX00', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912810PX00', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912810PX00', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912810PX00', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG1593PAA69', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG1593PAA69', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG1593PAA69', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG1593PAA69', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Real Estate', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0074563015', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0074563015', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CHASE', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0074563015', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0074563015', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Municipal', 0, 'script', 'script'

exec CalculatorAttributeStore 'US29244TAB70', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'YANKEE', 0, 'script', 'script'
exec CalculatorAttributeStore 'US29244TAB70', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CHASE', 0, 'script', 'script'
exec CalculatorAttributeStore 'US29244TAB70', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US29244TAB70', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0208158096', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0208158096', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0208158096', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0208158096', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Multi-National', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP5187CAA82', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP5187CAA82', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP5187CAA82', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP5187CAA82', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756BQ28', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BQ28', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS,ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BQ28', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BQ28', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US698299AQ76', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AQ76', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AQ76', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AQ76', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP98022AB57', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP98022AB57', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,CSFB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP98022AB57', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP98022AB57', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Packaging&Containers', 0, 'script', 'script'

exec CalculatorAttributeStore 'US917288BA96', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'US917288BA96', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US917288BA96', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US917288BA96', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US760942AU61', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US760942AU61', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB,ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'US760942AU61', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US760942AU61', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US219868AQ98', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US219868AQ98', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'US219868AQ98', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US219868AQ98', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Multi-National', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0106768608', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO NON-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0106768608', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BNPPAR,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0106768608', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'Y',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0106768608', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US059495AA97', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US059495AA97', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'US059495AA97', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US059495AA97', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828LF55', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LF55', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LF55', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LF55', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US040114GH79', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GH79', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JOINT LEADS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GH79', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GH79', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP8001VAD84', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP8001VAD84', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP8001VAD84', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP8001VAD84', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'US70645KBM09', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'US70645KBM09', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'HSBC,JPM,LEHNEW', 0, 'script', 'script'
exec CalculatorAttributeStore 'US70645KBM09', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US70645KBM09', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP17625AB33', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP17625AB33', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BCLY,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP17625AB33', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP17625AB33', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG4756WAA83', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG4756WAA83', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG4756WAA83', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG4756WAA83', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828KR03', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KR03', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KR03', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KR03', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0306322065', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0306322065', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0306322065', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0306322065', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0294367205', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0294367205', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0294367205', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0294367205', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US715638AL65', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AL65', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AL65', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US715638AL65', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP9308RAX19', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP9308RAX19', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP9308RAX19', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP9308RAX19', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Pipelines', 0, 'script', 'script'

exec CalculatorAttributeStore 'US21987BAL27', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US21987BAL27', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB,HSBCL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US21987BAL27', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US21987BAL27', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Mining', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3699PAB33', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3699PAB33', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3699PAB33', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3699PAB33', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0115743519', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0115743519', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0115743519', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0115743519', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'DE000A0DED93', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO NON-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'DE000A0DED93', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'COBA,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'DE000A0DED93', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'Y',  0, 'script', 'script'
exec CalculatorAttributeStore 'DE000A0DED93', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG07402AE39', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG07402AE39', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BBSECS,CSFB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG07402AE39', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG07402AE39', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756AL40', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AL40', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ML,MSDW', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AL40', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AL40', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG09077AB73', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG09077AB73', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', ',CS,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG09077AB73', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG09077AB73', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'USU84360AA17', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USU84360AA17', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'USU84360AA17', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USU84360AA17', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Mining', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP93960AD76', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP93960AD76', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP93960AD76', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP93960AD76', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US470160AT99', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AT99', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AT99', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US470160AT99', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0205930752', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0205930752', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0205930752', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0205930752', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG26593AA40', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG26593AA40', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS,ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG26593AA40', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG26593AA40', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Healthcare-Services', 0, 'script', 'script'

exec CalculatorAttributeStore 'US040114FC91', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114FC91', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MSDW', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114FC91', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US040114FC91', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828KY53', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KY53', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KY53', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KY53', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP24028AB16', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP24028AB16', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP24028AB16', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP24028AB16', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Beverages', 0, 'script', 'script'

exec CalculatorAttributeStore 'US10553JAE82', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'US10553JAE82', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US10553JAE82', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US10553JAE82', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Chemicals', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP22854AF31', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP22854AF31', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP22854AF31', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP22854AF31', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP6052AAA27', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP6052AAA27', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BAS,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP6052AAA27', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP6052AAA27', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Transportation', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756BM14', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BM14', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BCLY,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BM14', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756BM14', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US698299AM62', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AM62', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AM62', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AM62', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP69420AA81', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP69420AA81', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BTALEX', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP69420AA81', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP69420AA81', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'US40050BAB62', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'US40050BAB62', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US40050BAB62', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US40050BAB62', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828LB42', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LB42', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LB42', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LB42', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG1315RAA98', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG1315RAA98', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN,CAI,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG1315RAA98', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG1315RAA98', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Chemicals', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP37110AD80', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP37110AD80', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JOINT LEADS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP37110AD80', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP37110AD80', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US040114GD65', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GD65', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GD65', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GD65', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP37201AA18', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP37201AA18', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP37201AA18', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP37201AA18', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG9393BAA29', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG9393BAA29', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG9393BAA29', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG9393BAA29', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Building Materials', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0235386447', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0235386447', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0235386447', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0235386447', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'US25714PAF53', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US25714PAF53', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US25714PAF53', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US25714PAF53', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP7873PAD89', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP7873PAD89', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'HSBC,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP7873PAD89', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP7873PAD89', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91911TAH68', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91911TAH68', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN,CS,SANT,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91911TAH68', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91911TAH68', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Mining', 0, 'script', 'script'

exec CalculatorAttributeStore 'US151290AP84', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US151290AP84', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CHASE', 0, 'script', 'script'
exec CalculatorAttributeStore 'US151290AP84', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US151290AP84', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Building Materials', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3661PAA95', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3661PAA95', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BCLY,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3661PAA95', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3661PAA95', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP78628AE70', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP78628AE70', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CHASE,GS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP78628AE70', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP78628AE70', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US219868BN58', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US219868BN58', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BAML,CS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US219868BN58', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US219868BN58', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Multi-National', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP87993AA23', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP87993AA23', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CS-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP87993AA23', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP87993AA23', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Insurance', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG27631AA18', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG27631AA18', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG27631AA18', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG27631AA18', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG29440AA56', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG29440AA56', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BCLY,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG29440AA56', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG29440AA56', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP56064BV26', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP56064BV26', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MS-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP56064BV26', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP56064BV26', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Miscellaneous Manufactur', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3699PAE71', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3699PAE71', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3699PAE71', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3699PAE71', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US706451AF82', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451AF82', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451AF82', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US706451AF82', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP78954AA52', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP78954AA52', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP78954AA52', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP78954AA52', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91086QAW87', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAW87', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAW87', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAW87', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0222076449', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0222076449', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BARCLY,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0222076449', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'Y',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0222076449', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US151191AN37', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US151191AN37', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US151191AN37', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US151191AN37', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Forest Products&Paper', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP9037HAK97', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP9037HAK97', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JOINT LEADS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP9037HAK97', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP9037HAK97', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3058WAB39', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3058WAB39', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3058WAB39', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3058WAB39', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Water', 0, 'script', 'script'

exec CalculatorAttributeStore 'ARARGE03E196', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'DOMESTIC', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03E196', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03E196', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03E196', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP5881CAA73', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP5881CAA73', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP5881CAA73', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP5881CAA73', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'US872402AB86', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US872402AB86', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MSDW-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'US872402AB86', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US872402AB86', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Transportation', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0123149733', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO NON-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0123149733', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DRKW,ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0123149733', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'Y',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0123149733', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0115748401', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0115748401', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0115748401', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0115748401', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US760942AT98', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US760942AT98', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'US760942AT98', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US760942AT98', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3143NAE42', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3143NAE42', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3143NAE42', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3143NAE42', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Mining', 0, 'script', 'script'

exec CalculatorAttributeStore 'US706451BG56', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451BG56', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451BG56', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US706451BG56', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG5689DAB76', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG5689DAB76', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'MS,SANT', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG5689DAB76', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG5689DAB76', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Chemicals', 0, 'script', 'script'

exec CalculatorAttributeStore 'US195325AJ47', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325AJ47', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JOINT LEADS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325AJ47', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US195325AJ47', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US12517GAD79', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US12517GAD79', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BANFIN,STANBK', 0, 'script', 'script'
exec CalculatorAttributeStore 'US12517GAD79', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US12517GAD79', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP8716HAA16', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP8716HAA16', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP8716HAA16', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP8716HAA16', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Investment Companies', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP48864AC94', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP48864AC94', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BEAR-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP48864AC94', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP48864AC94', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828KU32', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KU32', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KU32', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KU32', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP97475AE09', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AE09', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DKW,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AE09', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AE09', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US40049JAV98', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US40049JAV98', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US40049JAV98', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US40049JAV98', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Media', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91086QAL23', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAL23', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAL23', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAL23', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0132229088', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO NON-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0132229088', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0132229088', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'Y',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0132229088', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0020116389', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'RESTRUCTURD DEBT', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0020116389', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0020116389', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'Y',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0020116389', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0077157575', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO NON-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0077157575', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0077157575', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'Y',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0077157575', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG27649AB17', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG27649AB17', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI,CS,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG27649AB17', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG27649AB17', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Telecommunications', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG25847AA53', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG25847AA53', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG25847AA53', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG25847AA53', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Iron/Steel', 0, 'script', 'script'

exec CalculatorAttributeStore 'US706451AB78', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451AB78', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451AB78', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US706451AB78', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'US12517HAD52', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'US12517HAD52', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BANFIN,STANBK', 0, 'script', 'script'
exec CalculatorAttributeStore 'US12517HAD52', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US12517HAD52', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP84477AA90', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP84477AA90', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'PRESIC', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP84477AA90', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP84477AA90', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Auto Parts&Equipment', 0, 'script', 'script'

exec CalculatorAttributeStore 'US195325AU91', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325AU91', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CHASE,GS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325AU91', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US195325AU91', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US29244TAA97', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'YANKEE', 0, 'script', 'script'
exec CalculatorAttributeStore 'US29244TAA97', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CHASE', 0, 'script', 'script'
exec CalculatorAttributeStore 'US29244TAA97', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US29244TAA97', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP8241VAB29', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP8241VAB29', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DKIB-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP8241VAB29', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP8241VAB29', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Food', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828LV06', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LV06', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LV06', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828LV06', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP97475AP55', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AP55', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AP55', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP97475AP55', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US71645WAN11', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAN11', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BSSA,HSBC,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAN11', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAN11', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP09669BT10', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO MTN', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP09669BT10', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CITI-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP09669BT10', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP09669BT10', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG4969UAA54', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG4969UAA54', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ABN-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG4969UAA54', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG4969UAA54', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91086QAS75', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAS75', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BEAR,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAS75', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAS75', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0201110037', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO NON-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0201110037', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DRKW,UBS', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0201110037', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0201110037', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG70474AE48', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG70474AE48', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BBVA,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG70474AE48', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG70474AE48', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Diversified Finan Serv', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105532AC91', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105532AC91', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'HSBC,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105532AC91', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105532AC91', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Chemicals', 0, 'script', 'script'

exec CalculatorAttributeStore 'US698299AP93', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AP93', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CHASE,MSDW', 0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AP93', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US698299AP93', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US151191AJ25', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'YANKEE', 0, 'script', 'script'
exec CalculatorAttributeStore 'US151191AJ25', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'US151191AJ25', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US151191AJ25', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Forest Products&Paper', 0, 'script', 'script'

exec CalculatorAttributeStore 'US71656MAB54', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71656MAB54', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BSSA,GS,HSBC', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71656MAB54', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US71656MAB54', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3579EAD96', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3579EAD96', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3579EAD96', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3579EAD96', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP22854AE65', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP22854AE65', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'DKW', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP22854AE65', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP22854AE65', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Electric', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP17625AA59', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP17625AA59', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BCLY,DB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP17625AA59', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP17625AA59', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP6558LAH26', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP6558LAH26', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP6558LAH26', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP6558LAH26', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG93932AA24', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG93932AA24', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG93932AA24', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG93932AA24', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Building Materials', 0, 'script', 'script'

exec CalculatorAttributeStore 'US040114GG96', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GG96', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JOINT LEADS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GG96', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US040114GG96', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP58072AB84', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP58072AB84', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP58072AB84', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP58072AB84', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Forest Products&Paper', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP18533AH51', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP18533AH51', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'HSBC,JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP18533AH51', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP18533AH51', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Chemicals', 0, 'script', 'script'

exec CalculatorAttributeStore 'US706451BC43', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451BC43', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GOLDMAN SACHS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US706451BC43', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US706451BC43', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'XS0270992380', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0270992380', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'ML-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'XS0270992380', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'XS0270992380', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Regional(state/provnc)', 0, 'script', 'script'

exec CalculatorAttributeStore 'USP3699PAA59', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3699PAA59', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CSFB-sole', 0, 'script', 'script'
exec CalculatorAttributeStore 'USP3699PAA59', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USP3699PAA59', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US912828KQ20', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'US GOVT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KQ20', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KQ20', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N.A.',  0, 'script', 'script'
exec CalculatorAttributeStore 'US912828KQ20', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US105756AK66', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AK66', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'CHASE,GS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AK66', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US105756AK66', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US40049JAR86', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US40049JAR86', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM,CITI', 0, 'script', 'script'
exec CalculatorAttributeStore 'US40049JAR86', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US40049JAR86', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Media', 0, 'script', 'script'

exec CalculatorAttributeStore 'US91086QAH11', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAH11', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAH11', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US91086QAH11', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US25714PAE88', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'PRIV PLACEMENT', 0, 'script', 'script'
exec CalculatorAttributeStore 'US25714PAE88', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'US25714PAE88', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US25714PAE88', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'US71645WAJ09', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAJ09', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'BEAR,MS', 0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAJ09', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US71645WAJ09', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Oil&Gas', 0, 'script', 'script'

exec CalculatorAttributeStore 'USG09077AA90', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'EURO-DOLLAR', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG09077AA90', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'JPM', 0, 'script', 'script'
exec CalculatorAttributeStore 'USG09077AA90', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'USG09077AA90', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Banks', 0, 'script', 'script'

exec CalculatorAttributeStore 'US195325BK01', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'GLOBAL', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BK01', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', 'GS,ML', 0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BK01', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'US195325BK01', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'

exec CalculatorAttributeStore 'ARARGE03E170', 'BondStaticCalc', 'MarketIssue',      'STRING', 0, 0, '1-1-1900', 'DOMESTIC', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03E170', 'BondStaticCalc', 'LeadManager',      'STRING', 0, 0, '1-1-1900', '', 0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03E170', 'BondStaticCalc', 'Bearer',           'STRING', 0, 0, '1-1-1900', 'N',  0, 'script', 'script'
exec CalculatorAttributeStore 'ARARGE03E170', 'BondStaticCalc', 'IndustryGroup',    'STRING', 0, 0, '1-1-1900', 'Sovereign', 0, 'script', 'script'


