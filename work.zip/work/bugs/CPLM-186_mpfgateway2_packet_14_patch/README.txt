# Patch mpfgateway2 #

To mirror the production instance of bloomberg-mpfgateway2-bonds_tradingsystem the following actions are required.

1) Modify the UAT configuration file bloomberg-mpfgateway2-stamford.xml to contain the following entry for LogAdmin

<log name="MPF-PACKET-14" active="true"/>
<log name="MPF-PACKET-8" active="true"/>

This will activate PACKET-8 and PACKET-14 logging

2) Also add the following component

<component lazy="true" name="IsMarketStatusOnPredicate" class_name="com.rbsfm.ficommon.mux.predicate.ConfigurableMessagePredicate">
<predicate>
<attribute name="marketStatus">
<and>
<notnull/>
<equals>ON</equals>
</and>
</attribute>
</predicate>
</component>

3) When the XML configuration has been updated the production patch.jar file needs to be copied across. This patch is build at source level 1.6 so the .ini file needs to be changed to run on a 1.6 VM. To do this the bloomberg-mpfgateway2-stamford.ini must be changed to contain the following.

jrepath= d:/java/jdk1.6.0_04

However, the server must still be build on a 1.5 JDK as the tag has classes that will not compile on a 1.6 JDK.

