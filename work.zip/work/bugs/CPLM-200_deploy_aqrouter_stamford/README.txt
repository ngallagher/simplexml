# Deployment Instructions for AQ Router #

1) To build the production archive the following build server should be used.

    http://lonms02482:44444/netbuild/netbuild?action=build

   The build should be made for the "prod" environment based on the build tag 

    aqrouter-2_0_4_release
 
   Also the JVM version should be 1.4 for 1.4 as the VM used in the 
   "bonds-aqrouter-stamford.ini" file for the AQ router is as follows.

    jrepath = d:\java\j2sdk1.4.2_07

2) Once the build has completed the build can be navigated in to to acquire
   the build archive. This can be downloaded from the netbuild server by
   selecting the following link.

    http://lonms02482:44444/builds/

3) When downloaded the .exe should be executed. This will install the 
   process on to the host machine. The .exe is called.

    bonds-aqrouter-stamford.exe

4) In order to deploy the AQ router the classpath used by the london master must
   be replicated. So, the following files need to be copied from the london master
   to the stamford libraries directory.

    \\lonms05305\readonly\rbsfm\egpricing\aqrouter-2_0_4_release\lib\patch.jar
    \\lonms05305\readonly\rbsfm\egpricing\aqrouter-2_0_4_release\lib\dbvault-patch.jar

5) Once the patches have been taken from the london master the configuration files
   need to be modified. The london master contains a file called.

    \\lonms05305\readonly\rbsfm\egpricing\aqrouter-2_0_4_release\bonds-aqrouter-master.xml

   This needs to be copied to a file for stamford called.

    bonds_aqrouter-stamford.xml

   The initial "app" section should be replaced so the "component" element contains the
   required details.

6) Start the process using the "services.msc" application and check out the 
   logs. If there are no errors then things should be fine.

7) To configure the process to connect to the correct servers the "fi_server_details.xml"
   file must be configured. Here the following XML element needs to be changed.

     <server servername="latam-autoquoter-offshore" servertype="EA">

   It requires a child element to be replaced as follows.

     <hostattribute name="AQRouter" value="supranew-aqrouter-master"/>

   Should become

     <hostattribute name="AQRouter" value="bonds-aqrouter-stamford"/>

   Also in the file "_base_clients.entity" the following element should be modified.  

     <client name="AQCLIENT-LATAM">

   This should have a child element replaced as follows.

     <argument>server=supranew-aqrouter-master</argument>

   Should become.

      <argument>server=bonds-aqrouter-stamford</argument>

   The change to the "_base_clients.entity" file affects the AQ client for LATAM as
   it ensures the connection from the client goes to the newly deployed router.

8) To test that everything has been set up correctly the following processes need
   to be bounced.

    supranew-aqrouter-master
    bonds-aqrouter-stamford
    latam-autoquoter-offshore

   This will ensure that the connections are established correctly. Bouncing the
   processes can be done from the CP Admin tool, reachable from.

    \\fm.rbsgrp.net\infraroot\Applications\WKS\GEOS\APPSYNC\CentralisedPricing

9) The status of the autoquoter can be determined from the LATAM autoquoter tool. When
   this is open select the following menu option.

    View > Autoquoters

   It should show "latam-autoquoter-offshort" with the status set to "true" in green.
