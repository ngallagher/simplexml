# Strange source

out_port=+4

# Set a second time from here?????

java.lang.System.setProperty(java.lang.String, java.lang.String) line: 724	
com.rbsfm.fi.pricing.util.ServerSystemProperties.set(java.lang.String, java.lang.String) line: 112	
com.rbsfm.fi.pricing.util.ServerSystemProperties.init() line: 94	
sun.reflect.NativeMethodAccessorImpl.invoke0(java.lang.reflect.Method, java.lang.Object, java.lang.Object[]) line: not available [native method]	
sun.reflect.NativeMethodAccessorImpl.invoke(java.lang.Object, java.lang.Object[]) line: 39	
sun.reflect.DelegatingMethodAccessorImpl.invoke(java.lang.Object, java.lang.Object[]) line: 25	
java.lang.reflect.Method.invoke(java.lang.Object, java.lang.Object...) line: 597	
com.rbsfm.common.config.annotation.PostConstructHelper.invokePostContruct(java.lang.Object, com.rbsfm.common.system.ComponentLogger) line: 64	
com.rbsfm.common.system.ConfigurableComponentManager.createComponent(com.rbsfm.common.config.Config) line: 185	
com.rbsfm.common.system.ConfigurableComponentManager.configure(com.rbsfm.common.config.Config) line: 117	
com.rbsfm.common.system.App.getComponentManager() line: 276	
com.rbsfm.common.system.ControlManager.getInstance(java.lang.String) line: 90	
com.rbsfm.common.system.ControlManager.getDefaultInstance() line: 94	
com.rbsfm.common.system.ControlServer.main0(java.lang.String[]) line: 62	
com.rbsfm.common.system.ControlServer$1.run() line: 34	
java.lang.Thread.run() line: 619	

# Bad props

{EcnSpreadsServer=%servergroup%-ecnspreads-%instance%
 BloombergMPFInsideGateway=%servergroup%-mpfgateway2-inside
 RatesServicesServerTokyo=ratesservices-uat-tokyo6
 PnLControl=%servergroup%-pnlcontrol-master1
 md_socket_port=+6
 taskcontrol_heartbeat_port=+5
 jmx_rmi_port=+7
 ExternalPriceServer=%servergroup%-expricepub-%instance%
 PricingServer=%servergroup%-pricing-%instance%
 BBPricingMaster=%servergroup%-bbpricing-bbpricing
 TOKYO_to_LONDON_port=+5
 AQRouter=%servergroup%-aqrouter-master
 EcnAutoQuoterServer=%servergroup%-autoquoter-%instance%
 global_port=+4
 ExchangeDataServer=%servergroup%-exchangedata-master
 RCSTokyo=corptok-rcs-master
 EcnPriceFeedServer=%servergroup%-ecnpricefeed-%instance%
 http_port=+6
 calc_results_port=+6
 clientmux_port=+5
 data_receive_port=+4
 debug_port=+8
 trade_booking_port=+0
 ReutersDacsId=Application_CP
 HermesExport=%servergroup%-hermesexport-master
 mbp_socket_port=+4
 BenchmarkPricingServer=%servergroup%-pricing-master
 EcnAutoHedgeServer=%servergroup%-autohedge-master
 proc_port=+10
 monitor_message_port=+5
 BloombergMPFGateway=%servergroup%-mpfgateway-bonds
 TOKYO_to_GREENWICH_port=+4
 external_socket_port=+3
 AIF=%servergroup%-aif-master
 RatesServicesServerLondon=ratesservices-uat-london6
 bootstrap_port=+2
 out_port=+4
 soap_port2=+7
 GREENWICH_to_TOKYO_port=+5
 MARK=%servergroup%-mark-master
 BloombergMPFGatewayCusip=%servergroup%-mpfgateway-cusip
 soap_port=+5
 CalcFarm=%servergroup%-farmmanager-master1
 RCSGreenwich=corpus-rcs-master
 task_allocation_port=+5
 security_service_port=+6
 ReutersDacsId2=Application_CP
 EuroGovAQRouter=bonds-aqrouter-master
 bp_socket_port=+5
 details_socket_port=+3
 message_port=+2
 state_port=+4
 LONDON_to_TOKYO_port=+4
 router_socket_port=+5
 MasterRiskTree=%servergroup%-masterriskpltree-master
 LONDON_to_GREENWICH_port=+5
 socket_port=+0
 TradeManager=%servergroup%-trademanager-master
 availability_check_port=+9
 BenchmarkExternalPriceServer=%servergroup%-expricepub-master
 availability_check_remote_port=+6
 InflationPricingServer=inflation-pricing-master
 jmx_port=+1
 RCS=%servergroup%-rcs-master
 AQAdmin=%servergroup%-aqadmin-master
 InstrumentMaintenanceServer=%servergroup%-pricing-instmaint
 proc_socket_port=+10
 priceyield_socket_port=+4
 web_tools_port=+7
 RatesServicesServerGreenwich=ratesservices-uat-greenwich6
 WIFPricing=%servergroup%-wipricing-master
 mkv_listen_port=+6
 ClientMux=%servergroup%-clientmux-%instance%
 GREENWICH_to_LONDON_port=+4
 RCSLondon=corp-rcs-master
 EcnBestPriceServer=%servergroup%-ecnbestprice-master
 appstatus_port=+3
 CdsExternalPriceServer=%servergroup%-expricepub-master14
 EcnMarketDepthServer=%servergroup%-ecnbestprice-master
 socket_port_remote=+3}


