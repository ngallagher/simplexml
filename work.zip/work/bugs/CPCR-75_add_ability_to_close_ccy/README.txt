# Note on task

Instead of refactoring the AutoCloseJob I decided to extend it (as several other implementations do) and create an AutoCloseCurveJob. The reason for this is that there are already several conflicting closing schemes/rules which seem to conflict with each other. Its possible to close specified node sets, close instrument types, and even apply several close times (not assigned to any particular close event). This means that anyone trying to configure the auto close job already has to invest some time figuring out how it should be configured. Adding an additional scheme/rule would just make it more bloated and less understandable. Both the AutoCloseJob and the AutoCloseCurveJob can be used together, ideally the AutoCloseJob would not have the "curve" type in its set of instrument types to close. This ensures the AutoCloseCurveJob is exclusively responsible for closing curves. The following configuration has been added to pricing.xml.

  <component name="AutoCloseCurveJob" class_name="com.rbsfm.fi.pricing.dependency.util.AutoCloseCurveJob" enabled="@{close.curves.enabled}" depends="${startMasterTree}">
    <dependencyTree>DependencyTree</dependencyTree>
    <cron>Cron</cron>
    <onlyCloseIfNotAlreadyClosed>@{close.only.if.not.already.closed}</onlyCloseIfNotAlreadyClosed>   
    <enableHolidayCalendar>@{close.enable.holiday.calendar}true</enableHolidayCalendar>
    <holidayCalendarHome>HolidayCalendarHome</holidayCalendarHome>
    <calendarCode>@{close.holiday.code}</calendarCode>
    @{close.curves.to.close}
    <autoCloseListeners>
		@{close.listeners}
    </autoCloseListeners> 
  </component>  

The close.curves.to.close property mirrors the close.instrument.to.close property and provides additional XML that is inserted in to the template at build time. An example of what should be added follows.

  <closeCurve>
    <curvesToClose closeTime="17:30">
      <curve name="6MFRA_PLN"/>
      <curve name="FRA_PLN"/>
      <curve name="CFRA_PLN"/>
    </curvesToClose>
    <curvesToClose closeTime="13:00">
      <curve name="6MFRA_HUF"/>
      <curve name="FRA_HUF"/>
      <curve name="CFRA_HUF"/>
    </curvesToClose>
  </closeCurve>

# NEW NEW Close curve job

  <component name="AutoCloseCurveJob" class_name="com.rbsfm.fi.pricing.dependency.util.AutoCloseCurveJob" enabled="@{close.curves.enabled}" depends="${startMasterTree}">
    <dependencyTree>DependencyTree</dependencyTree>
    <cron>Cron</cron>
    <onlyCloseIfNotAlreadyClosed>@{close.only.if.not.already.closed}</onlyCloseIfNotAlreadyClosed>   
    <enableHolidayCalendar>@{close.enable.holiday.calendar}true</enableHolidayCalendar>
    <holidayCalendarHome>HolidayCalendarHome</holidayCalendarHome>
    <calendarCode>@{close.holiday.code}</calendarCode>
    @{close.curves.to.close}
    <autoCloseListeners>
		@{close.listeners}
    </autoCloseListeners> 
  </component> 

# Close curve task configuration

<component name="AutoCloseJob" class_name="com.rbsfm.fi.pricing.dependency.util.AutoCloseJob" depends="${startMasterTree}">
    <dependencyTree>DependencyTree</dependencyTree>
    <cron>Cron</cron>
    <onlyCloseIfNotAlreadyClosed>false</onlyCloseIfNotAlreadyClosed>   
    <enableHolidayCalendar>falsetrue</enableHolidayCalendar>
    <holidayCalendarHome>HolidayCalendarHome</holidayCalendarHome>
    <calendarCode></calendarCode>
</component>

# Close seems to fail in UAT

2010-02-23 13:39:49.765 +0000 ERROR [Cron] cpratesdev: Error processing close 6MFRA_PLN_102v105. : Node [6MFRA_PLN_102v105] could not find Calculator [null]: Stack Trace: java.lang.IllegalArgumentException: Node [6MFRA_PLN_102v105] could not find Calculator [null]
	at com.rbsfm.fi.pricing.dependency.NodeWithCalculators.getCalculator(NodeWithCalculators.java:557)
	at com.rbsfm.fi.pricing.dependency.NodeWithCalculators.forward2Calculator(NodeWithCalculators.java:1270)
	at com.rbsfm.fi.pricing.dependency.fra.FraNode.processMessage(FraNode.java:108)
	at com.rbsfm.fi.pricing.dependency.util.CloseHelper.close(CloseHelper.java:136)
	at com.rbsfm.fi.pricing.dependency.util.CloseHelper.close(CloseHelper.java:105)
	at com.rbsfm.fi.pricing.dependency.util.CloseHelper.close(CloseHelper.java:102)
	at com.rbsfm.fi.pricing.dependency.util.OpenCloseManager.processCloseNodeSetEvenIfAlreadyClosedMessage(OpenCloseManager.java:119)
	at com.rbsfm.fi.pricing.dependency.util.OpenCloseManager.processMessage(OpenCloseManager.java:77)
	at com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessageWithConsumer(TreeMessageProcessingManagerImpl.java:232)
	at com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessageWithoutRecalc(TreeMessageProcessingManagerImpl.java:133)
	at com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessage(TreeMessageProcessingManagerImpl.java:89)
	at com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessage(TreeMessageProcessingManagerImpl.java:79)
	at com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree.processMessage(AbstractDependencyTree.java:644)
	at com.rbsfm.fi.pricing.dependency.util.AutoCloseJob.processCloseMessage(AutoCloseJob.java:271)
	at com.rbsfm.fi.pricing.dependency.util.AutoCloseJob.performAutoClose(AutoCloseJob.java:224)
	at com.rbsfm.fi.pricing.dependency.util.AutoCloseJob.run(AutoCloseJob.java:338)
	at com.rbsfm.common.cron.Cron$JobEntry.runJob(Cron.java:202)
	at com.rbsfm.common.cron.Cron.processing(Cron.java:153)
	at com.rbsfm.common.thread.SafeThread.processing(SafeThread.java:310)

# The following can now be used to close at a specific time

<closeNodeSet>
    <nodeSet name="<NodeSetId>" closeTime="12:00"/>
    <nodeSet name="<NodeSetId>" closeTime="15:00"/>
</closeNodeSet>

# What is needed is to ensure that the curve is missing from the close 

This ensures that the CloseAllEvenIfAlreadyClosedMessage does not get sent for that particular set of nodes.

# If the close contains swaps then it needs to be removed

<close>bonds,futures,swaps,mm_nodes,ir_futures</close> << -- if the token is here it gets a CloseAllEvenIfAlreadyClosedMessage

# If the below configuration is used the following can be applied

CloseNodeSetIfNotAlreadyClosedMessage

    # This is the XML configuration that can be used

<close>none</close>
<closeNodeSet>
    <nodeSet name="InterestRateFuture" closeTime="12:00"/>
    <nodeSet name="Index" closeTime="15:00"/>
    <nodeSet name="EMTN-Internal-Index" closeTime="17:00"/>
    <nodeSet name="EMTN-Index" closeTime="18:00"/>
</closeNodeSet>

# Looks like if we close by node set we can configure the following 

closeNodeSet

# Here is the current configuration for the auto close job in CEEMEA
 
<component name="AutoCloseJob" class_name="com.rbsfm.fi.pricing.dependency.util.AutoCloseJob" depends="${startMasterTree}">
    <closeTime>17:00</closeTime>
    <dependencyTree>DependencyTree</dependencyTree>
    <cron>Cron</cron>
    <runForTreeType>master,eurosupra,sterlingsupra,ussupra,plnbonds,jgb,inflation,lmeb,yenswap,latam,ceemea</runForTreeType>
    <onlyCloseIfNotAlreadyClosed>false</onlyCloseIfNotAlreadyClosed>   
    <enableHolidayCalendar>falsetrue</enableHolidayCalendar>
    <holidayCalendarHome>HolidayCalendarHome</holidayCalendarHome>
    <calendarCode></calendarCode>
    <close>bonds,futures,swaps,mm_nodes,ir_futures</close>
</component>
