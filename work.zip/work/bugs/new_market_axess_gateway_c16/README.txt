# To ensure ECN API can delete

The requestConsumer of the MessageWriter XML element should be InventoryImage

# Add the following under the server group "corp"

<hostattribute name="MarketAxessLocalMarketsPriceFeedGateway" value="marketaxess-mainventory-localmarkets"/>

# Here is an example of the sanitizer attribute maPrcPub

exec EcnSanitizerInstCtrlStore 'AQ Orders', 'XS0131593864', 'maPrcPub', 'ON', 1, 'gallane', 'gallane'

# !!!!! MUST NOT FORGET !!!!!!!!

maPrcPub attribute so that we can publish to MarketAxess

# Launcher

C16 - Local Markets (CP Client)
SBP London Corp Autoquoters (AQ Client)

# These properties introduced in patch for ecnpricefeed

${pricefeed.on.task}	
${pricefeed.off.publishers}

# All below problems are solved by

Ensuring the build of "mainventory" in cpbuild/build/rates/build-dependencies.xml includes them "dist.copy.marketaxess" target

# Also the DTD is required 

d:\uat\rbsfm\cp\dtd\ma.dtd

# The build needs an earlier jdom library

jdom-1.0.jar
xalan.jar

# Working branch for the MA changes

marketaxess-magw-4_5_0_local_markets_branch

# Name of the new MA inventory process

marketaxess-mainventory-localmarkets

# Properties added to credit\all.properties

marketaxess.adapter.update=com.rbsfm.fi.marketaxess.external.detail.xml.InventoryUpdateMessageXmlAdapter
marketaxess.adapter.delete=com.rbsfm.fi.marketaxess.external.detail.xml.InventoryDeleteMessageXmlAdapter
marketaxess.adapter.deleteall=com.rbsfm.fi.marketaxess.external.detail.xml.InventoryDeleteAllMessageXmlAdapter

marketaxess.adapter.update..marketaxess.mainventory.localmarkets=com.rbsfm.fi.marketaxess.external.detail.xml.InstrumentQuoteUpdateMessageXmlAdapter
marketaxess.adapter.delete..marketaxess.mainventory.localmarkets=com.rbsfm.fi.marketaxess.external.detail.xml.InstrumentQuoteDeleteMessageXmlAdapter
marketaxess.adapter.deleteall..marketaxess.mainventory.localmarkets=com.rbsfm.fi.marketaxess.external.detail.xml.InstrumentQuoteDeleteAllMessageXmlAdapter

maapi.sessionid=
maapi.sessionid..marketaxess.mainventory.stamford=IQLEVELS
maapi.sessionid..marketaxess.mainventory.localmarkets=IQLEVELS

maapi.username..marketaxess.mainventory.localmarkets=rbsukinv
maapi.password..marketaxess.mainventory.localmarkets=market123

# The new tag for the c16 (Emerging Markets) build will be an rtag of the existing marketaxess-magw-4_5_0_latam

marketaxess-magw-4_5_0_em 

# The Netbuild !!!! SHOULD NOT BE USED !!!!, instead use the following

http://lonms00804:44445/BuildServer/BuildServerApp.html

# The following target in egpricing\build.xml is the key target

<target name="compile.all" depends="compile.all.egpricing" description="compiles all centralised pricing code">

# Problems with the Netbuild server

1) The log4j library in the "lib" project is too old, and is not compatible with SQLTraceLevel.java
2) The caf alproxy.jar is not referenced on the classpath, edit egpricing\build.xml to reference alproxy.jar 
3) The egpricing\build.xml "compile.all" target calls the ficommon\build.xml "compile" which uses lib\share.xml for the classpath
4) The servlet.jar that needs to be in the lib\share.xml should be "${lib.dir}/thirdparty/glue/servlet.jar" to avoid version issues
5) The calcFarm is missing from the list of output classes to build egpricing in egpricing\build.xml
6) All the jars in emmlfi\jar need to be include in the egpricing\build classpath 
7) Reference required within the tradeweb\build.xml classpath to c:\work\Development\marketaxess\cpexternalmmrates\bin

# Argon route for corp-autoquoter-master16 is

ln:pre:cp_rates:aq_corp_16_sec

# Try to build locally

ant -v -Dconfig.group=rates -Dinstall.id=mainventory-stamford -Denv=uat -Dinclude.servers.regex=marketaxess-mainventory-stamford -Drebuild=true

# The following error occurs during the build

    [javac] d:\netbuildex\rbsfm\netbuild1258455226172-uat-marketaxess-magw-4_5_0_latam\common\src\com\rbsfm\common\logger\SQLTraceLevel.java:7: cannot find symbol
    [javac] symbol  : variable TRACE_INT
    [javac] location: class org.apache.log4j.Level
    [javac] 	public static final int SQLTRACE_INT = Level.TRACE_INT + 1; 
    [javac]                                                     ^
    [javac] d:\netbuildex\rbsfm\netbuild1258455226172-uat-marketaxess-magw-4_5_0_latam\common\src\com\rbsfm\common\logger\SQLTraceLevel.java:7: incompatible types
    [javac] found   : 
    [javac] required: int
    [javac] 	public static final int SQLTRACE_INT = Level.TRACE_INT + 1; 


# How do we integrate a new market axess gateway

AggregateEcnPublisher

# The following is used in the "corp" group

<hostattribute name="MarketAxessPriceFeedGateway" value="marketaxess-mainventory-master"/>

This is used to identify the gateway used by the ecnpricefeed-master16 gateway

