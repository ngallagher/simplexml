# All files are scanned with

string[] files = Directory.GetFiles(mFilePath, "*.xml");

# The main execution point is 

MainForm main = new MainForm(GetAqAdminService());

# The means by which it is invoked is as follows

Rbsfm.FI.Data.dll!Rbsfm.FI.Data.FieldDefSetProvider.Add(Rbsfm.FI.Data.IFieldDefSet fieldDefSet = {Rbsfm.FI.Data.FieldDefSet}) Line 102	C#
AQ Admin.exe!Rbsfm.Capmarkets.AutoQuoterAdmin.Messaging.Data.FieldDefSetCache.Load(string path = "..\\..\\config\\fieldmaps") Line 167 + 0xb bytes	C#
AQ Admin.exe!Rbsfm.Capmarkets.AutoQuoterAdmin.Startup.CPServiceConfigurator.FieldDefSetProvider.get() Line 204 + 0x1d bytes	C#
Rbsfm.Common.dll!Rbsfm.Common.Service.CPService.Configurator.set(Rbsfm.Common.Service.IDataServiceConfigurator value = {Rbsfm.Capmarkets.AutoQuoterAdmin.Startup.CPServiceConfigurator}) Line 156 + 0xb bytes	C#
Rbsfm.Common.dll!Rbsfm.Common.Service.AbstractServiceConfigurator.AbstractServiceConfigurator(Rbsfm.Common.Service.IDataService service = {Rbsfm.Common.Service.CPService}) Line 28 + 0xb bytes	C#
AQ Admin.exe!Rbsfm.Capmarkets.AutoQuoterAdmin.Startup.CPServiceConfigurator.CPServiceConfigurator(Rbsfm.Common.Service.CPService pricingService = {Rbsfm.Common.Service.CPService}) Line 175 + 0x9 bytes	C#
AQ Admin.exe!Rbsfm.Capmarkets.AutoQuoterAdmin.Startup.GetAqAdminService() Line 162 + 0x15 bytes	C#
AQ Admin.exe!Rbsfm.Capmarkets.AutoQuoterAdmin.Startup.Main(string[] args = {Dimensions:[10]}) Line 122 + 0x5 bytes	C#



# The FieldDefSetCache loads its configuration from the path 

..\\..\\config\\fieldmaps


# The place the field defs are loaded from is 

C:\work\development\aqadmin\aqadmin\aqadmin\src\Messaging\Data\FieldDefSetCache.cs
