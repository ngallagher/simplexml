# Here is how the changes to the baSprd affect the bid and ask prices

BAPriceYieldCalculator.getPriceSpread() { <<<<---------------------------- THIS IS USED IN THE CALC METHOD OF THE BAPriceYieldCalculator
  InternalBondNode owner = (InternalBondNode) getOwner();
  BidAskSpreadCalculator calc = (BidAskSpreadCalculator) owner.getBidAskSpreadCalculator();
  if (calc != null) {
    return calc.getBidAskSpread() / 2;
  } else {
    return 0.0;
  }
}


# The calculator that controls the bid ask spreading is

com.rbsfm.fi.pricing.dependency.bond.BidAskSpreadCalculator -> "baSprd"

# Euro Supra renames the baSprd to the following

<field name="baSprd" displayName="B/A Yld Sprd" dataType="System.Double" editType="edit" slave="True" multiplier="10000" format="0;-0;0" width="55" bold="false"/

# The dPrice and the baSprd are 100 times greater than bid/ask/mid

<field name="baSprd" displayName="B/A Sprd" dataType="System.Double" editType="edit" slave="True" multiplier="10000" format="0.00;-0.00;0.00" width="55" checkEditable="Rbsfm.Capmarkets.EuroPricingClient.nodeDetails.AlwaysCheckEditableFilter"/>    

<field name="askPrc" displayName="APrice" longName="Ask Price" dataType="System.Double" editType="edit" slave="True" multiplier="100" width="55" format="0.0000" backColour="#FFD0FF" foreColour="#FF0000" fontFormat="Bold" contextField="ticker" />

<field name="dPrc" displayName="dPrice" longName="Change in Price from previous days close" dataType="System.Double" format="+0.0;-0.0" multiplier="10000" width="50" editType="none"/>


# Change made to the swap spread calculator

  exec @error = appSwapSpreadCalcStore 
  							@NodeSetRef   = @Isin,
                       		@CurveNodeRef = @AssociatedCurve,
                          	@TemplateRef  = @TemplateId,
                          	@Spread       = 0,
                            @Version      = 1,
                           	@ServerName   = 'script',
                           	@UpdaterRef   = @UserName

  if (@error != 0)
  begin
     while @@trancount != 0 rollback
     raiserror 999999 'appCreateCEEMEACalcs:Error appSwapSpreadCalcStore'
     return -1
  end 

# Change to the manual bond price calculator

  exec @error=  appManualBondPriceCalculator 
  					@BondNodeRef = @Isin,
  					@PriceOrYield = 1, 
  					@IsPrice = 'Y',
    				@Version = 0, 
   					@ServerName = 'script', 
   					@UpdaterRef = @UserName
    
  if (@error != 0)
     begin
       while @@trancount != 0 rollback
       raiserror 999999 'appCreateCEEMEACalcs:Error appManualBondPriceCalculator'
      return -1
  end 

# Change to the yield spread calculator 

  exec @error = appYieldSpreadCalculator 
  						   @BondNodeRef  = @Isin,
                           @BenchmarkRef = '', -- allow the user to select it
                           @Spread       = 0.0,                                               
                           @Version      = 1,
                           @ServerName   = 'script',
                           @UpdaterRef   = @UserName
  
  if (@error != 0)
  begin
     while @@trancount != 0 rollback
     raiserror 999999 'appCreateCEEMEACalcs:Error appYieldSpreadCalculator'
     return -1
  end    

# Change to the asset swap spread calculator

  exec @error = appAssetSwapSpreadCalculator 
  								@BondNodeRef = @Isin, 
  								@CurveRef    = @Curve ,  
  								@Spread      = 0.0000, 
  								@Version     = 0, 
  								@ServerName  = "script", 
  								@UpdaterRef  = @UserName
  
  if (@error != 0)
  begin
    while @@trancount != 0 rollback
    raiserror 999999 "appCreateCEEMEACalcs:Error appAssetSwapSpreadCalculator"
    return -1
  end

# Comparison of the calculators that are used

com.rbsfm.fi.pricing.dependency.bond.BidAskAssetSwapSpreadCalculator -> com.rbsfm.fi.pricing.dependency.bond.AssetSwapSpreadCalculator
com.rbsfm.fi.pricing.dependency.bond.BidAskYieldSpreadCalculator -> com.rbsfm.fi.pricing.dependency.bond.YieldSpreadCalculator
com.rbsfm.fi.pricing.dependency.bond.BidAskManualBondPriceCalculator -> com.rbsfm.fi.pricing.dependency.bond.ManualBondPriceCalculator
com.rbsfm.fi.pricing.dependency.bond.BidAskSwapSpreadCalculator -> com.rbsfm.fi.pricing.dependency.bond.SwapSpreadCalculator 

# The following calculators are used for CEEMEA PL0000101937

com.rbsfm.fi.pricing.dependency.util.GenericTimeStampAdjustmentCalculator
com.rbsfm.fi.pricing.dependency.util.GenericTimeStampAdjustmentCalculator
com.rbsfm.fi.pricing.dependency.bond.BidAskSpreadCalculator
com.rbsfm.fi.pricing.dependency.bond.RatesBondCloseCalculator
com.rbsfm.fi.pricing.dependency.bond.BondStaticCalculator
com.rbsfm.fi.pricing.dependency.bond.BondUserDataCalculator
com.rbsfm.fi.pricing.dependency.bond.CDSBasisCalculator
com.rbsfm.fi.pricing.dependency.bond.IsInRunCalculator
com.rbsfm.fi.pricing.dependency.bond.RatingsDataCalculator
com.rbsfm.fi.pricing.dependency.bond.RunsCalculator
com.rbsfm.fi.pricing.dependency.bond.WhatIfAxeCalculator
com.rbsfm.fi.pricing.dependency.bond.WhatIfBidAskYieldSpreadCalculator
com.rbsfm.fi.pricing.dependency.bond.WhatIfPriceYieldCalculator
com.rbsfm.fi.pricing.dependency.bond.BidAskYieldSpreadCalculator
com.rbsfm.fi.pricing.dependency.bond.BidAskAssetSwapSpreadCalculator
com.rbsfm.fi.pricing.dependency.bond.BidAskBestPriceMuxRealtimeCalculator
com.rbsfm.fi.pricing.dependency.bond.ForwardPriceCalculator
com.rbsfm.fi.pricing.dependency.bond.BidAskManualBondPriceCalculator
com.rbsfm.fi.pricing.dependency.bond.PriceYieldCalculator
com.rbsfm.fi.pricing.dependency.bond.BidAskSwapSpreadCalculator

# The following calculators are used for EUROSUPRA PTBCVU1E0003

com.rbsfm.fi.pricing.dependency.util.GenericTimeStampAdjustmentCalculator
com.rbsfm.fi.pricing.dependency.bond.BidAskSpreadCalculator
com.rbsfm.fi.pricing.dependency.bond.RatesBondCloseCalculator
com.rbsfm.fi.pricing.dependency.bond.BondStaticCalculator
com.rbsfm.fi.pricing.dependency.bond.BondUserDataCalculator
com.rbsfm.fi.pricing.dependency.bond.BondVsFutsCalculator
com.rbsfm.fi.pricing.dependency.bond.BondVsEONIACurveCalculator
com.rbsfm.fi.pricing.dependency.bond.IsInRunCalculator
com.rbsfm.fi.pricing.dependency.bond.WhatIfBidAskYieldSpreadCalculator
com.rbsfm.fi.pricing.dependency.bond.WhatIfPriceYieldCalculator
com.rbsfm.fi.pricing.dependency.bond.YieldSpreadCalculator
com.rbsfm.fi.pricing.dependency.bond.ZSpreadCalculator
com.rbsfm.fi.pricing.dependency.bond.AssetSwapSpreadCalculator
com.rbsfm.fi.pricing.dependency.bond.MoneyMarketEquivalentYieldCalculator
com.rbsfm.fi.pricing.dependency.bond.ForwardPriceCalculator
com.rbsfm.fi.pricing.dependency.bond.ManualBondPriceCalculator
com.rbsfm.fi.pricing.dependency.bond.MidToBidAskAxeCalculator
com.rbsfm.fi.pricing.dependency.bond.BAPriceYieldCalculator
com.rbsfm.fi.pricing.dependency.bond.SimpleSwapSpreadCalculator
com.rbsfm.fi.pricing.dependency.bond.SwapSpreadCalculator

