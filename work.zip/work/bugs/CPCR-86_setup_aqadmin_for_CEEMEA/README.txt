# Selection list to use is

select * from EcnAqSelectionList where ListName = 'creditSalesperson'

# The following property defines the categorise deal implementation

categorise.deal..ceemea.autoquoter=EurogovDealCategoriser

# Here is the stack to categorise the deal

LMCategoriseDeal.getDealCategory(AqGetSetableMessage) line: 63	
ConversationRequestHandler.createConversation(AqGetSetableMessage) line: 436	
ConversationRequestHandler.processIncoming(AqGetSetableMessage) line: 173	
ConversationRequestHandler.handleConversationMessage(AqGetSetableMessage) line: 157	
ConversationRequestDispatcher$1.dispatch() line: 240	
ConversationRequestDispatcher$ConversationRequests.run() line: 83	

# Add CEEMEA sales people

exec EcnAqSelectionListStore 'ceemeaSalesperson','Advani, Indy','advanii','',0,'script','script'
exec EcnAqSelectionListStore 'ceemeaSalesperson','Ahn, Jun','ahnj','',0,'script','script'
exec EcnAqSelectionListStore 'ceemeaSalesperson','Alvarez-Carlon, Igancio','alvaria','',0,'script','script'

# The following additions are required for AQDetermineCustomerStatus

      <currencyStatus statusKey="aqStatus-PLN" currency="PLN"/>
      <currencyStatus statusKey="aqStatus-HUF" currency="HUF"/>
      <currencyStatus statusKey="aqStatus-CZK" currency="CZK"/>
      <currencyStatus statusKey="aqStatus-TRY" currency="TRY"/>
      <currencyStatus statusKey="aqStatus-ILS" currency="ILS"/>
      <currencyStatus statusKey="aqStatus-ZAR" currency="ZAR"/>
      <currencyStatus statusKey="aqStatus-RUB" currency="RUB"/>  
      <currencyStatus statusKey="aqStatus-ROM" currency="ROM"/>  

# Search a desks attributes for a given counterparty

SELECT 
    Ctrl.CounterpartyRef, 
    Ctrl.DeskId, 
    Ctrl.AttributeName, 
    Ctrl.AttributeValue, 
    Ctrl.Version, 
    Ctrl.CreatorRef, 
    Ctrl.CreationDatetime, 
    Ctrl.UpdaterRef, 
    Ctrl.UpdateDatetime 
FROM 
    EcnCounterpartyCtrlView Ctrl  
WHERE 
    Ctrl.DeskId = "ceemea"
ORDER BY
    Ctrl.AttributeName 

# How to get the counterparty details

CounterpartyServices2Impl.internalGetCounterpartyDetails(broker="BET", marketId="ROYAL BANK OF SCOTLAND PLC, THE", deskOrProductGroup="ceemea", mail="true") line: 317	
CounterpartyServices2Impl.getCounterpartyDetails(String, String, AttributeMap) line: 288	
BondConversationFactory(AbstractConversationFactory).setCounterpartyData(BaseInquiryDetailsMessage, IInternalConversation) line: 958	

# The aqStatus is determined from

CounterpartyDetails.getCustomerStatus() line: 62	
AQDetermineCustomerStatus.performStep(IConversation) line: 39	
PriceOrderAction(AbstractBusinessAction).executeStepsThenBusinessLogic(IConversation) line: 105	
StartBusinessAction(AbstractBusinessAction).carryOutNextBusinessLogic(IConversation, IBusinessAction) line: 76	
StartBusinessAction.executeBusinessLogic(IConversation) line: 100	
ConversationRequestHandler.doAction(IInternalConversation) line: 418	

# The conversation deal category is

LMC{115}

# In order to determine if a customer is to be accepted via the aqStatus the following is used

com.rbsfm.fi.bet.autoquoter.business.step.AQDetermineCustomerStatus

# Tag for the aqadmin-aqadmin-master is 

aqadmin-1_3_0

# Change is required for the aqStatus attributes

963.latam.aqStatus, value = ON -> example of CounterpartyControlAttribute

# Create a select to get a counterparty attributes for each desk

SELECT 
    Ctrl.CounterpartyRef, 
    Ctrl.DeskId, 
    Ctrl.AttributeName, 
    Ctrl.AttributeValue, 
    Ctrl.Version, 
    Ctrl.CreatorRef, 
    Ctrl.CreationDatetime, 
    Ctrl.UpdaterRef, 
    Ctrl.UpdateDatetime 
FROM 
    EcnCounterpartyCtrlView Ctrl  
WHERE 
    Ctrl.CounterpartyRef = "63" 
ORDER BY 
    DeskId ASC

# The following stack trace is called by the AqAdmin client on the aqadmin-aqadmin-master

AQAdminPersisterImpl.loadCounterparty(String, boolean, String) line: 994	
AQAdminPersisterImpl.publishCompleteCounterparty(String, String) line: 545	
AQAdminAsyncMessageHandler.onMessage(Message) line: 130	
AQAsyncRequestProcessor$1.run() line: 141	

# The name of the Java process is 

aqadmin-aqadmin-master, this is where the Aq Client feeds its information from


# In order to add tiering information AqAdmin needs to persist data also you need to

1) Add sales person information to the CEEMEA tab
2) Input tiering information where requried
3) Save the tab
4) Detauls should appear in EcnCounterpartyTierView

# Check to see if CEEMEA has any entries in the EcnCounterpartyTierView table

select * from EcnCounterpartyTierView where DeskId = 'ceemea'

# Typical query to extract the tier

SELECT 
    ECT.CounterpartyRef , ECT.DeskId , ECT.BookId , ECT.TierLevel  
FROM 
    EcnCounterpartyTierView ECT  
WHERE 
    ECT.CounterpartyRef = 
    (SELECT 
        distinct CounterpartyRef 
     FROM 
        EcnCounterpartyCtrlView ECC 
     WHERE 
        ECC.AttributeName = 'BloombergId' 
     AND 
        ECC.AttributeValue = 'APO ASSET MANAGEMENT GMBH' 
     AND 
        ECC.DeskId='null') 
AND 
    ECT.DeskId = 'ceemea' 
AND 
    ECT.BookId = 'CEEMEA-PLN'


# To clear down the books the following can be used

delete from EcnBookDefnRule
delete from EcnBookDefnRuleAudit
delete from EcnAutoQuoteBookCtrl
delete from EcnAutoQuoteBookCtrlAudit

# Examples of a counterparty reference selection follow

select distinct CounterpartyRef from EcnCounterpartyCtrlView where AttributeName = 'BloombergId' and AttributeValue = 'APO ASSET MANAGEMENT GMBH'
select distinct CounterpartyRef from EcnCounterpartyCtrlView where AttributeName = 'BloombergId' and AttributeValue = 'RBS SECURITIES JAPAN LTD'
select distinct CounterpartyRef from EcnCounterpartyCtrlView where AttributeName = 'BloombergId' and AttributeValue = 'RBS FM CPM'

# Select from the default book rather than a ceemea specific one

SELECT 
    ECT.CounterpartyRef , 
    ECT.DeskId , 
    ECT.BookId , 
    ECT.TierLevel  
FROM 
    EcnCounterpartyTierView ECT  
WHERE 
    ECT.CounterpartyRef = (SELECT
                                distinct CounterpartyRef 
                           FROM
                                EcnCounterpartyCtrlView ECC 
                           WHERE 
                                ECC.AttributeName = 'BloombergId' 
                           AND 
                                ECC.AttributeValue = 'RBS FM CPM' 
                           AND 
                                ECC.DeskId='null') 
AND 
    ECT.DeskId = 'ceemea' 
AND 
    ECT.BookId = 'default'


# This is the query to get the counterparty as taken from the AQAdminDb database, THIS WILL ALWAYS FAIL

SELECT 
    ECT.CounterpartyRef , 
    ECT.DeskId , 
    ECT.BookId , 
    ECT.TierLevel  
FROM 
    EcnCounterpartyTierView ECT  
WHERE 
    ECT.CounterpartyRef = (SELECT 
                                distinct CounterpartyRef 
                           FROM
                                EcnCounterpartyCtrlView ECC 
                           WHERE 
                                ECC.AttributeName = 'BloombergId' 
                           AND 
                                ECC.AttributeValue = 'RBS FM CPM' 
                           AND 
                                ECC.DeskId='null') 
AND 
    ECT.DeskId = 'ceemea' 
AND 
    ECT.BookId = 'CEEMEA-PLN'


# Here are the brokers used by the CounterpartyServices2Impl

BV=BondVisionId
INT=BloombergId
BLOOMBERG=BloombergId
TW2=TradewebId
BET=BloombergId
TW3=TradewebId
BET2=GdsId
BVC=BondVisionId
MA=MarketAxessId
TW=TradewebId

# The following needs to be added to Counterparty.xml 

        <field name="ceemea.virtualTier" displayName="CEEMEA" longName="Local Market - CEEMEA" dataType="System.String" editType="none" align="left" width="40" />
        <field name="ceemea.Enabled" displayName="CEEMEA Enabled" longName="CEEMEA Enabled" dataType="System.Boolean" editType="none" align="left" width="40" />
        <field name="ceemea.salesperson" displayName="Salesperson" longName="CEEMEA Salesperson SSO" dataType="System.String" editType="none" align="left" width="150" selectionType="ceemeaSalesperson" />
        <field name="ceemea.salespersonCode" displayName="Salesperson Code" longName="CEEMEA Salesperson Code" dataType="System.String" editType="none" align="left" width="150" selectionType="ceemeaSalespersonCode" />
        <field name="ceemea.OrderMode" displayName="Order Mode" longName="CEEMEA Order Mode" dataType="System.Int32" editType="none" align="left" selectionType="orderMode" />
        <field name="ceemea.aqStatus" displayName="AQ Status Default" longName="AQ Status" dataType="System.String" editType="none" align="left" width="50" selectionType="aqStatus" defaultValue="ON"/>        
        <field name="ceemea.aqStatus.PLN" displayName="AQ Status PLN" longName="AQ Status PLN" dataType="System.String" editType="none" align="left" width="50" selectionType="aqStatus" defaultValue="ON"/>
        <field name="ceemea.aqStatus.HUF" displayName="AQ Status HUF" longName="AQ Status HUF" dataType="System.String" editType="none" align="left" width="50" selectionType="aqStatus" defaultValue="ON"/>
        <field name="ceemea.aqStatus.CZK" displayName="AQ Status CZK" longName="AQ Status CZK" dataType="System.String" editType="none" align="left" width="50" selectionType="aqStatus" defaultValue="ON"/>
        <field name="ceemea.aqStatus.TRY" displayName="AQ Status TRY" longName="AQ Status TRY" dataType="System.String" editType="none" align="left" width="50" selectionType="aqStatus" defaultValue="ON"/>
        <field name="ceemea.aqStatus.ILS" displayName="AQ Status ILS" longName="AQ Status ILS" dataType="System.String" editType="none" align="left" width="50" selectionType="aqStatus" defaultValue="ON"/>
        <field name="ceemea.aqStatus.ZAR" displayName="AQ Status ZAR" longName="AQ Status ZAR" dataType="System.String" editType="none" align="left" width="50" selectionType="aqStatus" defaultValue="ON"/>
        <field name="ceemea.aqStatus.RUB" displayName="AQ Status RUB" longName="AQ Status RUB" dataType="System.String" editType="none" align="left" width="50" selectionType="aqStatus" defaultValue="ON"/>       
        <field name="ceemea.CEEMEA-PLN.Tier" displayName="CEEMEA-PLN" longName="CEEMEA PLN Tier" dataType="System.Double" editType="none" align="right" width="40" format="0" />
        <field name="ceemea.CEEMEA-HUF.Tier" displayName="CEEMEA-HUF" longName="CEEMEA HUF Tier" dataType="System.Double" editType="none" align="right" width="40" format="0" />
        <field name="ceemea.CEEMEA-CZK.Tier" displayName="CEEMEA-CZK" longName="CEEMEA CZK Tier" dataType="System.Double" editType="none" align="right" width="40" format="0" />
        <field name="ceemea.CEEMEA-TRY.Tier" displayName="CEEMEA-TRY" longName="CEEMEA TRY Tier" dataType="System.Double" editType="none" align="right" width="40" format="0" />
        <field name="ceemea.CEEMEA-ILS.Tier" displayName="CEEMEA-ILS" longName="CEEMEA ILS Tier" dataType="System.Double" editType="none" align="right" width="40" format="0" />
        <field name="ceemea.CEEMEA-ZAR.Tier" displayName="CEEMEA-ZAR" longName="CEEMEA ZAR Tier" dataType="System.Double" editType="none" align="right" width="40" format="0" />
        <field name="ceemea.CEEMEA-RUB.Tier" displayName="CEEMEA-RUB" longName="CEEMEA RUB Tier" dataType="System.Double" editType="none" align="right" width="40" format="0" /> 
        <field name="ceemea.enableSalespersonTierOverride" displayName="Salesperson Tier Override" longName="Enable Salesperson Tier Override" dataType="System.Boolean" editType="none" align="left" width="150" />
        <field name="ceemea.LastUpdateLogin" displayName="Last Update Login" longName="Last Update Login" dataType="System.String" editType="none" align="right" width="150" format="#" />
        <field name="ceemea.LastUpdateDate" displayName="Last Update Date" longName="Last Update Date" dataType="System.DateTime" editType="none" align="right" width="150" format="ddMMMyy HH:mm" />
        <field name="ceemea.bookOverride.Enabled" displayName="Salesperson-Book Override" longName="Salesperson-Book Override" dataType="System.Boolean" editType="none" align="left" width="40" />
        <field name="ceemea.traderOverride.Enabled" displayName="Salesperson-Trader Override" longName="Salesperson-Trader Override" dataType="System.Boolean" editType="none" align="left" width="40" />
        <field name="ceemea.pendIssueCountry" displayName="Pend Issue Country" longName="Pend-Issue-country" dataType="System.String" editType="none" align="right" width="80" selectionType="pendIssueCountry"/>
        <field name="ceemea.default.Tier" displayName="Default Tier" longName="Default Tier" dataType="System.Double" editType="none" align="right" width="40" format="0" defaultValue="2"/>

# The following needs to be added to aqadmin/aqadmin/App.config, this adds a tier per currency \\fm.rbsgrp.net\APPROOT\CentralisedPricing\UAT\aqadmin\aqadmin-2_025\bin\release

    	<desk name="ceemea" displayName="CEEMEA">
            <field name="ceemea.aqStatus" />
            <field name="ceemea.aqStatus.PLN" />
            <field name="ceemea.aqStatus.HUF" />
            <field name="ceemea.aqStatus.CZK" />
            <field name="ceemea.aqStatus.TRY" />
            <field name="ceemea.aqStatus.ILS" />
            <field name="ceemea.aqStatus.ZAR" />
            <field name="ceemea.aqStatus.RUB" />                  
            <field name="ceemea.CEEMEA-PLN.Tier"/>
            <field name="ceemea.CEEMEA-HUF.Tier" />
            <field name="ceemea.CEEMEA-CZK.Tier" />
            <field name="ceemea.CEEMEA-TRY.Tier" />
            <field name="ceemea.CEEMEA-ILS.Tier" />
            <field name="ceemea.CEEMEA-ZAR.Tier" />
            <field name="ceemea.CEEMEA-RUB.Tier" /> 
			<field name="ceemea.OrderMode" />
			<field name="ceemea.salesperson" />
			<field name="ceemea.salespersonCode" />
			<field name="ceemea.default.Tier" />
		</desk>

# Here is where we map the books to the AqAdmin tiers

1> select * from EcnBookDefnRule
