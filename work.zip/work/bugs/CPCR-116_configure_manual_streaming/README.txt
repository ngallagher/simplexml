# To get the position book in to the ExternalPriceDetails the book needs to be added to

BBPositionSubscriber ->> PositionMessage

# The following of these needs to be added for the PNL server

exec BookStore
@Domain      = 'BLOOMBERG',
@BookId      = 'enter in here', -- eg SOV-MURP
@BaseCcy     = 'JPY/GBP/USD/EUR', --one of these
@Version      =   1, --always
@ServerName   =   'script', --always
@UpdaterRef   =   'script', --always
@Location='TKY/LDNx' --One of these. Replace _x_ with a digit based on your selection from the Server-to-Book page.

# The following entries can be queried like so

select * from Book where BookId like '%EMRG%'

# The location for EuroGov is 

select Location from Book where BookId = 'SOV-MURP' <<--->> LDN4

# The connection details for the rates-pnlcalculator-master is as follows

fi_RATES_uat

# The JMX methods to use are the 

addBook
setBookSynchronized

# The following needs to be used in the rates-tradestatic-master via JMX on BookAdminView 

"EMRG-PLN", "GBLO", "Bloomberg"
"EMRG-HUF", "GBLO", "Bloomberg"
"EMRG-CE4", "GBLO", "Bloomberg"
"EMRG-ZAR", "GBLO", "Bloomberg"
"EMRG-TRY", "GBLO", "Bloomberg"
"EMRG-TRS", "GBLO", "Bloomberg"
"EMRG-ILS", "GBLO", "Bloomberg"
"EMRG-RUB", "GBLO", "Bloomberg"

# Ths is how to set up a new book

http://twiki.fm.rbsgrp.net/twiki/bin/view/CP/IntegratedRatesNewBook

# The component feeding positions in rates-pnlcalculator-master

PositionSink

# Attributes from the PNL position for pnlposition::PL0000104287@SOV-MURP:20100422:

nodeId=PL0000104287 
logical_date=2010-04-22 
error= Status: {10,Status not Populated} 
bookSecurityId=10615 
Curr=PLN 
sys.ccy=GBP 
isSynth=false 
book=SOV-MURP 
PosDate=2010-04-22 
contSz=1.0 
book.ccy=EUR 
data_is_live=true 
InstrumentType=Bond 
data_source_is_server=true 
PosBookId=SOV-MURP 
prcMthds= 

PosTraded= <<------------------------ MISSING POSITION VALUE

# Addition of MPF logging to an mpfgateway2, add the following XML to both create the log and enable it

 <log name="MPF-PACKET-14" active="true"/>


# The details of MPF logging is found in 

com.rbsfm.commonx.bloomberg.mpf.line.BBLineHandler

# To turn on packet 14 logging look at

MPF-PACKET-14

# The EuroGov PNLServer in UAT is

rates-pnlcalculator-master

# Basically no positions can be acquired for the following

PositionMessageCacheSourceSink.getPositionFromBook(String, String) line: 171	
PositionMessageCacheSourceSink.getPositionFromOwner(String, String) line: 138	
PositionCachePositionDecorator.getPosition(ConversationLeg) line: 37	
AQPositionDecorateStep.performStepForLeg(AQActionStep$StepResult, IConversation, ConversationLeg, boolean) line: 36	
AQPositionDecorateStep(AQAbstractMultiLegStep).performStep(IConversation) line: 48	
PriceTickAction(AbstractBusinessAction).executeStepsThenBusinessLogic(IConversation) line: 105	

# The following id is created from the PositionMessageCacheSourceSink

:PL0000105953@SOV-MURP:20100421:

# The default mapping is taken from 

select * from BookMapping where EcnUserId = 'default' and ProductGroup = 'default' and ProductId = 'default' <<-- SOV-MURP

# Perform the following SQL to grab the book

select * from BookMapping where ProductId = 'PL0000105953'

# Perform the trades on 

PL0000105953

# The risk book is found in the following place

com.rbsfm.ficommon.staticdata.RiskBookDetailsHomeImpl

# Add this for good measure, every other desk has it

position.decorator.usecoveringtrader..ceemea.autoquoter=true

# In order to add the missing attributes a position decorator is required

position.decorator.class.name..ceemea.autoquoter=com.rbsfm.fi.bet.autoquoter.position.PositionCachePositionDecorator

# The following attributes are required but are MISSING

Leg1.traderPosition - 0
Leg1.traderRiskBook - UNKNOWN
Leg1.aggPosition - (empty)
Leg1.aggPositionDesc - (empty)

# The traderRiskBook is used in the following step

com.rbsfm.fi.bet.autoquoter.business.step.AQPositionDecorateStep

# The actual streaming definitions we want are at

\\fm.rbsgrp.net\APPROOT\CentralisedPricing\DEV\aqclient\aqclient.122009.16.0\bin\release\config\clients\v2\Popups.config

# Basically we should copy EUROGOV.config and four lines with, no need for CEEMEA.user.config or CEEMEA.fields.config

    <add key="Security.SSO.ReadToken" value="FIPricing-CEEMEA-All-Read"/>
    <add key="Security.SSO.WriteToken" value="FIPricing-CEEMEA-All-Update"/>
    <add key="Config.Fields" value="config\clients\EUROGOV.fields.config" /> <<<----- USE EXISTING EUROGOV FILES
    <add key="Config.DefaultSettings" value="config\clients\EUROGOV.user.config" /> <<<----- USE EXISTING EUROGOV FILES

# For bond PL0000105953 ticker POLGB 04/25/15 you get this

     <field name="dealCategory" value="EGC" />
     <field name="dealCategoryVersion" value="2" />

# The property that should be set to use the _2 values are

deal.catergory.version..ceemea.autoquoter=2

# This is the conversation factory currently used by CEEMEA

  <component lazy="true" name="OutrightBondFactory" class_name="com.rbsfm.fi.bet.autoquoter.business.conversation.BaseBondConversationFactory">
      <ecnInstrumentStatusHome>EcnInstrumentStatusHome</ecnInstrumentStatusHome>
      <bookManager>BookManager</bookManager>
      <riskBookManager>RiskBookDetailsHome</riskBookManager>
      <conversationSnapshot>AqConversationManager</conversationSnapshot>
      <autoQuoterServices>AutoQuoterServices</autoQuoterServices>
      <counterpartyServices>CounterpartyServices2</counterpartyServices>
      <priceYieldConverter>PriceYieldConverter</priceYieldConverter>
      <yieldSpreadCalculator>YieldSpreadCalculator</yieldSpreadCalculator>
      <autoQuoterProcessorOut>AutoQuoterProcessorOut</autoQuoterProcessorOut>
      <orderTimer>30</orderTimer>
      <inquiryTimer>30</inquiryTimer>
      <brokerResendContinuous brokerId="TW" />
      <sendExecutingTraderBook>true</sendExecutingTraderBook>
      <displayNameHelper enabled="${conversation.factory.displaynamehelper.enabled}">DisplayNameHelper</displayNameHelper>
      <priceTickMonitor>RealtimeConversationPriceMonitor</priceTickMonitor>
      <dealCategoryVersion>${deal.catergory.version}</dealCategoryVersion>
      <brokerRejectIsSevere>${broker.reject.is.severe}</brokerRejectIsSevere>
    </component>

# Here is the code that could be creating the token

//Handle versioned template names (dealCategory + "_" + dealCategoryVersion)
if (!string.IsNullOrEmpty(templateVersion))
   template = (PopupTemplate)popupTemplates[templateName + "_" + templateVersion];


# The following contains the code to match the deal version

Rbsfm.FI.AQUI/Config/PopupPanelManager.cs

# The following attributes select the ticket layout

      <field name="dealCategory" value="EBC" />
      <field name="dealCategoryVersion" value="2" />
