"EMRG-PLN", "GBLO", "Bloomberg"
"EMRG-HUF", "GBLO", "Bloomberg"
"EMRG-CE4", "GBLO", "Bloomberg"
"EMRG-ZAR", "GBLO", "Bloomberg"
"EMRG-TRY", "GBLO", "Bloomberg"
"EMRG-TRS", "GBLO", "Bloomberg"
"EMRG-ILS", "GBLO", "Bloomberg"
"EMRG-RUB", "GBLO", "Bloomberg"

exec BookStore
@Domain        = 'BLOOMBERG',
@BookId        = 'EMRG-PLN', 
@BaseCcy       = 'GBP',
@Version       = 1, 
@ServerName    = 'script', 
@UpdaterRef    = 'script', 
@Location      = 'LDN2'

exec BookStore
@Domain        = 'BLOOMBERG',
@BookId        = 'EMRG-HUF', 
@BaseCcy       = 'GBP',
@Version       = 1, 
@ServerName    = 'script', 
@UpdaterRef    = 'script', 
@Location      = 'LDN2'

exec BookStore
@Domain        = 'BLOOMBERG',
@BookId        = 'EMRG-CE4', 
@BaseCcy       = 'GBP',
@Version       = 1, 
@ServerName    = 'script', 
@UpdaterRef    = 'script', 
@Location      = 'LDN2'

exec BookStore
@Domain        = 'BLOOMBERG',
@BookId        = 'EMRG-ZAR', 
@BaseCcy       = 'GBP',
@Version       = 1, 
@ServerName    = 'script', 
@UpdaterRef    = 'script', 
@Location      = 'LDN2'

exec BookStore
@Domain        = 'BLOOMBERG',
@BookId        = 'EMRG-TRY', 
@BaseCcy       = 'GBP',
@Version       = 1, 
@ServerName    = 'script', 
@UpdaterRef    = 'script', 
@Location      = 'LDN2'

exec BookStore
@Domain        = 'BLOOMBERG',
@BookId        = 'EMRG-TRS', 
@BaseCcy       = 'GBP',
@Version       = 1, 
@ServerName    = 'script', 
@UpdaterRef    = 'script', 
@Location      = 'LDN2'

exec BookStore
@Domain        = 'BLOOMBERG',
@BookId        = 'EMRG-ILS', 
@BaseCcy       = 'GBP',
@Version       = 1, 
@ServerName    = 'script', 
@UpdaterRef    = 'script', 
@Location      = 'LDN2'

exec BookStore
@Domain        = 'BLOOMBERG',
@BookId        = 'EMRG-RUB', 
@BaseCcy       = 'GBP',
@Version       = 1, 
@ServerName    = 'script', 
@UpdaterRef    = 'script', 
@Location      = 'LDN2'
