EXEC EcnQuoteTimerStore        
@BrokerRef="MTS",
@InstrumentRef="PL0000106100",
@TimerName="obligation1",
@CounterDirection="Asc",
@MaxSpread=0.004000,
@MinSize=5000000,
@ObligationTime=6,
@StartTime="15:29:00",
@EndTime="15:36:00",
@QuoteTime=0,
@LastRunning="15:33:00",
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql" 
GO

EXEC EcnQuoteTimerStore        
@BrokerRef="MTS",
@InstrumentRef="PL0000106100",
@TimerName="quoteTimer",
@CounterDirection="Asc",
@MaxSpread=NULL,
@MinSize=NULL,
@ObligationTime=NULL,
@StartTime=NULL,
@EndTime=NULL,
@QuoteTime=0,
@LastRunning="08:21:00",
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql" 
GO

EXEC EcnQuoteNewStore
@BrokerRef="MTS", 
@InstrumentRef="PL0000106100", 
@BucketRef="B0", 
@BuySell="B", 
@ChainId="Link1", 
@Size=5000000, 
@BlockSize=5000000, 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"     
GO

EXEC EcnQuoteNewStore    
@BrokerRef="MTS", 
@InstrumentRef="PL0000106100", 
@BucketRef="B0", 
@BuySell="S", 
@ChainId="Link1", 
@Size=5000000, 
@BlockSize=5000000, 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106100", 
@AttributeName="chkFastMkt",    
@AttributeValue="NO", 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106100", 
@AttributeName="chkFutFeed",    
@AttributeValue="NO", 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106100", 
@AttributeName="chkMkt",       
@AttributeValue="NO", 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106100", 
@AttributeName="chkMktYld",       
@AttributeValue="NO", 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106100", 
@AttributeName="chkSize",       
@AttributeValue="NO", 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106100", 
@AttributeName="mktPrcChkTol",       
@AttributeValue="0.0", 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106100", 
@AttributeName="mktPrcSprdTol",       
@AttributeValue="0.0", 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"
GO

EXEC EcnSpreadNewStore 
@BrokerRef="MTS", 
@InstrumentRef="PL0000106100", 
@BucketRef="B0", 
@Spread=0.0, 
@Skew=0.0, 
@Round=0.000100, 
@SpreadType="SP", 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"
GO
