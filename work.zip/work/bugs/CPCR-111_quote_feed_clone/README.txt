# Patch for production requires these changes

cpsql/sql/spapp/ceemea/appCloneQuoteFeedData.sql
cpsql/sql/spapp/ceemea/ceemea_grants.sql

# Script to clone quote feed data is

cpsql/sql/spapp/ceemea/appCloneQuoteFeedData.sql

# To add your trader user to DB Vault the following should be done

1) Go the the URL http://lon3617xns:9090/vaultmanager/
2) Select the domain CP
3) Select the role EDIT
4) Login with your Active Directory user name and password
5) Select the resources tab and add the resource name "gallane" and the resource type "TRADER"
6) Select the commit button to commit
7) Go to the credentials tab add the credentials where class is "MTS", type is "TRADER.ceemea", and resource is "gallane"
8) Finally select the systems tab, click on "ceemea" in the environments panel, then add the resource "gallane" to linke "CEEMEA" And "gallane"

# To delete an account the followign can be used

exec UserPlatformAccountDelete 'gallane', 'MTS', 'TRADER.ceemea', 'GALLANECP', 0, 'script', 'script' 

# To add a trader in CEEMEA the following should work

exec CPUserStore 'gallane', 'Niall Gallagher', 'niall.gallagher@rbs.com', 'not known', '', 0, 'script', 'script'
exec UserPlatformAccountStore 'gallane', 'MTS', 'TRADER.ceemea', 'GALLANECP', '', 1, 0, 'script', 'script' 

# The following SQL should be run in to add the quote feed data (non obligated)

EXEC EcnQuoteTimerStore        
@BrokerRef="MTS",
@InstrumentRef="PL0000106100",
@TimerName="obligation1",
@CounterDirection="Asc",
@MaxSpread=0.004000,
@MinSize=5000000,
@ObligationTime=0,
@StartTime="15:28:00",
@EndTime="15:37:00",
@QuoteTime=0,
@LastRunning=NULL,
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql" 
GO

EXEC EcnQuoteTimerStore        
@BrokerRef="MTS",
@InstrumentRef="PL0000106100",
@TimerName="quoteTimer",
@CounterDirection="Asc",
@MaxSpread=NULL,
@MinSize=NULL,
@ObligationTime=NULL,
@StartTime=NULL,
@EndTime=NULL,
@QuoteTime=0,
@LastRunning=NULL,
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql" 
GO

EXEC EcnQuoteNewStore
@BrokerRef="MTS", 
@InstrumentRef="PL0000106100", 
@BucketRef="B0", 
@BuySell="B", 
@ChainId="Link1", 
@Size=5000000, 
@BlockSize=5000000, 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"     
GO

EXEC EcnQuoteNewStore    
@BrokerRef="MTS", 
@InstrumentRef="PL0000106100", 
@BucketRef="B0", 
@BuySell="S", 
@ChainId="Link1", 
@Size=5000000, 
@BlockSize=5000000, 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106100", 
@AttributeName="chkFastMkt",    
@AttributeValue="NO", 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106100", 
@AttributeName="chkFutFeed",    
@AttributeValue="NO", 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106100", 
@AttributeName="chkMkt",       
@AttributeValue="NO", 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106100", 
@AttributeName="chkMktYld",       
@AttributeValue="NO", 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106100", 
@AttributeName="chkSize",       
@AttributeValue="NO", 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106100", 
@AttributeName="mktPrcChkTol",       
@AttributeValue="0.0", 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106100", 
@AttributeName="mktPrcSprdTol",       
@AttributeValue="0.0", 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"
GO

EXEC EcnSpreadNewStore 
@BrokerRef="MTS", 
@InstrumentRef="PL0000106100", 
@BucketRef="B0", 
@Spread=0.0, 
@Skew=0.0, 
@Round=0.000100, 
@SpreadType="SP", 
@Version=0, 
@ServerName="PL0000106100.sql", 
@UpdaterRef="PL0000106100.sql"
GO

# Bonds that have no obligation

PL0000106100
PL0000104857

# New EcnSanitizerInstCtrl defaults are

bnchMktPrcChkTol=0.0
buyMaxSettTol=7
buyMinSettTol=1
chkBnchMkt=NO
chkFastMkt=NO # OK
chkFutFeed=NO # OK
chkGFBond=OFF
chkHitCount=YES
chkIlliquidBond=OFF
chkMkt=NO # OK
chkMktSprd=NO
chkMktYld=NO # OK
chkMtsBond=OFF
chkPrcSprd=YES
chkPrcSprdTol=0
chkSettlementDate=YES
chkSize=NO # OK
clsYldChk=YES
clsYldChkTol=0.005
failNoBstPrc=NO
maPrcPub=ON
maxAsk=0
maxBid=0
maxDailyFwdMvt=0.01
maxHitCount=5
maxHitTimePeriod=10
minAsk=0
minBid=0
mktPrcChkTol=0.0 # OK
mktPrcSprdTol=0.0 # OK
mktYldChkTol=0.0 # OK
quoteStat=YES
sanitize=YES
sellMaxSettTol=7
sellMinSettTol=1

# The following new script needs to be modified on release

cpsql/sql/spapp/ceemea/appCreateFeedCtrls.sql
cpsql/sql/spapp/ceemea/appLoadCEEMEASanData.sql

# New defaults required for appCreateFeedCtrls

chkFutFeed=NO # DONE
chkFastMkt=NO # DONE
chkMkt=NO # DONE
mktPrcChkTol=0.0 # DONE
chkMktYld=NO # DONE
mktYldChkTol=0.0 # DONE
mktPrcSprdTol=0.0 # DONE
chkSize=NO # DONE

# What CEEMEA currently uses for sanitization

bnchMktPrcChkTol=0.0
buyMaxSettTol=7
buyMinSettTol=1
chkBnchMkt=NO
chkFastMkt=YES
chkGFBond=OFF
chkHitCount=YES
chkIlliquidBond=OFF
chkMkt=YES
chkMktSprd=NO
chkMtsBond=OFF
chkPrcSprd=YES
chkPrcSprdTol=0
chkSettlementDate=YES
chkSize=YES
clsYldChk=YES
clsYldChkTol=0.005
failNoBstPrc=NO
maPrcPub=ON
maxAsk=0
maxBid=0
maxDailyFwdMvt=0.01
maxHitCount=5
maxHitTimePeriod=10
minAsk=0
minBid=0
mktPrcChkTol=0.0001
mktPrcSprdTol=0.0050
quoteStat=YES
sanitize=YES
sellMaxSettTol=7
sellMinSettTol=1

# The quote feed requires

sanitize=YES # YES 
chkFutFeed=NO # MISSING !!
chkFastMkt=NO # YES
chkMkt=NO # YES
mktPrcChkTol=0.0 # 0.0001
failNoBstPrc=NO # NO 
chkMktYld=NO # MISSING !!
mktYldChkTol=0.0 # MISSING !!
chkMktSprd=NO # NO 
mktPrcSprdTol=0.0 # 0.0050 
chkSize=NO # YES 
minBid=0.0 # 0.0 
maxBid=0.0 # 0.0
minAsk=0.0 # 0.0
maxAsk=0.0 # 0.0

# Stop ceemea pricing

cpadmin start uat-ceemea-pricing-offshore
cpadmin start uat-ceemea-pricing-instmaint

# Execute the following to delete 

appEraseCEEMEABond "PL0000101937"
go
appEraseECNBond "PL0000101937"
go

# Stop ceemea pricing

cpadmin stop uat-ceemea-pricing-offshore
cpadmin stop uat-ceemea-pricing-instmaint

# The test bond to use is

PL0000101937

