EXEC EcnQuoteTimerStore        
@BrokerRef="MTS",
@InstrumentRef="PL0000106126",
@TimerName="obligation1",
@CounterDirection="Asc",
@MaxSpread=0.004000,
@MinSize=5000000,
@ObligationTime=0,
@StartTime="15:28:00",
@EndTime="15:37:00",
@QuoteTime=0,
@LastRunning=NULL,
@Version=0, 
@ServerName="PL0000106126.sql", 
@UpdaterRef="PL0000106126.sql" 
GO

EXEC EcnQuoteTimerStore        
@BrokerRef="MTS",
@InstrumentRef="PL0000106126",
@TimerName="quoteTimer",
@CounterDirection="Asc",
@MaxSpread=NULL,
@MinSize=NULL,
@ObligationTime=NULL,
@StartTime=NULL,
@EndTime=NULL,
@QuoteTime=0,
@LastRunning=NULL,
@Version=0, 
@ServerName="PL0000106126.sql", 
@UpdaterRef="PL0000106126.sql" 
GO

EXEC EcnQuoteNewStore
@BrokerRef="MTS", 
@InstrumentRef="PL0000106126", 
@BucketRef="B0", 
@BuySell="B", 
@ChainId="Link1", 
@Size=5000000, 
@BlockSize=5000000, 
@Version=0, 
@ServerName="PL0000106126.sql", 
@UpdaterRef="PL0000106126.sql"     
GO

EXEC EcnQuoteNewStore    
@BrokerRef="MTS", 
@InstrumentRef="PL0000106126", 
@BucketRef="B0", 
@BuySell="S", 
@ChainId="Link1", 
@Size=5000000, 
@BlockSize=5000000, 
@Version=0, 
@ServerName="PL0000106126.sql", 
@UpdaterRef="PL0000106126.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106126", 
@AttributeName="chkFastMkt",    
@AttributeValue="NO", 
@Version=0, 
@ServerName="PL0000106126.sql", 
@UpdaterRef="PL0000106126.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106126", 
@AttributeName="chkFutFeed",    
@AttributeValue="NO", 
@Version=0, 
@ServerName="PL0000106126.sql", 
@UpdaterRef="PL0000106126.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106126", 
@AttributeName="chkMkt",       
@AttributeValue="NO", 
@Version=0, 
@ServerName="PL0000106126.sql", 
@UpdaterRef="PL0000106126.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106126", 
@AttributeName="chkMktYld",       
@AttributeValue="NO", 
@Version=0, 
@ServerName="PL0000106126.sql", 
@UpdaterRef="PL0000106126.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106126", 
@AttributeName="chkSize",       
@AttributeValue="NO", 
@Version=0, 
@ServerName="PL0000106126.sql", 
@UpdaterRef="PL0000106126.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106126", 
@AttributeName="mktPrcChkTol",       
@AttributeValue="0.0", 
@Version=0, 
@ServerName="PL0000106126.sql", 
@UpdaterRef="PL0000106126.sql"
GO

EXEC EcnSanitizerInstCtrlStore  
@BrokerRef="AQ Orders", 
@InstrumentRef="PL0000106126", 
@AttributeName="mktPrcSprdTol",       
@AttributeValue="0.0", 
@Version=0, 
@ServerName="PL0000106126.sql", 
@UpdaterRef="PL0000106126.sql"
GO

EXEC EcnSpreadNewStore 
@BrokerRef="MTS", 
@InstrumentRef="PL0000106126", 
@BucketRef="B0", 
@Spread=0.0, 
@Skew=0.0, 
@Round=0.000100, 
@SpreadType="SP", 
@Version=0, 
@ServerName="PL0000106126.sql", 
@UpdaterRef="PL0000106126.sql"
GO
