exec appEcnCreateBond  @InstrumentRef="PL0000101937", @ProposalMarket="MTS", @ProposalSpread=0.004, @ProposalSize=5, @ProposalRound=0.0001, @ProposalSpreadType="SP"

exec EcnSanitizerInstCtrlStore  @BrokerRef="AQ Orders", @InstrumentRef="PL0000101937", @AttributeName="sanitize",      @AttributeValue="YES", @Version=0, @ServerName="script", @UpdaterRef="script"
exec EcnSanitizerInstCtrlStore  @BrokerRef="AQ Orders", @InstrumentRef="PL0000101937", @AttributeName="chkFutFeed",    @AttributeValue="NO", @Version=0, @ServerName="script", @UpdaterRef="script"
exec EcnSanitizerInstCtrlStore  @BrokerRef="AQ Orders", @InstrumentRef="PL0000101937", @AttributeName="chkFastMkt",    @AttributeValue="NO", @Version=0, @ServerName="script", @UpdaterRef="script"
exec EcnSanitizerInstCtrlStore  @BrokerRef="AQ Orders", @InstrumentRef="PL0000101937", @AttributeName="chkMkt",        @AttributeValue="NO", @Version=0, @ServerName="script", @UpdaterRef="script"
exec EcnSanitizerInstCtrlStore  @BrokerRef="AQ Orders", @InstrumentRef="PL0000101937", @AttributeName="mktPrcChkTol",  @AttributeValue="0.0", @Version=0, @ServerName="script", @UpdaterRef="script"
exec EcnSanitizerInstCtrlStore  @BrokerRef="AQ Orders", @InstrumentRef="PL0000101937", @AttributeName="failNoBstPrc",  @AttributeValue="NO", @Version=0, @ServerName="script", @UpdaterRef="script"
exec EcnSanitizerInstCtrlStore  @BrokerRef="AQ Orders", @InstrumentRef="PL0000101937", @AttributeName="chkMktYld",     @AttributeValue="NO"**, @Version=0, @ServerName="script", @UpdaterRef="script"
exec EcnSanitizerInstCtrlStore  @BrokerRef="AQ Orders", @InstrumentRef="PL0000101937", @AttributeName="mktYldChkTol",  @AttributeValue="0.0", @Version=0, @ServerName="script", @UpdaterRef="script"
exec EcnSanitizerInstCtrlStore  @BrokerRef="AQ Orders", @InstrumentRef="PL0000101937", @AttributeName="chkMktSprd",    @AttributeValue="NO"**, @Version=0, @ServerName="script", @UpdaterRef="script"
exec EcnSanitizerInstCtrlStore  @BrokerRef="AQ Orders", @InstrumentRef="PL0000101937", @AttributeName="mktPrcSprdTol", @AttributeValue="0.0", @Version=0, @ServerName="script", @UpdaterRef="script"
exec EcnSanitizerInstCtrlStore  @BrokerRef="AQ Orders", @InstrumentRef="PL0000101937", @AttributeName="chkSize",       @AttributeValue="NO"**, @Version=0, @ServerName="script", @UpdaterRef="script"
exec EcnSanitizerInstCtrlStore  @BrokerRef="AQ Orders", @InstrumentRef="PL0000101937", @AttributeName="minBid",        @AttributeValue="0.0", @Version=0, @ServerName="script", @UpdaterRef="script"
exec EcnSanitizerInstCtrlStore  @BrokerRef="AQ Orders", @InstrumentRef="PL0000101937", @AttributeName="maxBid",        @AttributeValue="0.0", @Version=0, @ServerName="script", @UpdaterRef="script"
exec EcnSanitizerInstCtrlStore  @BrokerRef="AQ Orders", @InstrumentRef="PL0000101937", @AttributeName="minAsk",        @AttributeValue="0.0", @Version=0, @ServerName="script", @UpdaterRef="script"
exec EcnSanitizerInstCtrlStore  @BrokerRef="AQ Orders", @InstrumentRef="PL0000101937", @AttributeName="maxAsk",        @AttributeValue="0.0", @Version=0, @ServerName="script", @UpdaterRef="script"

exec EcnQuoteNewStore    @BrokerRef="MTS", @InstrumentRef="PL0000101937", @BucketRef="B0", @BuySell="B", @ChainId="Link1", @Size=5000000, @BlockSize=5000000, @Version=0, @ServerName="script", @UpdaterRef="script"     
exec EcnQuoteNewStore    @BrokerRef="MTS", @InstrumentRef="PL0000101937", @BucketRef="B0", @BuySell="S", @ChainId="Link1", @Size=5000000, @BlockSize=5000000, @Version=0, @ServerName="script", @UpdaterRef="script"

exec EcnQuoteTimerStore  @BrokerRef="MTS", @InstrumentRef="PL0000101937", @TimerName="quoteTimer",  @CounterDirection="Asc", @MaxSpread=null,      @MinSize=null,    @ObligationTime=null, @StartTime=null,       @EndTime=null,       @LastRunning=null, @QuoteTime=0, @Version=0, @ServerName="script", @UpdaterRef="script"
exec EcnQuoteTimerStore  @BrokerRef="MTS", @InstrumentRef="PL0000101937", @TimerName="obligation1", @CounterDirection="Asc", @MaxSpread=0.0040000, @MinSize=5000000, @ObligationTime=5,    @StartTime="15:28:00", @EndTime="15:37:00", @LastRunning=null, @QuoteTime=0, @Version=0, @ServerName="script", @UpdaterRef="script"     












