# The following C# code is causing the 6MFRA_CZK curve to be missing

        private void AddEntryToCombo(DataSetComboEntry entry)
			{
            if (!cboCurves.Items.Contains(entry))
            {
                IDataFilter filter = CreateFilter(entry.ToString());
                IList data = gridPanel.Config.DataProvider.GetFieldDataSetsForFilter(filter);
                if (data.Count > 0) // <<<<<---------------------------------------------------------- COUNT = 0 for 6MFRA_CZK
                {
                    cboCurves.Items.Add(entry);
                    if (cboCurves.DroppedDown)
                    {
                        cboCurves.Refresh();//Will this work?
			        }
                }
            }
        }

