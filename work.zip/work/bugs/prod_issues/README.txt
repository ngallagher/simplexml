# For turning the book on the destination name needs to be

ceemea-autoquoter-offshore

# The reason we can not turn the book on is because there is no destinationName

GridMessage destinationType[AQ] destinationName[] treeToken[EuroGov.gallane] type[BookStatus] action[set] attributeName[bkTkP] id[BB] tradeId[] value[CEEMEA] parameters[null]

