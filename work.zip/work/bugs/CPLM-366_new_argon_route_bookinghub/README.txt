# Address for Argon enterprise manager 

http://lonms05430.fm.rbsgrp.net:8130/argonem/logon.htm

# Credentials for Argon enterprise manager

user: gallane
password: gallane99

# We currently do not send to rosetta directly

To send to rosetta directly the property rosetta.db.feed.action needs to be set.
This will cause some actions, such as ExecutionCompleteAction to perform the step 

<step stepName="AQCreateRosettaFeedRows"/>

This results in a table called EcnAqRosettaTradeFeed being populated. From there a database
poller loads the trades a pushes them through a RosettaTradeLoader, which in turn sends them 
to rosetta via a component called the TradeBookingClient.

# The trade grid works if 

<aqTradeBookingEnabled>true</aqTradeBookingEnabled>
<dispatcherEnabled>false</dispatcherEnabled>

# New argon route configuration

<argon_network_model name="A list of Argon routes used by the CP Autoquoter to the Booking Hub on UAT" environment="pre" xml_dir="eee_xml_files">
  <route cna="ldn:pre:cp_rates:aq_latam_sec" typ="e_security" ver="27" sk_cna="ldn:pre:cp_rates:tradehub_aq" sk_typ="e_security" sk_ver="30" /> 
</argon_network_model>


# CR raised for prod

http://change.fm.rbsgrp.net/Change/Forms/ChangeRequest/Details.aspx?ID=95244&_MI=1

# Argon sender connection issue

2009-11-03 10:15:18.314 -0500 ERROR [app-main] cpratesdev:
Unable to connect to Argon:
address=[ldn:pre:cp_rates:aq_latam_sec]
number of attempts=3
last exc: [com.rbsfm.argon.client.cga.ClientException: [E1020]Error during connection. Connecting as ldn:pre:cp_rates:aq_latam_sec.
java.lang.NullPointerException]

: [E1020]Error during connection. Connecting as ldn:pre:cp_rates:aq_latam_sec.
java.lang.NullPointerException: Stack Trace: com.rbsfm.argon.client.cga.ClientException: [E1020]Error during connection. Connecting as ldn:pre:cp_rates:aq_latam_sec.
java.lang.NullPointerException
        at com.rbsfm.argon.client.cga.Client.connect(Client.java:548)
        at com.rbsfm.argon.client.cga.Client.connect(Client.java:478)
        at com.rbsfm.ficommon.argon.SimpleArgonSender.connect(SimpleArgonSender.java:149)
        at com.rbsfm.ficommon.argon.SimpleArgonSender.forceStart(SimpleArgonSender.java:101)
        at com.rbsfm.ficommon.argon.SimpleArgonSender.internalStart(SimpleArgonSender.java:79)
        at com.rbsfm.common.system.AbstractControl.actualStart(AbstractControl.java:205)
        at com.rbsfm.common.system.AbstractControl.start(AbstractControl.java:97)
        at com.rbsfm.common.system.ControlManager.startControls(ControlManager.java:300)
        at com.rbsfm.common.system.ControlManager.start(ControlManager.java:206)
        at com.rbsfm.common.system.ControlServer.main0(ControlServer.java:62)
        at com.rbsfm.common.system.ControlServer$1.run(ControlServer.java:34)
        at java.lang.Thread.run(Thread.java:619)

The previous exception was caused by:
java.lang.NullPointerException
        at com.rbsfm.argon.client.bootstrap.ArgonBootstrapConfigBuilder.updateConfigurationDocument(ArgonBootstrapConfigBuilder.java:504)
        at com.rbsfm.argon.client.bootstrap.ArgonBootstrapConfigBuilder.processResponse(ArgonBootstrapConfigBuilder.java:476)
        at com.rbsfm.argon.client.bootstrap.ArgonBootstrapConfigBuilder.requestConfigFromServer(ArgonBootstrapConfigBuilder.java:451)
        at com.rbsfm.argon.client.bootstrap.ArgonBootstrapConfigBuilder.getBootstrap(ArgonBootstrapConfigBuilder.java:159)
        at com.rbsfm.argon.client.bootstrap.ArgonBootstrapConfig.<init>(ArgonBootstrapConfig.java:58)
        at com.rbsfm.argon.database.ConnectionSettings.loadConfiguration(ConnectionSettings.java:100)
        at com.rbsfm.argon.database.ConnectionSettings.<init>(ConnectionSettings.java:89)
        at com.rbsfm.argon.client.configuration.ClientConfiguration.loadClientConfigurationFromDatabase(ClientConfiguration.java:142)
        at com.rbsfm.argon.client.configuration.ClientConfiguration.loadClientConfiguration(ClientConfiguration.java:100)
        at com.rbsfm.argon.client.messaging.Connection.connect(Connection.java:347)
        at com.rbsfm.argon.client.messaging.Connection.connect(Connection.java:282)
        at com.rbsfm.argon.client.cga.Client.connect(Client.java:508)
        at com.rbsfm.argon.client.cga.Client.connect(Client.java:478)
        at com.rbsfm.ficommon.argon.SimpleArgonSender.connect(SimpleArgonSender.java:149)
        at com.rbsfm.ficommon.argon.SimpleArgonSender.forceStart(SimpleArgonSender.java:101)
        at com.rbsfm.ficommon.argon.SimpleArgonSender.internalStart(SimpleArgonSender.java:79)
        at com.rbsfm.common.system.AbstractControl.actualStart(AbstractControl.java:205)
        at com.rbsfm.common.system.AbstractControl.start(AbstractControl.java:97)
        at com.rbsfm.common.system.ControlManager.startControls(ControlManager.java:300)
        at com.rbsfm.common.system.ControlManager.start(ControlManager.java:206)
        at com.rbsfm.common.system.ControlServer.main0(ControlServer.java:62)
        at com.rbsfm.common.system.ControlServer$1.run(ControlServer.java:34)
        at java.lang.Thread.run(Thread.java:619)

# The following properties change for latam

argon.sender.enabled=true
postexecution.processor.recordOnlyTradeProcessor.dispatcherEnabled=true
conversation.dispatcher.enabled=true

# Required to use the TradeBookingArgonDispatcher

<control enabled="true">TradeBookingArgonDispatcher</control>

# Configuration component RecordOnlyTradeProcessor requires

 <dispatcherEnabled>true</dispatcherEnabled>

# Change made to the ExternalInstrumentAttributeDataProvider was 

  private double getBidAskSpread(ExternalBondPriceDetails ebpd, AttributeMap map) {
      String instrumentId = ebpd.getInstrumentId();
      double askPrice = ebpd.getAskPrice();
      double bidPrice = ebpd.getBidPrice();
      
      if(spreadHome != null) {
          EcnSpread spread = spreadHome.findByPrimaryKey(brokerId, bucketRef, instrumentId);
          
          if(spread != null) {
              return (askPrice - bidPrice) + spread.getSpread();
          } 
          Log.INFO.report("Could not find spread for broker '"+brokerId+"', bucket '"+bucketRef+"', and instrument '"+instrumentId+"'");          
      }
      return askPrice - bidPrice;
  }

# Additional name added to the com.rbsfm.fi.pricing.ecn.external.attribute.AutoQuoterAttributeNames

CNV_BID_ASK_SPREAD = "bidAskSpread"

# The posttrade.xml file has the following component

  <component name="ExternalInstrumentAttributeDataProvider" class_name="com.rbsfm.fi.pricing.ecn.instrument.ExternalInstrumentAttributeDataProvider">
    <jmxDomain>POST_EXECUTION</jmxDomain>
    <spreadHome>EcnSpreadHome</spreadHome>
    <brokerId>AQ Orders</brokerId>
    <bucketRef>B0</bucketRef>
  </component>


# Price calculations go here

<component name="ExternalInstrumentAttributeDataProvider" class_name="com.rbsfm.fi.pricing.ecn.instrument.ExternalInstrumentAttributeDataProvider">

# This will be used to calculate the bid ask spread

bidAskSpread = bidPrice - askPrice 

# Calculation of the actual spread can be done like so

65.0  (midPrice)
69.55 (originalPrice)
69.55 (executedPrice)

9.1 spread (2 * (executedPrice - midPrice))
60.45 askPrice (midPrice - (executedPrice - midPrice))

# This is the file that is used

file:/d:/dev/rbsfm/cp/latam-wk44/config/argon/templates/posttrade/booking.jelly.expanded

# Make a change to the following

${configdir}/argon/templates/posttrade/booking.jelly

# This is the XML message to be used

[<emml>
<messageHeader>
<eventDateTime timeContextReference="ID000000">2009-11-02T09:51:59.523</eventDateTime>
<system id="ID000001">
<systemName>CP AQ Post Trade</systemName>
<location>GREENWICH</location>
<systemRole>Publisher</systemRole>
</system>
<system id="ID000004">
<systemName>Bloomberg</systemName>
<location>LDN</location>
<systemRole>Upstream</systemRole>
</system>
<sourceSystemVersion>1.0</sourceSystemVersion>
<sourceSystemMachineName>lonms00433</sourceSystemMachineName>
<sourceSystemIPAddress>147.114.24.84</sourceSystemIPAddress>
<routingAttribute>
<routingAttributeName>CP Z Spread</routingAttributeName>
<routingAttributeValue>11762.91</routingAttributeValue>
</routingAttribute>
<routingAttribute>
<routingAttributeName>CP Modified Duration</routingAttributeName>
<routingAttributeValue>0.275</routingAttributeValue>
</routingAttribute>
<routingAttribute>
<routingAttributeName>CP Execution Type</routingAttributeName>
<routingAttributeValue>UNKNOWN</routingAttributeValue>
</routingAttribute>
<routingAttribute>
<routingAttributeName>CP Price Tier</routingAttributeName>
<routingAttributeValue>DEFAULT</routingAttributeValue>
</routingAttribute>
<timeContext id="ID000000">
<UTCOffset>0</UTCOffset>
</timeContext>
</messageHeader>
<tradeEventHeader>
<tradeIdentifier>
<tradeId>BET-091102-6</tradeId>
<tradeVersion>1</tradeVersion>
<systemReference>ID000001</systemReference>
</tradeIdentifier>
</tradeEventHeader>
<newSecurityTrade>
<tradeHeader>
<tradeDate>2009-11-02</tradeDate>
<bookingEntityPerspective>ID000001</bookingEntityPerspective>
<tradeTime>09:51:59.523</tradeTime>
<tradeOriginationMethod>Other</tradeOriginationMethod>
<tradeOriginationLocation>LDN</tradeOriginationLocation>
<party id="ID000002">
<isPartyInternal>true</isPartyInternal>
<partyIdentifier>
<partyId>SOV-MURP</partyId>
<partyIdClassificationScheme>Book Code</partyIdClassificationScheme>
</partyIdentifier>
<partyIdentifier>
<partyId>SOV-LATAM</partyId>
<systemDomainName>AQBook</systemDomainName>
</partyIdentifier>
<partyIdentifier>
<partyId>latam</partyId>
<systemDomainName>CPDesk</systemDomainName>
</partyIdentifier>
<partyClassificationIdentifier>
<partyClassificationId>Quoting Dealer</partyClassificationId>
<systemReference>ID000001</systemReference>
</partyClassificationIdentifier>
<partyRole>Trading</partyRole>
<employee>
<personIdentifier>
<personId>gallane</personId>
<systemReference>ID000001</systemReference>
<personIdScheme>Single Sign On</personIdScheme>
</personIdentifier>
<employeeRole>Trader</employeeRole>
</employee>
</party>
<party id="ID000003">
<isPartyInternal>true</isPartyInternal>
<partyIdentifier>
<partyId>ROYAL BANK OF SCOTLAND PLC, THE</partyId>
<partyName>ROYAL BANK OF SCOTLAND PLC, THE</partyName>
<systemReference>ID000001</systemReference>
<systemDomainName>BBG</systemDomainName>
</partyIdentifier>
<partyIdentifier>
<partyId>TEST</partyId>
<systemDomainName>Bloomberg Book Id</systemDomainName>
</partyIdentifier>
<partyRole>Trading</partyRole>
<employee>
<personIdentifier>
<personId>RRBSTRAD</personId>
<systemReference>ID000004</systemReference>
<personIdScheme>Person Identifier</personIdScheme>
</personIdentifier>
<employeeRole>Trader</employeeRole>
</employee>
</party>
<reportingGroupIdentifier>
<reportingGroupId>NA</reportingGroupId>
<systemReference>ID000001</systemReference>
</reportingGroupIdentifier>
</tradeHeader>
<EMM_Security>
<buyerPartyReference>ID000003</buyerPartyReference>
<sellerPartyReference>ID000002</sellerPartyReference>
<securityIdentifier>
<financialInstrumentId>US105756AV22</financialInstrumentId>
<financialInstrumentName>BRAZIL 12 Apr-10</financialInstrumentName>
<financialInstrumentIdClassificationScheme>ISIN</financialInstrumentIdClassificationScheme>
</securityIdentifier>
<securityIdentifier>
<financialInstrumentId>LATAM_BR_Sov</financialInstrumentId>
<systemDomainName>CPSector</systemDomainName>
</securityIdentifier>
<securityIdentifier>
<financialInstrumentId>BOND</financialInstrumentId>
<systemDomainName>CPInstrumentType</systemDomainName>
</securityIdentifier>
<securityPrice>
<cleanPrice>
<percentagePrice>
<percentage>69.55</percentage>
<percentagePriceDescription>Percentage</percentagePriceDescription>
</percentagePrice>
</cleanPrice>
<cleanPrice>
<percentagePrice>
<percentage>114.662948</percentage>
<percentagePriceDescription>Yield</percentagePriceDescription>
</percentagePrice>
</cleanPrice>
</securityPrice>
<quantity>
<quantityType>Face Amount</quantityType>
<quantityAmount>100000</quantityAmount>
</quantity>
<adjustedSettlementDate>2009-11-05</adjustedSettlementDate>
<settlementAmount>
<currency>USD</currency>
<amount>0</amount>
</settlementAmount>
<instrumentAttributes>
<instrumentClassificationIdentifier>
<financialInstrumentClassificationId>1-USD-30360:S</financialInstrumentClassificationId>
<systemReference>ID000001</systemReference>
</instrumentClassificationIdentifier>
<countryOfIssue>
<countryId>USA</countryId>
<systemReference>ID000001</systemReference>
<countryIdScheme>ISO</countryIdScheme>
</countryOfIssue>
<maturityDate>2010-04-15</maturityDate>
</instrumentAttributes>
</EMM_Security>
</newSecurityTrade>
</emml>]

# The trade is given asynchronously to the following

com.rbsfm.ficommon.trade.AttributeMapTradeArgonDispatcher.transformAndDispatch(com.rbsfm.fi.pricing.util.AttributeMap) line: 107	
com.rbsfm.ficommon.trade.AttributeMapTradeArgonDispatcher.internalConsume(java.lang.Object) line: 97	
com.rbsfm.common.system.AbstractConsumerControl$1.consume(java.lang.Object) line: 55	
com.rbsfm.common.thread.ProducerConsumer.runConsumerLoop() line: 292	
com.rbsfm.common.thread.ProducerConsumer.access$100(com.rbsfm.common.thread.ProducerConsumer) line: 24	
com.rbsfm.common.thread.ProducerConsumer$1.run() line: 214	
java.lang.Thread.run() line: 619	

# This is the TradeBookingArgonDispatcher must be enabled

<control enabled="${conversation.dispatcher.enabled}">TradeBookingArgonDispatcher</control>

# This is the entry point used to dispatch the trade

com.rbsfm.fi.bet.autoquoter.execution.RecordOnlyTradeProcessor.executionComplete(com.rbsfm.fi.bet.autoquoter.business.conversation.IConversation) line: 80	
com.rbsfm.fi.bet.autoquoter.business.conversation.DefaultAqConversationManager$1.dispatch(java.lang.Object, java.lang.Object) line: 90	
com.rbsfm.common.util.ListenerList.notifyListeners(java.lang.Object, com.rbsfm.common.util.ListenerList$Dispatcher) line: 128	
com.rbsfm.common.util.ListenerList.notifyListeners(java.lang.Object) line: 112	
com.rbsfm.fi.bet.autoquoter.business.conversation.NonCachingAqConversationManager(com.rbsfm.fi.bet.autoquoter.business.conversation.DefaultAqConversationManager).postProcess(com.rbsfm.fi.pricing.ecn.autoquote.conversation.ConversationEventType, com.rbsfm.fi.bet.autoquoter.business.conversation.IConversation) line: 403	
com.rbsfm.fi.bet.autoquoter.business.conversation.NonCachingAqConversationManager(com.rbsfm.fi.bet.autoquoter.business.conversation.DefaultAqConversationManager).raiseConversationEvents(com.rbsfm.fi.pricing.ecn.autoquote.conversation.AqConversation, com.rbsfm.fi.pricing.ecn.autoquote.conversation.ConversationEventType, java.lang.String) line: 493	
com.rbsfm.fi.bet.autoquoter.business.action.ExecutionCompleteAction.executeBusinessLogic(com.rbsfm.fi.bet.autoquoter.business.conversation.IConversation) line: 41	
com.rbsfm.fi.bet.autoquoter.business.action.ExecutionCompleteAction(com.rbsfm.fi.bet.autoquoter.business.action.AbstractBusinessAction).executeStepsThenBusinessLogic(com.rbsfm.fi.bet.autoquoter.business.conversation.IConversation) line: 138	
com.rbsfm.fi.bet.autoquoter.business.action.StartBusinessAction(com.rbsfm.fi.bet.autoquoter.business.action.AbstractBusinessAction).carryOutNextBusinessLogic(com.rbsfm.fi.bet.autoquoter.business.conversation.IConversation, com.rbsfm.fi.bet.autoquoter.business.action.IBusinessAction) line: 76	
com.rbsfm.fi.bet.autoquoter.business.action.StartBusinessAction.executeBusinessLogic(com.rbsfm.fi.bet.autoquoter.business.conversation.IConversation) line: 100	
com.rbsfm.fi.bet.autoquoter.business.conversation.ConversationRequestHandler.doAction(com.rbsfm.fi.bet.autoquoter.business.conversation.IInternalConversation) line: 418	
com.rbsfm.fi.bet.autoquoter.business.conversation.ConversationRequestHandler.processIncoming(com.rbsfm.fi.pricing.ecn.autoquote.external.message.AqGetSetableMessage) line: 190	
com.rbsfm.fi.bet.autoquoter.business.conversation.ConversationRequestHandler.handleConversationMessage(com.rbsfm.fi.pricing.ecn.autoquote.external.message.AqGetSetableMessage) line: 157	
com.rbsfm.fi.bet.autoquoter.business.conversation.ConversationRequestDispatcher$1.dispatch() line: 240	
com.rbsfm.fi.bet.autoquoter.business.conversation.ConversationRequestDispatcher$ConversationRequests.run() line: 83	
com.rbsfm.fi.pricing.util.ThreadPool$DefaultThreadPool$WorkerThread.internalRun() line: 217	
com.rbsfm.fi.pricing.util.ThreadPool$DefaultThreadPool$WorkerThread$1.run() line: 191	
java.lang.Thread.run() line: 619	


# This is the root for the dispatch

<component name="AttributeMapBondTransformer" class_name="com.rbsfm.ficommon.trade.AttributeMapTradeTransformer">

# The is the dispatcher

<component name="BookingHubArgonDispatcher" class_name="com.rbsfm.fi.pricing.util.attributemap.AttributeMapArgonDispatcher">

# The calculation to use

Sovs: Nominal * 5/10000
Corp: Nominal * 10/10000

# What is meant by the following

should we specify emm msg version 27 or 29, I understand theres going to be an upgrade at some point?

# Attribute to be added

<routingAttribute>
  <routingAttributeName>CP Bid Offer Price Spread</routingAttributeName>
  <routingAttributeValue>0.15</routingAttributeValue>
</routingAttribute>

# EMML template file

cpbuild/config/argon/templates/posttrade/booking.jelly

# Argon route

<argon_network_model name="A list of Argon routes used by the CP Autoquoter to the Booking Hub on UAT" environment="main" xml_dir="eee_xml_files">
  <route cna="ldn:main:cp_rates:aq_latam_sec" typ="e_security" ver="30" sk_cna="ldn:main:cp_rates:tradehub_aq" sk_typ="e_security" sk_ver="30" /> 
</argon_network_model>
