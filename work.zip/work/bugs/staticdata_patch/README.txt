C:\work\development\head\cpbuild>ant -v patch -Dconfig.group=rates -Denv=uat -Dinstall.id=gallane_staticdata-01_02_06 -Dscm.tag=staticdata-01_02_06 -Dpatch.file=C:\work\development\head\cppatches\staticdata-01_02_06\staticdata-01_02_06-patch001.xml -Dpatch.host.dir=\\lonms06332.fm.rbsgrp.net\d$\dev\rbsfm\cp\staticdata-01_02_06 -Dinclude.servers.regex=staticdata-.*
Apache Ant version 1.7.1 compiled on June 27 2008
Buildfile: build.xml
Detected Java version: 1.5 in: C:\Program Files\Java\j2sdk1.5.0_11\jre
Detected OS: Windows XP
parsing buildfile C:\work\development\head\cpbuild\build.xml with URI = file:/C:/work/development/head/cpbuild/build.xml
Project base dir set to: C:\work\development\head\cpbuild
[antlib:org.apache.tools.ant] Could not load definitions from resource org/apache/tools/ant/antlib.xml. It could not be found.
 [property] Loading C:\work\development\head\cpbuild\build\build.properties
 [property] Loading C:\work\development\head\cpbuild\build\ivy-build.properties
Override ignored for property "log.dir"
Override ignored for property "build.artifacts.dir"
Override ignored for property "dist.dir"
Override ignored for property "log.file"
Override ignored for property "projects.dir"
Override ignored for property "temp.dir"
Override ignored for property "installation.dir"
parsing buildfile jar:file:/C:/Program%20Files/Ant/lib/ant-contrib-1.0b3.jar!/net/sf/antcontrib/antlib.xml with URI = jar:file:/C:/Program%20Files/Ant/lib/ant-contrib-1.0b3.jar!/net/sf/antcontrib/antlib.xml
[available] Found file: C:\Program Files\Ant\lib\ant-contrib-1.0b3.jar
Importing file C:\work\development\head\cpbuild\build\build-bootstrap.xml from C:\work\development\head\cpbuild\build.xml
parsing buildfile C:\work\development\head\cpbuild\build\build-bootstrap.xml with URI = file:/C:/work/development/head/cpbuild/build/build-bootstrap.xml
Importing file C:\work\development\head\cpbuild\build\build-common.xml from C:\work\development\head\cpbuild\build\build-bootstrap.xml
parsing buildfile C:\work\development\head\cpbuild\build\build-common.xml with URI = file:/C:/work/development/head/cpbuild/build/build-common.xml
Importing file C:\work\development\head\cpbuild\build\build-taskdefs.xml from C:\work\development\head\cpbuild\build\build-common.xml
parsing buildfile C:\work\development\head\cpbuild\build\build-taskdefs.xml with URI = file:/C:/work/development/head/cpbuild/build/build-taskdefs.xml
Importing file C:\work\development\head\cpbuild\build\build-tools.xml from C:\work\development\head\cpbuild\build\build-taskdefs.xml
parsing buildfile C:\work\development\head\cpbuild\build\build-tools.xml with URI = file:/C:/work/development/head/cpbuild/build/build-tools.xml
parsing buildfile jar:file:/C:/Program%20Files/Ant/lib/ant-contrib-1.0b3.jar!/net/sf/antcontrib/antlib.xml with URI = jar:file:/C:/Program%20Files/Ant/lib/ant-contrib-1.0b3.jar!/net/sf/antcontrib/antlib.xml
parsing buildfile jar:file:/C:/work/development/head/cpbuild/lib/ivy-2.0.0.jar!/org/apache/ivy/ant/antlib.xml with URI = jar:file:/C:/work/development/head/cpbuild/lib/ivy-2.0.0.jar!/org/apache/ivy/ant/antlib.xml

BUILD FAILED
C:\work\development\head\cpbuild\build.xml:31: The following error occurred while executing this line:
C:\work\development\head\cpbuild\build\build-bootstrap.xml:6: The following error occurred while executing this line:
C:\work\development\head\cpbuild\build\build-common.xml:37: Unable to load a script engine manager (org.apache.bsf.BSFManager or javax.script.ScriptEngineManager)
        at org.apache.tools.ant.ProjectHelper.addLocationToBuildException(ProjectHelper.java:508)
        at org.apache.tools.ant.taskdefs.ImportTask.execute(ImportTask.java:148)
        at org.apache.tools.ant.UnknownElement.execute(UnknownElement.java:288)
        at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
        at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:39)
        at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:25)
        at java.lang.reflect.Method.invoke(Method.java:585)
        at org.apache.tools.ant.dispatch.DispatchUtils.execute(DispatchUtils.java:106)
        at org.apache.tools.ant.Task.perform(Task.java:348)
        at org.apache.tools.ant.Target.execute(Target.java:357)
        at org.apache.tools.ant.helper.ProjectHelper2.parse(ProjectHelper2.java:142)
        at org.apache.tools.ant.ProjectHelper.configureProject(ProjectHelper.java:93)
        at org.apache.tools.ant.Main.runBuild(Main.java:743)
        at org.apache.tools.ant.Main.startAnt(Main.java:217)
        at org.apache.tools.ant.launch.Launcher.run(Launcher.java:257)
        at org.apache.tools.ant.launch.Launcher.main(Launcher.java:104)
Caused by: C:\work\development\head\cpbuild\build\build-bootstrap.xml:6: The following error occurred while executing this line:
C:\work\development\head\cpbuild\build\build-common.xml:37: Unable to load a script engine manager (org.apache.bsf.BSFManager or javax.script.ScriptEngineManager)
        at org.apache.tools.ant.ProjectHelper.addLocationToBuildException(ProjectHelper.java:508)
        at org.apache.tools.ant.taskdefs.ImportTask.execute(ImportTask.java:148)
        at org.apache.tools.ant.UnknownElement.execute(UnknownElement.java:288)
        at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
        at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:39)
        at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:25)
        at java.lang.reflect.Method.invoke(Method.java:585)
        at org.apache.tools.ant.dispatch.DispatchUtils.execute(DispatchUtils.java:106)
        at org.apache.tools.ant.Task.perform(Task.java:348)
        at org.apache.tools.ant.Target.execute(Target.java:357)
        at org.apache.tools.ant.helper.ProjectHelper2.parse(ProjectHelper2.java:131)
        at org.apache.tools.ant.taskdefs.ImportTask.execute(ImportTask.java:146)
        ... 14 more
Caused by: C:\work\development\head\cpbuild\build\build-common.xml:37: Unable to load a script engine manager (org.apache.bsf.BSFManager or javax.script.ScriptEngineManager)
        at org.apache.tools.ant.util.ScriptRunnerCreator.createRunner(ScriptRunnerCreator.java:95)
        at org.apache.tools.ant.util.ScriptRunnerHelper.getRunner(ScriptRunnerHelper.java:190)
        at org.apache.tools.ant.util.ScriptRunnerHelper.getScriptRunner(ScriptRunnerHelper.java:55)
        at org.apache.tools.ant.taskdefs.optional.script.ScriptDef.execute(ScriptDef.java:207)
        at org.apache.tools.ant.UnknownElement.execute(UnknownElement.java:288)
        at sun.reflect.GeneratedMethodAccessor4.invoke(Unknown Source)
        at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:25)
        at java.lang.reflect.Method.invoke(Method.java:585)
        at org.apache.tools.ant.dispatch.DispatchUtils.execute(DispatchUtils.java:106)
        at org.apache.tools.ant.Task.perform(Task.java:348)
        at org.apache.tools.ant.Target.execute(Target.java:357)
        at org.apache.tools.ant.helper.ProjectHelper2.parse(ProjectHelper2.java:131)
        at org.apache.tools.ant.taskdefs.ImportTask.execute(ImportTask.java:146)
        ... 24 more
--- Nested Exception ---
C:\work\development\head\cpbuild\build\build-bootstrap.xml:6: The following error occurred while executing this line:
C:\work\development\head\cpbuild\build\build-common.xml:37: Unable to load a script engine manager (org.apache.bsf.BSFManager or javax.script.ScriptEngineManager)
        at org.apache.tools.ant.ProjectHelper.addLocationToBuildException(ProjectHelper.java:508)
        at org.apache.tools.ant.taskdefs.ImportTask.execute(ImportTask.java:148)
        at org.apache.tools.ant.UnknownElement.execute(UnknownElement.java:288)
        at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
        at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:39)
        at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:25)
        at java.lang.reflect.Method.invoke(Method.java:585)
        at org.apache.tools.ant.dispatch.DispatchUtils.execute(DispatchUtils.java:106)
        at org.apache.tools.ant.Task.perform(Task.java:348)
        at org.apache.tools.ant.Target.execute(Target.java:357)
        at org.apache.tools.ant.helper.ProjectHelper2.parse(ProjectHelper2.java:131)
        at org.apache.tools.ant.taskdefs.ImportTask.execute(ImportTask.java:146)
        at org.apache.tools.ant.UnknownElement.execute(UnknownElement.java:288)
        at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
        at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:39)
        at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:25)
        at java.lang.reflect.Method.invoke(Method.java:585)
        at org.apache.tools.ant.dispatch.DispatchUtils.execute(DispatchUtils.java:106)
        at org.apache.tools.ant.Task.perform(Task.java:348)
        at org.apache.tools.ant.Target.execute(Target.java:357)
        at org.apache.tools.ant.helper.ProjectHelper2.parse(ProjectHelper2.java:142)
        at org.apache.tools.ant.ProjectHelper.configureProject(ProjectHelper.java:93)
        at org.apache.tools.ant.Main.runBuild(Main.java:743)
        at org.apache.tools.ant.Main.startAnt(Main.java:217)
        at org.apache.tools.ant.launch.Launcher.run(Launcher.java:257)
        at org.apache.tools.ant.launch.Launcher.main(Launcher.java:104)
Caused by: C:\work\development\head\cpbuild\build\build-common.xml:37: Unable to load a script engine manager (org.apache.bsf.BSFManager or javax.script.ScriptEngineManager)
        at org.apache.tools.ant.util.ScriptRunnerCreator.createRunner(ScriptRunnerCreator.java:95)
        at org.apache.tools.ant.util.ScriptRunnerHelper.getRunner(ScriptRunnerHelper.java:190)
        at org.apache.tools.ant.util.ScriptRunnerHelper.getScriptRunner(ScriptRunnerHelper.java:55)
        at org.apache.tools.ant.taskdefs.optional.script.ScriptDef.execute(ScriptDef.java:207)
        at org.apache.tools.ant.UnknownElement.execute(UnknownElement.java:288)
        at sun.reflect.GeneratedMethodAccessor4.invoke(Unknown Source)
        at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:25)
        at java.lang.reflect.Method.invoke(Method.java:585)
        at org.apache.tools.ant.dispatch.DispatchUtils.execute(DispatchUtils.java:106)
        at org.apache.tools.ant.Task.perform(Task.java:348)
        at org.apache.tools.ant.Target.execute(Target.java:357)
        at org.apache.tools.ant.helper.ProjectHelper2.parse(ProjectHelper2.java:131)
        at org.apache.tools.ant.taskdefs.ImportTask.execute(ImportTask.java:146)
        ... 24 more
--- Nested Exception ---
C:\work\development\head\cpbuild\build\build-common.xml:37: Unable to load a script engine manager (org.apache.bsf.BSFManager or javax.script.ScriptEngineManager)
        at org.apache.tools.ant.util.ScriptRunnerCreator.createRunner(ScriptRunnerCreator.java:95)
        at org.apache.tools.ant.util.ScriptRunnerHelper.getRunner(ScriptRunnerHelper.java:190)
        at org.apache.tools.ant.util.ScriptRunnerHelper.getScriptRunner(ScriptRunnerHelper.java:55)
        at org.apache.tools.ant.taskdefs.optional.script.ScriptDef.execute(ScriptDef.java:207)
        at org.apache.tools.ant.UnknownElement.execute(UnknownElement.java:288)
        at sun.reflect.GeneratedMethodAccessor4.invoke(Unknown Source)
        at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:25)
        at java.lang.reflect.Method.invoke(Method.java:585)
        at org.apache.tools.ant.dispatch.DispatchUtils.execute(DispatchUtils.java:106)
        at org.apache.tools.ant.Task.perform(Task.java:348)
        at org.apache.tools.ant.Target.execute(Target.java:357)
        at org.apache.tools.ant.helper.ProjectHelper2.parse(ProjectHelper2.java:131)
        at org.apache.tools.ant.taskdefs.ImportTask.execute(ImportTask.java:146)
        at org.apache.tools.ant.UnknownElement.execute(UnknownElement.java:288)
        at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
        at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:39)
        at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:25)
        at java.lang.reflect.Method.invoke(Method.java:585)
        at org.apache.tools.ant.dispatch.DispatchUtils.execute(DispatchUtils.java:106)
        at org.apache.tools.ant.Task.perform(Task.java:348)
        at org.apache.tools.ant.Target.execute(Target.java:357)
        at org.apache.tools.ant.helper.ProjectHelper2.parse(ProjectHelper2.java:131)
        at org.apache.tools.ant.taskdefs.ImportTask.execute(ImportTask.java:146)
        at org.apache.tools.ant.UnknownElement.execute(UnknownElement.java:288)
        at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
        at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:39)
        at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:25)
        at java.lang.reflect.Method.invoke(Method.java:585)
        at org.apache.tools.ant.dispatch.DispatchUtils.execute(DispatchUtils.java:106)
        at org.apache.tools.ant.Task.perform(Task.java:348)
        at org.apache.tools.ant.Target.execute(Target.java:357)
        at org.apache.tools.ant.helper.ProjectHelper2.parse(ProjectHelper2.java:142)
        at org.apache.tools.ant.ProjectHelper.configureProject(ProjectHelper.java:93)
        at org.apache.tools.ant.Main.runBuild(Main.java:743)
        at org.apache.tools.ant.Main.startAnt(Main.java:217)
        at org.apache.tools.ant.launch.Launcher.run(Launcher.java:257)
        at org.apache.tools.ant.launch.Launcher.main(Launcher.java:104)

Total time: 0 seconds
C:\work\development\head\cpbuild>

















