# Practical use


<component name="RaiseAlarmLogFilter" class_name="com.rbsfm.commonx.log.RaiseAlarmLogFilter">
  <mailSender>RaiseAlarmMailSender</mailSender>
  <mailLookup>latam-dev</mailLookup>
  <alarm subject='[GenericNodeStore] Failed for pricing' enabled='true'>
    <match quickFilter='GenericNodeStore' regex='.*GenericNodeStore.*'/>
  </alarm>
</component>

<component name="RaiseAlarmMailSender" class_name="com.rbsfm.commonx.mail.MailSender">
  <host>mailhost.gcm.com</host>
  <email name="latam-dev">
     <to>niall.gallagher@rbs.com</to>
     <from>uat-latam-autoquoter-offshore@stams00058</from>
  </email>
</component>

# Use in UAT for latam

<component name="RaiseAlarmLogFilter" class_name="com.rbsfm.commonx.log.RaiseAlarmLogFilter">
  <mailSender>RaiseAlarmMailSender</mailSender>
  <mailLookup>latam-dev</mailLookup>
  <alarm subject='[EcnInstrumentMappingHome] Failed to match instrument' enabled='true'>
    <match quickFilter='Did not find' regex='.*Did not find instrument mapping for.*'/>
    <match quickFilter='Matching LinkSet contains' regex='.*Matching LinkSet contains.*'/>
  </alarm>
</component>

<component name="RaiseAlarmMailSender" class_name="com.rbsfm.commonx.mail.MailSender">
  <host>${smtp.host}</host>
  <email name="latam-dev">
     <to>niall.gallagher@rbs.com</to>
     <to>michail.michalakopoulos@rbs.com</to>
     <to>iain.toft@rbs.com</to>
     <from>uat-latam-autoquoter-offshore@stams00058</from>
  </email>
</component>

# To start the filter the following will work

<control enabled="true">RaiseAlarmLogFilter</control> 

# In order to configure the filter the following is a good example

<component name="RaiseAlarmLogFilter" class_name="com.rbsfm.commonx.log.RaiseAlarmLogFilter">
  <mailSender>AlarmMailSender</mailSender>
  <mailLookup>NIALL_GALLAGHER</mailLookup>
  <alarm subject='Something bad has occured' enabled='false'>
    <match quickFilter='Component' regex='.*Component.*'/>
  </alarm>
</component>

# Finally you might want to establish your own mail sender with an SMTP host like mailhost.gcm.com
  
<component name="AlarmMailSender" class_name="com.rbsfm.commonx.mail.MailSender">
  <host>mailhost.gcm.com</host>
  <email name="NIALL_GALLAGHER">
     <to>niall.gallagher@rbs.com</to>
	 <from>pricing_server</from>
  </email>
</component>

