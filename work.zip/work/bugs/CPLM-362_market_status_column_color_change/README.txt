# The EcnPublisherManager can enable all EcnPublishers

The config boolean "enableAllOnUnstale" will enable all of the publishers if the data
becomes unstale. This could be used to trigger the enablement of Rv.

# The RvIndicativePricePublisher is causing the problem

It needs to be enabled

# Setting it back to enabled

ExchangeMessageFormatter.formatMessage(String, String, EcnPublisherDetails) line: 47	
FeedPricePublisher.publisherUpdated(EcnPublisherDetails) line: 238	
AbstractEcnPublisher$1.dispatch(Object, Object) line: 137	
ListenerList.notifyListeners(Object, ListenerList$Dispatcher) line: 128	
ListenerList.notifyListeners(Object) line: 112	
MuxPublisher(AbstractEcnPublisher).notifyListeners() line: 977	
MuxPublisher(AbstractEcnPublisher).updatePublishingCounters(EcnFeedPriceDetails, boolean, boolean) line: 875	
MuxPublisher(AbstractEcnPublisher).throttledQuoteUpdated(EcnFeedPriceDetails) line: 801	
AbstractEcnPublisher$ThrottleConsumer.run() line: 76	

# Setting the broker to disabled

ExchangeMessageFormatter.formatMessage(String, String, EcnPublisherDetails) line: 47	
FeedPricePublisher.publisherUpdated(EcnPublisherDetails) line: 238	
AbstractEcnPublisher$1.dispatch(Object, Object) line: 137	
ListenerList.notifyListeners(Object, ListenerList$Dispatcher) line: 128	
ListenerList.notifyListeners(Object) line: 112	
RvEcnIndicativePricePublisher(AbstractEcnPublisher).notifyListeners() line: 977	
RvEcnIndicativePricePublisher(AbstractEcnPublisher).updatePublishingCounters(EcnFeedPriceDetails, boolean, boolean) line: 875	
RvEcnIndicativePricePublisher(AbstractEcnPublisher).throttledQuoteUpdated(EcnFeedPriceDetails) line: 801	
AbstractEcnPublisher$ThrottleConsumer.run() line: 76	

# Changes

GOLD {
    sanatizrtEnabled=false
    brokerEnabled=true
    bookEnabled=true
    status=ON
    bookStatus=MANUAL
}

RED {
    sanatizerEnabled=false
    brokerEnabled=false <------------ BROKER ENABLED CHANGES
    bookEnabled=true
    status=ON
    bookStatus=MANUAL
}

GOLD {
    sanatizerEnabled=false
    brokerEnabled=true <-------- BACK TO ENABLED
    bookEnabled=true
    status=ON
    bookStatus=MANUAL
}

# Focus on a single instrument for debugging

USP97475AD26

# The key attributes in the message are the following for market status color

statusField=AQ_marketStatus 
mSanitizerField=APT0B0enable 
mBookField=AQ_inbk

# GetBrushes method called with the following

data=ID=[XS0214851874] Type=[Bond] Sources=[EB=>latam-exchangedata-offshore
SP=>latam-ecnpricefeed-offshore
AT=>latam-ecnpricefeed-offshore
PS=>latam-pricing-offshore
EA=>latam-autoquoter-offshore
EI=>latam-ecnpricefeed-offshore
AQ=>latam-autoquoter-offshore] Attributes=[dataSetId=>XS0214851874
dataSetType=>Bond
sourceNames=>latam-exchangedata-offshore(EB)
 latam-ecnpricefeed-offshore(SP)
 latam-ecnpricefeed-offshore(AT)
 latam-pricing-offshore(PS)
 latam-autoquoter-offshore(EA)
 latam-ecnpricefeed-offshore(EI)
 latam-autoquoter-offshore(AQ)
lstTrdDir=>
lstTrdPrc=>0
lstTrdTm=>18/09/2009 00:00:00
bestBidLive=>N
bestAskLive=>N
bestAskRbsFlag=>-
bestBidRbsFlag=>-
bestBid=>120
bestBidLstUpdDtTm=>2009-09-01 06:34:38.816
version=>2.0
bestMid=>1.2
bestAskSz=>1
lstTrdSz=>0
totTrdSz=>NaN
bestAsk=>120
lstTrdDtTm=>1900-01-01 00:00:00.000
bestBidMkt=>EURO
bestAskMkt=>GFI
lstTrdMkt=>
bestBidSz=>1
bestAskLstUpdDtTm=>2009-09-01 07:07:54.473
bestPrcTyp=>Price
AP_chkHitCount=>YES
AP_maxHitTimePeriod=>10
AP_chkPrcSprdTol=>0
AP_buyMaxSettTol=>7
AP_sellMaxSettTol=>7
AP_sanitize=>YES
AP_chkSize=>YES
AP_maxBid=>0
AP_chkGFBond=>OFF
AP_clsYldChkTol=>10
AP_chkBnchMkt=>NO
AP_chkFastMkt=>YES
AP_clsYldChk=>YES
AP_quoteStat=>YES
AP_chkPrcSprd=>YES
AP_maxDailyFwdMvt=>100
AP_minAsk=>0
AP_buyMinSettTol=>1
AP_maxHitCount=>5
AP_chkSettlementDate=>YES
AP_mktPrcChkTol=>1
AP_chkMtsBond=>OFF
AP_mktPrcSprdTol=>50
AP_chkMkt=>YES
AP_chkIlliquidBond=>OFF
AP_sellMinSettTol=>1
AP_maxAsk=>0
AP_chkFutFeed=>YES
AP_minBid=>0
AP_bnchMktPrcChkTol=>0
AP_chkMktSprd=>YES
AP_failNoBstPrc=>NO
AT_RepoT3=>NaN
AT_RepoT2=>NaN
AT_RepoT5=>NaN
AT_RepoT4=>NaN
AT_RepoT7=>NaN
AT_RepoT6=>NaN
AT_RepoT0=>NaN
AT_RepoT1=>NaN
FitchChg=>3
Sov_dBenAskSprd=>0
todClsBidVsCurve=>0
todtreasuryDSwapSpread=>0
benWIAskPrc=>0
aswDStripSprd=>0
todClsBen=>
bidZSprd=>13.85
prevClsCdsBasis=>0
todClsAskPrc=>0
Sov_benBidSprdOvrrd=>Infinity
wifBenchDateOffset=>0
todClsBidDM=>0
aswFltAnn=>5.187851
cdsBasisBid=>0
todClsModDur=>0
runAskPrc=>120
Sov_benBYieldBasisBmk=>0
aswAskFltAnn=>518.7851
todtreasurySwapSpread=>0
dBidZSprdRBS=>0
Sov_benId=>none
derivedDisName=>
baSprd=>1
todClsBidZSpread=>0
startDate=>01/01/1900 00:00:00
prevClsAvgLife=>01/01/1900 00:00:00
vsCrvBidDSprd=>-0.000371
rtBestAskMkt=>GFI
aswDSprd=>-2.31
bondCat=>
Moodys=>B2
vsCrvSprd=>37.15
rtBestBidOvrd=>0
bidYld=>2.9826
prevCls5yCdsBasis=>0
todClsAskSimpleYld=>0
prevClsAskDM=>0
wifAxeBidAswSprd=>0
prevCloseDASW=>0
prevClsBidSwapRate=>0.001086
Sov_benSprd=>0
prevClsTreasuryDuration=>0
wifBenBidSprd=>Infinity
cdsBasisAsk=>0
prevClsNetBs=>0
stageALLQ=>False
BidBenchmarkSpread=>0
convty=>27.185603
setId=>LATAM_VE_Sov
prevClsBidSimpleYld=>0
efMatDtAsk=>16/03/2015 00:00:00
todClsTm=>18/09/2009 00:00:00
aswAskParSwpRt=>-100
prevClsBidDM=>0
Localsource=>
masterAskDM=>0
askZSprdRBS=>18.25
CouponFreq=>ANNUAL
todClsTreasuryDuration=>0
vsCrvId=>vsOTR_USD_BondCur
cpnType=>FIXED
lCpnAmtOv=>0.07
BenchmarkId=>
vsCrvYld=>2.611
altIds=>Cusip:ED8486141
bloombergBook=>
fullYearsToMaturity=>5.49041095890411
isDefaulted=>False
Sov_benAYieldBasisBmk=>0
masterMidDM=>0
modDur=>4.536
matDt=>16/03/2015 00:00:00
todClsBidStrp=>0
benBidPrc=>0
aswStrpBpv=>5.6557
SubDebt=>
wifAxeBidYield=>0
askDbpv=>0.3362
tm2NxCpn=>0.476712
nxCpnAmt=>0.07
axesType=>Bid
cdsInterpDt=>01/01/1900 00:00:00
masterCurve=>
Sov_benExtCode=>
prevClsASW=>18.78
cashflowRule=>BOTH
exportName=>VENZ 7 03/15
zSprdAskCurve=>IYC23_USD
FitchOld=>B+
aswBidStrpPrc=>120.7776
underWriters=>System.String[]
dBenAskSprd=>0
versionBSC=>0
todClsAskDM=>0
WIBidYld=>0
wifAxeAskYield=>0
wifAxeAskBenSprd=>NaN
swapSpreadCrvId=>IYC23_USD
runBidPrc=>120
supExtPrc=>False
isDeliverable=>
benAYieldBasisBmk=>0
fstCpnDt=>16/03/2006 00:00:00
benSupportCYCalc=>False
wifYYDiffBidSprd=>Infinity
prevClsAccInt=>0.036438
fstAccDt=>16/03/2005 00:00:00
prevClsSimpleYld=>0
wifAxeAskBenSprdVar=>0
bpv=>5.6091
swapSpreadUseBondFreq=>False
prevtreasurySwapSpread=>10.86
todClsSwapRate=>0
fwdSpotPrc=>120
aswAskStrpBpv=>5.6557
bidBpv=>5.6091
prevClsGrsBs=>0
wifBenBidPrcOverride=>0
wifAxeAskAswSprd=>0
aswAskSprd=>14.99
zSprdAskCurveRBS=>LIBOR-HD_USD
prevClsFinalTradeTime=>18/09/2009 00:00:00
benName=>none
todClsBidYld=>0
rtUpdateTm=>17/09/2009 13:04:45
clsStat=>Open
todClsPrc=>0
todClsCds=>0
rtrId=>
dMidZSprdRBS=>0
cdsSelectedYear=>5Y
todClsFinalTradeTime=>18/09/2009 00:00:00
todClsStrp=>0
jotter3=>VE 15 E
bidModDur=>4.536
prevClsCdsInterpAskSpread=>0
jotter2=>
prevClsStrp=>17.3
isInAxes=>0
ticker=>VENZ
prevIsClsd=>True
cty=>EU
aswBidStrpBpv=>5.6557
todClsAvgLife=>01/01/1900 00:00:00
vsCrvAskSprd=>37.15
todClsMidZSpread=>0
swapRate=>2.90890689259024
prevClsAskSimpleYld=>0
cdsInterpType=>
strctTyp=>
crvId=>IYC23_USD
prevClsSwapRate=>2.8756
prevClsCdsInterpBidSpread=>0
runAskYld=>2.98257725388188
stageRequestor=>
mastId=>bestPrice
todClsFinalTradedASW=>0
todClsAskYld=>0
isGrandFathered=>False
yld=>2.9826
dBidSwapRate=>0.0280075997485197
ScheduleGenId=>
fwdYld=>2.9896
realBenName=>none
Fitch=>B+
prevClsTm=>05:00:07 PM
fstSettDt=>16/03/2005 00:00:00
todClsSimpleBpv=>0
BASWYSprd=>1.029826
todCls5yCdsBasis=>0
runDur=>0
postStagingSectorOpts=>
CombinedRating=>B2/BB-/B+
wifSetDateOffset=>0
aswDFinalTradeSprd=>0
settDt=>23/09/2009 00:00:00
prevClsFinalTradeIsClosed=>False
aswBidSprd=>14.99
prevClsAskSwapRate=>0.001086
dftSettDt=>23/09/2009 00:00:00
benPrcOverride=>0
prevClsBpv=>5.6114
redAmt=>100
prevClsBidYld=>2.9842
bidPrcType=>Bid
prevClsDuration=>4.673784
cdsBAswBasis=>0
todClsConvty=>0
OptPrcMthds=>:Default
Call:Call
Put:Put
Maturity:Maturity
ToDate:ToDate
Worst:Worst
Best:Best
SimpleYield:SimpleYield
cdsBZSpreadBasis=>0
askPrcType=>Ask
dur=>4.671
filter1=>
filter3=>
filter2=>
filter5=>
filter4=>
AskBenchmarkSpread=>0
filter6=>
rtBestPrcTyp=>Price
MoodysOld=>B2
rtBestAsk=>120
AASWYSprd=>1.029826
Sov_benAskPrc=>0
benBidSprd=>0
dBidZSprd=>-3.50271464548905
Sov_benSupportCYCalc=>False
pointCds=>0
prevClsAskYld=>2.9842
prevClsFinalTradedASW=>0
comnts=>
aswBidParSwpRt=>-100
seniority=>
industryCode2=>
zSprdDisabled=>False
industryCode1=>
aswBidFltAnn=>518.7851
aswStrpYld=>2.8445
clnPrc=>120
exDivDays=>0
issuer=>
fwdRt=>1
isTaxExempt=>False
benAskSprd=>0
dAskZSprd=>-3.50271464548905
aswBidStrpSprd=>13.81
swapSpreadBidCrvId=>IYC23_USD
todClsVsFut=>0
prevCpnDt=>16/03/2009 00:00:00
absPrepaymentRate=>0
prevClsFinalTradeASW=>0
todCloseVsCurve=>0
axesSyncMethod=>MANUAL
Sov_benAskSprd=>0
bidSwapRate=>0.0290890689259024
nxCpnDt=>16/03/2010 00:00:00
Sov_dBenSprd=>0
todClsYld=>0
aswStrpPrc=>120.7776
bidDbpv=>0.3362
subSec=>
bidASWCompSFR=>0.029089
aswCompYldDiff=>7.37
wifBenAswBidSprd=>Infinity
benSprd=>0
wifSetDateOvrrd=>01/01/1900 00:00:00
putNoticePeriod=>0
BBCompositeRating=>
PrcToDt=>01/01/1900 00:00:00
disName=>VE 15 E
prevClsBenAskSprd=>0
alias=>
midZSprdRBS=>0
prevClsBidStrp=>18.78
bidCrvId=>IYC23_USD
benBidSprdOvrrd=>Infinity
cdsInterpBidSpread=>0.25
vsCrvAskDSprd=>-0.000371
isCallable=>False
masterBidDM=>0
treeTok=>LATAM.master
Sov_benPrcOverride=>0
rtBestBidMkt=>EURO
pointCdsBasis=>0
runBpv=>0
todClsFut=>
swapSpreadAskCrvId=>IYC23_USD
sptPrcOvrrd=>0
swBidSprd=>7.37
endDt=>16/03/2015 00:00:00
askYld=>2.9826
isInRun=>0
todClsAccInt=>0
bondType=>1-EUR-ACTACT:A
wifBenAswAskSprd=>Infinity
WifBenIdOverride=>none
prcMthds=>manualPrice:manualPrice:bidPrc
bestPrice:bestPrice
BondVsCurveCalc:BondVsCurveCalc:vsCrvBidSprd
assetSwapSpread:assetSwapSpread.assetSwapSpread:aswBidSprd
stripSpread:assetSwapSpread.stripSpread:aswBidStrpPrc
ZSpreadCalc:ZSpreadCalc:bidZSprd
YSpreadSov:YSpreadSov:Sov_benBidSprd
ZSpreadCalcRBS:ZSpreadCalcRBS:bidZSprdRBS
swapSpreadCalc:swapSpreadCalc:swBidSprd
YSpread:YSpread:benBidSprd
axeLastUpdatedDate=>01/01/1900 00:00:00
bidAdjTim=>15/07/2009 05:44:12
prevClsAskPrc=>120
zSprdBidCurve=>IYC23_USD
todClsBidPrc=>0
own=>tofti
BenchmarkSpread=>NaN
postStagingSector=>
prevClsAskVsCurve=>0.004086
prevClsFut=>
todClsBenSprd=>0
todClsBidSimpleYld=>0
prevClsBidZSpread=>17.35
todClsBenBidSprd=>0
todClsCdsBasis=>0
Sov_dBenBidSprd=>0
cdsInterpAskSpread=>0.25
zSprdBidCurveRBS=>LIBOR-HD_USD
IsModifiable=>True
todClsFinalTradeIsClosed=>False
vsCrvEnabledIfMaster=>False
aswParSwpRt=>-100
todClsTreasuryBpv=>0
prevClsTreasuryBpv=>0
aswAskStrpSprd=>13.81
cdsbasis=>0
prevtreasuryDSwapSpread=>8.49
axe=>0
rtBestAskOvrd=>0
extInstType=>UNKNOWN
zcurve=>IYC23_USD
prevClsMidZSpread=>17.35
fwdDys=>7
todClsSettDt=>01/01/1900 00:00:00
prevCls5yCds=>0
askCrvId=>IYC23_USD
quMarg=>0
dSimpleYld=>0
MoodysChg=>3
efMatDtBid=>16/03/2015 00:00:00
wifAxeBidBenSprd=>NaN
isPerp=>False
SandPChg=>3
midZSprd=>13.85
todCls5yCds=>0
todClsBpv=>0
todClsGrsBs=>0
isInFreeze=>0
zcurveRBS=>LIBOR-HD_USD
WIAskYld=>0
cpn=>7
yieldFreq=>QUOTE_YIELD_DEFAULT
aswAskStrpYld=>2.8445
Sov_benAskSprdOvrrd=>Infinity
stageBB=>False
todClsAskSwapRate=>0
swAskSprd=>7.37
fwdAswSprd=>14.71
dBenBidSprd=>0
prevClsAskStrp=>18.78
todClsASW=>0
fstCpnOvAmt=>0.07
isISIN=>True
fullBondName=>
mtgOrigWAL=>0
wifCurveId=>IYC23_USD
daysAcc=>191
todClsAskZSpread=>0
dataSource=>BestPriceDS
dYld=>-0.0016
tod=>18/09/2009 00:00:00
prevClsBen=>none
vsCrvBidSprd=>37.15
wifAskZSprd=>0
Sov_benName=>none
dirty=>False
todClsSimpleYld=>0
stageProblem=>
benId=>none
yearsToMaturity=>6
axeLastUpdatedTime=>18/09/2009 00:00:00
todClsAskVsCurve=>0
valDt=>23/09/2009 00:00:00
prevClsPrc=>120
instId=>XS0214851874
dAskZSprdRBS=>0
todClsDt=>01/01/1900 00:00:00
prevClsFinalTradeDate=>01/01/1900 00:00:00
askAdjTim=>15/07/2009 05:44:02
CountryISO=>VE
prc=>120
dPrc=>0
CIS=>
CalcTypDes=>
issNum=>0
ccy=>EUR
isInRun2=>0
callNoticePeriod=>0
bidPrc=>120
todIsClsd=>False
dbpv=>0.3362
prevClsConvty=>27.211187
issSz=>1000
SandPOld=>BB-
aswCompSFR=>2.9089
prevClsBenBidSprd=>0
prevClsModDur=>0
wifBenAskPrcOverride=>0
dBenSprd=>0
wifBidZSprd=>0
cds=>0
prevClsDt=>17/09/2009 00:00:00
bondTypeCategory=>
benWIBidPrc=>0
rtBestBid=>120
benExtCode=>
Series=>INTL
benAskSprdOvrrd=>Infinity
aswSprd=>14.99
prevClsAskZSpread=>17.35
askPrc=>120
isInRuns=>02 10
cdsId=>
isFrn=>False
aswAskStrpPrc=>120.7776
todClsCdsInterpBidSpread=>0.00025
isExDv=>False
cdsInterpValue=>0
askSwapRate=>0.0290890689259024
avgLife=>01/01/1900 00:00:00
wifAxeBidBenSprdVar=>0
todClsFinalTradeASW=>0
BidAskSpread=>0.0001
OptPrcMthd=>
fwdBid=>119.9
fwdDt=>29/09/2009 00:00:00
prevCloseVsCurve=>40.86
benWIPrc=>0
ALTID_Cusip=>ED8486141
lCpnDt=>16/03/2014 00:00:00
stageLiveStatus=>
wifBenchYld=>0
SandP=>BB-
prevClsYld=>2.9842
secApp=>FIPricing-LATAM-All-Update
efMatDt=>16/03/2015 00:00:00
todClsCdsInterpAskSpread=>0.00025
wifAxeBidPrice=>0
prevClsTreasuryConvexity=>0
aswDCompYldDiff=>-3.5
runBidYld=>2.98257725388188
stageBook=>
nodeId=>XS0214851874
benBYieldBasisBmk=>0
tranche=>
isLoan=>False
benAskPrc=>0
aswStrpSprd=>13.81
isBenchWIOverride=>0
todClsTreasuryConvexity=>0
Sov_benBidPrc=>0
bondDeleted=>False
todClsAskStrp=>0
todClsBidSwapRate=>0
symbol=>XS0214851874
wifBenchSetDateOvrrd=>01/01/1900 00:00:00
fwdPrc=>119.9055
dSwapRate=>3.33238072573728
vsCrvDSprd=>0
todClsBenAskSprd=>0
Sov_realBenName=>none
dAskSwapRate=>0.0280075997485197
askModDur=>4.536
todClsFinalTradeDate=>01/01/1900 00:00:00
prevClsBenSprd=>0
askZSprd=>13.85
accInt=>366.3014
bidZSprdRBS=>18.25
todClsDuration=>0
aswBidDSprd=>-2.31
prevClsCds=>0
isPricingSource=>False
dMidZSprd=>-3.50271464548905
isDummy=>False
prevClsSettDt=>22/09/2009 00:00:00
askBpv=>5.6091
aswAskDSprd=>-2.31
wifYYDiffAskSprd=>Infinity
wifBenAskSprd=>Infinity
wifAxeAskPrice=>0
todClsNetBs=>0
bndCalcType=>STREET CONVENTION
prevClsBidPrc=>120
prevClsVsFut=>0
prevClsBidVsCurve=>0.004086
prevClsSimpleBpv=>0
simFutHdg=>-9999
Sov_benBidSprd=>0
aswBidStrpYld=>2.8445
todCloseDASW=>0
askASWCompSFR=>0.029089
AQ_c

# The sanatizer will disable the quotes using the following

This is called by the sanatize() method which will try to sanatize both the
buy and sell sides of the quote. If there is a failure to sanatize then

com.rbsfm.fi.pricing.ecn.pricefeed.SanitizingPriceBroker.enableQuote

# Source of the market status messages 

com.rbsfm.fi.pricing.ecn.pricefeed.SanitizingPriceBroker
