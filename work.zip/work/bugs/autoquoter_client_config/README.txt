# Addition to the _hit_lift_popupsALT.config

<template name="CEEMEA_Bond_FAK

# Change to the CEEMEA.grid.config for the books

			<books>
            <book id="CEEMEA-HUF" name="CEEMEA-HUF"/>
            <book id="CEEMEA-PLN" name="CEEMEA-PLN"/>
            <book id="CEEMEA-CZK" name="CEEMEA-CZK"/>
            <book id="CEEMEA-ZAR" name="CEEMEA-ZAR"/>
            <book id="CEEMEA-RUB" name="CEEMEA-RUB"/>
            <book id="CEEMEA-TRY" name="CEEMEA-TRY"/>
            <book id="CEEMEA-ILS" name="CEEMEA-ILS"/>
			</books>

# Exception has been thrown by the target of an invocation.

   at System.Uri..ctor(String uriString)
   at Rbsfm.FI.AutoQuoter.Service.AutoQuoterServiceFactory..ctor(IServiceConfiguration serviceConfig, IAutoQuoterServiceSettings serviceSettings, IAutoQuoterMessageSink messageSink) in c:\Development\build\aqclient.122009.9\Rbsfm.FI.AutoQuoter.Service\Factory\AutoQuoterServiceFactory.cs:line 83
   at Rbsfm.Capmarkets.AutoQuoter.Forms.MainForm.GetServiceFactory() in c:\Development\build\aqclient.122009.9\aqclient\Client\Forms\MainForm.cs:line 853
   at Rbsfm.Capmarkets.AutoQuoter.Forms.MainForm..ctor() in c:\Development\build\aqclient.122009.9\aqclient\Client\Forms\MainForm.cs:line 496
 
