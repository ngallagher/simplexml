# More security issues

2009-11-08 04:47:27.961 -0500 INFO [app-main] unknown: ****** COMPONENT CREATED BY RESOLUTION: SecurityModel
2009-11-08 04:47:27.961 -0500 INFO [app-main] unknown: ConfigurableComponentManager creating component. Name: 'SecurityModel' Class: 'com.rbsfm.SSO.security.SSOSecurityModel'...
2009-11-08 04:47:31.343 -0500 WARNING [app-main] unknown: <SSOToken> exception com.rbsfm.SSO.SOCKETSSSOException {
2009-11-08 04:47:31.343 -0500 WARNING [app-main] unknown: <SSOToken> int ErrNo=3001,
2009-11-08 04:47:31.343 -0500 WARNING [app-main] unknown: <SSOToken> java.lang.String ErrDescription="NO SERVER AVAILABLE TO SERVICE REQUEST!"
2009-11-08 04:47:31.343 -0500 WARNING [app-main] unknown: <SSOToken> }
2009-11-08 04:47:31.343 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.SSO.SSOServerManager.noHealthyServersAvailable(SSOServerManager.java:168)
2009-11-08 04:47:31.343 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.SSO.SSOServerManager.getNextServer(SSOServerManager.java:153)
2009-11-08 04:47:31.343 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.SSO.SOCKETSSSOTransport.interfaceWithServer(SOCKETSSSOTransport.java:100)
2009-11-08 04:47:31.343 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.SSO.SSOToken.interfaceWithServer(SSOToken.java:364)
2009-11-08 04:47:31.343 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.SSO.SSOToken.checkPermission(SSOToken.java:351)
2009-11-08 04:47:31.343 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.SSO.SSOToken.authenticate(SSOToken.java:272)
2009-11-08 04:47:31.343 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.SSO.SSOToken.authenticate(SSOToken.java:241)
2009-11-08 04:47:31.343 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.SSO.security.SSOSecurityModel.createToken(SSOSecurityModel.java:102)
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.common.system.BaseSecurityHelper.getSystemToken(BaseSecurityHelper.java:132)
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.fi.pricing.dependency.maintenance.PerSectorDefaultHome.<init>(PerSectorDefaultHome.java:50)
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:39)
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:27)
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at java.lang.reflect.Constructor.newInstance(Constructor.java:513)
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at java.lang.Class.newInstance0(Class.java:355)
2009-11-08 04:47:31.343 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.SSO.SOCKETSSSOTransport.interfaceWithServer(SOCKETSSSOTransport.java:100)
2009-11-08 04:47:31.343 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.SSO.SSOToken.interfaceWithServer(SSOToken.java:364)
2009-11-08 04:47:31.343 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.SSO.SSOToken.checkPermission(SSOToken.java:351)
2009-11-08 04:47:31.343 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.SSO.SSOToken.authenticate(SSOToken.java:272)
2009-11-08 04:47:31.343 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.SSO.SSOToken.authenticate(SSOToken.java:241)
2009-11-08 04:47:31.343 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.SSO.security.SSOSecurityModel.createToken(SSOSecurityModel.java:102)
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.common.system.BaseSecurityHelper.getSystemToken(BaseSecurityHelper.java:132)
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.fi.pricing.dependency.maintenance.PerSectorDefaultHome.<init>(PerSectorDefaultHome.java:50)
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:39)
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:27)
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at java.lang.reflect.Constructor.newInstance(Constructor.java:513)
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at java.lang.Class.newInstance0(Class.java:355)
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at java.lang.Class.newInstance(Class.java:308)
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.common.util.SystemUtil.newInstance(SystemUtil.java:411)
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.common.util.SystemUtil.newInstance(SystemUtil.java:280)
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.common.system.ConfigurableComponentManager.createComponent(ConfigurableComponentManager.java:17
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.common.system.ConfigurableComponentManager.getComponent(ConfigurableComponentManager.java:210)
2009-11-08 04:47:31.358 -0500 WARNING [app-main] unknown: <SSOToken>    at com.rbsfm.common.system.AbstractConfigurable.getComponent(AbstractConfigurable.java:445)


# Exceptions thrown for SSO tokens in instmaint

2009-11-08 04:48:03.303 -0500 ERROR [app-main] unknown: Could not start server: ConfigurableComponentManager failed to create component 'ControlManager': Stack Trace: com.rbsfm.com
mon.exception.ChainedRuntimeException: ConfigurableComponentManager failed to create component 'ControlManager'
        at com.rbsfm.common.system.ConfigurableComponentManager.createComponent(ConfigurableComponentManager.java:189)
        at com.rbsfm.common.system.ConfigurableComponentManager.configure(ConfigurableComponentManager.java:116)
        at com.rbsfm.common.system.App.getComponentManager(App.java:276)
        at com.rbsfm.common.system.ControlManager.getInstance(ControlManager.java:70)
        at com.rbsfm.common.system.ControlManager.getDefaultInstance(ControlManager.java:74)
        at com.rbsfm.common.system.ControlServer.main0(ControlServer.java:62)
        at com.rbsfm.common.system.ControlServer$1.run(ControlServer.java:34)
        at java.lang.Thread.run(Thread.java:619)
Caused by: com.rbsfm.common.exception.ChainedRuntimeException: ConfigurableComponentManager failed to create component 'InstrumentEnlivener'
        at com.rbsfm.common.system.ConfigurableComponentManager.createComponent(ConfigurableComponentManager.java:189)
        at com.rbsfm.common.system.ConfigurableComponentManager.getComponent(ConfigurableComponentManager.java:210)
        at com.rbsfm.common.system.AbstractConfigurable.getComponent(AbstractConfigurable.java:445)
        at com.rbsfm.common.system.AbstractConfigurable.getReferencedComponent(AbstractConfigurable.java:408)
        at com.rbsfm.common.system.AbstractConfigurable.getReferencedComponent(AbstractConfigurable.java:366)
        at com.rbsfm.fi.instmaint.persist.InstrumentEnlivenerManager.configure(InstrumentEnlivenerManager.java:26)
        at com.rbsfm.common.system.ConfigurableComponentManager.createComponent(ConfigurableComponentManager.java:180)
        at com.rbsfm.common.system.ConfigurableComponentManager.getComponent(ConfigurableComponentManager.java:210)
        at com.rbsfm.fi.pricing.dependency.bond.InternalBondNode.configure(InternalBondNode.java:100)
        at com.rbsfm.fi.pricing.dependency.util.TreeUtil.newNodeInstance(TreeUtil.java:191)
        at com.rbsfm.fi.pricing.dependency.tree.TreeUpdateManagerImpl.createRealNode(TreeUpdateManagerImpl.java:357)
        at com.rbsfm.fi.pricing.dependency.tree.TreeUpdateManagerImpl.addNode(TreeUpdateManagerImpl.java:122)
        at com.rbsfm.fi.pricing.dependency.tree.AbstractTreePersistenceManager.populateNodeStore(AbstractTreePersistenceManager.java:718)
        at com.rbsfm.fi.pricing.dependency.tree.AbstractTreePersistenceManager.init(AbstractTreePersistenceManager.java:376)
        at com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree.configure(AbstractDependencyTree.java:262)
        at com.rbsfm.fi.pricing.dependency.tree.DependencyTreeImpl.configure(DependencyTreeImpl.java:47)
        at com.rbsfm.common.system.ConfigurableComponentManager.createComponent(ConfigurableComponentManager.java:180)
        at com.rbsfm.common.system.ConfigurableComponentManager.getComponent(ConfigurableComponentManager.java:210)
        at com.rbsfm.fi.pricing.dependency.index.IndexDataAdapterImpl$DependencyTreeIndexNameProvider.<init>(IndexDataAdapterImpl.java:194)
        at com.rbsfm.fi.pricing.dependency.index.IndexDataAdapterImpl.configure(IndexDataAdapterImpl.java:60)
        at com.rbsfm.common.system.ConfigurableComponentManager.createComponent(ConfigurableComponentManager.java:180)
        at com.rbsfm.common.system.ConfigurableComponentManager.getComponent(ConfigurableComponentManager.java:210)
        at com.rbsfm.fi.pricing.newanalytics.factory.AnalyticsDbIndexIniter.init(AnalyticsDbIndexIniter.java:17)
        at com.rbsfm.fi.pricing.newanalytics.factory.AnalyticsDbIniter.initAnaltyicsIndices(AnalyticsDbIniter.java:31)
        at com.rbsfm.fi.pricing.newanalytics.factory.AnalyticsIniter.configure(AnalyticsIniter.java:141)
        at com.rbsfm.fi.pricing.newanalytics.factory.AnalyticsDbIniter.configure(AnalyticsDbIniter.java:19)
        at com.rbsfm.common.system.ConfigurableComponentManager.createComponent(ConfigurableComponentManager.java:180)
        at com.rbsfm.common.system.ConfigurableComponentManager.getComponent(ConfigurableComponentManager.java:210)
        at com.rbsfm.common.system.DigestProperties.configure(DigestProperties.java:197)
        at com.rbsfm.common.system.ConfigurableComponentManager.createComponent(ConfigurableComponentManager.java:180)
        at com.rbsfm.common.system.ConfigurableComponentManager.getComponent(ConfigurableComponentManager.java:210)
        at com.rbsfm.common.system.AbstractConfigurable.getComponent(AbstractConfigurable.java:445)
        at com.rbsfm.common.system.AbstractConfigurable.getReferencedComponent(AbstractConfigurable.java:408)
        at com.rbsfm.common.system.AbstractConfigurable.getReferencedComponent(AbstractConfigurable.java:376)
        at com.rbsfm.common.system.SystemStatsDigestProvider.configure(SystemStatsDigestProvider.java:36)
        at com.rbsfm.common.system.ConfigurableComponentManager.createComponent(ConfigurableComponentManager.java:180)
        ... 7 more
Caused by: com.rbsfm.common.exception.ChainedRuntimeException: ConfigurableComponentManager failed to create component 'PerSectorDefaultHome'
        at com.rbsfm.common.system.ConfigurableComponentManager.createComponent(ConfigurableComponentManager.java:189)
        at com.rbsfm.common.system.ConfigurableComponentManager.getComponent(ConfigurableComponentManager.java:210)
        at com.rbsfm.common.system.AbstractConfigurable.getComponent(AbstractConfigurable.java:445)
        at com.rbsfm.common.system.AbstractConfigurable.getReferencedComponent(AbstractConfigurable.java:408)
        at com.rbsfm.common.system.AbstractConfigurable.getReferencedComponent(AbstractConfigurable.java:366)
        at com.rbsfm.fi.instmaint.persist.InstrumentEnlivener.configure(InstrumentEnlivener.java:91)
        at com.rbsfm.common.system.ConfigurableComponentManager.createComponent(ConfigurableComponentManager.java:180)
        ... 42 more
Caused by: exception com.natwestgfm.SSO.SSOClientException {
int ErrNo=3007,
java.lang.String ErrDescription="exception com.rbsfm.SSO.SOCKETSSSOException {
int ErrNo=3001,
java.lang.String ErrDescription="NO SERVER AVAILABLE TO SERVICE REQUEST!"
}"
}
        at com.rbsfm.SSO.SSOToken.interfaceWithServer(SSOToken.java:402)
        at com.rbsfm.SSO.SSOToken.checkPermission(SSOToken.java:351)
        at com.rbsfm.SSO.SSOToken.authenticate(SSOToken.java:272)
        at com.rbsfm.SSO.SSOToken.authenticate(SSOToken.java:241)
        at com.rbsfm.SSO.security.SSOSecurityModel.createToken(SSOSecurityModel.java:102)
        at com.rbsfm.common.system.BaseSecurityHelper.getSystemToken(BaseSecurityHelper.java:132)
        at com.rbsfm.fi.pricing.dependency.maintenance.PerSectorDefaultHome.<init>(PerSectorDefaultHome.java:50)
        at sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)
        at sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:39)
        at sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:27)
        at java.lang.reflect.Constructor.newInstance(Constructor.java:513)
        at java.lang.Class.newInstance0(Class.java:355)
        at java.lang.Class.newInstance(Class.java:308)
        at com.rbsfm.common.util.SystemUtil.newInstance(SystemUtil.java:411)
        at com.rbsfm.common.util.SystemUtil.newInstance(SystemUtil.java:280)
        at com.rbsfm.common.system.ConfigurableComponentManager.createComponent(ConfigurableComponentManager.java:174)
        ... 48 more

2009-11-08 04:48:03.454 -0500 INFO [Thread-0] unknown: ShutdownManager shutdown invoked...
2009-11-08 04:48:03.469 -0500 INFO [Thread-0] unknown: ControlManager stopping controls...
2009-11-08 04:48:03.469 -0500 INFO [Thread-0] unknown: ControlManager stopped controls
2009-11-08 04:48:03.469 -0500 INFO [Thread-0] unknown: ShutdownManager tasks complete
2009-11-09 04:33:03.673 -0500 INFO [app-main] unknown: File logger registered. Will write to file: d:/dev/rbsfm/log/latam-pricing-instmaint.log.%n
2009-11-09 04:33:03.736 -0500 INFO [app-main] unknown: ConfigurableComponentManager creating component. Name: 'logger.memory' Class: 'com.rbsfm.common.logger.InMemoryLogger'...
2009-11-09 04:33:03.736 -0500 INFO [app-main] unknown: ConfigurableComponentManager creating component. Name: 'logger.log4j.error' Class: 'com.rbsfm.common.logger.Log4jLogger'...
2009-11-09 04:33:04.314 -0500 WARNING [app-main] unknown: <PropertySetter> log4j:WARN No such property [file] in com.rbsfm.common.logger.ThrottledNTEventLogAppender.
g-instmaint/log4j.properties]
2009-11-09 04:33:04.360 -0500 INFO [app-main] unknown: ConfigurableComponentManager creating component. Name: 'LogAdmin' Class: 'com.rbsfm.common.logger.LogAdmin'...

