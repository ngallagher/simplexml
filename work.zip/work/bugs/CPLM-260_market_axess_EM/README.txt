# The following password should be used for production

maapi.username..prod.marketaxess.mainventory.stamford=rbsmactives
maapi.password..prod.marketaxess.mainventory.stamford=dealer12

# Missing DTD file in production

For some reason production MAAPI requires the file ma.dtd to be located in d:\prod\rbsfm\cp\dtd\.
If the file is not there then there is an exception thrown and nothing will start.

# The following libraries must be used

xalan.jar
jdom-1.0.jar

# Until further investigation is performed the log4j.properties file needs to be hacked

log4j.rootCategory=ERROR, A
log4j.logger.SQL=SQLTRACE#com.rbsfm.common.logger.SQLTraceLevel, SQL
log4j.appender.A=com.rbsfm.common.logger.ThrottledNTEventLogAppender
log4j.appender.SQL=org.apache.log4j.RollingFileAppender
log4j.additivity.A=false
log4j.additivity.SQL=false
log4j.appender.A.layout= org.apache.log4j.PatternLayout
log4j.appender.A.layout.ConversionPattern=%d %-5p %m%n
log4j.appender.SQL.layout=org.apache.log4j.PatternLayout
log4j.appender.SQL.layout.ConversionPattern=%d %m%n
log4j.appender.SQL.File=${log.dir}/${serverName}.sql
log4j.appender.SQL.MaxFileSize=1024MB
log4j.appender.SQL.MaxBackupIndex=


# Secondary require in the host details file

For host details there are dedicated secondary hosts. The server must be 
specified in that secondary section like so.

  <host name="" hostname="lon3731xns" type="secondary" location="london">
    <server name="marketaxess-mainventory-stamford"/>
  </host>

# Prod server details

    <server servername="marketaxess-mainventory-stamford" servertype="GW">
      <hosts>
        <hostdetails name="primary">
          <hostattribute name="hostname" value="trums00053"/>
          <hostattribute name="socket_port" value="60050"/>
          <hostattribute name="jmx_port" value="60051"/>
          <hostattribute name="availability_check_port" value="60059"/>
        </hostdetails>
        <hostdetails name="secondary">
          <hostattribute name="hostname" value="grnms00025"/>
          <hostattribute name="socket_port" value="60050"/>
          <hostattribute name="jmx_port" value="60051"/>
          <hostattribute name="availability_check_port" value="60059"/>
        </hostdetails>
        <hostdetails name="tertiary">
          <hostattribute name="hostname" value="shlms00013"/>
          <hostattribute name="socket_port" value="60050"/>
          <hostattribute name="jmx_port" value="60051"/>
          <hostattribute name="availability_check_port" value="60059"/>
        </hostdetails>
     </hosts>

# Prices need to be inverted on market axess

Strange as it seems the BID takes the offer price and the OFFER takes the bid
nverprice. This is require for market axess to publish. - THIS WAS REPORTED
BY MARKETAXESS BUT IT MAY NOT BE TRUE.

# Deployment hosts for the market axess gateway uat

  <host name="" hostname="stams00024" type="primary" location="greenwich">
      <server name="marketaxess-mainventory-stamford"/>
  </host>  

# Deployment hosts for the market axess gateway cont

  <host name="" hostname="stams00024" type="primary" location="greenwich">
      <server name="marketaxess-mainventory-stamford" disabled="true"/>
  </host>  

# Deployment hosts for the market axess gateway prod

  <host name="" hostname="shlms00013" type="tertiary" location="greenwich">
    <server name="marketaxess-mainventory-stamford" disabled="true"/>   
  </host>

  <host name="" hostname="trums00053" type="primary" location="greenwich">
      <server name="marketaxess-mainventory-stamford"/>
  </host>  

  <host name="" hostname="grnms00025" type="secondary" location="greenwich">
    <server name="marketaxess-mainventory-stamford" disabled="true"/>
  </host> 

# The following tag contains the changes taged frmo marketaxess-magw-4_5_0 

source: marketaxess-magw-4_5_0 
tag: marketaxess-magw-4_5_0_latam
branch: marketaxess-magw-4_5_0_local_markets_branch

# These are the price feeds that point the mainventory master

eurosupra-ecnpricefeed-master
sterlingsupra-ecnpricefeed-master
ussupra-ecnpricefeed-master

# In order for this to work the following files need to be patched for ecnpricefeed

D:\uat\rbsfm\cp\latam-0_0_7\lib>d:\java\jdk1.5.0_11\bin\jar.exe tvf MarketAxessECNPriceFeedPatch.jar
    25 Thu Aug 06 16:42:36 EDT 2009 META-INF/MANIFEST.MF
   967 Thu Aug 06 15:19:30 EDT 2009 com/rbsfm/fi/marketaxess/external/detail/InventoryDeleteAllDetails.class
   839 Thu Aug 06 15:19:30 EDT 2009 com/rbsfm/fi/marketaxess/external/detail/InventoryUpdateDetails.class
  4967 Thu Aug 06 15:19:30 EDT 2009 com/rbsfm/fi/marketaxess/external/detail/InventoryDetails.class
   839 Thu Aug 06 15:19:30 EDT 2009 com/rbsfm/fi/marketaxess/external/detail/InventoryDeleteDetails.class
  4374 Thu Aug 06 15:19:28 EDT 2009 com/rbsfm/fi/marketaxess/external/detail/mux/InventoryUpdateMessage.class
  3107 Thu Aug 06 15:19:30 EDT 2009 com/rbsfm/fi/marketaxess/external/detail/mux/InventoryDeleteAllMessage.class
  4374 Thu Aug 06 15:19:28 EDT 2009 com/rbsfm/fi/marketaxess/external/detail/mux/InventoryDeleteMessage.class

These contain additional attributes for the bid and offer prices.

# Use the following to build

ant -Dconfig.group=rates -Dinstall.id=gallane_6_aug_09 -Denv=uat -Dinclude.servers.regex=marketaxess-.* -Drebuild=true

This will have to be done with a 1.5 JDK so set the "Path" environment variable. Ensure that
the "bin" directory of the 1.5 JDK is the first in the pat so it is no overridden by the
system JDK in c:\WINDOWS\system32

Also the JAVA_HOME env variable needs to be set as Ant will resolve to a different compile time
JDK if you do not.

# Add an new XML element to the config, this will take care of the IQLEVELS session establishment

<sessionId>IQLEVELS</sessionId>

# Branch that is in use is

marketaxess-magw-4_5_0_local_markets_branch

# Login message for trader is

<?xml version='1.0'?>
<!DOCTYPE MA SYSTEM 'ma.dtd'>
<MA>
<HEADER>
<MESSAGE-ID>3</MESSAGE-ID>
<MESSAGE-TYPE>REQUEST</MESSAGE-TYPE>
<MESSAGE-VERSION>2.7.0</MESSAGE-VERSION>
</HEADER>
<CONNECTION>
<TRADING-SESSION STATUS="ACTIVE">
<USERNAME>rbsuk01</USERNAME>
<PASSWORD>market123</PASSWORD>
</TRADING-SESSION>
</CONNECTION>
</MA>

# Set the defaul trader

maapi.defaulttrader=rbsuk01
maapi.defaulttraderpassword=market123

# Set the API session to IQLEVELS

-Xrunjdwp:transport=dt_socket,address=60039,suspend=y,server=y

In order to send an IQLEVELS message you must have the following settings
for the Session object.


		<tradingSession>
			<defaultTrader>${maapi.defaulttrader}</defaultTrader>
			<defaultTraderPassword>${maapi.defaulttraderpassword}</defaultTraderPassword>
			<traderMappingHome>EcnTraderMappingHome</traderMappingHome>
		</tradingSession>

Also for the EcnTraderMappingHome use the following

	<component name="DbRowModificationHome" class_name="com.rbsfm.neutrino.modification.DbRowModificationHome">
		<dbName>FiDb</dbName>
		<tableName>RowModification</tableName>
		<jmxDomain>HOMES</jmxDomain>
	</component>
	<component name="EcnTraderMappingHome" class_name="com.rbsfm.fi.pricing.ecn.tradermapping.DbEcnTraderMappingHome">
		<dbName>FiDb</dbName>
		<autoload>true</autoload>
		<set_poller>true</set_poller>
		<db_poller>DbRowModificationPoller</db_poller>
		<jmxDomain>HOMES</jmxDomain>
	</component>
	<component name="DbRowModificationPoller" class_name="com.rbsfm.neutrino.modification.DbRowModificationPollerImpl">
		<homeName>DbRowModificationHome</homeName>
		<pollIntervalMs>1000</pollIntervalMs>
		<jmxDomain>HOMES</jmxDomain>
		<logPolledInModifications>false</logPolledInModifications>
	</component>

# Each of the messages requires a new XML adapter

marketaxess.adapter.update=com.rbsfm.fi.marketaxess.external.detail.xml.InventoryUpdateMessageXmlAdapter
marketaxess.adapter.delete=com.rbsfm.fi.marketaxess.external.detail.xml.InventoryDeleteMessageXmlAdapter
marketaxess.adapter.deleteall=com.rbsfm.fi.marketaxess.external.detail.xml.InventoryDeleteAllMessageXmlAdapter

marketaxess.adapter.update..marketaxess.mainventory.stamford=com.rbsfm.fi.marketaxess.external.detail.xml.InstrumentQuoteUpdateMessageXmlAdapter
marketaxess.adapter.delete..marketaxess.mainventory.stamford=com.rbsfm.fi.marketaxess.external.detail.xml.InstrumentQuoteDeleteMessageXmlAdapter
marketaxess.adapter.deleteall..marketaxess.mainventory.stamford=com.rbsfm.fi.marketaxess.external.detail.xml.InstrumentQuoteDeleteAllMessageXmlAdapter

# Message taylored for EM

<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE MA SYSTEM "ma.dtd">
<MA>
    <INSTRUMENT-QUOTE ACTION="UPDATE" FIRM="N">
        <SENDER-SYSTEM>latam-ecnpricefeed-offshore</SENDER-SYSTEM>
        <SECURITY>
            <ISIN>US105756AV22</ISIN>
        </SECURITY>
        <QUOTE>
            <PRICE PRICE-TYPE="BID">
                <REAL>123.45</REAL>
                <SIZE>1000</SIZE>
            </PRICE>
            <PRICE PRICE-TYPE="OFFER">
                <REAL>123.95</REAL>
                <SIZE>1000</SIZE>
            </PRICE>
        </QUOTE>
        <TRADING-BOOK-NAME>latam</TRADING-BOOK-NAME>
    </INSTRUMENT-QUOTE>
</MA>

# The user name and password

maapi.username..marketaxess.mainventory.stamford=rbsemapi
maapi.password..marketaxess.mainventory.stamford=test123

# Message out to the market axess system

<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE MA SYSTEM "ma.dtd">
<MA>
    <INSTRUMENT-QUOTE ACTION="UPDATE" FIRM="N">
        <SENDER-SYSTEM>latam-ecnpricefeed-offshore</SENDER-SYSTEM>
        <SECURITY>
            <ISIN>US105756AV22</ISIN>
        </SECURITY>
        <QUOTE>
            <BENCHMARK>
                <ISIN>US912828LD08</ISIN>
            </BENCHMARK>
            <PRICE PRICE-TYPE="BID">
                <SPREAD>-2197.2</SPREAD>
                <SIZE>1000</SIZE>
            </PRICE>
            <PRICE PRICE-TYPE="OFFER">
                <SPREAD>-2250.8</SPREAD>
                <SIZE>1000</SIZE>
            </PRICE>
        </QUOTE>
        <TRADING-BOOK-NAME>latam</TRADING-BOOK-NAME>
    </INSTRUMENT-QUOTE>
</MA>

# To execute the SQL in the update file use

isql -S UAT -U fi_latam_server -P svrpwd -D fi_LATAM_uat -i UPDATE.sql

Making sure that your sql.ini file has an entry like the following.

[UAT] 
master=NLWNSCK,trussdb0022.gcm.com,2050
query=NLWNSCK,trussdb0022.gcm.com,205

# This can be used to add the maPrcPub attribute for market axess publication

exec EcnSanitizerInstCtrlStore 'AQ Orders', 'US105756BJ84', 'maPrcPub', 'ON', 1, 'gallane', 'gallane'
exec EcnSanitizerInstCtrlStore 'AQ Orders', 'US91911TAE38', 'maPrcPub', 'ON', 1, 'gallane', 'gallane'
select * from EcnSanitizerInstCtrl where InstrumentRef like 'US91911TAE38'

# To turn the price feed back on again use the following

  <component name="D2CCompositeEcnPublisher" lazy="true" class_name="com.rbsfm.fi.pricing.ecn.pricefeed.CompositeEcnPublisher">
    <id>D2C</id>
    <incomingListener enabled="${bloomberg_indicative_enabled}">RvIndicativePricePublisher</incomingListener>
    <incomingListener enabled="false">MarketAxessPublisher</incomingListener> <----------------------- THIS MUST BE TRUE
    <incomingListener enabled="${bondvision_enabled}">BondVisionPublisher</incomingListener>
    <outgoingListener>PriceFeedMuxClient</outgoingListener>
    <autoEnable>true</autoEnable>
  	<fastMarketStatusProvider>FastMarketStatusProvider</fastMarketStatusProvider>
  </component>

# The ultimate delivery is done here

com.rbsfm.fi.pricing.mux.mlist.MessageQueue.tryPush(com.rbsfm.fi.pricing.mux.Message) line: 220	
com.rbsfm.fi.pricing.mux.socket.AsyncSocketQueue(com.rbsfm.fi.pricing.mux.socket.SocketQueue).enqueueOrWrite(com.rbsfm.fi.pricing.mux.Message) line: 286	
com.rbsfm.fi.pricing.mux.socket.AsyncSocketQueue(com.rbsfm.fi.pricing.mux.socket.SocketQueue).addMessage(com.rbsfm.fi.pricing.mux.Message) line: 256	
com.rbsfm.fi.pricing.mux.socket.SocketClientSource$RemoteSink.addMessage(com.rbsfm.fi.pricing.mux.Message) line: 361	
com.rbsfm.fi.pricing.mux.socket.XMLProtocolConverter.sendMessage(com.rbsfm.fi.pricing.mux.Message, com.rbsfm.fi.pricing.mux.socket.MessageChannel[], com.rbsfm.fi.pricing.mux.socket.MessageChannel) line: 64	
com.rbsfm.fi.pricing.mux.socket.XMLProtocolConverter.sendMessage(com.rbsfm.fi.pricing.mux.Message, com.rbsfm.fi.pricing.mux.socket.MessageChannel[]) line: 54	
com.rbsfm.fi.pricing.mux.socket.SocketClientSource.processMessage(com.rbsfm.fi.pricing.mux.Message) line: 216	
com.rbsfm.fi.marketaxess.pricefeed.MarketAxessPriceFeedAdaptor.performQuoteUpdated(com.rbsfm.fi.pricing.external.detail.EcnFeedPriceDetails) line: 185	
com.rbsfm.fi.marketaxess.pricefeed.MarketAxessPriceFeedAdaptor(com.rbsfm.fi.pricing.ecn.pricefeed.AbstractEcnPublisher).throttledQuoteUpdated(com.rbsfm.fi.pricing.external.detail.EcnFeedPriceDetails) line: 775	
com.rbsfm.fi.pricing.ecn.pricefeed.AbstractEcnPublisher$ThrottleConsumer.run() line: 71	


# This is where we determine the type of message

com.rbsfm.fi.marketaxess.pricefeed.MarketAxessPriceFeedAdaptor.performQuoteUpdated(com.rbsfm.fi.pricing.external.detail.EcnFeedPriceDetails) line: 179	
com.rbsfm.fi.marketaxess.pricefeed.MarketAxessPriceFeedAdaptor(com.rbsfm.fi.pricing.ecn.pricefeed.AbstractEcnPublisher).throttledQuoteUpdated(com.rbsfm.fi.pricing.external.detail.EcnFeedPriceDetails) line: 775	
com.rbsfm.fi.pricing.ecn.pricefeed.AbstractEcnPublisher$ThrottleConsumer.run() line: 71	

    if (enabled){
      msg = new InventoryUpdateMessage("EI", mSourceSystem, generateInventoryUpdateDetails(details));
    } else {
      msg = new InventoryDeleteMessage("EI", mSourceSystem, generateInventoryDeleteDetails(details));
    }

The reason we are not publishing is because details.isEnabled() is true. This means that inventoryPriceNeedsUpdating 
will always return false.


# The price feed tells the MarketAxessPublisher the following

com.rbsfm.fi.marketaxess.pricefeed.MarketAxessPriceFeedAdaptor(com.rbsfm.fi.pricing.ecn.pricefeed.AbstractEcnPublisher).processUpdate(java.lang.String, com.rbsfm.fi.pricing.external.detail.EcnFeedPriceDetails) line: 496	
com.rbsfm.fi.marketaxess.pricefeed.MarketAxessPriceFeedAdaptor(com.rbsfm.fi.pricing.ecn.pricefeed.AbstractEcnPublisher).internalQuoteUpdated(com.rbsfm.fi.pricing.external.detail.EcnFeedPriceDetails, boolean) line: 484	
com.rbsfm.fi.marketaxess.pricefeed.MarketAxessPriceFeedAdaptor(com.rbsfm.fi.pricing.ecn.pricefeed.AbstractEcnPublisher).quoteUpdated(com.rbsfm.fi.pricing.external.detail.EcnFeedPriceDetails, boolean) line: 477	
com.rbsfm.fi.pricing.ecn.pricefeed.SanitizingPriceBroker(com.rbsfm.fi.pricing.ecn.pricefeed.AbstractPriceFeedBroker).notifyListeners(com.rbsfm.fi.pricing.external.detail.EcnFeedPriceDetails, boolean) line: 1604	
com.rbsfm.fi.pricing.ecn.pricefeed.SanitizingPriceBroker.consumeBondPrice(com.rbsfm.fi.pricing.ecn.EcnQuote, com.rbsfm.fi.pricing.ecn.EcnQuote, com.rbsfm.external.fi.pricing.detail.ExternalBondPriceDetails, boolean) line: 545	
com.rbsfm.fi.pricing.ecn.pricefeed.SanitizingPriceBroker(com.rbsfm.fi.pricing.ecn.pricefeed.AbstractPriceFeedBroker).consumePrice(com.rbsfm.fi.pricing.ecn.EcnQuote, com.rbsfm.fi.pricing.ecn.EcnQuote, java.lang.Object, boolean) line: 1205	
com.rbsfm.fi.pricing.ecn.pricefeed.SanitizingPriceBroker(com.rbsfm.fi.pricing.ecn.pricefeed.AbstractPriceFeedBroker).consumePrice(java.lang.String, java.lang.Object, boolean) line: 1266	
com.rbsfm.fi.pricing.ecn.pricefeed.SanitizingPriceBroker(com.rbsfm.fi.pricing.ecn.pricefeed.AbstractPriceFeedBroker).consumePrice(java.lang.String, java.lang.Object) line: 1231	
com.rbsfm.fi.pricing.ecn.mux.ExternalDetailsSubscriber.notifyPriceConsumers(com.rbsfm.external.fi.pricing.detail.ExternalDetails) line: 229	
com.rbsfm.fi.pricing.ecn.mux.ExternalDetailsSubscriber.processPrice(com.rbsfm.external.fi.pricing.detail.ExternalDetails) line: 360	
com.rbsfm.fi.pricing.ecn.mux.ExternalDetailsSubscriber.processDetails(java.util.Collection) line: 139	
com.rbsfm.fi.pricing.external.detail.mux.ExternalDetailsSource$ConsumerDetails.processDetails(com.rbsfm.fi.pricing.mux.Message, java.lang.Object) line: 64	
com.rbsfm.fi.pricing.external.detail.mux.ExternalDetailsSource.notifyConsumers(java.lang.Object, com.rbsfm.fi.pricing.mux.Message) line: 288	
com.rbsfm.fi.pricing.external.detail.mux.ExternalDetailsSource.internalProcessMessage(com.rbsfm.fi.pricing.mux.Message) line: 251	
com.rbsfm.fi.pricing.external.detail.mux.ExternalDetailsSource(com.rbsfm.fi.pricing.mux.QueueSourceSink).internalRun() line: 168	
com.rbsfm.fi.pricing.mux.QueueSourceSink.access$000(com.rbsfm.fi.pricing.mux.QueueSourceSink) line: 16	
com.rbsfm.fi.pricing.mux.QueueSourceSink$1.run() line: 79	
java.lang.Thread.run() line: 619	


# Ensure the ecnpricefeed sends to market axess

Here we need to ensure that the MarketAxessPublisher is hooked up to the EcnPublisherManager. This
will ensure that messages can be sent to MarketAxess. Also the following property needs to be set
in env.properties.

marketaxess.enabled..latam=true

  <component name="EcnPublisherManager" class_name="com.rbsfm.fi.pricing.ecn.pricefeed.EcnPublisherManager">
    <bookControlHome>AutoQuoteBookControlHome</bookControlHome>
    <sanitizer>Sanitizer</sanitizer>
    <publishers>
        <publisher name="MpfClosePricePublisher"/>
        <publisher name="MpfIndicativePricePublisher"/>
        <publisher name="RvIndicativePricePublisher"/>
        <publisher name="RvRTRSIndicativePricePublisher"/>
        <publisher name="MarketAxessPublisher"/>
    </publishers>
    <userMessageListeners>
      <listener name="PriceFeedMuxClient" /> 
    </userMessageListeners>
    <sanitizedPublisherRules>    
    </sanitizedPublisherRules>        
    <useThreads>${ecn_publisher_use_threads}</useThreads>
    <threadPool>SystemThreadPool</threadPool>    
    <sanitizedBookRules>    
    </sanitizedBookRules>
  </component>

# The message information

The information we get from the ECN pricefeed server is as follows. It sends on the
XML formatted message.

com.rbsfm.fi.pricing.mux.MessageImpl 
id=US76113BAM19, 
type=MAInventoryD 
msg=<?xml version="1.0" encoding="UTF-8"?>
<msg sourceType="   EI" 
    sourceName="                         corp-ecnpricefeed-master1" 
    id="                                      US76113BAM19" 
    group="0000000000000000000" type="              MAInventoryD" 
    destination="                               *">
        <body senderSystem="corp-ecnpricefeed-master1" 
               isin="US76113BAM19" 
               benchIsin="US912828KY53" 
               bidSpread="-158.769483" 
               bidSize="5000000" 
               offerSpread="-163.769483" 
               offerSize="5000000" 
               book="C1 - AutoMed"/>
</msg>

# This is the stack trace for messages from the price feed

com.rbsfm.fi.marketaxess.message.HeartBeatMonitor.processMessage(com.rbsfm.fi.pricing.mux.Message) line: 96	
com.rbsfm.fi.pricing.mux.Source$SourceCollection.processMessage(com.rbsfm.fi.pricing.mux.Message) line: 60	
com.rbsfm.fi.pricing.mux.socket.SocketServerSink(com.rbsfm.fi.pricing.mux.socket.AbstractSocketMessageReader).notifySources(com.rbsfm.fi.pricing.mux.Message) line: 254	
com.rbsfm.fi.pricing.mux.socket.SocketServerSink.onMessage(com.rbsfm.fi.pricing.mux.Message, java.nio.channels.SocketChannel) line: 281	
com.rbsfm.fi.pricing.mux.socket.SocketServerSink(com.rbsfm.fi.pricing.mux.socket.AbstractSocketMessageReader).readAndDispatch(java.nio.channels.SocketChannel) line: 189	
com.rbsfm.fi.pricing.mux.socket.SocketServerSink$ReaderThread.run() line: 254	


# The  build of the MarketAxess gateway is driven off server_details.xml

  <server_group name="marketaxess">
    <!-- etc... -->
    <server servername="marketaxess-maposttrade-master" servertype="GW" baseport="60030"/>
    <server servername="marketaxess-mainventory-stamford" servertype="GW" baseport="60031"/>
  </server_group>    

In the above we have an entry for "marketaxess-mainventory-stamford" this will result in a
build for marketaxess-.* creating a marketaxess-mainventory-stamford.(ini,exe,xml) file. The 
XML configuration is derived from mainventory.xml


# Change the properties

marketaxess.adapter.update=com.rbsfm.fi.marketaxess.external.detail.xml.InventoryUpdateMessageXmlAdapter
marketaxess.adapter.delete=com.rbsfm.fi.marketaxess.external.detail.xml.InventoryDeleteMessageXmlAdapter
marketaxess.adapter.deleteall=com.rbsfm.fi.marketaxess.external.detail.xml.InventoryDeleteAllMessageXmlAdapter

marketaxess.adapter.update..marketaxess.mainventory.stamford=com.rbsfm.fi.marketaxess.external.detail.xml.InstrumentQuoteUpdateMessageXmlAdapter

# Change to the configuration required

  <component name="XmlAdapterManager" class_name="com.rbsfm.common.xml.XmlAdapterManager">
    <adapters>
      <!-- Details classes -->
      <adapter class_name="${marketaxess.adapter.update}"/>
      <adapter class_name="${marketaxess.adapter.delete}"/>
      <adapter class_name="${marketaxess.adapter.deleteall}"/>
    </adapters>
  </component>


# Configuration of the messages are
  <component name="XmlAdapterManager" class_name="com.rbsfm.common.xml.XmlAdapterManager">
    <adapters>
      <!-- Details classes -->
      <adapter class_name="com.rbsfm.fi.marketaxess.external.detail.xml.InventoryUpdateMessageXmlAdapter"/>
      <adapter class_name="com.rbsfm.fi.marketaxess.external.detail.xml.InventoryDeleteMessageXmlAdapter"/>
      <adapter class_name="com.rbsfm.fi.marketaxess.external.detail.xml.InventoryDeleteAllMessageXmlAdapter"/>
    </adapters>
  </component>

# The adapter map, for EM we need to inject a different type
{class com.rbsfm.fi.marketaxess.external.detail.InventoryUpdateDetails=com.rbsfm.fi.marketaxess.external.detail.xml.InventoryUpdateMessageXmlAdapter@1512ff1,
 class com.rbsfm.fi.marketaxess.external.detail.InventoryDeleteAllDetails=com.rbsfm.fi.marketaxess.external.detail.xml.InventoryDeleteAllMessageXmlAdapter@8d03b,
 class com.rbsfm.fi.marketaxess.external.detail.InventoryDeleteDetails=com.rbsfm.fi.marketaxess.external.detail.xml.InventoryDeleteMessageXmlAdapter@9efea4}

# The actual adapter
com.rbsfm.fi.marketaxess.external.detail.xml.InventoryUpdateMessageXmlAdapter@1512ff1

# XML message
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE MA SYSTEM "ma.dtd">
<MA>
    <INVENTORY ACTION="UPDATE">
        <SENDER-SYSTEM>eurosupra-ecnpricefeed-master</SENDER-SYSTEM>
        <SECURITY>
            <ISIN>DE0002760790</ISIN>
        </SECURITY>
        <QUOTE>
            <BENCHMARK>
                <ISIN>DE0001135218</ISIN>
            </BENCHMARK>
            <PRICE PRICE-TYPE="BID">
                <SPREAD>276.18236599</SPREAD>
                <SIZE>0</SIZE>
            </PRICE>
            <PRICE PRICE-TYPE="OFFER">
                <SPREAD>263.18715241</SPREAD>
                <SIZE>0</SIZE>
            </PRICE>
        </QUOTE>
        <TRADING-BOOK-NAME>eurosupra</TRADING-BOOK-NAME>
    </INVENTORY>
</MA>



# Input object
(InventoryUpdateDetails) action [Update] isin [DE0002760790] benchmark isin [DE0001135218] bid spread [276.18236599] bid size [0] offer spread [263.18715241] offer size [0] sender system [eurosupra-ecnpricefeed-master] book [eurosupra] 

# Call trace
com.rbsfm.fi.marketaxess.message.MessageWriter.createXmlString(java.lang.Object) line: 128	
com.rbsfm.fi.marketaxess.message.MessageWriter.writeMessage(java.lang.Object) line: 109	
com.rbsfm.fi.marketaxess.message.MessageWriter.processDetails(java.util.Collection) line: 104	
com.rbsfm.fi.marketaxess.external.detail.Throttler.run() line: 103	
java.lang.Thread.run() line: 619	

