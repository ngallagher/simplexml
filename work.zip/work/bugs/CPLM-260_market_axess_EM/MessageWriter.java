package com.rbsfm.fi.marketaxess.message;

import java.util.Collection;
import java.util.Iterator;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.rbsfm.common.config.Config;
import com.rbsfm.common.config.Configurable;
import com.rbsfm.common.system.Administrable;
import com.rbsfm.common.system.App;
import com.rbsfm.common.system.Control;
import com.rbsfm.common.system.Log;
import com.rbsfm.common.system.ShutdownManager;
import com.rbsfm.common.util.StringUtil;
import com.rbsfm.common.xml.DocumentFactory;
import com.rbsfm.common.xml.XMLPrinter;
import com.rbsfm.common.xml.XMLWriter;
import com.rbsfm.common.xml.XmlAdapter;
import com.rbsfm.common.xml.XmlAdapterManager;
import com.rbsfm.fi.marketaxess.external.detail.InventoryDeleteAllDetails;
import com.rbsfm.fi.marketaxess.external.detail.InventoryUpdateDetails;
import com.rbsfm.fi.marketaxess.external.detail.mux.MABaseMessageInterface;
import com.rbsfm.fi.marketaxess.session.util.LegacySessionAdapter;
import com.rbsfm.fi.pricing.external.detail.DetailsConsumer;
import com.rbsfm.fi.pricing.external.detail.FIConfig;

public class MessageWriter implements DetailsConsumer, Control, Configurable, Administrable {

  private String mName;
  private boolean mIsActive = false;
  private LegacySessionAdapter mConnection; 
  private XmlAdapterManager mXmlAdapterManager;
  private String mDTD;
  private RequestConsumer[] mRequestConsumers;
  
  private boolean shuttingDown;

  public void configure(Config config) {
    mName = config.getStringValue("name");

    String connectionName = config.getStringValue("connection");
    mConnection = (LegacySessionAdapter)App.getComponentManager().getComponent(connectionName);

    String adapterManagerName = config.getStringValue("xmlAdapterManager");
    mXmlAdapterManager = (XmlAdapterManager)App.getComponentManager().getComponent(adapterManagerName);

    mDTD = config.getStringValue("dtd");
    
    if (config.containsValue("requestConsumer")) {
      Config[] requestConsumersConfig = config.getChildren("requestConsumer");
      mRequestConsumers = new RequestConsumer[requestConsumersConfig.length];
      
      for (int i = 0; i < mRequestConsumers.length; i++) {
        String consumer = requestConsumersConfig[i].getStringValue(Config.CURRENT_KEY);
        mRequestConsumers[i] = (RequestConsumer)App.getComponentManager().getComponent(consumer);
        Log.INFO.report(this, " added RequestConsumer [" + consumer + "]");
      }
    } else {
      mRequestConsumers = new RequestConsumer[0]; 
      Log.INFO.report(this, " no RequestConsumers");
    }
    
    boolean deleteInvOnShutdown = config.getBooleanValue("deleteInventoryOnShutdown", false);

    if (deleteInvOnShutdown) {
        Log.INFO.report("Adding shutdown task to delete all inventory on exit");
        ShutdownManager sm = ShutdownManager.getInstance();
        sm.addShutdownTask(new Runnable() {
            public void run() {
                shuttingDown = true;
                Log.INFO.report("Running shutdown task to pull all inventory from MA in 2 seconds time");
                try {Thread.sleep(2000);} catch (InterruptedException e) {}
                InventoryDeleteAllDetails details = new InventoryDeleteAllDetails("EVERYTHING");
                writeMessage(details);
                Log.INFO.report("Waiting 2 seconds to allow for MAAPI consumption");
                try {Thread.sleep(2000);} catch (InterruptedException e) {} 
            }
        });
    }
  }

  public void start(){

  }

  public void stop(){

  }

  public void restart(){

  }

  public boolean isActive(){
    return mIsActive;
  }

  public void processDetails(Collection details) {
    Log.DEBUG.report(mName, " processDetails [" + details + "]");
    for (Iterator i = details.iterator(); i.hasNext(); ){
        if (!shuttingDown)
            writeMessage(i.next());
    }
  }
    
  public void writeMessage(Object object){
    String[] retVals = createXmlString(object);
    String traderLogin = retVals[0];
    String xml = retVals[1];
    Log.DEBUG.report(mName, " created xml :", xml);
    long messageId = mConnection.sendRequest(xml, traderLogin);
    notifyRequestConsumers(messageId, object);
  }
  
  private void notifyRequestConsumers(long messageId, Object object) {
    for (int i = 0; i < mRequestConsumers.length; i++){
      mRequestConsumers[i].processRequest(messageId, object);
    }
  }

  private String[] createXmlString(Object object){
    String xml = null;
    String traderLogin = null;
    
    try {
        Document doc = DocumentFactory.createDocumentForFactory( FIConfig.getInstance().getJaxpDocFactoryClassName() );
        XMLWriter writer = new XMLWriter( doc, "MA" );

        // TODO: Here we need to create an XmlAdapter that will generate the
        //        correct XML for sending to the MarketAxess gateway.
        XmlAdapter adapter = mXmlAdapterManager.getAdapter(object.getClass());
        Element root = writer.getRootElement();
        adapter.writeXml(object, root);
        
        if (adapter.getType().equals("MESSAGE-PRICE")) { 
        	traderLogin = ((MABaseMessageInterface)object).getLastTrader(); 
        	Log.DEBUG.report(this, "lastTrader is " + traderLogin);
        } else { 
        	traderLogin = null; 
        }

        //String xml = XMLPrinter2.print(doc, false, false);
        xml = XMLPrinter.getXMLText(doc, false, true, "MA", mDTD);
        xml = StringUtil.stripChars(xml, "\n");
    } catch (Throwable t) {
        Log.ERROR.report(mName, " got exception when creating xml :", t.toString());
		t.printStackTrace();
    }
    Log.DEBUG.report(this, "returning traderLogin " + traderLogin);
    return new String[] {traderLogin, xml};
  }


  public Object getAdmin() {
    return new Admin();
  }

  /**
   * For JMX MBean administration
   */
  public static interface AdminMBean {
    public void testCreateInventoryUpdateXml(String senderSystem, String isin, String benchmarkISIN, double bidSpread, long bidSize, double offerSpread, long offerSize, String book); 
  }

  public class Admin implements AdminMBean {
    public void testCreateInventoryUpdateXml(String senderSystem, String isin, String benchmarkISIN, double bidSpread, long bidSize, double offerSpread, long offerSize, String book) { 

      InventoryUpdateDetails msg = new InventoryUpdateDetails(senderSystem, isin, benchmarkISIN, bidSpread, bidSize, offerSpread, offerSize, book);
      try {
        writeMessage(msg);
      } catch (Exception e) {
        Log.ERROR.report(mName + " Unable to createXmlString() from Admin interface", e);
      }
    }
  }

}

