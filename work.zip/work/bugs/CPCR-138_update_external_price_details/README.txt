# The following configuration changes were required

pricing.xml:  <map node_attribute_name="${AttributeNames.POSITION_BOOK_ATT}" /> (node_type="com.rbsfm.fi.pricing.dependency.risk.PositionNode")
expricepub.xml:     <att name="${AttributeNames.POSITION_BOOK_ATT}"/> (component name="BondPriceTransformer")

# The autoquoter will recieve the message via

ExternalDetailsSubscriber.processPrice(ExternalDetails) line: 351	
ExternalDetailsSubscriber.processDetails(Collection) line: 140	
ExternalDetailsSource$ConsumerDetails.processDetails(Message, Object) line: 65	
ExternalDetailsSource.notifyConsumers(Object, Message) line: 295	
ExternalDetailsSource.internalProcessMessage(Message) line: 258	
ExternalDetailsSource(QueueSourceSink).internalRunWorker() line: 265	
QueueSourceSink.access$000(QueueSourceSink) line: 33	
QueueSourceSink$1.run() line: 122	
Thread.run() line: not available	

# Marshalling and unmarshalling is done here, this is what connects the autoquoter to expricepub

com.rbsfm.fi.pricing.external.detail.mux.ExternalBondPriceMessage

# Added the following to the ExternalBondPriceDetailsXmlAdapter

    details.setPositionBook( XMLReader.getChildText( element, "positionBook" ) );

# The following was added to ExternalDetailsAdapter

      if (map.containsAttribute(AttributeNames.POSITION_BOOK_ATT)) {
        details.setPositionBook(map.getStringValue(AttributeNames.POSITION_BOOK_ATT));
      }

# To ensure the expricepub listens to the updates the following

  <component name="BondPriceTransformer" class_name="${bond.price.transformer.class}">
    ...
    <att name="${AttributeNames.POSITION_ATT}"/>
    <att name="${AttributeNames.POSITION_BOOK_ATT}"/>


# In order for the new attribute "posBook" to be sent the following is needed in GridManager

  <mapper node_type="com.rbsfm.fi.pricing.dependency.risk.PositionNode">
     ...
     <attribute_mapping_rule pass_through="false">
        ...
        <map node_attribute_name="${AttributeNames.POSITION_BOOK_ATT}" /> <<----- SEND "posBook"

# This is where we deliver the results to

RowAttributeMapperManager.toRowAttributeDetails(Object, RowAttributeConsumer) line: 107 <<---- MAP ATTRIBUTES	
GridManager.updateGrid(NodeAttributeDetails) line: 91	
GridResultsPublisher.processPendingMessages() line: 351	
GridResultsPublisher.run() line: 196	
Thread.run() line: not available	

# The class that actually creates the ExternalBondPriceDetails is 

com.rbsfm.fi.pricing.external.detail.ExternalDetailsAdapter

# On BOOTSTRAP the external price details are created like so

ExternalBondPriceDetails.<init>() line: 592	
ExternalDetailsAdapter.createExtBondPriceDetails(String, AttributeMap, Collection, boolean) line: 71  <<<------- CREATION HERE	
ExternalDetailsPricingSource.processMessage(Message) line: 79	
Source$SourceCollection.processMessage(Message) line: 59	
MessageCacheSourceSink(AbstractSourceSink).send(Message) line: 46	
MessageCacheSourceSink(FilterSourceSink).processFilteredParsedMessage(Message) line: 49	
MessageCacheSourceSink.processFilteredParsedMessage(Message) line: 78	
MessageCacheSourceSink(FilterSourceSink).processMessage(Message) line: 31	
Source$SourceCollection.processMessage(Message) line: 59	
AttributeAdder(AbstractSourceSink).send(Message) line: 46	
AttributeAdder(FilterSourceSink).processFilteredParsedMessage(Message) line: 49	
AttributeAdder.processFilteredParsedMessage(Message) line: 56	
AttributeAdder(FilterSourceSink).processMessage(Message) line: 31	
Source$SourceCollection.processMessage(Message) line: 59	
MessageTransformerSourceSink(AbstractSourceSink).send(Message) line: 46	
MessageTransformerSourceSink(FilterSourceSink).processFilteredParsedMessage(Message) line: 49	
MessageTransformerSourceSink.internalProcessMessage(Message) line: 45	
MessageTransformerSourceSink.access$000(MessageTransformerSourceSink, Message) line: 10	
MessageTransformerSourceSink$1.consumeMessage(Message) line: 15	
ConfigurableMessageTransformer.transform(Message, MessageConsumer, String[], String[], String[], String[]) line: 186	
ConfigurableMessageTransformer.transform(Message, MessageConsumer) line: 97	
MessageTransformerSourceSink.processFilteredParsedMessage(Message) line: 37	
MessageTransformerSourceSink(FilterSourceSink).processMessage(Message) line: 31	
Source$SourceCollection.processMessage(Message) line: 59	

# The following stack trace is how it gets from the transformer to the sink

ExternalDetailsSink.processDetails(Collection) line: 51	
ExternalDetailsPricingSource.notifyConsumers(Object, Message) line: 141	
ExternalDetailsPricingSource.processMessage(Message) line: 114	
Source$SourceCollection.processMessage(Message) line: 59	
MessageCacheSourceSink(AbstractSourceSink).send(Message) line: 46	
MessageCacheSourceSink(FilterSourceSink).processFilteredParsedMessage(Message) line: 49	
MessageCacheSourceSink.processFilteredParsedMessage(Message) line: 78	
MessageCacheSourceSink(FilterSourceSink).processMessage(Message) line: 31	
Source$SourceCollection.processMessage(Message) line: 59	
AttributeAdder(AbstractSourceSink).send(Message) line: 46	
AttributeAdder(FilterSourceSink).processFilteredParsedMessage(Message) line: 49	
AttributeAdder.processFilteredParsedMessage(Message) line: 56	
AttributeAdder(FilterSourceSink).processMessage(Message) line: 31	
Source$SourceCollection.processMessage(Message) line: 59	
MessageTransformerSourceSink(AbstractSourceSink).send(Message) line: 46	
MessageTransformerSourceSink(FilterSourceSink).processFilteredParsedMessage(Message) line: 49	
MessageTransformerSourceSink.internalProcessMessage(Message) line: 45	
MessageTransformerSourceSink.access$000(MessageTransformerSourceSink, Message) line: 10	
MessageTransformerSourceSink$1.consumeMessage(Message) line: 15	
ConfigurableMessageTransformer.transform(Message, MessageConsumer, String[], String[], String[], String[]) line: 186	
ConfigurableMessageTransformer.transform(Message, MessageConsumer) line: 97	
MessageTransformerSourceSink.processFilteredParsedMessage(Message) line: 37	
MessageTransformerSourceSink(FilterSourceSink).processMessage(Message) line: 31	
Source$SourceCollection.processMessage(Message) line: 59	

# This is where the details from the expricepub are emitted

com.rbsfm.fi.pricing.external.detail.mux.ExternalDetailsSink

# To extract the values the following should be evaluated

((com.rbsfm.fi.pricing.mux.MessageNP)((ConcurrentHashMap)mCache.values().toArray()[1]).values().toArray()[0]).getAttributes()

# Attributes for the PositionNode are found via

select * from GenericNodeAttribute where NodeRef = 'Master-ZAG000010547'

# The ExternalPriceDetails that are populated

com.rbsfm.external.fi.pricing.detail.ExternalBondPriceDetails
