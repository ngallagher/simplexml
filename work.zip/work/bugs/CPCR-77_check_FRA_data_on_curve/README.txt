# The class that emits the attributes is the

CurvePointAttributeMarshaller

# The class that populates the MutableFra object is 

CurveFVarReader

# To set the reset convention use

setResetConvention(ResetConventionType.resolve(instrument.getStringElement(Constants.RESET_CONVENTION))

# All attributes look ok apart from 

paymentBasis
fixFloat

# The following attributes are missing from some curve points

otherPaymentPeriod (not applicable to FRN) (OtherPayPeriod) ## SwapFloatSide: direct attribute CurvePointAttributeMarshaller
otherPaymentBasis  (not applicable to FRN) (OtherPayBasis)  ## SwapFloatSide: direct attribute CurvePointAttributeMarshaller
paymentBasis       (not applicable to any) (PayBasis)       ## ??? FraStaticCalculator (FraLegDetails) not even in CurvePointAttributeMarshaller
fixFloat           (not applicable to any) (FixFloat)       ## ??? FraStaticCalculator (FraLegDetails) not even in CurvePointAttributeMarshaller
statMsg                                    (Status)         ## CurvePointQuoteCalculator - calculator status
parentProjectionCurveName*                 (PProjCrv)     **## Fra: direct attribute CurvePointAttributeMarshaller
paymentPeriod*                             (PayPeriod)      ## Turn: direct attribute CurvePointAttributeMarshaller
resetConvention*                           (ResetConv)      ## SwapFloatSide: direct attribute CurvePointAttributeMarshaller
priority*                                  (Priority)       ## FixedLoanInstrument: direct attribute CurvePointAttributeMarshaller
