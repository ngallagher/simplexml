# Required

HISTORICAL=yes

# Result from adding stepup cap to BDL

START-OF-FILE
RUNDATE=20091130
PROGRAMFLAG=oneshot
PROGRAMNAME=getdata
FIRMNAME=dl252456
SECMASTER=yes
DERIVED=yes
HEADER=yes
COLUMNHEADER=yes
OUTPUTFORMAT=bulklist
SECID=ISIN
REPLYFILENAME=cpsc20091130161558525.res
START-OF-FIELDS
EXT_CAP_CPN_SCHED
END-OF-FIELDS
TIMESTARTED=Mon Nov 30 16:16:43 GMT 2009
START-OF-DATA
XS0205545840|0|1|N.D.|
USP3579EAD96|0|1|N.D.|
USP3579EAC14|0|1|N.D.|
US040114GL81|0|1|N.D.|
END-OF-DATA
TIMEFINISHED=Mon Nov 30 16:16:46 GMT 2009
END-OF-FILE

# This is the best price calc

         <sqlSP name="appBidAskBestPxMuxRTCalcStore">         
            <conditions>
                <condition><testField>${AttributeNames.SD_IS_FRN}</testField><testValue>true</testValue><type>Boolean</type></condition>
            </conditions>
            <parameters>
               <parameter name="@BondNodeRef" from="${AttributeNames.SD_INSTRUMENT_ID}" />
               <parameter name="@Version" value="0" type="Integer" />
               <parameter name="@ServerName" value="latam-pricing-instmaint" />
               <parameter name="@UpdaterRef" value="latam-pricing-instmaint" />
            </parameters>
         </sqlSP>   

# This is the appCreateBidAskFRNCurveCalc

        <sqlSP name="appCreateBidAskFRNCurveCalc">         
            <conditions>
                <condition><testField>${AttributeNames.SD_IS_FRN}</testField><testValue>true</testValue><type>Boolean</type></condition>
            </conditions>
            <parameters>
               <parameter name="@NodeRef" from="${AttributeNames.SD_INSTRUMENT_ID}" />
               <parameter name="@CurveId" from="${AttributeNames.SD_CURVE}" />
               <parameter name="@Version" value="0" type="Integer" />
               <parameter name="@ServerName" value="latam-pricing-instmaint" />
               <parameter name="@UpdaterRef" value="latam-pricing-instmaint" />
            </parameters>
         </sqlSP>

# This is used to drive the bond adder

com.rbsfm.fi.pricing.bloomberg.BBDataDump

#############################################################################
## There were errors detected within the request file, please correct and
## then resubmit the resulting file.
##
## Source:   dl252456 (ftp)
## Filename: /xfer/dl252456/1259254663_60817418.req.checking
## Parent:   1259254663  60817418   
##
## The following errors were found:
##
## >>HEADER=on<<
##
## Line 9,   E3001: HEADER expects a case-insensitive text value
##
##	suitable values are yes, no and timeonly
##
##	HEADER is optional. This allows customers to specify if the
##	header should be returned in the reply file. This option can be set
##	to either 'yes', 'no' or 'timeonly' and defaults to 'yes'.
##
## >>COLUMNHEADER=on<<
##
## Line 10,  E3004: COLUMNHEADER expects a boolean value(y[es] or n[o])
##
##	COLUMNHEADER option only applies to the getdata, company, fundamentals and snap
##	programs. The default is "no"; if set to "yes", the output file
##	will return the title of each column of data.
##
#############################################################################
## There were 2 errors encountered within the request file.
## The request file has been moved to cpsc20091126165736625.res.err
##
## Make sure no unprintable characters, such as tabs are present in the
## definitions and all the required statements (eg. 'START-OF-DATA'
## are present.
##
## Please consult the "Per Security Product Manual" for more information on
## the request file structure and program options, plus the periodic
## "Data Service Enhancement Notice(s)" about interface changes.
#############################################################################
## Request file:
#############################################################################


START-OF-FILE
SERVER=ftp1ny
REQUESTFILENAME=cpsc20091126165736625.req
PROGRAMFLAG=oneshot
PROGRAMNAME=getdata
FIRMNAME=dl252456
SECMASTER=yes
DERIVED=yes
HEADER=on
COLUMNHEADER=on
OUTPUTFORMAT=bulklist
SECID=ISIN
REPLYFILENAME=cpsc20091126165736625.res

START-OF-FIELDS
FACTOR_SCHEDULE
END-OF-FIELDS

START-OF-DATA
XS0205545840|ISIN
USP3579EAD96|ISIN
USP3579EAC14|ISIN
US040114GL81|ISIN
END-OF-DATA

END-OF-FILE

