# The following will remove bonds completely

appEraseCEEMEABond "HU0000402045" 
go 
appEraseCEEMEABond "HU0000402193" 
go 
appEraseCEEMEABond "PL0000101937"
go

# To test this the following should be done

exec appDeleteBond @InstrumentRef = 'HU0000402235'
go
exec appDeleteEcnInstrumentSub @InstrumentRef = 'HU0000402235' 
go

# This is used to compare the data added by the bond adder

select * from CalculatorAttribute c where c.NodeRef = 'HU0000402235' and RecordStatus = 'C'
select * from Calculator c where c.NodeRef = 'HU0000402235' and RecordStatus = 'C'
select * from GenericNode c where c.NodeRef = 'HU0000402235' and RecordStatus = 'C'
select * from GenericNodeAttribute c where c.NodeRef = 'HU0000402235' and RecordStatus = 'C'
select * from Node n where n.NodeId = 'HU0000402235' and RecordStatus = 'C'
select * from SubTreeNodes n where n.NodeRef = 'HU0000402235' and RecordStatus = 'C'
select * from EcnQuoteNew e where e.InstrumentRef = 'HU0000402235' and RecordStatus = 'C'
select * from EcnSpreadNew e where e.InstrumentRef = 'HU0000402235' and RecordStatus = 'C'
select * from EcnQuoteTimer e where e.InstrumentRef = 'HU0000402235' and RecordStatus = 'C'
select * from EcnInstrumentStatus e where e.InstrumentRef = 'HU0000402235' and RecordStatus = 'C'
select * from EcnSanitizerInstCtrl e where e.InstrumentRef = 'HU0000402235' and RecordStatus = 'C'
select * from EcnInstrumentSub e where e.InstrumentRef = 'HU0000402235' and RecordStatus = 'C'

