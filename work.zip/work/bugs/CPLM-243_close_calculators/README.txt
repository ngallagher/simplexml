# Requirements

In order for the below configuration to work the JavaClass in the database MUST be a concrete class. In some databases the JavaClass is specified as a com.rbsfm.fi.pricing.dependency.bond.BondCloseCalculator, however this no longer exists as a contrete implementation. Instead it is now an interface and will not be valid. So, bonds with BondCloseCalculator need to choose either CreditBondCloseCalculator or RatesBondCloseCalculator.

# Configuration change

                <delegate name="CreditBondCloseCalculatorHome" class_name="com.rbsfm.fi.pricing.dependency.generic.DbGenericCalculatorHome" autocommit="${autoCommit}" populateForTreeType="all" readOnly="${readOnly}" closeSetClassName="com.rbsfm.fi.pricing.dependency.bond.close.CreditCloseSetImpl" calculatorClass="com.rbsfm.fi.pricing.dependency.bond.CreditBondCloseCalculator" dbwrite_queue="DbWriteQueue">
                     @{master.close.calc}
                     <preConfig>true</preConfig>
                </delegate>

                <delegate name="RatesBondCloseCalculatorHome" class_name="com.rbsfm.fi.pricing.dependency.generic.DbGenericCalculatorHome" autocommit="${autoCommit}" populateForTreeType="all" readOnly="${readOnly}" calculatorClass="com.rbsfm.fi.pricing.dependency.bond.RatesBondCloseCalculator" dbwrite_queue="DbWriteQueue">
                     @{master.close.calc}
                     <preConfig>true</preConfig>
                </delegate>

# SQL that is used to instantiate the calculators from DbGenericCalculatorHome
select 
    C.NodeRef, 
    C.CalculatorId, 
    C.JavaClass, 
    C.Version, 
    C.CreatorRef, 
    C.CreationDatetime, 
    C.UpdaterRef, 
    C.UpdateDatetime 
from 
    CalculatorView C, 
    TreeView T, 
    SubTreeView ST, 
    SubTreeNodesView STN 
where 
    C.NodeRef = STN.NodeRef 
and 
    C.JavaClass = 'com.rbsfm.fi.pricing.dependency.bond.CreditBondCloseCalculator' 
and 
    STN.SubTreeRef = ST.SubTreeId   
and 
    ST.TreeRef = T.TreeId   
and 
    T.TreeId = 'LATAM'

# Error with close set

java.lang.ClassCastException: com.rbsfm.fi.pricing.dependency.bond.close.DefaultCloseSet cannot be cast to com.rbsfm.fi.pricing.dependency.bond.close.CreditCloseSet in java.lang.Throwable.printStackTrace(Throwable.java:461)-	at com.rbsfm.fi.pricing.dependency.util.CloseHelper.close(CloseHelper.java:137)
	at com.rbsfm.fi.pricing.dependency.bond.CreditBondCloseCalculator.getTodayCreditSet(CreditBondCloseCalculator.java:34)
	at com.rbsfm.fi.pricing.dependency.bond.CreditBondCloseCalculator.setTodayClose(CreditBondCloseCalculator.java:390)
	at com.rbsfm.fi.pricing.dependency.bond.AbstractBondCloseCalculator.processCloseMessage(AbstractBondCloseCalculator.java:422)
	at com.rbsfm.fi.pricing.dependency.bond.AbstractBondCloseCalculator.processMessage(AbstractBondCloseCalculator.java:407)
	at com.rbsfm.fi.pricing.dependency.bond.InternalBondNode.processCloseMessage(InternalBondNode.java:578)
	at com.rbsfm.fi.pricing.dependency.bond.InternalBondNode.processMessage(InternalBondNode.java:234)
	at com.rbsfm.fi.pricing.dependency.util.CloseHelper.close(CloseHelper.java:133)
	at com.rbsfm.fi.pricing.dependency.util.CloseHelper.close(CloseHelper.java:102)
	at com.rbsfm.fi.pricing.dependency.util.CloseHelper.close(CloseHelper.java:99)
	at com.rbsfm.fi.pricing.dependency.util.OpenCloseManager.processCloseMessage(OpenCloseManager.java:228)
	at com.rbsfm.fi.pricing.dependency.util.OpenCloseManager.processMessage(OpenCloseManager.java:83)
	at com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessageWithConsumer(TreeMessageProcessingManagerImpl.java:232)
	at com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessageWithoutRecalc(TreeMessageProcessingManagerImpl.java:133)
	at com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessage(TreeMessageProcessingManagerImpl.java:89)
	at com.rbsfm.fi.pricing.dependency.tree.TreeMessageProcessingManagerImpl.processMessage(TreeMessageProcessingManagerImpl.java:79)
	at com.rbsfm.fi.pricing.dependency.tree.AbstractDependencyTree.processMessage(AbstractDependencyTree.java:628)
	at com.rbsfm.fi.pricing.dependency.remote.ClientImpl.processMessage(ClientImpl.java:243)
	at sun.reflect.GeneratedMethodAccessor3.invoke(Unknown Source)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:25)
	at java.lang.reflect.Method.invoke(Method.java:597)
	at electric.util.reflect.Invocation.execute(Unknown Source)
	at electric.util.reflect.Invocation.invoke(Unknown Source)
	at electric.service.object.ObjectService.invoke(Unknown Source)
	at electric.soap.local.handlers.service.SOAPToServiceHandler.invoke(Unknown Source)
	at electric.soap.local.handlers.service.SOAPToServiceHandler.handle(Unknown Source)
	at electric.soap.security.handlers.SecurityHandler.handle(Unknown Source)
	at electric.soap.handlers.interceptor.SOAPInterceptorHandler.handle(Unknown Source)
	at electric.soap.routing.RoutingHandler.handle(Unknown Source)
	at electric.soap.handlers.logging.SOAPLoggingHandler.handle(Unknown Source)
	at electric.soap.handlers.setup.SetupHandler.handle(Unknown Source)
	at electric.soap.http.handler.HTTPToSOAP.service(Unknown Source)
	at electric.server.http.ServletServer.service(Unknown Source)
	at javax.servlet.http.HttpServlet.service(HttpServlet.java:865)
	at electric.servlet.Config.service(Unknown Source)
	at electric.servlet.HTTPContext.service(Unknown Source)
	at electric.servlet.ServletEngine.service(Unknown Source)
	at electric.webserver.WebServer.service(Unknown Source)
	at electric.net.socket.SocketServer.run(Unknown Source)
	at electric.net.socket.SocketRequest.run(Unknown Source)
	at electric.util.thread.ThreadPool.run(Unknown Source)
	at java.lang.Thread.run(Thread.java:619)
