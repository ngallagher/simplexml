package org.simpleframework.http.search;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.StringWriter;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocCollector;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.simpleframework.http.Request;
import org.simpleframework.http.Response;
import org.simpleframework.http.core.Container;
import org.simpleframework.http.search.parse.LineStripper;
import org.simpleframework.transport.connect.Connection;
import org.simpleframework.transport.connect.SocketConnection;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;
import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.Transient;
import org.simpleframework.xml.core.Commit;
import org.simpleframework.xml.core.Persister;
import org.simpleframework.xml.core.Validate;
import org.simpleframework.xml.util.Dictionary;
import org.simpleframework.xml.util.Entry;

public class SearchServer implements Container {
    
    @Root(name="search")
    public static class SearchEngine {
       
       @ElementList(inline=true)
       Dictionary<SearchConfig> registry;
       
       @Transient
       String defaultSearcher;
       
       @Commit
       public void commit() {
           if(registry.size() > 0) {
               // just have a basic default in case default="true" is not set
               defaultSearcher = registry.iterator().next().getName();
           }
           for(Searcher index : registry) {
               if(index.isDefault()) {
                   defaultSearcher = index.getName();
               }
           }
       }       
       
       public String getDefaultSearcher() {
           return defaultSearcher;
       }
       
       public Searcher index(String config) throws Exception {
          return registry.get(config);
       }
       public List<Searcher> all() throws Exception {
           List<Searcher> all = new ArrayList<Searcher>();
           for(Searcher searcher : registry) {
               all.add(searcher);
           }
           return all;           
       }
    } 
    
    public interface Searcher {
       
       public boolean isDefault();
       public void search(String index, String term, boolean refresh, boolean grep, boolean searchNames, PrintStream out) throws Exception;
       public File getRoot(String index);
       public List<String> getIndexes();
       public String getDefaultIndex();
       public String getName();
    }
    
    @Root(name="index")
    private static class SearchConfig implements Searcher, Entry {
       
       private static final String NAME = "name";
       private static final String TEXT = "text";
    
       @ElementList(inline=true) 
       Dictionary<Index> list;
       
       @Attribute(name="default", required=false)
       boolean isDefault;
       
       @Attribute
       String name;
       
       @Transient
       String defaultIndex;
       
       @Commit
       public void commit() {
           if(list.size() > 0) {
               // just have a basic default in case default="true" is not set
               defaultIndex = list.iterator().next().getName();
           }
           for(Index index : list) {
               if(index.isDefault()) {
                   defaultIndex = index.getName();
               }
           }
       }
       
       public boolean isDefault() {
           return isDefault;
       }
       
       public String getDefaultIndex() {
           return defaultIndex;
       }
       
       public List<String> getIndexes() {
           List<String> all = new ArrayList<String>();
           for(Index index : list) {
               all.add(index.getName());
           }
           return all;
       }
       
       public File getRoot(String index) {
           return list.get(index).scan;
       }
       
       public String getName() {
          return name;
       }
       
       public void search(String index, String term, boolean refresh, boolean grep, boolean searchNames, PrintStream out) throws Exception  {
          Directory directory = index(index, refresh);
          StandardAnalyzer analyzer = analyzer(index);
          
          // the "title" arg specifies the default field to use
          // when no field is explicitly specified in the query.
          Query query = null;
          
          if(searchNames) {
              query = new QueryParser(NAME, analyzer).parse(term);
          } else {
              query = new QueryParser(TEXT, analyzer).parse(term);
          }

          // 3. search
          int hitsPerPage = 1000;
          IndexSearcher searcher = new IndexSearcher(directory);
          TopDocCollector collector = new TopDocCollector(hitsPerPage);
          searcher.search(query, collector);
          ScoreDoc[] hits = collector.topDocs().scoreDocs;
          
          // 4. display results
          out.println("<br>Found " + hits.length + " hits for <b>"+term+"</b>");
          out.println("<table border='1'>");
          int countIndex = 0;
          for(int i=0;i<hits.length;++i) {
            int docId = hits[i].doc;
            Document d = searcher.doc(docId);
            List<String> list = new ArrayList<String>();
            boolean match = false; 
            
            if(grep && !searchNames) {
                String value = d.get(TEXT);
                List<String> lines = LineStripper.stripLines(value);

                for(String line : lines) {
                    if(line.indexOf(term) != -1) {
                        line = line.replaceAll("<", "&lt;").replaceAll(">", "&gt;");
                        line = line.replaceAll(term, "<font style='BACKGROUND-COLOR: yellow'>"+term+"</font>");
                        list.add(line);
                        match = true;
                    }
                }
            } else {
                match = true;
            }
            if(match) {
                int length = (int)(hits[i].score * 100.0);
                int percent = Math.min(100, length);
                String docName = d.get(NAME);
                
                out.println("<tr><td>");
                out.println("<table border='0'>");   
                out.println("<tr><td>"+ (countIndex++ + 1) + "</td><td>");
                out.println("<table>\n");
                out.println(" <tr>\n");
                out.println("    <td>\n");
                out.println("    <table cellpadding='1' cellspacing='0' width='60' border='0' bgcolor='#000000'>\n");
                out.println("    <tr>\n");
                out.println("       <td>\n");
                out.println("       <table cellpadding='0' cellspacing='0' border='0' width='100%'>\n");
                out.println("       <tr>\n");
                out.println("          <td bgcolor='#00ff00' height=10 style='border: 0' width='"+percent+"%'>\n");
                out.println("             <spacer type=block width=2 height=8>\n");                
                out.println("          </td>\n");
                out.println("          <td bgcolor='#ffffff' height=10 style='border: 0' width='"+(100-percent)+"%'>\n");
                out.println("             <spacer type=block width=2 height=8>\n");
                out.println("          </td>\n");
                out.println("       </tr>\n");
                out.println("       </table>\n");
                out.println("       </td>\n");
                out.println("    </tr>\n");
                out.println("    </table>\n");
                out.println("    </td>\n");
                out.println(" <tr>\n");
                out.println(" </table>\n");
                out.println("</td><td><a href='/index/" + docName+"?index="+index+"&searcher="+name+"'><b>"+ docName+"</b></a></td></tr>");
                out.println("</table>");
                out.println("</td></tr>");
                if(list.size() > 0) {
                    out.println("<tr><td>");
                    out.println("<table border='0'>");
                    String preClass = "";
                    
                    // Consider only a subset of possible highlights 
                    if(docName.endsWith(".java")) {
                        preClass = " class='sh_java'";
                    } 
                    else if(docName.endsWith(".xml")) {
                        preClass = " class='sh_xml'";
                    }
                    else if(docName.endsWith(".sql")) {
                        preClass = " class='sh_sql'";
                    }
                    else if(docName.endsWith(".cs")) {
                        preClass = " class='sh_csharp'";
                    }
                    else if(docName.endsWith(".properties")) {
                        preClass = " class='sh_properties'";
                    }
                    
                    out.println("<tr><td><pre"+preClass+">");
                    for(String val : list) {
                        out.println(val);
                    }
                    out.println("</pre></td></tr>");                    
                    out.println("</table>");  
                    out.println("</td></tr>");
                }
            }
          }
          out.println("</table>");
          // searcher can only be closed when there
          // is no need to access the documents any more. 
          searcher.close();
       }
       
       public StandardAnalyzer analyzer(String name) throws Exception {
          Index index = list.get(name);
          return index.analyzer(); 
       }
       
       public Directory index(String name, boolean refresh) throws Exception {
          Index index = list.get(name);
          return index.index(refresh);
       }
     
       
       @Root(name="create")
       private static class Index implements Entry {
       
          @Attribute String name;
          @Attribute File directory;
          @Attribute File scan;
          @Attribute(name="default", required=false) boolean isDefault; 
          @ElementList(inline=true) List<Filter> filters;  
          @Transient Directory index;
          @Transient StandardAnalyzer analyzer;
          @Transient IndexWriter writer;
          
          @Validate
          private void validate() throws Exception {
              if(!scan.exists()) {
                  throw new FileNotFoundException("Scan directory does not exist " +scan);
              }
          }
          
          @Commit
          private void start() throws Exception {
             this.index = FSDirectory.getDirectory(directory);
             this.analyzer = new StandardAnalyzer();
          }
          
          public boolean isDefault(){
              return isDefault;
          }
          
          public StandardAnalyzer analyzer() {
             return analyzer;
          }
          
          // Only allow use if its not currently being indexed
          public synchronized Directory index(boolean refresh) throws Exception {
              // only scan if its not been done in last five hours
             if(refresh || isEmpty(directory)) {
                 // deletes the original index
                writer = new IndexWriter(index, analyzer, true, IndexWriter.MaxFieldLength.UNLIMITED);
                scan(scan);
                writer.optimize();
                writer.close();
             }
             return index;
          }
          
          // is this a valid index directory?????
          private boolean isEmpty(File directory) {
              if(!directory.exists() || !directory.isDirectory()) {
                  return true;
              }
              File[] list = directory.listFiles();
              int count = 0;
              
              for(File file : list) {
                  String name = file.getName();                  
                  if(name.length() > 0 && !name.equals(".") && !name.equals("..") && !name.equals("CVS") && !name.equals(".svn")) {
                      count++;
                  }
              }
              return count == 0;            
          }
          
          private void scan(File root) throws IOException {
             File[] list = root.listFiles();
             
             for(File file : list) {
                if(file.isDirectory() && !file.equals(root) && !file.getName().equals(".svn")) {
                   scan(file);
                } else {
                   if(accept(file)) {
                      String text = load(file);
                      String scanPath = scan.getCanonicalPath();
                      String namePath = file.getCanonicalPath();
                      String relativePath = namePath.substring(scanPath.length() + 1, namePath.length());
                      String url = relativePath.replace('\\', '/');
                      System.out.println("OK: "+file);
                      
                      add(text, url);
                   }
                }
             }    
          }
          
          private String load(File root) throws IOException {
             ByteArrayOutputStream buffer = new ByteArrayOutputStream();
             InputStream source = new FileInputStream(root);
             byte[] chunk = new byte[8192];
             int count = 0;
             
             while((count = source.read(chunk)) != -1) {
                buffer.write(chunk, 0, count);
             }
             return buffer.toString("UTF-8");
          }
          
          private void add(String value, String name) throws IOException {
             Document doc = new Document();
             doc.add(new Field(NAME, name, Field.Store.YES, Field.Index.ANALYZED));
             doc.add(new Field(TEXT, value, Field.Store.YES, Field.Index.ANALYZED));
             writer.addDocument(doc);
           }
          
          private boolean accept(File file) throws IOException {
             for(Filter filter : filters) {
                if(filter.accept(file))
                   return true;
             }
             return false;
          }
          
          public String getName() {
             return name;
          }
       }
       
       @Root(name="filter")
       private static class Filter {
       
          @Attribute String pattern;
          
          public boolean accept(File file) throws IOException {
             return file.getCanonicalPath().matches(pattern);
          }
       }
    }
    
    
    private interface Searchable extends Entry {
       
        public boolean matches(String regex, boolean deep, List<String> bagOfTokens);
        public String getSource();
        public void setSource(String source);
    }
   

    @Root(name = "server_details")
    private static class ServerDetails {
        
        @ElementList(empty=false, required=false)
        Dictionary<Server> servers;        
        
        @ElementList(inline=true, required=false)
        Dictionary<Host> hosts;    
        
        @ElementList(inline=true, required=false)
        Dictionary<HostAttribute> hostAttributes;
        
        @ElementList(inline=true, required=false)        
        Dictionary<Server> serverList;
        
        @ElementList(inline=true, required=false)
        Dictionary<ServerGroup> serverGroups;        
        
        String source;
        
        public String getSource() {
            return source;
        }
        
        public void setSource(String source) {
            this.source = source;
        }
        
        @Commit
        public void commit() {
            if(servers != null) {
                for(Server server : servers) {
                    String originalSource = server.getSource();
                    
                    if(serverList == null) {
                        serverList = new Dictionary<Server>();
                    }
                    serverList.add(server);
                    
                    if(originalSource != null) {
                        server.setSource(source);
                    }
                }
            }
            if(serverGroups != null) {
                for(ServerGroup serverGroup : serverGroups) {
                    String originalSource = serverGroup.getSource();                
                    
                    if(originalSource == null) {
                        serverGroup.setSource(source);
                    }
                }
            }
            if(serverList != null) {
                for(Server server : serverList) {
                    String originalSource = server.getSource();                
                    
                    if(originalSource == null) {
                        server.setSource(source);
                    }
                }
            }
            if(hostAttributes != null) {
                for(HostAttribute hostatt : hostAttributes) {
                    String originalSource = hostatt.getSource();                
                    
                    if(originalSource == null) {
                        hostatt.setSource(source);
                    }
                }
            }
            if(hosts != null) {
                for(Host host : hosts) {
                    String originalSource = host.getSource();                
                    
                    if(originalSource == null) {
                        host.setSource(source);
                    }
                }
            }
        }
        
        public List<Searchable> search(String regex, boolean deep, List<String> bagOfTokens) {
            List<Searchable> list = new ArrayList<Searchable>();

            if(serverGroups != null) {
                for(ServerGroup serverGroup : serverGroups) {
                    if(serverGroup.matches(regex, deep, bagOfTokens)) {
                        list.add(serverGroup);                    
                    }
                }
            }
            if(serverList != null) {
                for(Server server : serverList) {
                    if(server.matches(regex, deep, bagOfTokens)) {
                        list.add(server);                    
                    }
                }
            }
            if(hostAttributes != null) {
                for(HostAttribute hostatt : hostAttributes) {
                    if(hostatt.matches(regex, deep, bagOfTokens)) {
                        list.add(hostatt);                    
                    }
                }
            }
            if(hosts != null) {
                for(Host host : hosts) {
                    if(host.matches(regex, deep, bagOfTokens)) {
                        list.add(host);                    
                    }
                }
            }
            return list;
        }
    }
    
    @Root(name="host", strict=false)
    private static class Host implements Searchable {
        
        @Attribute
        String name;
        
        @Attribute
        String hostname;
        
        @Attribute
        String type;
        
        // not required for some prod settings?
        @Attribute(required=false)
        String location;
        
        @Attribute(required=false)
        String network;        
        
        @Attribute(name="relay-hostname", required=false)
        String relay_hostname;
        
        @ElementList(inline=true, required=false, empty=false)
        List<Server> list;
        
        String source;
        
        public String getSource() {
            return source;
        }
        
        public void setSource(String source) {
            this.source = source;
        }
        
        public String getName() {
            return hostname;
        }
        
        public boolean matches(String regex, boolean deep, List<String> bagOfTokens) {
            int count = 0;
            
            if(list != null) {
                for(Server server : list) {
                    if(server.name != null && server.name.toLowerCase().matches(regex)) {
                        bagOfTokens.add(server.name);
                        count++;
                    }
                }
            }
            if(name != null && name.toLowerCase().matches(regex)) {
                bagOfTokens.add(name);
                count++;
            }
            if(hostname != null && hostname.toLowerCase().matches(regex)) {
                bagOfTokens.add(hostname);
                count++;
            }
            return count > 0;
        }
        
        // some rubbish in host_details so use non strict
        @Root(name="server", strict=false)
        private static class Server {
            
            @Attribute
            String name;      
            
            @Attribute(required=false)
            String disabled;            
            
            
            @ElementList(inline=true, required=false)
            List<HostAttribute> list;
        }
        
        
    }

    @Root(name = "hostattribute")    
    private static class HostAttribute implements Searchable {
        
        @Attribute
        String name;
        
        @Attribute
        String value;
        
        // fi_server_details
        @Attribute(required=false)
        String mw_value;
        
        String source;
        
        public String getSource() {
            return source;
        }
        
        public void setSource(String source) {
            this.source = source;
        }
        
        public String getName() {
            return name;
        }
        
        public boolean matches(String regex, boolean deep, List<String> bagOfTokens) {
            int count = 0;
            
            if(name != null && name.toLowerCase().matches(regex)) {
                bagOfTokens.add(name);
                count++;
            }
            if(value != null && value.toLowerCase().matches(regex)) {
                bagOfTokens.add(value);
                count++;
            }
            return count > 0;
        }
    }

    @Root(name = "server_group")
    private static class ServerGroup implements Searchable {
        
        @Attribute
        String name;
        
        @ElementList(inline = true, required = false)
        Dictionary<HostAttribute> hostAttributes;
        
        @ElementList(inline = true, required = false)
        Dictionary<Server> server;
        
        String source;
        
        public String getSource() {
            return source;
        }
        
        public void setSource(String source) {
            this.source = source;
        }
        
        public String getName() {
            return name;
        }
        
        public boolean matches(String regex, boolean deep, List<String> bagOfTokens) {
            int count = 0;
            
            if(deep) {
                if(server != null) {
                    for(Server entry : server) {
                        if(entry.matches(regex, deep, bagOfTokens)) {
                            count++;
                        }
                    }                
                }
                if(hostAttributes != null) {
                    for(HostAttribute attr : hostAttributes) {
                        if(attr.matches(regex, deep, bagOfTokens)) {
                            count++;                            
                        }
                    }
                }
            }
            if(name.toLowerCase().matches(regex)) {
                bagOfTokens.add(name);
                count++;
            }
            return count > 0;
        }
    }

    @Root(name = "server", strict=false)
    private static class Server implements Searchable {
        
        // fi_server_details
        @Attribute(name="default", required=false)
        String deflt;

        @Attribute(required = false)
        String servername;

        @Attribute(required = false)
        String servertype;

        @Attribute(required = false)
        String baseport;

        @Attribute(required = false)
        String location;

        @Attribute(required = false)
        String virtual;

        @Attribute(required = false)
        String serverMode;

        @Attribute(required = false)
        String servermode;

        @ElementList(inline=true, required=false, empty=false)
        Dictionary<HostAttribute> hostAttributes;

        // this is needed if there are multiple hosts segments
        @ElementList(inline=true, required=false, empty=false)
        List<Hosts> hostList;
        
        @Transient
        Dictionary<HostDetails> hosts;
             
        String source;
        
        public Server() {
            this.hosts = new Dictionary<HostDetails>();
        }
        
        @Commit
        public void commit() {
            // dump from multiple hosts to a single one
            for(Hosts host : hostList) {
                host.addAll(hosts);
            }            
        }
        
        public String getSource() {
            return source;
        }
        
        public void setSource(String source) {
            this.source = source;
        }
        
        public String getName() {
            return servername;
        }  
        
        public boolean matches(String regex, boolean deep, List<String> bagOfTokens) {
            int count = 0;
            
            if(deep) {
                if(hostAttributes != null) {
                    for(HostAttribute attr : hostAttributes) {
                        if(attr.matches(regex, deep, bagOfTokens)) {                            
                            count++;
                        }
                    }
                }
            }
            if(servername != null && servername.toLowerCase().matches(regex)) {
                bagOfTokens.add(servername);
                count++;
            }
            if(baseport != null && baseport.matches(regex)) {
                bagOfTokens.add(baseport);
                count++;
            }
            return count > 0;
        }
        
        @Root(name="hosts")
        private static class Hosts {
            
            @ElementList(inline=true, required=false)
            Dictionary<HostDetails> list;
            
            public void addAll(Dictionary list) {
                list.addAll(list);
            }
        }
    }

    @Root(name = "hostdetails")
    private static class HostDetails implements Searchable {
        
        @Attribute
        String name;
        
        // fi_server_details
        @Attribute(required=false)
        String location;
        
        // fi_server_details
        @Attribute(required=false)
        String network;
        
        @Attribute(required=false)
        String disabled;
        
        @ElementList(inline = true, required = false)
        Dictionary<HostAttribute> hostAttributes;
        
        String source;
        
        public String getSource() {
            return source;
        }
        
        public void setSource(String source) {
            this.source = source;
        }
        
        public String getName() {
            return name;
        }
        
        public boolean matches(String regex, boolean deep, List<String> bagOfTokens) {
            int count = 0;
            
            if(name.toLowerCase().matches(regex)){
                bagOfTokens.add(name);
                count++;
            }
            return count > 0;
        }
    }
    
    @Root(name="config")
    private static class Config {
    
        @ElementList(inline=true)
        Dictionary<Environment> list;
        
        public Set<Environment> getEnvironments() {
            return list;
        }
        
        public Environment getEnvironment(String name) {
            return list.get(name);
        }
        
        @Root(name="environment")
        private static class Environment implements Entry {
            
            @Attribute
            String name;
            
            @Attribute
            String server;
            
            @Element
            String fi_server_details;
            
            @Element
            String server_details;
            
            @Element
            String host_details;
            
            @Commit
            public void commit() {
                String delimeter = "/";
                
                if(server.endsWith("/")) {
                    delimeter = "";
                }
                server_details = server+delimeter+server_details;
                fi_server_details = server+delimeter+fi_server_details;
                host_details = server+delimeter+host_details;
            }
            
            public String getName() {
                return name;
            }
            
            ServerDetails load(Serializer serializer, boolean serverDetails, boolean fiServerDetails, boolean hostDetails) throws Exception {
                ServerDetails details = new ServerDetails();
                
                if(serverDetails) {
                    details.setSource(server_details);
                    load(serializer, server_details, details);
                }
                if(fiServerDetails) {
                    details.setSource(fi_server_details);
                    load(serializer, fi_server_details, details);
                }
                if(hostDetails) {
                    details.setSource(host_details);
                    load(serializer, host_details, details);
                }
                return details;
            }
            
            public void load(Serializer serializer, String target, ServerDetails existing) throws Exception {
                URL url = new URL(target);
                InputStream in = url.openStream();

                serializer.read(existing, in);
            }
        }
    }
    
    
    private final Persister persister;
    private final SearchEngine searchEngine;
    private final Config config;
    
    public SearchServer(Config config, SearchEngine searchEngine, Persister persister) {
        this.persister = persister;
        this.searchEngine = searchEngine;
        this.config = config;
    }

    public void handle(Request req, Response resp) {
        PrintStream out = null;
        
        try {
            out = resp.getPrintStream(8192);
            String env = req.getParameter("env");
            String regex = req.getParameter("regex");
            String deep = req.getParameter("deep");
            String term = req.getParameter("term");
            String index = req.getParameter("index");
            String refresh = req.getParameter("refresh");
            String searcher = req.getParameter("searcher");
            String grep = req.getParameter("grep");
            String fiServerDetails = req.getParameter("fi_server_details");
            String serverDetails = req.getParameter("server_details");
            String hostDetails = req.getParameter("host_details");
            String name = req.getParameter("name");
            String path = req.getPath().getPath();
            
            
            if(path.startsWith("/index/") && index != null && searcher != null) {
                resp.set("Content-Type", "text/plain");
                 
                String file = req.getPath().getPath(1);
                File source = new File(searchEngine.index(searcher).getRoot(index), file.replace('/', File.separatorChar));
                File canonical = source.getCanonicalFile();
                FileInputStream in = new FileInputStream(canonical);
                byte[]chunk = new byte[8192];
                int count = 0;
                while((count = in.read(chunk)) != -1) {
                    out.write(chunk, 0, count);
                } 
            } else if(path.endsWith(".js") || path.endsWith(".css")) {
                 path = path.replace('/', File.separatorChar);
                 
                 if(path.endsWith(".js")) {
                   resp.set("Content-Type", "application/javascript");
                 } else {
                     resp.set("Content-Type", "text/css");
                 }
                 File file = new File(".", path).getCanonicalFile();
                 System.err.println("looking for "+file);
                 FileInputStream in = new FileInputStream(file);
                 byte[]chunk = new byte[8192];
                 int count = 0;
                 while((count = in.read(chunk)) != -1) {
                     out.write(chunk, 0, count);
                 }                 
            } else if(env != null && regex != null) { 
                ServerDetails details = config.getEnvironment(env).load(persister, serverDetails != null, fiServerDetails != null, hostDetails != null);
                List<String> tokens = new ArrayList<String>();               
                // Sort by longest first so that when we replace tokens we replace 
                // the fully matched token
                Comparator<String> comparator = new Comparator<String>() {

                    @Override
                    public int compare(String o1, String o2) {
                        Integer l1 = o1.length();
                        Integer l2 = o2.length();
                        
                        return l2.compareTo(l1);
                    }
                    
                };
                List<Searchable> list = details.search(regex, deep != null, tokens);
                Collections.sort(tokens, comparator);
                
                for(String token : tokens) {
                    System.out.println("TOKEN: "+token);
                }
                
                resp.set("Content-Type", "text/html");
                
                out.println("<html>");
                out.println("<head>");
                out.println("<link rel='stylesheet' type='text/css' href='style.css'>");
                out.println("<script src='highlight.js'></script>");
                out.println("</head>");
                out.println("<body onload=\"sh_highlightDocument('lang/', '.js')\">");
             
                writeSearchBox(out, searcher);
                
                out.println("<br>Found " + list.size() + " hits for <b>"+regex+"</b>");
                out.println("<table border='1''>");
                int countIndex = 1;
                for(Searchable value : list) {
                    out.println("    <tr><td>"+countIndex+++"&nbsp;<a href='"+value.getSource()+"'><b>"+value.getSource()+"</b></a></td></tr>");
                    out.println("    <tr><td><pre class='sh_xml'>");
                    StringWriter buffer = new StringWriter();
                    persister.write(value, buffer);
                    String text = buffer.toString();
                    text = text.replaceAll("<", "&lt;").replaceAll(">", "&gt;");
                    
                    for(String token : tokens) {
                        text = text.replaceAll(token, "<font style='BACKGROUND-COLOR: yellow'>"+token+"</font>");
                    }
                    out.println(text);
                    out.println("    </pre></td></tr>");
                }
                out.println("</table>");
                out.println("</form>");
                out.println("</body>");
                out.println("</html>");
            } else if(index != null && term != null && term.length() > 0){
                out.println("<html>");
                out.println("<head>");
                out.println("<link rel='stylesheet' type='text/css' href='style.css'>");
                out.println("<script src='highlight.js'></script>");
                out.println("</head>");
                out.println("<body onload=\"sh_highlightDocument('lang/', '.js')\">");
                
                writeSearchBox(out, searcher);

                if(searcher == null) {
                    searcher = searchEngine.getDefaultSearcher();
                }
                searchEngine.index(searcher).search(index, term, refresh != null, grep != null, name != null, out);
                
                out.println("</body>");
                out.println("</html>");
            }else {
            
                out.println("<html>");
                out.println("<body>");
                
                // write out with the searcher selected if any
                writeSearchBox(out, searcher);
                
                out.println("</body>");
                out.println("</html>");
            }
            out.close();
        }catch(Exception e) {
            try {
                e.printStackTrace();
                resp.reset();
                resp.setCode(500);
                resp.setText("Internal Server Error");
                resp.set("Content-Type", "text/html");
                out.println("<html>");
                out.println("<body><h1>Internal Server Error</h1><pre>");
                e.printStackTrace(out);
                out.println("</pre></body>");
                out.println("</html>");
                out.close();
            }catch(Exception ex) {
                ex.printStackTrace();
            }
        }        
    }
    
    public void writeSearchBox(PrintStream out, String searcherToUse) throws Exception {
        out.println("<table border='1'><tr><td valign='top'>");
        out.println("<tr><td valign='top'>");
        
        writeXmlSearchBox(out);
        
        out.println("</td><td valign='top'>");
        
        writeCodeSearchBox(out, searcherToUse);
        
        out.println("</td></tr></table>");
    }
    
    private void writeXmlSearchBox(PrintStream out) throws Exception {
        out.println("<form action='/search' method='POST'>");
        out.println("<table border='0'>");
        out.println("<tr><td valign='top'>");
        // search table
        out.println("<table border='1'>");
        String checked = "checked";
        
        for(Config.Environment entry : config.getEnvironments()) {
            out.println("    <tr><td>"+entry.getName().toUpperCase()+": <input type='radio' name='env' value='"+entry.getName()+"' "+checked+"/></td></tr>");
            checked = "";
        }           
        out.println("    <tr><td><input type='text' name='regex' /><input type='submit' value='Search' /></td></tr>");
        out.println("</table>");
        out.println("</td><td valign='top'>");
        // scope table
        out.println("<table border='1'>");       
        out.println("    <tr><td>Search fi_server_details</td><td><input type='checkbox' name='fi_server_details' checked></td></tr>");
        out.println("    <tr><td>Search server_details</td><td><input type='checkbox' name='server_details' checked></td></tr>");   
        out.println("    <tr><td>Search host_details</td><td><input type='checkbox' name='host_details' checked></td></tr>");
        out.println("    <tr><td>Deep Search</td><td><input type='checkbox' name='deep'></td></tr>");   
        out.println("</table>");
        out.println("</table>");
        out.println("</form>");
    }
    
    private void writeCodeSearchBox(PrintStream out, String searcherToUse) throws Exception {
        out.println("<form name='searchForm' action='/search' method='POST'>");
        out.println("<table border='1'>");
        String defaultSearcher = searchEngine.getDefaultSearcher();
        
        // Use the one your told to use
        if(searcherToUse != null) {
            defaultSearcher = searcherToUse;
        }
        out.println("<tr><td><select name='searcher' onChange='searchForm.submit();'>");
        for(Searcher searcher : searchEngine.all()) {
            String name = searcher.getName();
            String selected = "";
            
            if(name.equals(defaultSearcher)) {
                selected = "selected";
            }
            out.println("<option value='"+name+"' "+selected+">"+name+"</option>");
        }
        out.println("</select></td></tr>");
        
        for(Searcher searcher : searchEngine.all()) {
            String name = searcher.getName();
            
            if(name.equals(defaultSearcher)) {
                String defaultIndex = searcher.getDefaultIndex();
                List<String> indexes = searcher.getIndexes();
                for(String index : indexes) {
                    String checked = "";
                    if(index.equals(defaultIndex)) {
                        checked = "checked";
                    }
                    out.println("<tr><td>"+index+": <input type='radio' name='index' value='"+index+"' "+checked+"/></td></tr>");
                }
            }                           
        }           
        out.println("<tr><td><input type='text' name='term' /><input type='submit' value='Search' /></td></tr>");
        out.println("<tr><td>");        
        out.println("<table border='0'>");
        out.println("<tr><td>Match Exactly</td><td><input type='checkbox' name='grep' checked></td></tr>");
        out.println("<tr><td>Refresh Index</td><td><input type='checkbox' name='refresh'></td></tr>");
        out.println("<tr><td>Search File Names</td><td><input type='checkbox' name='name'></td></tr>");   
        out.println("</table>");        
        out.println("</td></tr>");
        out.println("</table>");
        out.println("</form>");
    }

    public static void main(String[] list) throws Exception {
        int port = new Integer(list[0]).intValue();
        File configFile = new File(list[1]);
        File searchConfigFile = new File(list[2]);
        Persister persister = new Persister();
        SearchEngine searchEngine = persister.read(SearchEngine.class, searchConfigFile);
        Config config = persister.read(Config.class, configFile);
        Container container = new SearchServer(config, searchEngine, persister);
        Connection connection = new SocketConnection(container);
        SocketAddress address = new InetSocketAddress(port);

        connection.connect(address);
     }

}

