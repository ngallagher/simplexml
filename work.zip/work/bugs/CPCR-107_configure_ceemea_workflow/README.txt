# The following location contains the configuration for streaming

\\fm.rbsgrp.net\APPROOT\CentralisedPricing\UAT\aqclient\aqclient.122009.16.0\bin\release\config\clients

# Documentation for manual streaming

https://confluence.dts.fm.rbsgrp.net/display/PRELECLQ/User+Training+Guide

# For EuroGov the following deal types support manual streaming

EBC: LD -> Reject -> Rbsfm.Capmarkets.AutoQuoter.PopUps.RejectStreamingButtonHandler
SBC: LD -> Reject -> Rbsfm.Capmarkets.AutoQuoter.PopUps.RejectStreamingButtonHandler
ESTRIPC: LD -> Reject -> Rbsfm.Capmarkets.AutoQuoter.PopUps.RejectStreamingButtonHandler

EGC_2: TI -> Send Stream -> Rbsfm.Capmarkets.AutoQuoter.PopUps.SendStreamButtonHandler
EGC_2: TI -> Go To Manual -> Rbsfm.Capmarkets.AutoQuoter.PopUps.GoToManualStreamingButtonHandler 
EGC_2: TI -> Reject -> Rbsfm.Capmarkets.AutoQuoter.PopUps.RejectStreamingButtonHandler

ESC_2: TI -> Send Stream -> Rbsfm.Capmarkets.AutoQuoter.PopUps.SendStreamButtonHandler
ESC_2: TI -> Go To Manual -> Rbsfm.Capmarkets.AutoQuoter.PopUps.GoToManualStreamingButtonHandler 
ESC_2: TI -> Reject -> Rbsfm.Capmarkets.AutoQuoter.PopUps.RejectStreamingButtonHandler

EBC: -> NONE ????
SBC: -> NONE ????

# The RFQ type for the tickets 

     <field name="dealCategory" value="EBC" />

# Following steps needed

- raise a ticket and see if it works we might need to make a change to the aqclient config file to specify we're using eurogov tickets. any issues speak to Rod on client team. 

- get e-trading working for Outrights and Switches. Ie ensure theres a price and yield that can be ticketd, manual streaming works, there are no msgs in the text box that can't be explained. ensure the autoquoter logs are error free. 

- once we've established that the basics work we'll hand over to the QA team.  

# Configure the ticket type of the AQ client, change the AppLauncher config

client=LOCAL_MARKETS -> client=EUROGOV

# To raise a switch trade do the following from a BBG terminal

BBT => Markets -> non-euro => Strategy -> switch 

# Perform the seasoning checks for CEEMEA

MultiInquiryOrderAction
PriceOrderAction
OrderAutoQuoteAction

# Set the ceemea deal category to match eurogov

categorise.deal..ceemea.autoquoter=EurogovDealCategoriser

# Add ceemea to eurogov entry 

      <server type="eurogov,ceemea">
