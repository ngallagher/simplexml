<<< pricing >>>

<hostattribute name="InstMaintServer" value="latam-pricing-instmaint"/>

<<< instrument maintainence >>>

# Missing from template

${request.bonds.email.tokyo}  
<al_directory>d:/caf/mainline/bin</al_directory>
<recalcBASprd>${bidAskManualFrnPriceCalculator.recalcBASprd}</recalcBASprd>
<tokyoDataSource>${instmaint.persistence.tokyoDS}</tokyoDataSource>

# Missing from UAT

<audit_server_port></audit_server_port>
<audit_realtime_symbol></audit_realtime_symbol>
<audit_bond_ref></audit_bond_ref>

# Missing reuters config ******************

<reutersDacsId>Application_CP_LM</reutersDacsId>

# Missing data source

<tokyoDataSource>${instmaint.persistence.tokyoDS}</tokyoDataSource>

# Enlivener properties

<emailTradeSupportControlTeam>${request.bonds.emailTSC}</emailTradeSupportControlTeam>
<emailBBGTeam>${request.bonds.emailBBG}</emailBBGTeam>

