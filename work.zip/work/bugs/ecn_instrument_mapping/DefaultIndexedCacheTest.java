package com.rbsfm.fi.pricing.util.cache;

import java.util.List;
import java.util.concurrent.CountDownLatch;

import junit.framework.TestCase;


public class DefaultIndexedCacheTest extends TestCase {
    
    private static final String INDEX_NAME = "indexName";
    private static final int ITERATIONS = 1000;
    
    private static final String[] OID_PROPERTIES = {
        "InstrumentId",
        "EcnId",
        "MappingType"
    };
    
    private static final String[] INDEX_PROPERTIES = {
        "EcnId",
        "MappingType"
    };
    
    private static final String[] ORDER_BY_PROPERTIES = {
        "EcnInstrumentId"
    };        
    
    public void testIndexCacheTest() throws Exception {
        ObjectAttributeIndexFunction oidFunc = new ObjectAttributeIndexFunction(null, null, OID_PROPERTIES, new String[]{}, true);
        ObjectAttributeIndexFunction indexFunc = new ObjectAttributeIndexFunction(oidFunc, INDEX_NAME, INDEX_PROPERTIES, ORDER_BY_PROPERTIES, true);
        OrderedLinkIndexedCache cache = new OrderedLinkIndexedCache(oidFunc, new IndexFunction[]{indexFunc});
        EcnInstrumentMapping cacheValue = new EcnInstrumentMapping("US195325AJ47", "Bloomberg", "AutoQuoter", "195325AJ4");
        CountDownLatch startLatch = new CountDownLatch(3);
        FindThread findThread = new FindThread(cache, cacheValue, startLatch);
        PutThread putThread = new PutThread(cache, cacheValue, startLatch);  
        
        cache.put(cacheValue);
        putThread.start();
        findThread.start();
        startLatch.countDown();
        putThread.join();
        findThread.join();
    }
    
    public class FindThread extends Thread {
        
        private final DefaultIndexedCache cache;
        private final EcnInstrumentMapping value;
        private final CountDownLatch latch;
        
        public FindThread(DefaultIndexedCache cache, EcnInstrumentMapping value, CountDownLatch latch) {
            this.cache = cache;
            this.value = value;
            this.latch = latch;
        }
        
        public void run() {
            try {
                latch.countDown();
                latch.await();
                
                for(int i = 0; i < ITERATIONS; i++) {
                    List<?> list = cache.findByIndex(INDEX_NAME, value);
                    
                    assertNotNull(list);
                    assertNotNull(list.get(0));
                    assertEquals(list.get(0), value);
                    Thread.sleep(1);
                }
            }catch(Exception e) {
               e.printStackTrace(); 
            }        
        }
    }
    
    public class PutThread extends Thread {
        
        private final DefaultIndexedCache cache;
        private final EcnInstrumentMapping value;
        private final CountDownLatch latch;
        
        public PutThread(DefaultIndexedCache cache, EcnInstrumentMapping value, CountDownLatch latch) {
            this.cache = cache;
            this.value = value;
            this.latch = latch;
        }
        
        public void run() {
            try {
                latch.countDown();
                latch.await();
                
                for(int i = 0; i < ITERATIONS; i++) {
                    cache.put(value);
                    Thread.sleep(1);
                }
            }catch(Exception e) {
               e.printStackTrace(); 
            }        
        }
    }
}

