# Updating the mapping in the table

OrderedLinkSet.remove(PseudoKey) line: 91	
OrderedLinkIndexedCache(DefaultIndexedCache).putToIndex(IndexFunction, Map<PseudoKey,LinkSet>, PseudoKey, Object, Object) line: 381	
OrderedLinkIndexedCache(DefaultIndexedCache).put(Object) line: 180	
ConfigurableIndexedCache(AbstractIndexedCacheDecorator).put(Object) line: 154	
AbstractHome$InternalHomeStore.load(Object[]) line: 91	
PollingDbHomeBehaviour(AbstractHomeBehaviour).load(Object[]) line: 44	
PollingDbHomeBehaviour.internalDbRowsModified(List) line: 220	
PollingDbHomeBehaviour.access$000(PollingDbHomeBehaviour, List) line: 29	
PollingDbHomeBehaviour$1.dbRowsModified(List) line: 53	
DbRowModificationPollerImpl.sendChanges(String, List) line: 228	
DbRowModificationPollerImpl.processChanges() line: 178	
DbRowModificationPollerImpl.poll() line: 126	
DbRowModificationPollerImpl.access$000(DbRowModificationPollerImpl) line: 43	
DbRowModificationPollerImpl$1.run() line: 273	
Thread.run() line: 619	

# Storing the mapping

exec EcnInstrumentMappingStore 'US706448AR84', 'Bloomberg', 'AutoQuoter', '706448AR8', 2, 'gallane', 'gallane' 

# Removal hitting the comparison

ObjectAttributeIndexFunction$PropertyPseudoKeyComparator.compare(PseudoKey, PseudoKey) line: 255	
ObjectAttributeIndexFunction$PropertyPseudoKeyComparator.compare(Object, Object) line: 248	
OrderedLinkSet.remove(PseudoKey) line: 90	
OrderedLinkIndexedCache(DefaultIndexedCache).removeFromIndex(IndexFunction, Map<PseudoKey,LinkSet>, PseudoKey, Object) line: 403	
OrderedLinkIndexedCache(DefaultIndexedCache).remove(Object) line: 301	
ConfigurableIndexedCache(AbstractIndexedCacheDecorator).remove(Object) line: 162	
AbstractHome$InternalHomeStore.unload(Object[]) line: 127	
PollingDbHomeBehaviour(AbstractHomeBehaviour).unload(Object[]) line: 52	
PollingDbHomeBehaviour.internalDbRowsModified(List) line: 256	
PollingDbHomeBehaviour.access$000(PollingDbHomeBehaviour, List) line: 29	
PollingDbHomeBehaviour$1.dbRowsModified(List) line: 53	
DbRowModificationPollerImpl.sendChanges(String, List) line: 228	
DbRowModificationPollerImpl.processChanges() line: 178	
DbRowModificationPollerImpl.poll() line: 126	
DbRowModificationPollerImpl.access$000(DbRowModificationPollerImpl) line: 43	
DbRowModificationPollerImpl$1.run() line: 273	
Thread.run() line: 619	

# The resulting removal is the following 

EcnInstrumentMapping instrumentId[US706448AR84] ecnId[Bloomberg] mappingType[AutoQuoter] ecnInstrumentId[]

# To remove use the following

exec EcnInstrumentMappingDelete "US706448AR84", "Bloomberg", "AutoQuoter", 2, "mccarmd", "mccarmd"

# Call from the DbPoller

OrderedLinkIndexedCache(DefaultIndexedCache).remove(Object) line: 288	
ConfigurableIndexedCache(AbstractIndexedCacheDecorator).remove(Object) line: 162	
AbstractHome$InternalHomeStore.unload(Object[]) line: 127	
PollingDbHomeBehaviour(AbstractHomeBehaviour).unload(Object[]) line: 52	
PollingDbHomeBehaviour.internalDbRowsModified(List) line: 256	
PollingDbHomeBehaviour.access$000(PollingDbHomeBehaviour, List) line: 29	
PollingDbHomeBehaviour$1.dbRowsModified(List) line: 53	
DbRowModificationPollerImpl.sendChanges(String, List) line: 228	
DbRowModificationPollerImpl.processChanges() line: 178	
DbRowModificationPollerImpl.poll() line: 126	
DbRowModificationPollerImpl.access$000(DbRowModificationPollerImpl) line: 43	
DbRowModificationPollerImpl$1.run() line: 273	
Thread.run() line: 619	


# There is a race condition in the put method

The com.rbsfm.fi.pricing.util.cache.DefaultIndexedCache is not thread safe with regards to a put.
Unlike a synchronized hash map it will not replace the value, it will remove it and then release
any synchronization before adding it again. This can cause problems if the 
com.rbsfm.fi.pricing.home.db.PollingDbHomeBehaviour is updating the cache when an RFQ comes in.
As a reload will remove the mapping from the linked set before adding it again, meaning that
getting the value by index results in null. 


# The putToIndex results in the following being called

{ call EcnInstrumentMappingStore( 'US912828KR03', 'Bloomberg', 'AutoQuoter', '912828KR0', 0, 'STAMS00058::11780::latam autoquoter offshore', 'cpratesdev' ) }

# The puts can result in removals from the cache

// FOR THE DATA MAP
put(new EcnInstrumentMapping("SG70415AB35", "Bloomberg", "AutoQuoter", "DD0110062")); -> "SG70415AB35" ^ "Bloomberg" ^ "AutoQuoter"
put(new EcnInstrumentMapping("USP6988YAK75", "Bloomberg", "AutoQuoter", "EF6077624")); -> "USP6988YAK75" ^ "Bloomberg" ^ "AutoQuoter"

// FOR THE FUNCTION MAP
put(new EcnInstrumentMapping("SG70415AB35", "Bloomberg", "AutoQuoter", "DD0110062")); -> "Bloomberg" ^ "AutoQuoter"
put(new EcnInstrumentMapping("USP6988YAK75", "Bloomberg", "AutoQuoter", "EF6077624")); -> "Bloomberg" ^ "AutoQuoter"

FOR DIFFERENT MARKETS THE KEY IS THE SAME FOR THE INDEX FUNCTION, THIS MEANS THAT THE PUT CAN FAIL IN
A MULTITHREADED ENVIRONMENT.

TWO UPDATES OF THE SAME TYPE, "THE ONLY WAY THIS CAN BE DIFFERENT IS IF WE CHANGE THE MAPPING AND THE POLLER CATCHES THIS" 

!!! THE PUT REMOVES RANDOMLY !!!

# The clear function 

The clear function as with many other functions is not strictly thread safe.

# On load the object is not introduced as a component until all mappings are loaded

The com.rbsfm.fi.pricing.home.db.PollingDbHomeBehaviour object is used to load and
reload the data from the database. It will then populate the EcnInstrumentMappingHomeImpl
so that the groups can be acquired.

# Locks are attempted to be acquired on intervals of

writeAcquireTimeout=60000
readAcquireTimeout=60000

# Here is the query used to populate the EcnInstrumentMapping home

"SELECT InstrumentId , EcnId , MappingType , EcnInstrumentId , Version, CreatorRef, CreationDatetime, UpdaterRef, UpdateDatetime FROM EcnInstrumentMappingView"  

# The resulting cache has a __NULL__ combimer

a) A null combiner means that on a "put()" you do not accumulate the data you simply replace
   the existing object, just as you would do with a hash map.

b) When adding existing objects mapped are removed.

c) Adding the object to the cache will also add the object to a map where the map represents
   a group of objects. These objects are sorted by an index function, where we key the map
   using the index function.

   IndexFunction --> Map<PseudoKey, LinkSet>()

   This means that for each index function you have private LinkSet that is maintained
   seperately from the other LinkSet objects. The LinkSet will store the
   EcnInstrumentMapping objects.

d) The index functions are used to group objects based on a certain property. So for
   example if some object had a name and an index was used for the name, it would
   group all objects based on their names.



# Indernal indexes used by the index cache is

Map<IndexFunction, Map<PseudoKey, LinkSet>>(); == ObjectAttributeIndexFunction({"EcnInstrumentId", "InstrumentId", "EcnId", "MappingType"}) -> Map<PseudoKey, LinkSet>();
Map<String, Map<PseudoKey, LinkSet>>(); == "findAllByTypeOrderByEcnInstrumentId" -> Map<PseudoKey, LinkSet>();

# Only one index function exists it is called

"findAllByTypeOrderByEcnInstrumentId" ---> ObjectAttributeIndexFunction({"EcnInstrumentId", "InstrumentId", "EcnId", "MappingType"})

# Creation of the cache finishes with

com.rbsfm.fi.pricing.util.cache.OrderedLinkIndexedCache.OrderedLinkIndexedCache(
    "EcnInstrumentMappingHomeCache", 
    "ObjectAttributeIndexFunction", 
    {"ObjectAttributeIndexFunction"}
}

# [INDEX FUNCTION] the order is determined from

Ordering is done by exposing a method "ordering()" from the INDEX FUNCTION and
doing a comparison of the objects using a string comparitor, the order by which
the comparisons are done is as follows.

EcnInstrumentId, 
InstrumentId,  
EcnId,        
MappingType    

# [INDEX FUNCTION] The function used to index

mPropertyAccessors = {    
    EcnId
    MappingType
}

mOrderByAccessors = {
    EcnInstrumentId, 
    InstrumentId,  <-- INHERITED FROM OID
    EcnId,         <-- INHERITED FROM OID
    MappingType    <-- INHERITED FROM OID
}

# [OID FUNCTION] These property methods are used to generate a key like so

      int hashCode = 0;
      for (int i = 0; i < mKeyValues.length; i++) {
        hashCode = hashCode ^ (mKeyValues[i] == null ? 0 : mKeyValues[i].hashCode());
      }
      return hashCode;


# [OID FUNCTION] The property accessors use a really crap string concat like so

InstrumentId -> "getInstrumentId()"
EcnId -> "getEcnId()"
MappingType -> "getMappingType()"


# [OID FUNCTION] On initialisation the property accessors are, WHICH ARE ALSO THE ORDERED ACCESSORS

mPropertyAccessors = {
    InstrumentId
    EcnId
    MappingType
}

mOrderByAccessors = {
    InstrumentId
    EcnId
    MappingType
}

# When the com.rbsfm.fi.pricing.util.cache.ObjectAttributeIndexFunction is used the following is true

safelyUserLinkOrdering=true

# The cache configuration is as follows

    <cache name="EcnInstrumentMappingHomeCache" class_name="com.rbsfm.fi.pricing.util.cache.ConfigurableIndexedCache">
      <oidFunction class_name="com.rbsfm.fi.pricing.util.cache.ObjectAttributeIndexFunction">
        <attribute name="InstrumentId" />
        <attribute name="EcnId" />
        <attribute name="MappingType" />
      </oidFunction>
      <indexes>
        <indexFunction name="findAllByTypeOrderByEcnInstrumentId" class_name="com.rbsfm.fi.pricing.util.cache.ObjectAttributeIndexFunction">
          <attribute name="EcnId" />
          <attribute name="MappingType" />
          <orderBy name="EcnInstrumentId" />
        </indexFunction>
      </indexes>
    </cache>

# The cache used by the EcnInstrumentMappingHomeImpl is 

com.rbsfm.fi.pricing.util.cache.ConfigurableIndexedCache

# Creation of the EcnInstrumentMappingHomeImpl comes from 

com.rbsfm.fi.pricing.ecn.mapping.EcnInstrumentMappingHomeImpl.configure(com.rbsfm.common.config.Config) line: 126	
com.rbsfm.common.system.ConfigurableComponentManager.createComponent(com.rbsfm.common.config.Config) line: 151	
com.rbsfm.common.system.ConfigurableComponentManager.getComponent(java.lang.String) line: 180	
com.rbsfm.fi.pricing.ecn.instrumentmapping.AllBrokerInstrumentMapper(com.rbsfm.common.system.AbstractConfigurable).getComponent(java.lang.String, boolean) line: 423	
com.rbsfm.fi.pricing.ecn.instrumentmapping.AllBrokerInstrumentMapper(com.rbsfm.common.system.AbstractConfigurable).getReferencedComponent(com.rbsfm.common.config.Config, java.lang.String, java.lang.String, boolean) line: 386	
com.rbsfm.fi.pricing.ecn.instrumentmapping.AllBrokerInstrumentMapper(com.rbsfm.common.system.AbstractConfigurable).getReferencedComponent(com.rbsfm.common.config.Config, java.lang.String, boolean) line: 344	
com.rbsfm.fi.pricing.ecn.instrumentmapping.AllBrokerInstrumentMapper.configure(com.rbsfm.common.config.Config) line: 122	
com.rbsfm.common.system.ConfigurableComponentManager.createComponent(com.rbsfm.common.config.Config) line: 151	
com.rbsfm.common.system.ConfigurableComponentManager.getComponent(java.lang.String) line: 180	
com.rbsfm.fi.pricing.ecn.autoquote.util.DefaultAutoQuoterServices(com.rbsfm.common.system.AbstractConfigurable).getComponent(java.lang.String, boolean) line: 423	
com.rbsfm.fi.pricing.ecn.autoquote.util.DefaultAutoQuoterServices(com.rbsfm.common.system.AbstractConfigurable).getReferencedComponent(com.rbsfm.common.config.Config, java.lang.String, java.lang.String, boolean) line: 386	
com.rbsfm.fi.pricing.ecn.autoquote.util.DefaultAutoQuoterServices(com.rbsfm.common.system.AbstractConfigurable).getReferencedComponent(com.rbsfm.common.config.Config, java.lang.String) line: 354	
com.rbsfm.fi.pricing.ecn.autoquote.util.DefaultAutoQuoterServices.configure(com.rbsfm.common.config.Config) line: 79	

