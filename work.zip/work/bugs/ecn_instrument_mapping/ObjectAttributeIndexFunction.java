/*
 * Created on 02-Nov-2004 by BartodB (Dave Barton)
 */
package com.rbsfm.fi.pricing.util.cache;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import com.rbsfm.common.config.Config;
import com.rbsfm.common.system.AbstractConfigurable;

/**
 * @author <a href="mailto:dave.barton@rbos.com">Dave Barton</a>
 */
public class ObjectAttributeIndexFunction extends AbstractConfigurable implements IndexFunction, ObjectIdFunction {

  private static final Comparator DEFAULT_COMPARATOR = new ComparableComparator();
  
  private Comparator mCachedComparator;
  
  // TODO: Use Methods instead
  private String[]  mPropertyAccessors;
  private String[] mOrderByAccessors;

  private Comparator[] mPropertyComparators; 
  private ObjectAttributeIndexFunction mOidFunc;
  private boolean mOrderingEnabled = true;
  private boolean mInitialised;
  
  /**
   * 
   */
  public ObjectAttributeIndexFunction() {
    super();
    mOidFunc = null;
  }
  
  /**
   * 
   */
  public ObjectAttributeIndexFunction(ObjectAttributeIndexFunction oidFunc) {
    super();
    mOidFunc = oidFunc;
  }
  
  /**
   * This constructor is used for unit testing purposes. 
   */
  ObjectAttributeIndexFunction(ObjectAttributeIndexFunction oidFunc, String name, String[] propertyAccessors, String[] orderByAccessors, boolean orderingEnabled) {
      super();
      mOidFunc = oidFunc;
      setName(name);
      initialise(propertyAccessors, orderByAccessors, orderingEnabled);      
  }  

  /**
   *
   */
  public void configure(Config config) {
    super.configure(config);
    Config[] attConfigs = config.getChildren("attribute");
    String[] propertyAccessors = new String[attConfigs.length];
    for (int i = 0; i < attConfigs.length; i++) {
      // TODO: Use Methods instead
      String propertyName = attConfigs[i].getStringValue("name");
      propertyAccessors[i] = propertyName;
    }
    boolean orderingEnabled = config.getBooleanValue("ordering_enabled", mOrderingEnabled);
   
    Config[] orderByConfigs = config.getChildren("orderBy");
    int orderByConfigsLen = orderByConfigs.length;
    List<String> l = new ArrayList<String>();
    for (int i = 0; i < orderByConfigsLen; i++) {
      // TODO: Use Methods instead
      String propertyName = orderByConfigs[i].getStringValue("name");
      l.add(propertyName);
    }
    String[] orderByAccessors = new String[l.size()];
    orderByAccessors = (String[])l.toArray(orderByAccessors);
    
    initialise(propertyAccessors, orderByAccessors, orderingEnabled);
  }
  
  /**
   * Initialisation shared across configuration and object instantiation.
   * This can only be called once for an instance.
   */
  private void initialise(String[] propertyAccessors, String[] orderByAccessors, boolean orderingEnabled) {
    if(mInitialised) {
        throw new IllegalStateException("Object has already been initialised");
    }
    mPropertyAccessors = propertyAccessors;
    mOrderingEnabled = orderingEnabled;
    mInitialised = true;
    
    if (mOidFunc == null) {
      //this must be an OIDFUNC so store the orderby for the IndexFuncs
      mOrderByAccessors = new String[mPropertyAccessors.length];
      System.arraycopy(mPropertyAccessors,0,mOrderByAccessors,0,mOrderByAccessors.length);
    } else {
      //here we are an INDEXFUNC so we need to make sure that any orderby is consistent 
      //with the oid.
      if (orderByAccessors.length > 0) {
        ArrayList l = new ArrayList();
        for (int i = 0; i < orderByAccessors.length; i++) {
          // TODO: Use Methods instead
          String propertyName = orderByAccessors[i];
          l.add(propertyName);
        }
        for (int j = 0; j < mOidFunc.mOrderByAccessors.length; j++) {
          String n = mOidFunc.mOrderByAccessors[j];
          if (!l.contains(n)) {
            l.add(n);
          }
        }
        mOrderByAccessors = new String[l.size()];
        mOrderByAccessors = (String[])l.toArray(mOrderByAccessors);
        mPropertyComparators = new Comparator[l.size()];
        for (int i = 0; i < l.size(); i++) {
          // TODO: Use Methods instead
          String propertyName = (String) l.get(i);
          mOrderByAccessors[i] = propertyName;
          mPropertyComparators[i] = DEFAULT_COMPARATOR;
        }
        mCachedComparator = new PropertyComparator();
      }
    }
  }
  
  
  public boolean orderingEnabled() {
	return mOrderingEnabled;
  }

 
  public Comparator ordering() {
    return mCachedComparator;
  }
  
  /**
   *
   */
  public PseudoKey pseudoKey(Object value) {
    return new PropertyPseudoKey(value);
  }
  
  /**
   *
   */

  public PseudoKey eval(Object value) {
    return pseudoKey(value);
  }
  
  // Private Helper Methods
  // ======================
  
  
  private Object getPropertyValue(Object obj, int index) {
    // TODO: Use Methods instead
    return extractValue(obj, mPropertyAccessors[index]);
  }
  
  private Object getOrderByValue(Object obj, int index) {
    // TODO: Use Methods instead
    return extractValue(obj, mOrderByAccessors[index]);
  }
  /**
   * @param obj
   * @param propName
   * @return
   */
  private Object extractValue(Object obj, String propName) {
    Object retVal;
    Method method;
    try {
      method = obj.getClass().getMethod("get"+propName,null);
      method.setAccessible(true);
      retVal = method.invoke(obj,null);
    } catch (Exception ex) {
      try {
        method = obj.getClass().getMethod("is"+propName,null);
        method.setAccessible(true);
        retVal = method.invoke(obj,null);
        
      } catch (Exception ex2) {
        retVal = null;
      }
    }
    return retVal;
  }
  
  
  private class PropertyPseudoKey implements PseudoKey {

    private Object[] mKeyValues;
    private String str;
    /**
     * 
     */
    public PropertyPseudoKey(Object obj) {
      StringBuffer sb = new StringBuffer("{");
      mKeyValues = new Object[mPropertyAccessors.length];
      for (int i = 0; i < mKeyValues.length; i++) {
        mKeyValues[i] = getPropertyValue(obj, i);
        sb.append(mPropertyAccessors[i]).append("[").append(mKeyValues[i]).append("]");
        if (i+1 < mKeyValues.length) {
          sb.append(",");
        }
      }
      sb.append("}");
      str=sb.toString();
    }
    public String toString() {
      return str;
    }
    
    /**
     *
     */
    public boolean equals(Object obj) {
      boolean retVal = false;
      if (obj == this) {
        retVal = true;
      } else if (obj == null) {
        retVal = false;
      } else if (obj instanceof PropertyPseudoKey) {
        retVal = Arrays.equals(mKeyValues, ((PropertyPseudoKey) obj).mKeyValues);
      }
      return retVal;
    }

    /**
     *
     */
    public int hashCode() {
      int retVal = 0;
      for (int i = 0; i < mKeyValues.length; i++) {
        retVal = retVal ^ (mKeyValues[i] == null ? 0 : mKeyValues[i].hashCode());
      }
      return retVal;
    }
    
    /**
     * @see com.rbsfm.fi.pricing.util.cache.PseudoKey#values()
     */
    public List<Object> values() {
      return Arrays.asList(mKeyValues);
    }
  }  
  
  private class PropertyComparator implements Comparator {

      public int compare(Object o1, Object o2) {
          int retVal = 0;
          for (int i = 0; i < mPropertyComparators.length; i++) {
            retVal = mPropertyComparators[i].compare(getOrderByValue(o1, i), getOrderByValue(o2, i));
            if (retVal != 0) {
              break;
            }
          }
          return retVal;
        }
      };
  
  private static class ComparableComparator implements Comparator {

    public int compare(Object o1, Object o2) {
      int retVal = 0;
      if (o1 instanceof Comparable) {
        retVal = ((Comparable) o1).compareTo(o2);
      } if (o2 instanceof Comparable) {
        retVal = - ((Comparable) o2).compareTo(o1);
      } else {
        throw new ClassCastException("Instances not comparable. ["+ (o1 !=null ? o1.getClass().getName() : "NULL")  +"] vs ["+(o2 !=null ? o2.getClass().getName() : "NULL")+"]");
      }
      return retVal;
    }
  }
  private static final Comparator keyComparer = new ComparableComparator();
  public static final Comparator<PseudoKey> PSEUDO_KEY_COMPARER = new PropertyPseudoKeyComparator();
  private static class PropertyPseudoKeyComparator implements Comparator<PseudoKey> {

    public int compare(PseudoKey p1,PseudoKey p2) {
      List<?> keyValues1 = p1.values();
      List<?> keyValues2 = p2.values();
      int min = Math.min(keyValues1.size(), keyValues2.size());
      int retval = 0;;
      for (int i = 0; i < min; i++) {
        int tmp = keyComparer.compare(keyValues1.get(i), keyValues1.get(i));
        if (tmp != 0) {
          retval = tmp;
          break;
        } 
      }
      return retval;
    }
    
  }
}

