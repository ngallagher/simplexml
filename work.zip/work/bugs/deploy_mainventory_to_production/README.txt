# Credentials for EM Actives prices 

Userid: rbsmactives
Password: dealer12

# Addresses for the gateway

The IP/port for Production and DR are as below:

Production: 63.123.195.193 on port 443
DR: 63.123.195.134 on port 443

