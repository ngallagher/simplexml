# Messages from MarketAxess are basically raising the inquiry and timing out

<?xml version='1.0'?><!DOCTYPE MA SYSTEM 'ma.dtd'><MA><HEADER><MESSAGE-ID>1269</MESSAGE-ID><MESSAGE-TYPE>REQUEST</MESSAGE-TYPE><MESSAGE-VERSION>3.1.0</MESSAGE-VERSION></HEADER><TRADING PROTOCOL="PRICE"><INQUIRY-UPDATE STATE="SUBMITTED" DIRECTION="FORWARD" SPOT-PROCESS="STANDARD"><INQUIRY-ID>609351</INQUIRY-ID><UPDATE-TIME>07/29/2009 10:07:09</UPDATE-TIME><ALLOW-PARTIAL-FILL>Y</ALLOW-PARTIAL-FILL><CUSTOMER><SHORT-NAME>rbsclient1</SHORT-NAME><LONG-NAME>MarketAxess QA UK Staging</LONG-NAME><TRADER-FULL-NAME>rbsclient1 rbsclient1</TRADER-FULL-NAME><MA-ACCOUNT-ID>88306826</MA-ACCOUNT-ID><FIRM-NAME>MAQAUKS</FIRM-NAME></CUSTOMER><DUE-IN-TIME>60</DUE-IN-TIME><TIME-DUE>07/29/2009 10:08:09</TIME-DUE><ASAP-FLAG>Y</ASAP-FLAG><CREATE-TIME>07/29/2009 10:07:09</CREATE-TIME><NUMBER-OF-DEALERS>1</NUMBER-OF-DEALERS><NUMBER-OF-LEGS>1</NUMBER-OF-LEGS><INQUIRY-LEG SIDE="BUY" INSTRUMENT-TYPE="CORPORATE" LEG-TYPE="CORPORATE"><LEG-ID>1</LEG-ID><INQUIRY-SIZE>7777</INQUIRY-SIZE><SETTLEMENT-DATE>08/03/2009</SETTLEMENT-DATE><LEVEL-TYPE>PRICE</LEVEL-TYPE><SECURITY><CUSIP9>105756BB5</CUSIP9><CUSIP>105756BB</CUSIP><ISIN>US105756BB58</ISIN><WKN>A0ACBP</WKN><ISSUE-DATE>01/20/2004</ISSUE-DATE><DATED-DATE>01/20/2004</DATED-DATE><ISSUER>BRAZIL</ISSUER><TICKER>BRAZIL</TICKER><COUPON>8.25</COUPON><MATURITY>01/20/2034</MATURITY><CURRENCY>USD</CURRENCY><DESCRIPTION>Bond</DESCRIPTION></SECURITY></INQUIRY-LEG><LOG-INFO>MAQAUKS (rbsclient1) requests bid on $7,777,000 BRAZIL 8.250 01/20/34, due in 1 mins (ASAP) Single-Dealer</LOG-INFO></INQUIRY-UPDATE></TRADING></MA>


<?xml version='1.0'?><!DOCTYPE MA SYSTEM 'ma.dtd'><MA><HEADER><MESSAGE-ID>1272</MESSAGE-ID><MESSAGE-TYPE>REQUEST</MESSAGE-TYPE><MESSAGE-VERSION>3.1.0</MESSAGE-VERSION></HEADER><TRADING PROTOCOL="PRICE"><INQUIRY-UPDATE STATE="TIMED-OUT" DIRECTION="FORWARD" SPOT-PROCESS="STANDARD"><INQUIRY-ID>609351</INQUIRY-ID><UPDATE-TIME>07/29/2009 10:08:09</UPDATE-TIME><ALLOW-PARTIAL-FILL>Y</ALLOW-PARTIAL-FILL><CUSTOMER><SHORT-NAME>rbsclient1</SHORT-NAME><LONG-NAME>MarketAxess QA UK Staging</LONG-NAME><TRADER-FULL-NAME>rbsclient1 rbsclient1</TRADER-FULL-NAME><MA-ACCOUNT-ID>88306826</MA-ACCOUNT-ID><FIRM-NAME>MAQAUKS</FIRM-NAME></CUSTOMER><ASAP-FLAG>Y</ASAP-FLAG><CREATE-TIME>07/29/2009 10:07:09</CREATE-TIME><NUMBER-OF-DEALERS>1</NUMBER-OF-DEALERS><NUMBER-OF-LEGS>1</NUMBER-OF-LEGS><INQUIRY-LEG SIDE="BUY" INSTRUMENT-TYPE="CORPORATE" LEG-TYPE="CORPORATE"><LEG-ID>1</LEG-ID><INQUIRY-SIZE>7777</INQUIRY-SIZE><SETTLEMENT-DATE>08/03/2009</SETTLEMENT-DATE><LEVEL-TYPE>PRICE</LEVEL-TYPE><SECURITY><CUSIP9>105756BB5</CUSIP9><CUSIP>105756BB</CUSIP><ISIN>US105756BB58</ISIN><WKN>A0ACBP</WKN><ISSUE-DATE>01/20/2004</ISSUE-DATE><DATED-DATE>01/20/2004</DATED-DATE><ISSUER>BRAZIL</ISSUER><TICKER>BRAZIL</TICKER><COUPON>8.25</COUPON><MATURITY>01/20/2034</MATURITY><CURRENCY>USD</CURRENCY><DESCRIPTION>Bond</DESCRIPTION></SECURITY></INQUIRY-LEG><LOG-INFO>TIMED-OUT</LOG-INFO></INQUIRY-UPDATE></TRADING></MA>

# From the python script it looks as if PRICETICK is missing

def convert_InquiryResponseMessage(sourceMessage, destQueue):
	if str(sourceMessage["PRICETICK"]) == "TRUE"

# Exception in the market axess gateway 

2009-07-29 11:07:21.512 ERROR [AQGatewayServer-Handler[/11.176.198.126:1334]:FromAQ:ConsumerThread] unknown: Component [Converter]: Handling exception:: (PyException:null: null: Stack Trace: Traceback (innermost last):
  File "d:\uat\rbsfm\cp\ma_latam\config\out-marketaxess-matrading-latam-messagemap.py", line 282, in ?
  File "d:\uat\rbsfm\cp\ma_latam\config\out-marketaxess-matrading-latam-messagemap.py", line 263, in convert
  File "d:\uat\rbsfm\cp\ma_latam\config\out-marketaxess-matrading-latam-messagemap.py", line 102, in convert_InquiryResponseMessage
KeyError: PRICETICK

	at org.python.core.Py.KeyError(Py.java)
	at org.python.core.PyObject.__getitem__(PyObject.java)
	at org.python.pycode._pyx1.convert_InquiryResponseMessage$7(d:\uat\rbsfm\cp\ma_latam\config\out-marketaxess-matrading-latam-messagemap.py:102)
	at org.python.pycode._pyx1.call_function(d:\uat\rbsfm\cp\ma_latam\config\out-marketaxess-matrading-latam-messagemap.py)
	at org.python.core.PyTableCode.call(PyTableCode.java)
	at org.python.core.PyTableCode.call(PyTableCode.java)
	at org.python.core.PyFunction.__call__(PyFunction.java)
	at org.python.pycode._pyx1.convert$28(d:\uat\rbsfm\cp\ma_latam\config\out-marketaxess-matrading-latam-messagemap.py:263)
	at org.python.pycode._pyx1.call_function(d:\uat\rbsfm\cp\ma_latam\config\out-marketaxess-matrading-latam-messagemap.py)
	at org.python.core.PyTableCode.call(PyTableCode.java)
	at org.python.core.PyTableCode.call(PyTableCode.java)
	at org.python.core.PyFunction.__call__(PyFunction.java)
	at org.python.pycode._pyx1.f$0(d:\uat\rbsfm\cp\ma_latam\config\out-marketaxess-matrading-latam-messagemap.py:282)
	at org.python.pycode._pyx1.call_function(d:\uat\rbsfm\cp\ma_latam\config\out-marketaxess-matrading-latam-messagemap.py)
	at org.python.core.PyTableCode.call(PyTableCode.java)
	at org.python.core.PyCode.call(PyCode.java)
	at org.python.core.Py.runCode(Py.java)
	at org.python.core.Py.exec(Py.java)
	at org.python.util.PythonInterpreter.exec(PythonInterpreter.java)
	at com.rbsfm.fi.pricing.ecn.gateway.converter.ConverterScript.exec(ConverterScript.java:81)
	at com.rbsfm.fi.pricing.ecn.gateway.converter.ConverterScript.execOutgoing(ConverterScript.java:58)
	at com.rbsfm.fi.pricing.ecn.gateway.converter.Converter.convert(Converter.java:227)
	at com.rbsfm.fi.pricing.ecn.gateway.converter.Converter.convertOutgoing(Converter.java:143)
	at com.rbsfm.fi.marketaxess.converter.MaTradingMessageOutputManager.onMessage(MaTradingMessageOutputManager.java:48)
	at com.rbsfm.fi.pricing.ecn.gateway.message.AqMessageListener$1.dispatch(AqMessageListener.java:22)
	at com.rbsfm.common.util.ListenerList.notifyListeners(ListenerList.java:128)
	at com.rbsfm.common.util.ListenerList.notifyListeners(ListenerList.java:112)
	at com.rbsfm.fi.pricing.ecn.gateway.connection.AbstractAqMessageHandler.notifyListeners(AbstractAqMessageHandler.java:216)
	at com.rbsfm.fi.pricing.ecn.gateway.connection.AqMessageHandlerImpl.processMessageFromAutoquoter(AqMessageHandlerImpl.java:82)
	at com.rbsfm.fi.pricing.ecn.gateway.connection.AbstractAqMessageHandler$2.consume(AbstractAqMessageHandler.java:275)
	at com.rbsfm.common.thread.ProducerConsumer.runConsumerLoop(ProducerConsumer.java:292)
	at com.rbsfm.common.thread.ProducerConsumer.access$100(ProducerConsumer.java:24)
	at com.rbsfm.common.thread.ProducerConsumer$1.run(ProducerConsumer.java:214)
	at java.lang.Thread.run(Thread.java:619)

2009-07-29 11:07:21.512 ERROR [AQGatewayServer-Handler[/11.176.198.126:1334]:FromAQ:ConsumerThread] unknown: Listener MAOutgoingHandler[MaTradingMessageOutputManager] threw an Exception processing event: InquiryResponseMessage[ buySell='B', MA_SpotProcess='STANDARD', benchmarkYield='3.7315', MA_LongName='MarketAxess QA UK Staging', JAVA_CLASS='com.rbsfm.fi.pricing.ecn.autoquote.external.message.InquiryResponseMessage', MA_DateTime='2009-07-29 10:07:09.000', MA_State='SUBMITTED', MA_Protocol='PRICE', instrumentRef='US105756BB58', ticker='BRAZIL', MA_AllowPartialFill='Y', MA_TimeDue='2009-07-29 10:08:09.000', indicativeYieldSpread='273.5893331001895', benchmarkMaturity='2039-02-15', MA_CurrencyCode='USD', MA_Isin='US105756BB58', MA_Asap='Y', MA_DueInTime='60', MA_LevelType='PRICE', MA_Customer='MAQAUKS', MA_Account='88306826', MA_OrderQty='7777000.0', benchmarkPrice='95.89999999999999', qty='7777000.0', indicativePrice='121.75', MA_UserLogon='rbsclient1', priceDetailType='BOND', MA_OrderSeqNo='609351', tradeDate='2009-07-29', benchmark='US912810QA97', validTime='30', TradePhase='HoldingBinActive', counterpartyId='88306826', counterPartyFirmName='Barclays Global Investors Limited', indicativeYield='6.467390000000001', tradeType='OUTRIGHT', MA_LegType='CORPORATE', benchmarkTicker='T', MA_messageId='1269', currency='USD', convStartTime='2009-07-29 10:07:09.000', brokerRef='MA', settlementDate='2009-08-03', MA_Side='BUY', MA_NumberOfLegs='1', clientName='MAQAUKS', coupon='0.0825', brokerOrderSeqNo='609351', tradeProtocol='Price', MA_InstrumentType='CORPORATE', memoText2='MAQAUKS (rbsclient1) requests bid on $7,777,000 BRAZIL 8.250 01/20/34, due in 1 mins (ASAP) Single-Dealer', rbosTrader='gallane', maturityDate='2034-01-20', brkConvId='609351', MA_MA-MESSAGE-TYPE='INQUIRY_UPDATE', messageType='PriceRequestFill', MA_Competition='0', MA_UpdateTime='2009-07-29 10:07:09.000', noOfDealers='0', MA_TradeDate='2009-07-29', MA_Ticker='BRAZIL', MA_Direction='FORWARD', counterpartyTrader='rbsclient1', MESSAGETYPE='InquiryMessage', account='88306826', benchmarkCoupon='3.5000000000000004',]: null: Stack Trace: java.lang.NullPointerException
	at com.rbsfm.fi.marketaxess.converter.MaTradingMessageOutputManager.onMessage(MaTradingMessageOutputManager.java:49)
	at com.rbsfm.fi.pricing.ecn.gateway.message.AqMessageListener$1.dispatch(AqMessageListener.java:22)
	at com.rbsfm.common.util.ListenerList.notifyListeners(ListenerList.java:128)
	at com.rbsfm.common.util.ListenerList.notifyListeners(ListenerList.java:112)
	at com.rbsfm.fi.pricing.ecn.gateway.connection.AbstractAqMessageHandler.notifyListeners(AbstractAqMessageHandler.java:216)
	at com.rbsfm.fi.pricing.ecn.gateway.connection.AqMessageHandlerImpl.processMessageFromAutoquoter(AqMessageHandlerImpl.java:82)
	at com.rbsfm.fi.pricing.ecn.gateway.connection.AbstractAqMessageHandler$2.consume(AbstractAqMessageHandler.java:275)
	at com.rbsfm.common.thread.ProducerConsumer.runConsumerLoop(ProducerConsumer.java:292)
	at com.rbsfm.common.thread.ProducerConsumer.access$100(ProducerConsumer.java:24)
	at com.rbsfm.common.thread.ProducerConsumer$1.run(ProducerConsumer.java:214)
	at java.lang.Thread.run(Thread.java:619)

2009-07-29 11:07:21.512 ERROR [AQGatewayServer-Handler[/11.176.198.126:1334]:FromAQ:ConsumerThread] unknown: Got exception passing message to AQ: null: Stack Trace: java.lang.NullPointerException
	at com.rbsfm.fi.marketaxess.converter.MaTradingMessageOutputManager.onMessage(MaTradingMessageOutputManager.java:49)
	at com.rbsfm.fi.pricing.ecn.gateway.message.AqMessageListener$1.dispatch(AqMessageListener.java:22)
	at com.rbsfm.common.util.ListenerList.notifyListeners(ListenerList.java:128)
	at com.rbsfm.common.util.ListenerList.notifyListeners(ListenerList.java:112)
	at com.rbsfm.fi.pricing.ecn.gateway.connection.AbstractAqMessageHandler.notifyListeners(AbstractAqMessageHandler.java:216)
	at com.rbsfm.fi.pricing.ecn.gateway.connection.AqMessageHandlerImpl.processMessageFromAutoquoter(AqMessageHandlerImpl.java:82)
	at com.rbsfm.fi.pricing.ecn.gateway.connection.AbstractAqMessageHandler$2.consume(AbstractAqMessageHandler.java:275)
	at com.rbsfm.common.thread.ProducerConsumer.runConsumerLoop(ProducerConsumer.java:292)
	at com.rbsfm.common.thread.ProducerConsumer.access$100(ProducerConsumer.java:24)
	at com.rbsfm.common.thread.ProducerConsumer$1.run(ProducerConsumer.java:214)
	at java.lang.Thread.run(Thread.java:619)

# Logs from send

2009-07-29 06:07:21.394 INFO [ThreadPoolWorker: Thread-28] gallane: Component [FromRouter]: .... Messageid=AQ_ACTION_REQUEST,type=TRADER_RESPONSE,destination=latam-autoquoter-offshore,sourcename=sourceName,sourcetype=CLINT
	Attributes(size=131)
	name=conversationId,value=MA-090729-609351,status=0
	name=actionType,value=TRADER_RESPONSE,status=0
	name=traderResponseType,value=Send,status=0
	name=traderResponseReason,value=,status=0
	name=NEW.Leg1.traderInsideYield,value=6.467393331001893,status=0
	name=NEW.numberOfLegs,value=1,status=0
	name=NEW.Leg1.benchmarkCoupon,value=0.035,status=0
	name=NEW.reason,value=Order or inquiry falls outside all buckets
Book status is PEND
Bank OFF for broker MA
,status=0
	name=NEW.rejectAllowed,value=true,status=0
	name=NEW.Leg1.priceDetailType,value=BOND,status=0
	name=NEW.conversationId,value=MA-090729-609351,status=0
	name=NEW.Leg1.rfqPriceValid,value=true,status=0
	name=NEW.Leg1.maturityDate,value=2034-01-20,status=0
	name=NEW.Leg1.benchmarkYield,value=3.7315,status=0
	name=NEW.Leg1.benchmarkPrice,value=95.89999999999999,status=0
	name=NEW.Leg1.traderRef,value=gallane,status=0
	name=NEW.Leg1.nssdRepoRate,value=0.0,status=0
	name=NEW.convTimeLimit,value=60,status=0
	name=NEW.dealCategory,value=ESC,status=0
	name=NEW.deskId,value=latam,status=0
	name=NEW.rejectionReason,value=,status=0
	name=NEW.priorityCustomer,value=false,status=0
	name=NEW.Leg1.indicativeYield,value=6.467390000000001,status=0
	name=NEW.Leg1.nssdAdjustedYield,value=6.467390000000001,status=0
	name=NEW.Leg1.productGroup,value=,status=0
	name=NEW.Leg1.principal,value=9.4684975E8,status=0
	name=NEW.Leg1.appliedSpread,value=0.0,status=0
	name=NEW.traderRef,value=gallane,status=0
	name=NEW.Leg1.midYield,value=6.4568335374916,status=0
	name=NEW.Leg1.appliedBucket,value=> B1,status=0
	name=NEW.Leg1.pricingOwner,value=gallane,status=0
	name=NEW.Leg1.bookId,value=BR-LATAM,status=0
	name=NEW.counterPartyFirmName,value=Barclays Global Investors Limited,status=0
	name=NEW.Leg1.indicativePrice,value=121.75,status=0
	name=NEW.convNextTimeCheck,value=2009-07-29 06:08:09.362,status=0
	name=NEW.Leg1.isOutsideAllBuckets,value=true,status=0
	name=NEW.manualAllowed,value=true,status=0
	name=NEW.Leg1.rfqInvalidReason,value=,status=0
	name=NEW.Leg1.traderInsidePrice,value=121.75,status=0
	name=NEW._serverName_,value=latam-autoquoter-offshore,status=0
	name=NEW.counterpartyInternal,value=false,status=0
	name=NEW.brokerRef,value=MA,status=0
	name=NEW.clientName,value=MAQAUKS,status=0
	name=NEW.salespersonLocation,value=Europe,status=0
	name=NEW.memoText2,value=MAQAUKS (rbsclient1) requests bid on $7,777,000 BRAZIL 8.250 01/20/34, due in 1 mins (ASAP) Single-Dealer,status=0
	name=NEW.Leg1.calculatorAdjustment,value=0.0,status=0
	name=NEW.Leg1.qty,value=7777000.0,status=0
	name=NEW.convTimeRemaining,value=59,status=0
	name=NEW.counterpartyTrader,value=rbsclient1,status=0
	name=NEW.Leg1.appliedSkew,value=0.0,status=0
	name=NEW.Leg1.ecnPriceType,value=,status=0
	name=NEW.Leg1.benchmark,value=US912810QA97,status=0
	name=NEW.account,value=88306826,status=0
	name=NEW.Leg1.accrued,value=23168.97916666667,status=0
	name=NEW.Leg1.tPlusDays,value=3,status=0
	name=NEW.Leg1.midSpread,value=272.7,status=0
	name=NEW.Leg1.benchmarkMaturity,value=2039-02-15,status=0
	name=NEW.interventionReason,value=Order or inquiry falls outside all buckets
Book status is PEND
Bank OFF for broker MA
,status=0
	name=NEW.Leg1.stdtPlusDays,value=3,status=0
	name=NEW.Leg1.suggestedCalculatorAdjustment,value=0.8893331001895035,status=0
	name=NEW.type,value=3,status=0
	name=NEW.Leg1.ticker,value=BRAZIL,status=0
	name=NEW.Leg1.appliedTier,value=AQT2,status=0
	name=NEW.Leg1.suggestedYield,value=6.467390000000001,status=0
	name=NEW.Leg1.benchmarkDescription,value=T 3.5 Feb-39,status=0
	name=NEW.Leg1.netAmount,value=9.468729189791666E8,status=0
	name=NEW.counterParty,value=88306826,status=0
	name=NEW.resendCount,value=0,status=0
	name=NEW.Leg1.ISIN,value=US105756BB58,status=0
	name=NEW.counterpartyError,value=No Tier Found for market[MA] ID[88306826] and Book[BR-LATAM],status=0
	name=NEW.Leg1.traderPosition,value=0.0,status=0
	name=NEW.quoteId,value=1609,status=0
	name=NEW.Leg1.ecnPrice,value=0.0,status=0
	name=NEW.Leg1.suggestedPrice,value=121.75,status=0
	name=NEW.Leg1.brokerOrderSeqNo,value=609351,status=0
	name=NEW.orderSeqNo,value=MA-090729-609351,status=0
	name=NEW.Leg1.brokerOrderSeqCode,value=,status=0
	name=NEW.Leg1.currentCalc,value=bestPrice,status=0
	name=NEW.Leg1.traderInsideSpread,value=2734900.0,status=0
	name=NEW.Leg1.bondRef,value=BRAZIL 8.25 Jan-34,status=0
	name=NEW.Leg1.instrumentRef,value=US105756BB58,status=0
	name=NEW.salespersonCode,value=EE31,status=0
	name=NEW.noOfCompetitors,value=0,status=0
	name=NEW.quoteType,value=V,status=0
	name=NEW.wireTime,value=30,status=0
	name=NEW.nucleusId,value=2216977,status=0
	name=NEW.Leg1.benchmarkTicker,value=T,status=0
	name=NEW.Leg1.coupon,value=0.0825,status=0
	name=NEW.quoteTime,value=29/07/2009 06:07:10,status=0
	name=NEW.Leg1.bestMid,value=0.0,status=0
	name=NEW.counterAllowed,value=true,status=0
	name=NEW.salespersonRef,value=hotsont,status=0
	name=NEW.secondaryTraderRef,value=singhah,status=0
	name=NEW.Leg1.appliedBucketNumber,value=1,status=0
	name=NEW.Leg1.marketLegOrder,value=,status=0
	name=NEW.Leg1.dailyLimit,value=500000.0,status=0
	name=NEW.Leg1.originalPrice,value=0.0,status=0
	name=NEW.salesToTrader,value=false,status=0
	name=NEW.counterpartyFacingEntity,value=,status=0
	name=NEW.Leg1.currency,value=USD,status=0
	name=NEW.Leg1.crossServerSwitch,value=false,status=0
	name=NEW.INCLUDE_SUGGESTED,value=true,status=0
	name=NEW.Leg1.settlementDate,value=2009-08-03,status=0
	name=NEW.orderMode,value=2,status=0
	name=NEW.Leg1.nssdAdjustedPrice,value=121.75,status=0
	name=NEW.Leg1.buySell,value=B,status=0
	name=NEW.counterpartyGTEAccountCode,value=JJ98490,status=0
	name=NEW.Leg1.originalYield,value=0.0,status=0
	name=NEW.Leg1.indicativeYieldSpread,value=273.5893331001901,status=0
	name=NEW.Leg1.traderRiskBook,value=UNKNOWN,status=0
	name=NEW.orderOrInq,value=I,status=0
	name=NEW.brkConvId,value=609351,status=0
	name=NEW.counterpartyEnabled,value=true,status=0
	name=NEW.Leg1.midPrice,value=121.9,status=0
	name=NEW.Leg1.originalYieldSpread,value=0.0,status=0
	name=NEW.Leg1.suggestedYieldSpread,value=273.5893331001895,status=0
	name=NEW.counterpartyFound,value=true,status=0
	name=NEW.aqAqdminCPRef,value=193,status=0
	name=NEW.failedBankOnoffCheck,value=true,status=0
	name=NEW.SourceType,value=AQ,status=0
	name=NEW.SourceName,value=latam-autoquoter-offshore,status=0
	name=NEW.isMine,value=True,status=0
	name=NEW.isQuote,value=False,status=0
	name=NEW.___PRIMARY_KEY___,value=latam-autoquoter-offshore.QU.1609,status=0
	name=NEW.description,value=7.777,BRAZIL 8.25 Jan-34@121.750,status=0
	name=NEW.isExpiration,value=False,status=0
	name=NEW.isTraderIntervention,value=True,status=0
	name=NEW.indicativeTime,value=48,status=0
	name=NEW.quoteValidTime,value=0,status=0
	name=NEW.activeTrade,value=True,status=0
	name=SECURITY_TOKEN,value=sso://NUaBs/o0ePKTq52kS+mIjUc8KJLtoOa1PxHSOGWXmlLH8h8U7Dr+jknDu9HR4eBGsthySbmBcSJe/2PRfIM5grESgp5/XnzkvSuK+wfhUwv7Av157+h6cXUAG827PYdHWBxbYNmM5W6iuVAyiHfjHRXQkg01wO9cl8A9ojgEC2M=|0|gallane|FIPricing-EuroSupra-All-Read|20091106085152|8640000|,status=0
2009-07-29 06:07:21.394 INFO [ThreadPoolWorker: Thread-28] gallane: Control[RequestProcessor]: Router request Messageid=AQ_ACTION_REQUEST,type=TRADER_RESPONSE,destination=latam-autoquoter-offshore,sourcename=sourceName,sourcetype=CLINT
	Attributes(size=131)
	name=conversationId,value=MA-090729-609351,status=0
	name=actionType,value=TRADER_RESPONSE,status=0
	name=traderResponseType,value=Send,status=0
	name=traderResponseReason,value=,status=0
	name=NEW.Leg1.traderInsideYield,value=6.467393331001893,status=0
	name=NEW.numberOfLegs,value=1,status=0
	name=NEW.Leg1.benchmarkCoupon,value=0.035,status=0
	name=NEW.reason,value=Order or inquiry falls outside all buckets
Book status is PEND
Bank OFF for broker MA
,status=0
	name=NEW.rejectAllowed,value=true,status=0
	name=NEW.Leg1.priceDetailType,value=BOND,status=0
	name=NEW.conversationId,value=MA-090729-609351,status=0
	name=NEW.Leg1.rfqPriceValid,value=true,status=0
	name=NEW.Leg1.maturityDate,value=2034-01-20,status=0
	name=NEW.Leg1.benchmarkYield,value=3.7315,status=0
	name=NEW.Leg1.benchmarkPrice,value=95.89999999999999,status=0
	name=NEW.Leg1.traderRef,value=gallane,status=0
	name=NEW.Leg1.nssdRepoRate,value=0.0,status=0
	name=NEW.convTimeLimit,value=60,status=0
	name=NEW.dealCategory,value=ESC,status=0
	name=NEW.deskId,value=latam,status=0
	name=NEW.rejectionReason,value=,status=0
	name=NEW.priorityCustomer,value=false,status=0
	name=NEW.Leg1.indicativeYield,value=6.467390000000001,status=0
	name=NEW.Leg1.nssdAdjustedYield,value=6.467390000000001,status=0
	name=NEW.Leg1.productGroup,value=,status=0
	name=NEW.Leg1.principal,value=9.4684975E8,status=0
	name=NEW.Leg1.appliedSpread,value=0.0,status=0
	name=NEW.traderRef,value=gallane,status=0
	name=NEW.Leg1.midYield,value=6.4568335374916,status=0
	name=NEW.Leg1.appliedBucket,value=> B1,status=0
	name=NEW.Leg1.pricingOwner,value=gallane,status=0
	name=NEW.Leg1.bookId,value=BR-LATAM,status=0
	name=NEW.counterPartyFirmName,value=Barclays Global Investors Limited,status=0
	name=NEW.Leg1.indicativePrice,value=121.75,status=0
	name=NEW.convNextTimeCheck,value=2009-07-29 06:08:09.362,status=0
	name=NEW.Leg1.isOutsideAllBuckets,value=true,status=0
	name=NEW.manualAllowed,value=true,status=0
	name=NEW.Leg1.rfqInvalidReason,value=,status=0
	name=NEW.Leg1.traderInsidePrice,value=121.75,status=0
	name=NEW._serverName_,value=latam-autoquoter-offshore,status=0
	name=NEW.counterpartyInternal,value=false,status=0
	name=NEW.brokerRef,value=MA,status=0
	name=NEW.clientName,value=MAQAUKS,status=0
	name=NEW.salespersonLocation,value=Europe,status=0
	name=NEW.memoText2,value=MAQAUKS (rbsclient1) requests bid on $7,777,000 BRAZIL 8.250 01/20/34, due in 1 mins (ASAP) Single-Dealer,status=0
	name=NEW.Leg1.calculatorAdjustment,value=0.0,status=0
	name=NEW.Leg1.qty,value=7777000.0,status=0
	name=NEW.convTimeRemaining,value=59,status=0
	name=NEW.counterpartyTrader,value=rbsclient1,status=0
	name=NEW.Leg1.appliedSkew,value=0.0,status=0
	name=NEW.Leg1.ecnPriceType,value=,status=0
	name=NEW.Leg1.benchmark,value=US912810QA97,status=0
	name=NEW.account,value=88306826,status=0
	name=NEW.Leg1.accrued,value=23168.97916666667,status=0
	name=NEW.Leg1.tPlusDays,value=3,status=0
	name=NEW.Leg1.midSpread,value=272.7,status=0
	name=NEW.Leg1.benchmarkMaturity,value=2039-02-15,status=0
	name=NEW.interventionReason,value=Order or inquiry falls outside all buckets
Book status is PEND
Bank OFF for broker MA
,status=0
	name=NEW.Leg1.stdtPlusDays,value=3,status=0
	name=NEW.Leg1.suggestedCalculatorAdjustment,value=0.8893331001895035,status=0
	name=NEW.type,value=3,status=0
	name=NEW.Leg1.ticker,value=BRAZIL,status=0
	name=NEW.Leg1.appliedTier,value=AQT2,status=0
	name=NEW.Leg1.suggestedYield,value=6.467390000000001,status=0
	name=NEW.Leg1.benchmarkDescription,value=T 3.5 Feb-39,status=0
	name=NEW.Leg1.netAmount,value=9.468729189791666E8,status=0
	name=NEW.counterParty,value=88306826,status=0
	name=NEW.resendCount,value=0,status=0
	name=NEW.Leg1.ISIN,value=US105756BB58,status=0
	name=NEW.counterpartyError,value=No Tier Found for market[MA] ID[88306826] and Book[BR-LATAM],status=0
	name=NEW.Leg1.traderPosition,value=0.0,status=0
	name=NEW.quoteId,value=1609,status=0
	name=NEW.Leg1.ecnPrice,value=0.0,status=0
	name=NEW.Leg1.suggestedPrice,value=121.75,status=0
	name=NEW.Leg1.brokerOrderSeqNo,value=609351,status=0
	name=NEW.orderSeqNo,value=MA-090729-609351,status=0
	name=NEW.Leg1.brokerOrderSeqCode,value=,status=0
	name=NEW.Leg1.currentCalc,value=bestPrice,status=0
	name=NEW.Leg1.traderInsideSpread,value=2734900.0,status=0
	name=NEW.Leg1.bondRef,value=BRAZIL 8.25 Jan-34,status=0
	name=NEW.Leg1.instrumentRef,value=US105756BB58,status=0
	name=NEW.salespersonCode,value=EE31,status=0
	name=NEW.noOfCompetitors,value=0,status=0
	name=NEW.quoteType,value=V,status=0
	name=NEW.wireTime,value=30,status=0
	name=NEW.nucleusId,value=2216977,status=0
	name=NEW.Leg1.benchmarkTicker,value=T,status=0
	name=NEW.Leg1.coupon,value=0.0825,status=0
	name=NEW.quoteTime,value=29/07/2009 06:07:10,status=0
	name=NEW.Leg1.bestMid,value=0.0,status=0
	name=NEW.counterAllowed,value=true,status=0
	name=NEW.salespersonRef,value=hotsont,status=0
	name=NEW.secondaryTraderRef,value=singhah,status=0
	name=NEW.Leg1.appliedBucketNumber,value=1,status=0
	name=NEW.Leg1.marketLegOrder,value=,status=0
	name=NEW.Leg1.dailyLimit,value=500000.0,status=0
	name=NEW.Leg1.originalPrice,value=0.0,status=0
	name=NEW.salesToTrader,value=false,status=0
	name=NEW.counterpartyFacingEntity,value=,status=0
	name=NEW.Leg1.currency,value=USD,status=0
	name=NEW.Leg1.crossServerSwitch,value=false,status=0
	name=NEW.INCLUDE_SUGGESTED,value=true,status=0
	name=NEW.Leg1.settlementDate,value=2009-08-03,status=0
	name=NEW.orderMode,value=2,status=0
	name=NEW.Leg1.nssdAdjustedPrice,value=121.75,status=0
	name=NEW.Leg1.buySell,value=B,status=0
	name=NEW.counterpartyGTEAccountCode,value=JJ98490,status=0
	name=NEW.Leg1.originalYield,value=0.0,status=0
	name=NEW.Leg1.indicativeYieldSpread,value=273.5893331001901,status=0
	name=NEW.Leg1.traderRiskBook,value=UNKNOWN,status=0
	name=NEW.orderOrInq,value=I,status=0
	name=NEW.brkConvId,value=609351,status=0
	name=NEW.counterpartyEnabled,value=true,status=0
	name=NEW.Leg1.midPrice,value=121.9,status=0
	name=NEW.Leg1.originalYieldSpread,value=0.0,status=0
	name=NEW.Leg1.suggestedYieldSpread,value=273.5893331001895,status=0
	name=NEW.counterpartyFound,value=true,status=0
	name=NEW.aqAqdminCPRef,value=193,status=0
	name=NEW.failedBankOnoffCheck,value=true,status=0
	name=NEW.SourceType,value=AQ,status=0
	name=NEW.SourceName,value=latam-autoquoter-offshore,status=0
	name=NEW.isMine,value=True,status=0
	name=NEW.isQuote,value=False,status=0
	name=NEW.___PRIMARY_KEY___,value=latam-autoquoter-offshore.QU.1609,status=0
	name=NEW.description,value=7.777,BRAZIL 8.25 Jan-34@121.750,status=0
	name=NEW.isExpiration,value=False,status=0
	name=NEW.isTraderIntervention,value=True,status=0
	name=NEW.indicativeTime,value=48,status=0
	name=NEW.quoteValidTime,value=0,status=0
	name=NEW.activeTrade,value=True,status=0
	name=SECURITY_TOKEN,value=sso://NUaBs/o0ePKTq52kS+mIjUc8KJLtoOa1PxHSOGWXmlLH8h8U7Dr+jknDu9HR4eBGsthySbmBcSJe/2PRfIM5grESgp5/XnzkvSuK+wfhUwv7Av157+h6cXUAG827PYdHWBxbYNmM5W6iuVAyiHfjHRXQkg01wO9cl8A9ojgEC2M=|0|gallane|FIPricing-EuroSupra-All-Read|20091106085152|8640000|,status=0
2009-07-29 06:07:21.394 INFO [MA-090729-609351] cpratesdev: Received trader response Send from AQ client
2009-07-29 06:07:21.394 INFO [MA-090729-609351] cpratesdev: Component [TraderResponseAction]: executing action TraderResponseAction step AQ_SET_BOND_TRADER_PRICE_STEP
2009-07-29 06:07:21.394 INFO [MA-090729-609351] cpratesdev: Component [TraderResponseAction]: conversation manual[false] reject[false] rejectionReason[] overrideAction[null]
2009-07-29 06:07:21.394 INFO [MA-090729-609351] cpratesdev: Component [TraderResponseAction]: Handling Trader Response type[SEND]
2009-07-29 06:07:21.394 INFO [MA-090729-609351] cpratesdev: Component [AqConversationPersister]: Wrote conversation in : 0


# Tier for counterparty
select * into #tmp from EcnCounterpartyTier where CounterpartyRef = '193' and BookId = 'default' and DeskId = 'credit'
update #tmp set DeskId = 'latam'
insert EcnCounterpartyTier select * from #tmp

# Error in logs
2009-07-28 06:03:19.018 INFO [MABrokerConnection.Receiver:ConsumerThread] unknown: Control[ConversationDispatcher]: CONV#[MA-090728-608636]: processing message: InquiryMessage[ buySell='B', MA_SpotProcess='STANDARD', MA_LongName='MarketAxess QA UK Staging', JAVA_CLASS='com.rbsfm.fi.pricing.ecn.autoquote.external.message.InquiryMessage', MA_DateTime='2009-07-28 10:03:18.000', MA_State='SUBMITTED', MA_Protocol='PRICE', instrumentRef='USP09669BT10', ticker='BNCGAL', MA_AllowPartialFill='Y', MA_TimeDue='2009-07-28 10:06:18.000', MA_Isin='USP09669BT10', MA_CurrencyCode='USD', MA_Asap='Y', MA_DueInTime='180', MA_LevelType='PRICE', MA_Customer='MAQAUKS', MA_Account='88306826', MA_OrderQty='1000000.0', qty='1000000.0', MA_UserLogon='rbsclient1', MA_OrderSeqNo='608636', tradeDate='2009-07-28', TradePhase='HoldingBinActive', counterpartyId='88306826', counterPartyFirmName='MarketAxess QA UK Staging', tradeType='OUTRIGHT', MA_LegType='CORPORATE', MA_messageId='1251', currency='USD', convStartTime='2009-07-28 10:03:18.000', brokerRef='MA', settlementDate='2009-07-31', MA_Side='BUY', MA_NumberOfLegs='1', clientName='MAQAUKS', coupon='4.6175', brokerOrderSeqNo='608636', tradeProtocol='Price', MA_InstrumentType='CORPORATE', memoText2='MAQAUKS (rbsclient1) requests bid on $1,000,000 BNCGAL 01/01/10 c09 (RegS,FRN), due in 3 mins (ASAP) Single-Dealer', maturityDate='2010-01-01', MA_MA-MESSAGE-TYPE='INQUIRY_UPDATE', brkConvId='608636', messageType='PriceRequestFill', MA_UpdateTime='2009-07-28 10:03:18.000', MA_Competition='0', noOfDealers='0', MA_TradeDate='2009-07-28', MA_Ticker='BNCGAL', MA_Direction='FORWARD', counterpartyTrader='rbsclient1', MESSAGETYPE='InquiryMessage', account='88306826',]
2009-07-28 06:03:19.018 INFO [MA-090728-608636] cpratesdev: Component [SupraCategoriseDeal]: Conversation MA-090728-608636 categorised as Type=[ESC{3}], Factory=SingleBondFactory[BondConversationFactory]]
2009-07-28 06:03:19.018 INFO [MA-090728-608636] cpratesdev: price yield converter init analytics for USP09669BT10


2009-07-28 06:03:19.502 WARNING [MA-090728-608636] cpratesdev: Component [SingleBondFactory]: Tier not found for counterparty 88306826 defaulting to AQT3
2009-07-28 06:03:19.736 INFO [MA-090728-608636] cpratesdev: Component [CounterpartyServices2]: found counterparty[SimpleAttributeMap[com.rbsfm.fi.pricing.ecn.autoquote.util.CounterpartyDetails: internalId='Barclays Global Investors Limited',  bookOverride.Enabled='False',  PriorityCustomer='false',  aqStatus='ON',  Enabled='true',  Description='Barclays Global Investors Limited',  salesperson2='UNKNOWN',  BloombergDFACode='BGIBLOCK',  deskOrProductGroup='latam',  BloombergId='BARCLAYS GLOBAL INVESTORS',  TradewebId='Barclays Glob. Inv.',  salespersonCode='EE31',  salesperson='hotsont',  GdsId='2216977',  OrderMode='2',  isCounterpartyFound='true',  CounterpartyId='193',  CreditRating='Collateralised',  iSwapId='17449951',  GTEAccountCode='JJ98490',  MarketAxessId='88306826', ]]


88306826 -> Barclays


