# These are appearing for LATAM but not CEEMEA

16:12:27.027 MSG (346 bytes) : src=latam-autoquoter-offshore/AQ id=US105756BJ84 type=Bond atts={AQ_bkSizeMult=1.0,AQ_bkSpread=0.0,AQ_bkStat=OFF,AQ_bookIds=SOV-LATAM:SOV-LATAM,CORP-LATAM:CORP-LATAM,CAC-LATAM:CAC-LATAM,CEEMEA-HUF:CEEMEA-HUF,CEEMEA-PLN:CEEMEA-PLN,CEEMEA-RUB:CEEMEA-RUB,CEEMEA-TRY:CEEMEA-TRY,CEEMEA-ZAR:CEEMEA-ZAR,CEEMEA-ILS:CEEMEA-ILS,CEEMEA-CZK:CEEMEA-CZK,AQ_brk=AQ,AQ_exbk=SOV-LATAM,AQ_hedgeStat=,AQ_inbk=SOV-LATAM,AQ_primaryTraderId=NONE,AQ_secondaryTraderId=loughna,AQ_subscribedTraderIds=NONE} 
16:12:27.027 MSG (348 bytes) : src=latam-autoquoter-offshore/AQ id=USP3058XAJ48 type=Bond atts={AQ_bkSizeMult=1.0,AQ_bkSpread=0.0,AQ_bkStat=OFF,AQ_bookIds=SOV-LATAM:SOV-LATAM,CORP-LATAM:CORP-LATAM,CAC-LATAM:CAC-LATAM,CEEMEA-HUF:CEEMEA-HUF,CEEMEA-PLN:CEEMEA-PLN,CEEMEA-RUB:CEEMEA-RUB,CEEMEA-TRY:CEEMEA-TRY,CEEMEA-ZAR:CEEMEA-ZAR,CEEMEA-ILS:CEEMEA-ILS,CEEMEA-CZK:CEEMEA-CZK,AQ_brk=AQ,AQ_exbk=CORP-LATAM,AQ_hedgeStat=,AQ_inbk=CORP-LATAM,AQ_primaryTraderId=loughna,AQ_secondaryTraderId=NONE,AQ_subscribedTraderIds=NONE} 

# Configuration for the autoquoter

1) <property name="gateway.ma.enabled" value="false" />
2) <updateCacheSize>100</updateCacheSize>
4) <control enabled="false">TrendManager</control>   Missing from CEEMEA
5) Below is in CEEMEA only
  <component lazy="true" name="TrendManager" class_name="com.rbsfm.fi.bet.autoquoter.business.trend.TrendManager">
    <serverName>ceemea-autoquoter-offshore</serverName>
    <muxOut>AQMuxPublisher</muxOut>
    <bookDefinitionRuleHome>BookDefinitionRuleHome</bookDefinitionRuleHome>
    <brokerRef>TB</brokerRef>
    <tradeBookingManager>AqTradeBookingManager</tradeBookingManager>
    <debug>true</debug>
  </component>

6) <gdsCounterpartyEnabled>true</gdsCounterpartyEnabled>
 
