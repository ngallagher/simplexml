package simple.xml.temp;

import java.util.ArrayList;

class ContactList extends ArrayList<Contact>  {

}
