package org.simpleframework.xml.load;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;
import org.simpleframework.xml.ValidationTestCase;
import org.simpleframework.xml.util.Dictionary;
import org.simpleframework.xml.util.Entry;


public class ContainerTest extends ValidationTestCase {

   private static final String DEFAULT =
   "<?xml version=\"1.0\"?>\n"+
   "<container name='default'>\n"+
   "   <imports>  \n\r"+
   "      <import name='other'/>\r\n"+
   "      <import name='blah'/>\r\n"+   
   "   </imports>  \n\r"+
   "   <entities>  \n\r"+
   "      <entity name='other' type='org.simpleframework.xml.load.ContainerTest$ExampleType'/>\r\n"+
   "      <entity name='blah' type='org.simpleframework.xml.load.ContainerTest$ExampleType'/>\r\n"+   
   "   </entities>  \n\r"+
   "</container>";
   
   private static final String OTHER =
   "<?xml version=\"1.0\"?>\n"+
   "<container name='blah'>\n"+
   "   <entities>  \n\r"+
   "      <entity name='other' type='org.simpleframework.xml.load.ContainerTest$ExampleType'/>\r\n"+
   "      <entity name='blah' type='org.simpleframework.xml.load.ContainerTest$ExampleType'/>\r\n"+   
   "   </entities>  \n\r"+
   "</container>";  
   
   private static final String BLAH =
   "<?xml version=\"1.0\"?>\n"+
   "<container name='blah'>\n"+
   "   <entities>  \n\r"+
   "      <entity name='other' type='org.simpleframework.xml.load.ContainerTest$ExampleType'/>\r\n"+
   "      <entity name='blah' type='org.simpleframework.xml.load.ContainerTest$ExampleType'/>\r\n"+   
   "   </entities>  \n\r"+
   "</container>";   
 

   @Root
   private static class Container extends Entry {
     
      @ElementList(required=false)
      public Dictionary<Entity> entities;
      
      @ElementList(required=false) 
      public ImportList<Import> imports;     

      
      public Entity getEntity(String name) throws Exception {
         return entities.get(name);
      }
      
      public Entity getEntity(String name, String from) throws Exception {
         return imports.getContainer(from).getEntity(name);
      }
      
      public Container getContainer(String name) throws Exception {
         return imports.getContainer(name);
      }  
   }
   
   @Root
   private static class Entity extends Entry {
      
      @Element(required=false)
      private Construct construct;
      
      @Attribute
      private String type;
      
      public Object getInstance(Container source) throws Exception {
         return getType().newInstance();
      }
      
      public Class getType() throws Exception {
         return Class.forName(type);
      }
      
      public String getName() {
         return name;
      }
   }
   
   @Root
   private static class Construct extends Entry {
      
      @ElementList
      private Dictionary<Reference> list;     
      
      public Object getInstance(Container source, Class type) throws Exception {         
         return null;
      }            
   }
   
   @Root
   private static class Reference extends Entry {
      
      public Entity getEntity(Container source) throws Exception {
         return source.getEntity(name);
      }
      
   }
   
   private static class ExampleType {      
   }
   
   @Root
   private static class Import extends Entry {     

      public Container getContainer() throws Exception {
         return new Persister().read(Container.class, BLAH);
      }
   }
   
   
   private static class ImportList<T extends Import> extends Dictionary<T> {   
      
      public Container getContainer(String name) throws Exception {
         return get(name).getContainer();
      }
   }
   
   public void testContainer() throws Exception {
      Persister persister = new Persister();
      Container container = persister.read(Container.class, DEFAULT);
      
      assertEquals(container.getEntity("other").getName(), "other");
      assertEquals(container.getEntity("blah").getName(), "blah");
   }
}
